import { SCHEMES } from './src/data/schemes.js';
import { PERSONAS } from './src/data/personas.js';
import { evaluateSchemeEligibility, rankAndFilterSchemes } from './src/utils/eligibilityEngine.js';

console.log("=== SCHEMESAATHI AUTOMATED INTEGRATION & LOGIC TEST ===");

// 1. Verify Scheme database counts & categories
console.log(`\n[Test 1] Verifying Scheme Database: Total Schemes = ${SCHEMES.length}`);
const categories = new Set(SCHEMES.map(s => s.category));
console.log(`  Categories covered: ${Array.from(categories).join(', ')}`);
if (SCHEMES.length >= 10) {
  console.log("  ✅ Test 1 Passed: Rich scheme database (>10 schemes).");
} else {
  throw new Error("Scheme database has fewer than 10 schemes.");
}

// 2. Verify Housing Flagship schemes
console.log("\n[Test 2] Verifying Housing Flagship schemes (PMAY-G & PMAY-U)");
const pmayG = SCHEMES.find(s => s.id === 'pmay-g');
const pmayU = SCHEMES.find(s => s.id === 'pmay-u');
if (pmayG && pmayG.isHousingScheme && pmayU && pmayU.isHousingScheme) {
  console.log("  ✅ Test 2 Passed: PMAY-G (Rural) and PMAY-U (Urban 2.0) present with flagship housing flags.");
} else {
  throw new Error("Housing flagship schemes missing or invalid.");
}

// 3. Test Persona 1: Ramesh Kumar (Marginal Farmer, Rural UP, Kutcha house)
console.log("\n[Test 3] Testing Persona: Ramesh Kumar (Farmer, UP, Rural)");
const ramesh = PERSONAS.find(p => p.id === 'ramesh-farmer');
const rameshResults = rankAndFilterSchemes(SCHEMES, ramesh.profile);

const rameshPmayG = rameshResults.find(s => s.id === 'pmay-g');
const rameshPmKisan = rameshResults.find(s => s.id === 'pm-kisan');
const rameshPmayU = rameshResults.find(s => s.id === 'pmay-u');

console.log(`  PMAY-G Status: ${rameshPmayG.evaluation.status} (${rameshPmayG.evaluation.shortReason})`);
console.log(`  PM-KISAN Status: ${rameshPmKisan.evaluation.status} (${rameshPmKisan.evaluation.shortReason})`);
console.log(`  PMAY-U Status: ${rameshPmayU.evaluation.status} (${rameshPmayU.evaluation.shortReason})`);

if (rameshPmayG.evaluation.status === 'eligible' && rameshPmKisan.evaluation.status === 'eligible' && rameshPmayU.evaluation.status === 'ineligible') {
  console.log("  ✅ Test 3 Passed: Ramesh correctly qualifies for PMAY-G & PM-KISAN, correctly disqualified from PMAY-U.");
} else {
  throw new Error("Ramesh persona eligibility evaluation failed.");
}

// 4. Test Persona 2: Sunita Shinde (Urban Informal Worker, Rented chawl, Girl child < 10)
console.log("\n[Test 4] Testing Persona: Sunita Shinde (Urban Worker, Pune)");
const sunita = PERSONAS.find(p => p.id === 'sunita-domestic');
const sunitaResults = rankAndFilterSchemes(SCHEMES, sunita.profile);

const sunitaPmayU = sunitaResults.find(s => s.id === 'pmay-u');
const sunitaSukanya = sunitaResults.find(s => s.id === 'sukanya-samriddhi');
const sunitaPmayG = sunitaResults.find(s => s.id === 'pmay-g');

console.log(`  PMAY-U Status: ${sunitaPmayU.evaluation.status} (${sunitaPmayU.evaluation.shortReason})`);
console.log(`  Sukanya Samriddhi Status: ${sunitaSukanya.evaluation.status}`);
console.log(`  PMAY-G Status: ${sunitaPmayG.evaluation.status}`);

if (sunitaPmayU.evaluation.status === 'eligible' && sunitaSukanya.evaluation.status === 'eligible' && sunitaPmayG.evaluation.status === 'ineligible') {
  console.log("  ✅ Test 4 Passed: Sunita correctly qualifies for PMAY-U & Sukanya Samriddhi, disqualified from rural PMAY-G.");
} else {
  throw new Error("Sunita persona eligibility evaluation failed.");
}

// 5. Test Persona 3: Arjun Gond (ST College Student)
console.log("\n[Test 5] Testing Persona: Arjun Gond (Student, Tribal/ST)");
const arjun = PERSONAS.find(p => p.id === 'arjun-student');
const arjunResults = rankAndFilterSchemes(SCHEMES, arjun.profile);
const arjunScholarship = arjunResults.find(s => s.id === 'post-matric-scholarship');

console.log(`  Post-Matric Scholarship Status: ${arjunScholarship.evaluation.status}`);
if (arjunScholarship.evaluation.status === 'eligible') {
  console.log("  ✅ Test 5 Passed: Arjun correctly qualifies for Post-Matric Scholarship.");
} else {
  throw new Error("Arjun scholarship test failed.");
}

// 6. Test Document Deduplication & Aggregation
console.log("\n[Test 6] Testing Document Passport Deduplication");
const docMap = new Map();
rameshResults.filter(s => s.evaluation.status === 'eligible').forEach(scheme => {
  scheme.requiredDocuments.forEach(doc => {
    const key = doc.name.trim().toLowerCase();
    if (!docMap.has(key)) {
      docMap.set(key, { name: doc.name, issuingAuthority: doc.issuingAuthority, count: 1 });
    } else {
      docMap.get(key).count++;
    }
  });
});
console.log(`  Unique documents aggregated for Ramesh: ${docMap.size}`);
for (const [key, val] of docMap.entries()) {
  console.log(`    - ${val.name} (Issuing: ${val.issuingAuthority}, used by ${val.count} schemes)`);
}
if (docMap.size > 0 && docMap.has("aadhaar card")) {
  console.log("  ✅ Test 6 Passed: Document passport correctly deduplicates and identifies issuing authorities.");
} else {
  throw new Error("Document aggregation failed.");
}

console.log("\n🎉 ALL 6 LOGICAL & INTEGRATION TESTS PASSED WITH 100% INTEGRITY!\n");
