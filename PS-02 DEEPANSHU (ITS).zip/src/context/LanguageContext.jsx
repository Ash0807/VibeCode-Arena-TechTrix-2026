import React, { createContext, useContext, useState, useEffect } from 'react';

const LanguageContext = createContext();

export const TRANSLATIONS = {
  hi: {
    // Utility & Nav
    skipToMain: "▼ मुख्य कंटेंट पर जाएं",
    screenReader: "स्क्रीन रीडर",
    sitemap: "साइट मैप",
    portalSubtitle: "नागरिक कल्याण एवं आवास सहायता सेवा पोर्टल",
    home: "मुख्य पृष्ठ",
    eligibility: "पात्रता जांचें",
    housing: "आवास (PMAY)",
    passport: "दस्तावेज़ पासपोर्ट",
    services: "योजना निर्देशिका",
    support: "सहायता व हेल्पलाइन",
    shortlisted: "सहेजी गई",

    // Ticker
    latestUpdates: "नवीन सूचनाएं",
    tickerContent: "📢 PMAY-U 2.0: ब्याज सब्सिडी पंजीकरण शुरू • PM-KISAN: 19वीं किस्त ई-केवाईसी जारी • आयुष्मान भारत: 70+ वरिष्ठ नागरिकों हेतु नि:शुल्क ₹5 लाख कवर • PMAY-G: आवास+ सर्वेक्षण सत्यापन जारी।",

    // Hero & Wheel
    majorServices: "प्रमुख सेवाएं",
    housingWheel: "आवास",
    farmerWheel: "किसान",
    kutumbWheel: "पेंशन",
    healthWheel: "स्वास्थ्य",
    educationWheel: "शिक्षा",
    livelihoodWheel: "रोजगार",
    missionTitle: "नागरिक कल्याण एवं आवास सहायता मिशन",
    missionQuote: '"प्रत्येक पात्र ग्रामीण एवं शहरी परिवार को पारदर्शी नियम-आधारित जांच के माध्यम से सरकारी कल्याणकारी योजनाओं व पक्के आवास की गारंटी।"',
    missionGov: "भारत सरकार एवं राज्य अभिसरण पोर्टल",
    heroTitle1: "SchemeSaathi पोर्टल",
    heroTitle2: "एकीकृत कल्याण एवं आवास सहायता",
    heroSubtitle: "अपने परिवार के स्थान, आय और आवास की स्थिति के अनुसार सरकारी कल्याणकारी योजनाओं की खोज करें। शत-प्रतिशत पारदर्शी नियम-आधारित पात्रता और एकीकृत दस्तावेज़ पासपोर्ट।",
    checkEligibilityBtn: "पात्रता की जांच करें",
    docPassportBtn: "दस्तावेज़ पासपोर्ट",

    // Rainbow ribbon
    ribbonHousing: "🏠 आवास योजना (PMAY)",
    ribbonFarmer: "🌾 किसान सहायता (PM-KISAN)",
    ribbonPassport: "📄 दस्तावेज़ पासपोर्ट",
    ribbonHealth: "🩺 आयुष्मान भारत (Health)",
    ribbonAudit: "📋 पात्रता ऑडिट इंजन",
    ribbonShortlist: "⭐ सहेजी गई योजनाएं",

    // Metrics
    statCitizens: "पंजीकृत नागरिक",
    statSchemes: "कल्याणकारी योजनाएं",
    statDisbursed: "वितरित डीबीटी सहायता",
    statTransparency: "पारदर्शी नियम-आधारित जांच",

    // Persona Bar
    personaHeading: "त्वरित नागरिक डेमो प्रोफाइल / One-Click Test Citizen Archetypes",
    personaSubheading: "किसी भी नागरिक को चुनें और बिना फॉर्म भरे तुरंत पात्रता मिलान देखें:",

    // Eligibility Page
    finderHeading: "पारदर्शी योजना पात्रता निर्धारण इंजन",
    finderSubtitle: "अपने परिवार के बुनियादी विवरण दर्ज करें या एक-क्लिक से नमूना प्रोफाइल चुनें। व्यवस्था प्रत्येक योजना के लिए पारदर्शी नियम-आधारित जांच प्रदान करती है।",
    formHeading: "नागरिक विवरण फॉर्म",
    formClear: "साफ़ करें",
    formPrivacy: "🔒 आधार नंबर या बैंक विवरण की आवश्यकता नहीं है। गणना आपके ब्राउज़र में सुरक्षित रूप से होती है।",
    secLocation: "1. राज्य एवं क्षेत्र / Location & Sector",
    labelState: "राज्य चुनें (State)",
    labelArea: "क्षेत्र का प्रकार (Area Type)",
    optRural: "🌾 ग्रामीण (Rural)",
    optUrban: "🏙️ शहरी (Urban)",
    secOccupation: "2. व्यवसाय एवं आजीविका / Occupation",
    labelOccupation: "मुख्य व्यवसाय (Primary Occupation)",
    secIncomeAge: "3. पारिवारिक आय एवं आयु / Income & Age",
    labelIncome: "वार्षिक पारिवारिक आय (Approx. Family Income)",
    labelAge: "आवेदक की आयु (Age Group)",
    secHousing: "4. आवास एवं सामाजिक श्रेणी / Housing & Social",
    labelHousing: "वर्तमान आवास की स्थिति (Housing Type)",
    labelPuccaQuery: "क्या देश में कहीं भी कोई पक्का मकान है?",
    optNo: "नहीं (No)",
    optYes: "हाँ (Yes)",
    labelSocial: "सामाजिक श्रेणी (Social Category)",
    labelExtraCriteria: "अतिरिक्त पारिवारिक मापदंड:",
    chkGirlChild: "10 वर्ष से कम आयु की बेटी (सुकन्या समृद्धि योजना)",
    chkSenior: "परिवार में 60+ वरिष्ठ नागरिक (वृद्धावस्था पेंशन / आयुष्मान)",
    chkPregnant: "गर्भवती या धात्री माता (मातृ वंदना योजना ₹5,000)",

    // Results Bar
    resultsHeading: "पात्रता मिलान परिणाम",
    filterAll: "सभी",
    filterEligible: "संभावित पात्र",
    filterNeedsInfo: "अधिक जानकारी आवश्यक",
    filterIneligible: "शर्त पूरी नहीं हुई",
    filterHousing: "आवास सहायता (PMAY)",
    deptLabel: "विभाग:",
    deptAll: "सभी विभाग",
    searchPlaceholder: "योजना, मंत्रालय या कीवर्ड खोजें...",

    // Scheme Card
    statusEligible: "संभावित पात्र (Potentially Eligible)",
    statusNeedsInfo: "अधिक जानकारी आवश्यक (More Info Needed)",
    statusIneligible: "शर्त पूरी नहीं हुई (Criteria Not Met)",
    whyResult: "पात्रता का कारण: ",
    btnViewDetails: "विस्तार से देखें व दस्तावेज़",
    btnAudit: "ऑडिट ट्रेल",
    btnShortlist: "सहेजें",
    btnSaved: "सहेजा गया",
    btnOfficialLink: "आधिकारिक पोर्टल ↗",

    // Document Passport
    passportPageTitle: "नागरिक दस्तावेज़ पासपोर्ट (Consolidated Document Passport)",
    passportPageSubtitle: "विभिन्न सरकारी योजनाओं के लिए आवश्यक कागजात की एकल, गैर-दोहरावदार चेकलिस्ट। बार-बार सरकारी कार्यालयों के चक्कर लगाने से बचें।",
    passportReadiness: "दस्तावेज़ तैयारी स्तर",
    passportPreparedOf: "तैयार हैं",
    passportComplete: "पूर्ण",
    passportPrintBtn: "पासपोर्ट प्रिंट करें",
    passportCopyBtn: "टेक्स्ट कॉपी करें",
    passportCopied: "कॉपी हो गया!",
    whereToGet: "जारीकर्ता प्राधिकरण (Issuing Body): ",
    unlocksSchemes: "लागू योजनाएं (Unlocks): ",

    // Housing Page
    housingPageTitle: "राष्ट्रीय आवास सहायता मिशन (PMAY Gramin & Urban)",
    housingPageSubtitle: '"सबके लिए पक्का मकान" — ग्रामीण एवं शहरी बेघर व कच्चे मकानों में रहने वाले परिवारों के लिए सरकारी अनुदान एवं ऋण ब्याज सब्सिडी।',
    housingCalcHeading: "आवास सब्सिडी एवं अनुदान कैलकुलेटर (Interactive Subsidy Estimator)",
    calcIncomeLabel: "वार्षिक पारिवारिक आय",
    totalBenefitLabel: "कुल अनुमानित सहायता (Total Benefit)",

    // Helplines & Support
    supportPageTitle: "नागरिक सहायता केंद्र एवं अक्सर पूछे जाने वाले प्रश्न",
    helplinesHeading: "आधिकारिक राष्ट्रीय एवं राज्य टोल-फ्री हेल्पलाइन डेस्क",
    faqHeading: "अक्सर पूछे जाने वाले महत्वपूर्ण प्रश्न (FAQs)",

    // Disclaimer
    disclaimerText: "वैधानिक अस्वीकरण: SchemeSaathi एक नागरिक सहायता और हैकथॉन प्रोटोटाइप है जो प्राथमिक सिफारिशें प्रदान करता है। आधिकारिक पात्रता एवं लाभ स्वीकृति संबंधित प्रशासनिक विभागों के सत्यापन के अधीन है।"
  },
  en: {
    // Utility & Nav
    skipToMain: "▼ Skip to main content",
    screenReader: "Screen Reader",
    sitemap: "Sitemap",
    portalSubtitle: "Citizen Welfare & Housing Assistance Service Portal",
    home: "Home",
    eligibility: "Check Eligibility",
    housing: "Housing (PMAY)",
    passport: "Document Passport",
    services: "Scheme Directory",
    support: "Support & Helplines",
    shortlisted: "Shortlisted",

    // Ticker
    latestUpdates: "Latest Updates",
    tickerContent: "📢 PMAY-U 2.0: Interest subsidy registration live • PM-KISAN: 19th installment e-KYC active • Ayushman Bharat: Free ₹5 Lakh health cover opened for all senior citizens 70+ • PMAY-G: Awaas+ verification in progress.",

    // Hero & Wheel
    majorServices: "Major Services",
    housingWheel: "Housing",
    farmerWheel: "Farmers",
    kutumbWheel: "Pension",
    healthWheel: "Health",
    educationWheel: "Education",
    livelihoodWheel: "Livelihood",
    missionTitle: "Citizen Welfare & Housing Assistance Mission",
    missionQuote: '"Ensuring every eligible rural and urban household receives rightful government welfare benefits, pucca housing assistance, and social security with absolute transparency."',
    missionGov: "Government of India & State Convergence Portal",
    heroTitle1: "SchemeSaathi Portal",
    heroTitle2: "Unified Welfare & Housing Assistance",
    heroSubtitle: "Discover government welfare schemes tailored to your family's exact location, income, and housing conditions with transparent rule-based eligibility checks and instant Document Passports.",
    checkEligibilityBtn: "Check My Eligibility",
    docPassportBtn: "Document Passport",

    // Rainbow ribbon
    ribbonHousing: "🏠 Housing Scheme (PMAY)",
    ribbonFarmer: "🌾 Farmer Support (PM-KISAN)",
    ribbonPassport: "📄 Document Passport",
    ribbonHealth: "🩺 Ayushman Bharat (Health)",
    ribbonAudit: "📋 Eligibility Audit Engine",
    ribbonShortlist: "⭐ Shortlisted Schemes",

    // Metrics
    statCitizens: "Registered Citizens",
    statSchemes: "Welfare Schemes",
    statDisbursed: "DBT Assistance Disbursed",
    statTransparency: "Rule-Based Transparency",

    // Persona Bar
    personaHeading: "One-Click Test Citizen Archetypes",
    personaSubheading: "Select any citizen to test instant eligibility matching without typing:",

    // Eligibility Page
    finderHeading: "Transparent Scheme Eligibility Engine",
    finderSubtitle: "Enter basic personal and household details or select a sample persona. The system evaluates transparent rule-based criteria for every scheme.",
    formHeading: "Household Profile Form",
    formClear: "Clear Form",
    formPrivacy: "🔒 No Aadhaar numbers or bank details required. Evaluation occurs securely in your browser.",
    secLocation: "1. Location & Sector",
    labelState: "Select State / UT",
    labelArea: "Area Type",
    optRural: "🌾 Rural Setting",
    optUrban: "🏙️ Urban Setting",
    secOccupation: "2. Occupation & Livelihood",
    labelOccupation: "Primary Occupation",
    secIncomeAge: "3. Annual Family Income & Age",
    labelIncome: "Approximate Annual Family Income",
    labelAge: "Applicant Age Group",
    secHousing: "4. Housing Condition & Social Category",
    labelHousing: "Current Housing Condition",
    labelPuccaQuery: "Does any family member own a pucca house in India?",
    optNo: "No",
    optYes: "Yes",
    labelSocial: "Social Category",
    labelExtraCriteria: "Additional Household Conditions:",
    chkGirlChild: "Has daughter under 10 years (Sukanya Samriddhi)",
    chkSenior: "Has senior citizen aged 60+ (Old Age Pension / AB-PMJAY)",
    chkPregnant: "Pregnant or lactating mother (Matru Vandana Yojana ₹5,000)",

    // Results Bar
    resultsHeading: "Eligibility Matching Results",
    filterAll: "All",
    filterEligible: "Potentially Eligible",
    filterNeedsInfo: "More Info Needed",
    filterIneligible: "Criteria Not Met",
    filterHousing: "Housing Assistance (PMAY)",
    deptLabel: "Department:",
    deptAll: "All Departments",
    searchPlaceholder: "Search by scheme name, ministry, or keyword...",

    // Scheme Card
    statusEligible: "Potentially Eligible",
    statusNeedsInfo: "More Information Needed",
    statusIneligible: "Criteria Not Met",
    whyResult: "Why this result: ",
    btnViewDetails: "View Full Details & Docs",
    btnAudit: "Audit Trail",
    btnShortlist: "Shortlist",
    btnSaved: "Shortlisted",
    btnOfficialLink: "Official Portal ↗",

    // Document Passport
    passportPageTitle: "Citizen Document Passport (Consolidated Checklist)",
    passportPageSubtitle: "Single, deduplicated checklist of all documents required across your matching schemes. Prevents multiple visits to government offices.",
    passportReadiness: "Document Readiness Level",
    passportPreparedOf: "Documents Ready",
    passportComplete: "Complete",
    passportPrintBtn: "Print Passport",
    passportCopyBtn: "Copy Checklist Text",
    passportCopied: "Copied to Clipboard!",
    whereToGet: "Issuing Authority: ",
    unlocksSchemes: "Applicable Schemes: ",

    // Housing Page
    housingPageTitle: "National Housing Assistance Mission (PMAY Gramin & Urban)",
    housingPageSubtitle: '"Housing for All" — Direct financial assistance and credit-linked interest subsidies for rural and urban homeless and kutcha dwelling families.',
    housingCalcHeading: "Housing Subsidy & Grant Estimator (Interactive Calculator)",
    calcIncomeLabel: "Annual Family Income",
    totalBenefitLabel: "Total Estimated Benefit",

    // Helplines & Support
    supportPageTitle: "Citizen Support Center & Frequently Asked Questions",
    helplinesHeading: "Official National & State Toll-Free Helplines",
    faqHeading: "Frequently Asked Questions (FAQs)",

    // Disclaimer
    disclaimerText: "Statutory Advisory: SchemeSaathi provides preliminary rule-based recommendations. It does not guarantee official approval or benefit receipt. Always verify on official government portals."
  }
};

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState(() => {
    try {
      return localStorage.getItem('schemesathi_lang') || 'hi';
    } catch {
      return 'hi';
    }
  });

  const toggleLanguage = (newLang) => {
    setLanguage(newLang);
    try {
      localStorage.setItem('schemesathi_lang', newLang);
    } catch (e) {
      console.error(e);
    }
  };

  const t = (key) => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS['hi']?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    return {
      language: 'hi',
      setLanguage: () => {},
      t: (key) => key
    };
  }
  return context;
}
