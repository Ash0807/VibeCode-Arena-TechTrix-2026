import React from 'react';
import { 
  X, 
  ExternalLink, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Building, 
  FileCheck, 
  Bookmark,
  Share2
} from 'lucide-react';

export default function SchemeDetailModal({ 
  scheme, 
  isSaved, 
  onToggleSave, 
  onClose,
  onOpenPassport
}) {
  if (!scheme) return null;

  const { auditTrail, status, shortReason } = scheme.evaluation;

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="scheme-ministry">{scheme.ministry}</div>
            <h2 style={{ fontSize: '1.25rem', color: '#0B1B3D' }}>{scheme.name}</h2>
            <div style={{ color: '#EA580C', fontWeight: 600, fontSize: '0.9rem' }}>
              {scheme.nameHindi}
            </div>
          </div>
          <button 
            className="modal-close-btn" 
            onClick={onClose}
            aria-label="Close details modal"
          >
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          {/* Statutory Notice */}
          <div style={{ 
            background: 'var(--status-needs-bg)', 
            border: '1px solid var(--status-needs-border)', 
            borderRadius: 'var(--radius-sm)', 
            padding: '0.65rem 0.85rem', 
            fontSize: '0.8rem', 
            color: 'var(--status-needs-text)' 
          }}>
            <strong>Important:</strong> This assessment is an automated preliminary screening based on your inputs. Final eligibility is determined by the relevant government department upon document verification.
          </div>

          {/* Purpose & Target Beneficiaries */}
          <div>
            <h3 style={{ fontSize: '1rem', marginBottom: '0.4rem', color: '#0B1B3D' }}>
              🎯 Objective & Target Beneficiaries / उद्देश्य
            </h3>
            <p style={{ fontSize: '0.9rem', color: '#334155', lineHeight: 1.6, marginBottom: '0.5rem' }}>
              {scheme.purpose}
            </p>
            <div style={{ background: '#F8FAFC', padding: '0.65rem 0.85rem', borderRadius: 'var(--radius-sm)', fontSize: '0.82rem', borderLeft: '3px solid var(--gov-navy)' }}>
              <strong>Intended Beneficiaries: </strong>
              <span>{scheme.intendedBeneficiaries}</span>
            </div>
          </div>

          {/* Full Benefits Breakdown */}
          <div>
            <h3 style={{ fontSize: '1rem', marginBottom: '0.6rem', color: '#0B1B3D' }}>
              💰 Available Scheme Benefits / मिलने वाली सहायता
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '0.5rem' }}>
              {scheme.benefits.map((b, i) => (
                <div key={i} style={{ 
                  background: '#F8FAFC', 
                  border: '1px solid var(--border-subtle)', 
                  borderLeft: '3px solid var(--gov-blue-accent)',
                  borderRadius: 'var(--radius-sm)', 
                  padding: '0.65rem 0.85rem', 
                  fontSize: '0.84rem' 
                }}>
                  <strong style={{ color: 'var(--gov-navy-dark)' }}>{b.type}: </strong>
                  <span>{b.description}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Rule Evaluation Audit Trail */}
          <div>
            <h3 style={{ fontSize: '1rem', marginBottom: '0.6rem', color: '#0B1B3D' }}>
              🔍 Eligibility Rule Audit Trail / पात्रता का पारदर्शी विश्लेषण
            </h3>
            <table className="audit-table">
              <thead>
                <tr>
                  <th style={{ width: '35%' }}>Rule Parameter</th>
                  <th style={{ width: '25%' }}>Status</th>
                  <th>Evaluation Detail</th>
                </tr>
              </thead>
              <tbody>
                {auditTrail.map((item, idx) => (
                  <tr key={idx}>
                    <td><strong>{item.criterion}</strong></td>
                    <td>
                      {item.status === 'pass' && (
                        <span className="audit-status-icon pass">
                          <CheckCircle size={14} /> Criteria Met
                        </span>
                      )}
                      {item.status === 'fail' && (
                        <span className="audit-status-icon fail">
                          <XCircle size={14} /> Unmet
                        </span>
                      )}
                      {item.status === 'missing' && (
                        <span className="audit-status-icon missing">
                          <AlertCircle size={14} /> Needed
                        </span>
                      )}
                    </td>
                    <td style={{ color: '#475569' }}>{item.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Required Documents Checklist */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.6rem' }}>
              <h3 style={{ fontSize: '1rem', color: '#0B1B3D' }}>
                📄 Required Documents / आवश्यक दस्तावेज़
              </h3>
              <button 
                onClick={onOpenPassport}
                style={{ fontSize: '0.78rem', color: '#EA580C', fontWeight: 600, textDecoration: 'underline' }}
              >
                View in Document Passport →
              </button>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {scheme.requiredDocuments.map((doc, idx) => (
                <div key={idx} style={{ 
                  border: '1px solid var(--border-subtle)', 
                  borderRadius: 'var(--radius-sm)', 
                  padding: '0.65rem 0.85rem',
                  background: '#FFFFFF'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <strong style={{ fontSize: '0.88rem', color: '#0F172A' }}>{doc.name}</strong>
                    <span style={{ fontSize: '0.72rem', color: '#EA580C', background: '#FFF7ED', padding: '0.1rem 0.4rem', borderRadius: '4px', fontWeight: 600 }}>
                      {doc.issuingAuthority}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.78rem', color: '#64748B', marginTop: '0.25rem' }}>
                    {doc.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Application Steps & Verified Link */}
          <div style={{ 
            background: '#F8FAFC', 
            borderRadius: 'var(--radius-sm)', 
            padding: '0.85rem 1rem', 
            border: '1px solid var(--border-strong)' 
          }}>
            <h4 style={{ fontSize: '0.88rem', color: '#0F172A', marginBottom: '0.4rem' }}>
              🌐 How to Apply Officially / आधिकारिक आवेदन प्रक्रिया
            </h4>
            <p style={{ fontSize: '0.84rem', color: '#475569', marginBottom: '0.85rem', lineHeight: 1.5 }}>
              {scheme.applicationProcess}
            </p>
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              <a 
                href={scheme.officialLink}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
                style={{ textDecoration: 'none' }}
              >
                <span>Visit Official Portal ({scheme.officialLink.replace('https://', '')})</span>
                <ExternalLink size={15} />
              </a>

              <button 
                className={`btn-secondary ${isSaved ? 'saved' : ''}`}
                onClick={() => onToggleSave(scheme.id)}
              >
                <Bookmark size={15} fill={isSaved ? '#EA580C' : 'none'} />
                <span>{isSaved ? "Saved in Shortlist" : "Save Scheme"}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
