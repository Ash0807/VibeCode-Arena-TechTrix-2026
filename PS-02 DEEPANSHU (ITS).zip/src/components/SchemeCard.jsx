import React from 'react';
import { 
  Home, 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  Bookmark, 
  ExternalLink, 
  FileText, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function SchemeCard({ 
  scheme, 
  isSaved, 
  onToggleSave, 
  onViewDetails,
  onInspectAudit
}) {
  const { language, t } = useLanguage();
  const { status, shortReason } = scheme.evaluation;

  const renderStatusBadge = () => {
    if (status === "eligible") {
      return (
        <span className="status-pill eligible">
          <CheckCircle size={13} />
          <span>{t('statusEligible')}</span>
        </span>
      );
    }
    if (status === "needs_info") {
      return (
        <span className="status-pill needs_info">
          <AlertCircle size={13} />
          <span>{t('statusNeedsInfo')}</span>
        </span>
      );
    }
    return (
      <span className="status-pill ineligible">
        <XCircle size={13} />
        <span>{t('statusIneligible')}</span>
      </span>
    );
  };

  const primaryTitle = language === 'hi' ? scheme.nameHindi : scheme.name;
  const secondaryTitle = language === 'hi' ? scheme.name : scheme.nameHindi;

  return (
    <article 
      className={`scheme-card ${scheme.isHousingScheme ? 'is-housing' : ''}`}
      aria-labelledby={`scheme-title-${scheme.id}`}
    >
      {/* Top Header: Ministry & Status */}
      <div className="scheme-card-top">
        <div>
          <div className="scheme-ministry-label">
            {scheme.ministry} • {scheme.category}
          </div>
          {scheme.isHousingScheme && (
            <div className="housing-flagship-tag">
              <Home size={11} />
              <span>{language === 'hi' ? "पीएम आवास योजना (PMAY Housing)" : "PMAY Housing Flagship"}</span>
            </div>
          )}
          <h3 className="scheme-title" id={`scheme-title-${scheme.id}`}>
            {primaryTitle}
          </h3>
          <span className="scheme-title-hindi">{secondaryTitle}</span>
        </div>
        <div>
          {renderStatusBadge()}
        </div>
      </div>

      {/* Purpose / Scope */}
      <p className="scheme-purpose">
        {scheme.purpose}
      </p>

      {/* Direct Scannable Benefit Line */}
      {scheme.benefits && scheme.benefits.length > 0 && (
        <div className="scheme-benefit-line">
          <strong>{language === 'hi' ? "मुख्य सहायता: " : "Benefit: "}</strong>
          <span>{scheme.benefits[0].type} — {scheme.benefits[0].description}</span>
          {scheme.benefits[1] && (
            <span style={{ color: 'var(--text-faint)', marginLeft: '0.4rem' }}>
              ({scheme.benefits[1].description})
            </span>
          )}
        </div>
      )}

      {/* Why this result? — Quiet editorial note */}
      <div className={`scheme-decision-box ${status}`}>
        {status === "eligible" ? (
          <ShieldCheck size={15} style={{ flexShrink: 0, marginTop: 2, color: '#16A34A' }} />
        ) : status === "needs_info" ? (
          <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2, color: '#D97706' }} />
        ) : (
          <XCircle size={15} style={{ flexShrink: 0, marginTop: 2, color: '#64748B' }} />
        )}
        <div>
          <strong style={{ color: 'var(--text-main)', marginRight: '0.35rem' }}>
            {t('whyResult')}
          </strong>
          <span>{shortReason}</span>
        </div>
      </div>

      {/* Compact Card Actions */}
      <div className="scheme-card-actions">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          <button 
            className="btn-primary"
            onClick={() => onViewDetails(scheme)}
            aria-label={`View full details for ${scheme.name}`}
          >
            <span>{t('btnViewDetails')}</span>
            <ArrowRight size={13} />
          </button>

          <button 
            className="btn-secondary"
            onClick={() => onInspectAudit(scheme)}
            title="Inspect rule evaluation criteria"
          >
            <FileText size={13} />
            <span>{t('btnAudit')}</span>
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
          <button 
            className={`btn-bookmark ${isSaved ? 'saved' : ''}`}
            onClick={() => onToggleSave(scheme.id)}
            aria-label={isSaved ? "Remove from shortlisted" : "Save scheme"}
          >
            <Bookmark size={13} fill={isSaved ? 'currentColor' : 'none'} />
            <span>{isSaved ? t('btnSaved') : t('btnShortlist')}</span>
          </button>

          <a 
            href={scheme.officialLink}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
            style={{ padding: '0.45rem 0.55rem' }}
            title={`Visit official government portal (${scheme.officialLink})`}
            aria-label="Open official portal"
          >
            <ExternalLink size={13} />
          </a>
        </div>
      </div>
    </article>
  );
}
