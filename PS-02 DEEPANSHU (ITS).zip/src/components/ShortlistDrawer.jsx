import React from 'react';
import { X, Trash2, ArrowRight, ExternalLink, BookmarkCheck, FileCheck } from 'lucide-react';

export default function ShortlistDrawer({ 
  isOpen, 
  onClose, 
  savedSchemes, 
  onRemove, 
  onViewDetails,
  onOpenPassport
}) {
  if (!isOpen) return null;

  return (
    <div className="drawer-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="drawer-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <BookmarkCheck size={20} color="#EA580C" />
            <h3 style={{ fontSize: '1.15rem', color: '#0B1B3D' }}>
              Shortlisted Schemes ({savedSchemes.length})
            </h3>
          </div>
          <button className="modal-close-btn" onClick={onClose} aria-label="Close saved drawer">
            <X size={20} />
          </button>
        </div>

        <div style={{ padding: '1.25rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {savedSchemes.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem 1rem', color: '#64748B' }}>
              <p style={{ marginBottom: '1rem' }}>You have not shortlisted any schemes yet.</p>
              <p style={{ fontSize: '0.8rem' }}>Click "Shortlist / सहेजें" on any scheme card to save it here for quick reference.</p>
            </div>
          ) : (
            <>
              <button 
                className="btn-primary"
                style={{ width: '100%', justifyContent: 'center' }}
                onClick={() => {
                  onClose();
                  onOpenPassport();
                }}
              >
                <FileCheck size={16} />
                <span>Generate Document Passport for Saved</span>
              </button>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                {savedSchemes.map((scheme) => (
                  <div 
                    key={scheme.id}
                    style={{
                      border: '1px solid var(--border-subtle)',
                      borderRadius: 'var(--radius-sm)',
                      padding: '0.75rem 0.85rem',
                      background: '#FFFFFF',
                      boxShadow: 'var(--shadow-subtle)'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.35rem' }}>
                      <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#EA580C', background: '#FFF7ED', padding: '0.1rem 0.4rem', borderRadius: '4px' }}>
                        {scheme.category}
                      </span>
                      <button 
                        onClick={() => onRemove(scheme.id)}
                        style={{ color: '#94A3B8', padding: '0.2rem' }}
                        title="Remove from shortlisted"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>

                    <h4 style={{ fontSize: '0.95rem', color: '#0B1B3D', marginBottom: '0.2rem' }}>
                      {scheme.name}
                    </h4>
                    <p style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.65rem' }}>
                      {scheme.nameHindi}
                    </p>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <button 
                        onClick={() => {
                          onClose();
                          onViewDetails(scheme);
                        }}
                        style={{ fontSize: '0.8rem', color: '#0B1B3D', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                      >
                        <span>View Details</span>
                        <ArrowRight size={13} />
                      </button>

                      <a 
                        href={scheme.officialLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ fontSize: '0.78rem', color: '#2563EB', display: 'flex', alignItems: 'center', gap: '0.2rem', textDecoration: 'none' }}
                      >
                        <span>Apply</span>
                        <ExternalLink size={12} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
