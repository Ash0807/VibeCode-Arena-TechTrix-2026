import React from 'react';
import { 
  MapPin, 
  Home, 
  Briefcase, 
  IndianRupee, 
  RotateCcw,
  FileSpreadsheet
} from 'lucide-react';
import { STATES_OF_INDIA } from '../data/personas';
import { useLanguage } from '../context/LanguageContext';

export default function ProfileForm({ 
  profile, 
  onChange, 
  onReset 
}) {
  const { language, t } = useLanguage();

  const handleInputChange = (field, value) => {
    onChange({
      ...profile,
      [field]: value
    });
  };

  return (
    <div className="edistrict-box" id="profile-section">
      {/* Box Header */}
      <div className="edistrict-box-header">
        <h2>
          <FileSpreadsheet size={16} />
          <span>{t('formHeading')}</span>
        </h2>
        <button 
          onClick={onReset}
          style={{ 
            color: 'var(--text-faint)', 
            fontSize: '0.76rem', 
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            background: 'none',
            border: 'none',
            fontWeight: 600
          }}
          title="Reset to blank profile"
        >
          <RotateCcw size={12} />
          {t('formClear')}
        </button>
      </div>

      <div className="edistrict-box-body">
        <p style={{ fontSize: '0.76rem', color: 'var(--text-faint)', marginBottom: '1rem', lineHeight: 1.45 }}>
          {t('formPrivacy')}
        </p>

        {/* STEP 1: LOCATION & SETTING */}
        <div className="form-step-section">
          <div className="form-step-title">
            <MapPin size={13} />
            <span>{t('secLocation')}</span>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="state-select">
              <span>{t('labelState')}</span>
              <span className="form-hint">Domicile</span>
            </label>
            <select
              id="state-select"
              className="input-select"
              value={profile.state || "Uttar Pradesh"}
              onChange={(e) => handleInputChange("state", e.target.value)}
            >
              {STATES_OF_INDIA.map((st) => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">
              <span>{t('labelArea')}</span>
              <span className="form-hint">{language === 'hi' ? "PMAY पात्रता हेतु" : "Determines PMAY-G vs U"}</span>
            </label>
            <div className="segmented-cards">
              <button
                type="button"
                className={`segmented-card-btn ${profile.location === "rural" ? "active" : ""}`}
                onClick={() => handleInputChange("location", "rural")}
              >
                {t('optRural')}
              </button>
              <button
                type="button"
                className={`segmented-card-btn ${profile.location === "urban" ? "active" : ""}`}
                onClick={() => handleInputChange("location", "urban")}
              >
                {t('optUrban')}
              </button>
            </div>
          </div>
        </div>

        {/* STEP 2: OCCUPATION & LIVELIHOOD */}
        <div className="form-step-section">
          <div className="form-step-title">
            <Briefcase size={13} />
            <span>{t('secOccupation')}</span>
          </div>

          <div className="form-group" style={{ marginBottom: profile.occupation === "farmer" ? '0.75rem' : 0 }}>
            <label className="form-label" htmlFor="occupation-select">
              <span>{t('labelOccupation')}</span>
            </label>
            <select
              id="occupation-select"
              className="input-select"
              value={profile.occupation || "farmer"}
              onChange={(e) => handleInputChange("occupation", e.target.value)}
            >
              <option value="farmer">{language === 'hi' ? "किसान (Cultivator / Land Farmer)" : "Farmer / Land Cultivator"}</option>
              <option value="agricultural-laborer">{language === 'hi' ? "खेतिहर मजदूर (Agricultural Laborer)" : "Agricultural Laborer"}</option>
              <option value="daily-wage-worker">{language === 'hi' ? "दिहाड़ी कामगार (Daily Wage Worker)" : "Daily Wage Worker"}</option>
              <option value="street-vendor">{language === 'hi' ? "स्ट्रीट वेंडर / रेहड़ी पटरी (Street Vendor)" : "Street Vendor / Hawker"}</option>
              <option value="artisan">{language === 'hi' ? "पारंपरिक दस्तकार (Vishwakarma Artisan)" : "Traditional Artisan / Craftsman"}</option>
              <option value="student">{language === 'hi' ? "विद्यार्थी / छात्र (Student)" : "Student"}</option>
              <option value="informal-worker">{language === 'hi' ? "घरेलू / असंगठित कामगार (Informal Worker)" : "Domestic / Informal Worker"}</option>
              <option value="self-employed">{language === 'hi' ? "छोटा व्यापारी / दुकानदार (Self Employed)" : "Small Business / Self Employed"}</option>
              <option value="unemployed">{language === 'hi' ? "बेरोजगार / आश्रित (Unemployed / Senior)" : "Unemployed / Senior Citizen"}</option>
              <option value="other">{language === 'hi' ? "अन्य (Other)" : "Other"}</option>
            </select>
          </div>

          {/* Conditional for Farmer */}
          {profile.occupation === "farmer" && (
            <div style={{ background: '#F8FAFC', border: '1px solid var(--border-subtle)', borderRadius: '4px', padding: '0.65rem', marginTop: '0.5rem' }}>
              <div style={{ fontSize: '0.76rem', fontWeight: 700, color: 'var(--gov-saffron)', marginBottom: '0.35rem' }}>
                {language === 'hi' ? "कृषि भूमि स्वामित्व (PM-KISAN पात्रता हेतु):" : "Agricultural Landholding (PM-KISAN Requirement):"}
              </div>
              <div className="segmented-cards" style={{ marginBottom: '0.4rem' }}>
                <button
                  type="button"
                  className={`segmented-card-btn ${profile.hasCultivableLand === "yes" ? "active" : ""}`}
                  onClick={() => handleInputChange("hasCultivableLand", "yes")}
                >
                  {language === 'hi' ? "भूमि है (Landowner)" : "Owns Land"}
                </button>
                <button
                  type="button"
                  className={`segmented-card-btn ${profile.hasCultivableLand === "no" ? "active" : ""}`}
                  onClick={() => handleInputChange("hasCultivableLand", "no")}
                >
                  {language === 'hi' ? "भूमिहीन (Landless)" : "Landless"}
                </button>
              </div>
              {profile.hasCultivableLand === "yes" && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                  <span>{language === 'hi' ? "रकबा:" : "Area:"}</span>
                  <input 
                    type="number"
                    step="0.1"
                    min="0.1"
                    className="input-text"
                    style={{ width: '80px', padding: '0.3rem 0.5rem' }}
                    value={profile.landSizeAcres || 1.2}
                    onChange={(e) => handleInputChange("landSizeAcres", parseFloat(e.target.value) || 0)}
                  />
                  <span>{language === 'hi' ? "एकड़" : "Acres"}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* STEP 3: HOUSEHOLD INCOME & AGE */}
        <div className="form-step-section">
          <div className="form-step-title">
            <IndianRupee size={13} />
            <span>{t('secIncomeAge')}</span>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="income-select">
              <span>{t('labelIncome')}</span>
            </label>
            <select
              id="income-select"
              className="input-select"
              value={profile.incomeRange || "100001-200000"}
              onChange={(e) => {
                const val = e.target.value;
                let numeric = 140000;
                if (val === "0-100000") numeric = 60000;
                if (val === "100001-200000") numeric = 140000;
                if (val === "200001-300000") numeric = 250000;
                if (val === "300001-600000") numeric = 450000;
                if (val === "600001-800000") numeric = 700000;
                if (val === "800000+") numeric = 950000;
                onChange({
                  ...profile,
                  incomeRange: val,
                  incomeAmount: numeric
                });
              }}
            >
              <option value="0-100000">{language === 'hi' ? "₹1,00,000 से कम / वर्ष (BPL / अंत्योदय)" : "Below ₹1,00,000 / year (BPL)"}</option>
              <option value="100001-200000">{language === 'hi' ? "₹1,00,001 - ₹2,00,000 / वर्ष (कम आय वर्ग)" : "₹1,00,001 - ₹2,00,000 / year (Low Income)"}</option>
              <option value="200001-300000">{language === 'hi' ? "₹2,00,001 - ₹3,00,000 / वर्ष (EWS सीमा)" : "₹2,00,001 - ₹3,00,000 / year (EWS limit)"}</option>
              <option value="300001-600000">{language === 'hi' ? "₹3,00,001 - ₹6,00,000 / वर्ष (LIG वर्ग)" : "₹3,00,001 - ₹6,00,000 / year (LIG bracket)"}</option>
              <option value="600001-800000">{language === 'hi' ? "₹6,00,001 - ₹8,00,000 / वर्ष (MIG वर्ग)" : "₹6,00,001 - ₹8,00,000 / year (MIG bracket)"}</option>
              <option value="800000+">{language === 'hi' ? "₹8,00,000 से अधिक / वर्ष" : "Above ₹8,00,000 / year"}</option>
            </select>
          </div>

          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" htmlFor="age-select">
              <span>{t('labelAge')}</span>
            </label>
            <select
              id="age-select"
              className="input-select"
              value={profile.ageGroup || "36-50"}
              onChange={(e) => {
                const val = e.target.value;
                let numAge = 40;
                if (val === "18-25") numAge = 21;
                if (val === "26-35") numAge = 30;
                if (val === "36-50") numAge = 42;
                if (val === "51-59") numAge = 55;
                if (val === "60+") numAge = 65;
                onChange({
                  ...profile,
                  ageGroup: val,
                  age: numAge
                });
              }}
            >
              <option value="18-25">{language === 'hi' ? "18 - 25 वर्ष (युवा / छात्रवृत्ति)" : "18 - 25 years (Youth / Student)"}</option>
              <option value="26-35">{language === 'hi' ? "26 - 35 वर्ष (युवा परिवार)" : "26 - 35 years (Young Household)"}</option>
              <option value="36-50">{language === 'hi' ? "36 - 50 वर्ष (परिवार मुखिया)" : "36 - 50 years (Household Head)"}</option>
              <option value="51-59">{language === 'hi' ? "51 - 59 वर्ष (प्रौढ़ नागरिक)" : "51 - 59 years (Mature Adult)"}</option>
              <option value="60+">{language === 'hi' ? "60 वर्ष से अधिक (वरिष्ठ नागरिक / पेंशन)" : "60+ years (Senior Citizen / Pension)"}</option>
            </select>
          </div>
        </div>

        {/* STEP 4: HOUSING & SOCIAL SPECIFICS */}
        <div className="form-step-section">
          <div className="form-step-title">
            <Home size={13} />
            <span>{t('secHousing')}</span>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="housing-select">
              <span>{t('labelHousing')}</span>
              <span className="form-hint">{language === 'hi' ? "PMAY पात्रता" : "For PMAY"}</span>
            </label>
            <select
              id="housing-select"
              className="input-select"
              value={profile.housingType || "kutcha"}
              onChange={(e) => handleInputChange("housingType", e.target.value)}
            >
              <option value="kutcha">{language === 'hi' ? "कच्चा मकान / मिट्टी व घास-फूंस (Kutcha House)" : "Kutcha / Mud & Thatch House"}</option>
              <option value="rented">{language === 'hi' ? "किराए का कमरा (Rented Accommodation)" : "Living on Rent / Chawl"}</option>
              <option value="homeless">{language === 'hi' ? "आश्रयहीन / अस्थायी शेल्टर (Homeless)" : "Homeless / Temporary Shelter"}</option>
              <option value="pucca">{language === 'hi' ? "स्वयं का पक्का मकान है (Owns Pucca House)" : "Already Owns a Pucca House"}</option>
            </select>
          </div>

          {profile.housingType !== "pucca" && (
            <div className="form-group">
              <label className="form-label">
                <span>{t('labelPuccaQuery')}</span>
              </label>
              <div className="segmented-cards">
                <button
                  type="button"
                  className={`segmented-card-btn ${profile.ownsPuccaHouse === "no" ? "active" : ""}`}
                  onClick={() => handleInputChange("ownsPuccaHouse", "no")}
                >
                  {t('optNo')}
                </button>
                <button
                  type="button"
                  className={`segmented-card-btn ${profile.ownsPuccaHouse === "yes" ? "active" : ""}`}
                  onClick={() => handleInputChange("ownsPuccaHouse", "yes")}
                >
                  {t('optYes')}
                </button>
              </div>
            </div>
          )}

          <div className="form-group">
            <label className="form-label" htmlFor="social-category-select">
              <span>{t('labelSocial')}</span>
            </label>
            <select
              id="social-category-select"
              className="input-select"
              value={profile.socialCategory || "OBC"}
              onChange={(e) => handleInputChange("socialCategory", e.target.value)}
            >
              <option value="SC">{language === 'hi' ? "अनुसूचित जाति (SC)" : "Scheduled Caste (SC)"}</option>
              <option value="ST">{language === 'hi' ? "अनुसूचित जनजाति (ST)" : "Scheduled Tribe (ST)"}</option>
              <option value="OBC">{language === 'hi' ? "अन्य पिछड़ा वर्ग (OBC)" : "Other Backward Classes (OBC)"}</option>
              <option value="General-EWS">{language === 'hi' ? "सामान्य - ई.डब्ल्यू.एस (General EWS)" : "General - EWS"}</option>
              <option value="General">{language === 'hi' ? "सामान्य वर्ग (General)" : "General Category"}</option>
            </select>
          </div>

          {/* Quick Household Criteria Toggles */}
          <div style={{ background: '#F8FAFC', border: '1px solid var(--border-subtle)', borderRadius: '4px', padding: '0.65rem' }}>
            <div style={{ fontSize: '0.74rem', fontWeight: 700, color: 'var(--gov-navy)', marginBottom: '0.35rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              {t('labelExtraCriteria')}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.78rem' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', cursor: 'pointer' }}>
                <input 
                  type="checkbox"
                  checked={profile.hasGirlChildUnder10 === "yes"}
                  onChange={(e) => handleInputChange("hasGirlChildUnder10", e.target.checked ? "yes" : "no")}
                  style={{ width: 15, height: 15, accentColor: 'var(--gov-saffron)' }}
                />
                <span>{t('chkGirlChild')}</span>
              </label>

              <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', cursor: 'pointer' }}>
                <input 
                  type="checkbox"
                  checked={profile.hasSeniorCitizen === "yes" || profile.ageGroup === "60+"}
                  onChange={(e) => handleInputChange("hasSeniorCitizen", e.target.checked ? "yes" : "no")}
                  style={{ width: 15, height: 15, accentColor: 'var(--gov-saffron)' }}
                />
                <span>{t('chkSenior')}</span>
              </label>

              <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', cursor: 'pointer' }}>
                <input 
                  type="checkbox"
                  checked={profile.isPregnantOrLactating === "yes"}
                  onChange={(e) => handleInputChange("isPregnantOrLactating", e.target.checked ? "yes" : "no")}
                  style={{ width: 15, height: 15, accentColor: 'var(--gov-saffron)' }}
                />
                <span>{t('chkPregnant')}</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
