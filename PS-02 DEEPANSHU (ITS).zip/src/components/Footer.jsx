import React from 'react';
import { PhoneCall, Shield, ExternalLink } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function Footer({ onNavigate }) {
  const { language, t } = useLanguage();

  return (
    <footer className="site-footer-refined" id="helpline-section" aria-label="Portal Footer">
      <div className="footer-columns-grid">
        {/* Column 1: Portal Overview */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.65rem' }}>
            <div style={{ background: 'var(--gov-saffron)', color: '#FFF', padding: '0.3rem', borderRadius: '3px', display: 'flex' }}>
              <Shield size={16} />
            </div>
            <h3 style={{ color: '#FFFFFF', margin: 0, fontSize: '1.05rem', fontWeight: 800 }}>
              SchemeSaathi
            </h3>
          </div>
          <p style={{ lineHeight: 1.55, color: '#CBD5E1', marginBottom: '0.75rem', fontSize: '0.8rem' }}>
            {language === 'hi' 
              ? "नागरिक कल्याण एवं आवास सहायता सेवा पोर्टल। भारतीय नागरिकों को पारदर्शी नियम-आधारित पात्रता जांच, पीएम आवास योजना (ग्रामीण व शहरी) और एकीकृत दस्तावेज़ पासपोर्ट उपलब्ध कराने हेतु समर्पित मंच।"
              : "Citizen Welfare & Housing Assistance Service Portal. Providing Indian citizens with transparent rule-based eligibility checks, PMAY rural & urban housing discovery, and unified document readiness."}
          </p>
          <div style={{ fontSize: '0.72rem', color: '#94A3B8' }}>
            {language === 'hi' ? "डिजिटल इंडिया • पारदर्शी ई-गवर्नेंस • शून्य डेटा संग्रह" : "Digital India • Transparent E-Governance • Zero Data Retention"}
          </div>
        </div>

        {/* Column 2: National Helplines */}
        <div>
          <h4 className="footer-col-title">
            {language === 'hi' ? "राष्ट्रीय टोल-फ्री हेल्पलाइन" : "National Helplines (Toll-Free)"}
          </h4>
          <ul className="footer-links-list">
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <PhoneCall size={12} color="#FB923C" />
              <span><strong>PMAY ग्रामीण:</strong> 1800-11-6446</span>
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <PhoneCall size={12} color="#FB923C" />
              <span><strong>PM किसान:</strong> 155261 / 1800-115-526</span>
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <PhoneCall size={12} color="#FB923C" />
              <span><strong>आयुष्मान भारत:</strong> 14555</span>
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <PhoneCall size={12} color="#FB923C" />
              <span><strong>राष्ट्रीय उपभोक्ता हेल्पलाइन:</strong> 1915</span>
            </li>
          </ul>
        </div>

        {/* Column 3: Official Portals */}
        <div>
          <h4 className="footer-col-title">
            {language === 'hi' ? "आधिकारिक सरकारी पोर्टल" : "Official Gateways"}
          </h4>
          <ul className="footer-links-list">
            <li>
              <a href="https://pmayg.nic.in" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <span>PMAY Gramin</span>
                <ExternalLink size={11} />
              </a>
            </li>
            <li>
              <a href="https://pmay-urban.gov.in" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <span>PMAY Urban</span>
                <ExternalLink size={11} />
              </a>
            </li>
            <li>
              <a href="https://pmkisan.gov.in" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <span>PM-KISAN Portal</span>
                <ExternalLink size={11} />
              </a>
            </li>
            <li>
              <a href="https://pmjay.gov.in" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <span>National Health Authority</span>
                <ExternalLink size={11} />
              </a>
            </li>
            <li>
              <a href="https://india.gov.in" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <span>National Portal of India</span>
                <ExternalLink size={11} />
              </a>
            </li>
          </ul>
        </div>

        {/* Column 4: Portal Navigation */}
        <div>
          <h4 className="footer-col-title">
            {language === 'hi' ? "पोर्टल अनुभाग" : "Portal Navigation"}
          </h4>
          <ul className="footer-links-list">
            <li>
              <button onClick={() => onNavigate('home')}>• {t('home')}</button>
            </li>
            <li>
              <button onClick={() => onNavigate('eligibility')}>• {t('eligibility')}</button>
            </li>
            <li>
              <button onClick={() => onNavigate('housing')}>• {t('housing')}</button>
            </li>
            <li>
              <button onClick={() => onNavigate('passport')}>• {t('passport')}</button>
            </li>
            <li>
              <button onClick={() => onNavigate('services')}>• {t('services')}</button>
            </li>
            <li>
              <button onClick={() => onNavigate('support')}>• {t('support')}</button>
            </li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom-disclaimer">
        <p>
          <strong>{language === 'hi' ? "वैधानिक अस्वीकरण:" : "Statutory Disclaimer:"}</strong> {t('disclaimerText')}
        </p>
      </div>
    </footer>
  );
}
