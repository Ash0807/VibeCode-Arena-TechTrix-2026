import React from 'react';
import { Users } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function PersonaSelector({ 
  personas, 
  activePersonaId, 
  onSelectPersona 
}) {
  const { language, t } = useLanguage();

  return (
    <div className="gov-persona-strip" aria-label="त्वरित नमूना नागरिक प्रोफाइल">
      <div className="gov-persona-header">
        <h3>
          <Users size={18} color="#0B4F8A" />
          <span>{t('personaHeading')}</span>
        </h3>
        <span>{t('personaSubheading')}</span>
      </div>

      <div className="gov-persona-row" role="radiogroup" aria-label="Citizen Profiles">
        {personas.map((persona) => {
          const isSelected = activePersonaId === persona.id;
          return (
            <button
              key={persona.id}
              className={`gov-persona-pill-btn ${isSelected ? 'active' : ''}`}
              onClick={() => onSelectPersona(persona)}
              role="radio"
              aria-checked={isSelected}
            >
              <div>
                <div className="gov-persona-pill-top">
                  <span style={{ fontSize: '1.4rem', lineHeight: 1 }} aria-hidden="true">
                    {persona.avatar}
                  </span>
                  <div className="gov-persona-name">
                    {language === 'hi' ? persona.nameHindi : persona.name}
                    <small>{language === 'hi' ? persona.name : persona.nameHindi}</small>
                  </div>
                </div>
                <div className="gov-persona-meta">
                  <strong>{persona.locationDesc}</strong>
                  <div>{persona.summary}</div>
                </div>
              </div>
              <span className="gov-persona-badge-tag">{persona.badge}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
