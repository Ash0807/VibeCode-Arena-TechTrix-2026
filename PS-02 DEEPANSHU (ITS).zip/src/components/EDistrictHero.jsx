import React from 'react';
import { 
  Home, 
  Wheat, 
  HeartHandshake, 
  Stethoscope, 
  GraduationCap, 
  Briefcase, 
  FileText, 
  ArrowRight,
  CheckCircle,
  ExternalLink,
  Lock,
  Layers
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function EDistrictHero({ 
  onSelectCategory, 
  selectedCategory, 
  onOpenPassport,
  onOpenShortlist,
  onScrollToForm
}) {
  const { language, t } = useLanguage();

  const departments = [
    { id: 'Housing', label: 'Housing (PMAY)', labelHi: 'आवास (PMAY)', icon: Home, count: '2 Schemes' },
    { id: 'Agriculture', label: 'Agriculture & Farmers', labelHi: 'कृषि एवं किसान कल्याण', icon: Wheat, count: '2 Schemes' },
    { id: 'Healthcare', label: 'Health & Medical', labelHi: 'स्वास्थ्य एवं परिवार कल्याण', icon: Stethoscope, count: '2 Schemes' },
    { id: 'Social Welfare', label: 'Social Security & Pension', labelHi: 'सामाजिक सुरक्षा व पेंशन', icon: HeartHandshake, count: '3 Schemes' },
    { id: 'Education', label: 'Education & Scholarships', labelHi: 'शिक्षा व छात्रवृत्ति', icon: GraduationCap, count: '1 Scheme' },
    { id: 'Employment', label: 'Livelihood & Mudra', labelHi: 'रोजगार व सूक्ष्म ऋण', icon: Briefcase, count: '2 Schemes' }
  ];

  return (
    <section className="light-intro-hero" id="home" aria-label="Portal Introduction">
      <div className="light-intro-inner">
        {/* Left column: Clear Service Introduction */}
        <div>
          <div className="service-portal-tagline">
            SchemeSaathi <span style={{ color: 'var(--gov-saffron)' }}>|</span> योजना साथी
          </div>

          <h1 className="intro-main-title">
            {language === 'hi' 
              ? "अपने परिवार के अनुकूल सरकारी कल्याणकारी योजनाओं की खोज करें"
              : "Find government schemes that may match your household."}
          </h1>

          <p className="intro-description">
            {language === 'hi'
              ? "पारिवारिक आय, व्यवसाय और आवास की स्थिति से जुड़े कुछ सरल प्रश्नों के उत्तर दें, संभावित लाभों को समझें, पात्रता शर्तों की जांच करें और अपने दस्तावेज़ तैयार करें।"
              : "Answer a few simple questions to explore possible benefits, understand eligibility conditions, and prepare your documents."}
          </p>

          <div className="intro-actions-row">
            <button 
              className="btn-primary"
              style={{ padding: '0.65rem 1.4rem', fontSize: '0.92rem' }}
              onClick={onScrollToForm}
            >
              <span>{language === 'hi' ? "पात्रता जाँचें" : "Check Eligibility"}</span>
              <ArrowRight size={15} />
            </button>

            <button 
              className="btn-secondary"
              style={{ padding: '0.65rem 1.2rem', fontSize: '0.92rem' }}
              onClick={onOpenPassport}
            >
              <FileText size={15} />
              <span>{language === 'hi' ? "दस्तावेज़ सूची देखें" : "View Document Checklist"}</span>
            </button>
          </div>
        </div>

        {/* Right column: Quick Department Selection */}
        <div className="intro-dept-ribbon">
          <div className="dept-ribbon-title">
            {language === 'hi' ? "विभागीय योजना निर्देशिका" : "Explore by Department"}
          </div>
          <div className="dept-buttons-grid">
            {departments.map((dept) => {
              const IconComp = dept.icon;
              const isActive = selectedCategory === dept.id;
              return (
                <button
                  key={dept.id}
                  className={`dept-quick-btn ${isActive ? 'active' : ''}`}
                  onClick={() => onSelectCategory(dept.id)}
                  aria-pressed={isActive}
                >
                  <IconComp size={15} color={isActive ? '#FFFFFF' : 'var(--gov-navy)'} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: '0.8rem', lineHeight: 1.25 }}>
                      {language === 'hi' ? dept.labelHi : dept.label}
                    </div>
                    <small style={{ fontSize: '0.68rem', color: isActive ? '#FEF3C7' : 'var(--text-faint)' }}>
                      {dept.count}
                    </small>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* RESTRAINED SERVICE FACT STRIP */}
      <div className="service-facts-strip" aria-label="Portal Facts">
        <div className="service-facts-inner">
          <div className="service-fact-item">
            <CheckCircle size={14} color="var(--status-eligible-text)" />
            <span>{language === 'hi' ? "निःशुल्क नागरिक सेवा" : "Free to explore"}</span>
          </div>
          <div className="service-fact-item">
            <Lock size={14} color="var(--gov-navy)" />
            <span>{language === 'hi' ? "लॉगिन की आवश्यकता नहीं" : "No sign-in required"}</span>
          </div>
          <div className="service-fact-item">
            <Layers size={14} color="var(--gov-navy)" />
            <span>{language === 'hi' ? "पारदर्शी नियम-आधारित मार्गदर्शन" : "Preliminary eligibility guidance"}</span>
          </div>
          <div className="service-fact-item">
            <ExternalLink size={14} color="var(--gov-saffron)" />
            <span>{language === 'hi' ? "सत्यापित आधिकारिक पोर्टल लिंक" : "Official-source links provided"}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
