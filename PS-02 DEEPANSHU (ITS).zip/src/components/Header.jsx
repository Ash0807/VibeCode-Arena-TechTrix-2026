import React, { useState, useEffect } from 'react';
import { 
  Bookmark, 
  ShieldCheck, 
  Volume2, 
  Network, 
  Clock, 
  Info, 
  Contrast, 
  Check,
  Sun,
  Moon
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function Header({ 
  currentPage,
  onNavigate,
  savedCount, 
  onOpenSaved, 
  onOpenPassport,
  eligibleCount 
}) {
  const { language, setLanguage, t } = useLanguage();
  const [currentDateTime, setCurrentDateTime] = useState("");

  // Day / Night (Dark Mode) Theme State
  const [dayNightMode, setDayNightMode] = useState(() => {
    try {
      return localStorage.getItem("schemesathi_day_night") || "day";
    } catch {
      return "day";
    }
  });

  // Black and White / High-Contrast Theme State
  const [colorMode, setColorMode] = useState(() => {
    try {
      return localStorage.getItem("schemesathi_color_mode") || "standard";
    } catch {
      return "standard";
    }
  });

  // Font size scaler state
  const [fontSizeLevel, setFontSizeLevel] = useState(0); // -1, 0, 1, 2

  // Sync Day / Night Theme
  useEffect(() => {
    const root = document.documentElement;
    if (dayNightMode === 'night') {
      root.classList.add('theme-dark');
    } else {
      root.classList.remove('theme-dark');
    }
    try {
      localStorage.setItem("schemesathi_day_night", dayNightMode);
    } catch (e) {
      console.error(e);
    }
  }, [dayNightMode]);

  // Clock timer
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const locale = language === 'hi' ? 'hi-IN' : 'en-IN';
      const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: true 
      };
      setCurrentDateTime(now.toLocaleDateString(locale, options));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [language]);

  // Apply Black & White / High Contrast Theme to Document Root
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('theme-bw', 'theme-high-contrast');

    if (colorMode === 'bw') {
      root.classList.add('theme-bw');
    } else if (colorMode === 'high-contrast') {
      root.classList.add('theme-bw', 'theme-high-contrast');
    }

    try {
      localStorage.setItem("schemesathi_color_mode", colorMode);
    } catch (e) {
      console.error(e);
    }
  }, [colorMode]);

  // Handle Font Scaler
  const handleFontSizeChange = (delta) => {
    let nextLevel = 0;
    if (delta === 0) nextLevel = 0;
    else nextLevel = Math.max(-1, Math.min(2, fontSizeLevel + delta));
    
    setFontSizeLevel(nextLevel);
    const scaleMap = { '-1': '90%', '0': '100%', '1': '110%', '2': '120%' };
    document.documentElement.style.fontSize = scaleMap[nextLevel] || '100%';
  };

  // Screen Reader Accessibility Trigger
  const handleScreenReaderAnnounce = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const announcement = language === 'hi' 
        ? "स्कीम साथी पोर्टल में आपका स्वागत है। यह भारतीय नागरिकों हेतु सरकारी कल्याणकारी योजनाओं और आवास सहायता की पारदर्शी पात्रता जांच मंच है।"
        : "Welcome to SchemeSaathi. Welfare Scheme Discovery and Housing Assistance portal for Indian citizens.";
      const utterance = new SpeechSynthesisUtterance(announcement);
      utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      window.speechSynthesis.speak(utterance);
    } else {
      alert(language === 'hi' ? "स्क्रीन रीडर सहायता सक्रिय है।" : "Screen reader aid is active.");
    }
  };

  return (
    <>
      {/* 1. TOP UTILITY & ACCESSIBILITY BAR */}
      <div className="edistrict-utility-bar">
        <div className="edistrict-utility-inner">
          <div className="utility-clock">
            <Clock size={13} color="var(--gov-navy)" />
            <span>{currentDateTime || (language === 'hi' ? "शनिवार, 24 अक्टूबर 2026, 4:30:00 अपराह्न" : "Saturday, October 24, 2026, 4:30:00 PM")}</span>
          </div>

          <div className="utility-tools">
            <button 
              onClick={() => onNavigate('eligibility')} 
              className="utility-link" 
              style={{ background: 'none', border: 'none' }}
            >
              {t('skipToMain')}
            </button>

            {/* LIVE WORKING HINDI / ENGLISH TRANSLATOR DROPDOWN */}
            <select 
              className="utility-lang-select" 
              aria-label="Language selection" 
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              style={{ fontWeight: 700, borderColor: 'var(--gov-navy)', cursor: 'pointer' }}
            >
              <option value="hi">हिंदी (Hindi)</option>
              <option value="en">English (अंग्रेजी)</option>
            </select>

            {/* DAY & NIGHT (DARK MODE) TOGGLE MENU */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }} role="region" aria-label="Day and Night Theme Menu">
              <select
                className="utility-bw-select"
                aria-label="Select day or night mode"
                value={dayNightMode}
                onChange={(e) => setDayNightMode(e.target.value)}
                style={{ fontWeight: 600, borderColor: 'var(--gov-navy)' }}
                title="Day / Night Mode Menu"
              >
                <option value="day">
                  {language === 'hi' ? "☀️ दिन (Day Mode)" : "☀️ Day Mode"}
                </option>
                <option value="night">
                  {language === 'hi' ? "🌙 रात (Night Mode)" : "🌙 Night Mode"}
                </option>
              </select>

              {/* Fast 1-Click Day / Night Toggle Button */}
              <button
                className={`utility-theme-btn ${dayNightMode === 'night' ? 'active' : ''}`}
                onClick={() => setDayNightMode(prev => prev === 'day' ? 'night' : 'day')}
                title={dayNightMode === 'night' ? "Switch to Day Mode" : "Switch to Night Mode"}
                aria-pressed={dayNightMode === 'night'}
              >
                {dayNightMode === 'night' ? <Sun size={12} /> : <Moon size={12} />}
                <span>{dayNightMode === 'night' ? (language === 'hi' ? "दिन" : "Day") : (language === 'hi' ? "रात" : "Night")}</span>
              </button>
            </div>

            {/* BLACK & WHITE / HIGH CONTRAST ACCESSIBILITY MENU */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }} role="region" aria-label="Contrast and Color Theme Menu">
              <select
                className="utility-bw-select"
                aria-label="Select black and white or color theme"
                value={colorMode}
                onChange={(e) => setColorMode(e.target.value)}
                style={{ fontWeight: 600, borderColor: 'var(--gov-navy)' }}
                title="Black and White / High Contrast Toggle Menu"
              >
                <option value="standard">
                  {language === 'hi' ? "🎨 रंगीन (Standard Color)" : "🎨 Standard Color"}
                </option>
                <option value="bw">
                  {language === 'hi' ? "🌓 काला और सफेद (B&W Grayscale)" : "🌓 Black & White (Grayscale)"}
                </option>
                <option value="high-contrast">
                  {language === 'hi' ? "⬛ उच्च कंट्रास्ट (High Contrast B&W)" : "⬛ High Contrast B&W"}
                </option>
              </select>

              {/* Fast 1-Click B&W Toggle Button */}
              <button
                className={`utility-bw-btn ${colorMode !== 'standard' ? 'active' : ''}`}
                onClick={() => setColorMode(prev => prev === 'standard' ? 'bw' : 'standard')}
                title={colorMode !== 'standard' ? "Switch to Standard Color" : "Switch to Black and White Mode"}
                aria-pressed={colorMode !== 'standard'}
              >
                <Contrast size={12} />
                <span>{colorMode !== 'standard' ? (language === 'hi' ? "रंगीन" : "Color") : (language === 'hi' ? "श्वेत-श्याम" : "B&W")}</span>
              </button>
            </div>

            {/* ACCESSIBILITY FONT SIZE ADJUSTMENT */}
            <div className="utility-font-scalers" aria-label="Font size adjustment">
              <button 
                className="utility-font-btn" 
                title="Increase font size (+A)"
                onClick={() => handleFontSizeChange(1)}
              >
                +A
              </button>
              <button 
                className="utility-font-btn" 
                title="Reset font size (A)"
                onClick={() => handleFontSizeChange(0)}
              >
                A
              </button>
              <button 
                className="utility-font-btn" 
                title="Decrease font size (-A)"
                onClick={() => handleFontSizeChange(-1)}
              >
                -A
              </button>
            </div>

            {/* SCREEN READER & SITEMAP */}
            <button 
              onClick={handleScreenReaderAnnounce}
              style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '0.74rem', color: 'var(--gov-navy)', cursor: 'pointer', background: 'none', border: 'none' }}
              title="Screen Reader Audio Assistance"
            >
              <Volume2 size={13} />
              <span>{t('screenReader')}</span>
            </button>

            <button 
              onClick={() => onNavigate('services')}
              style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '0.74rem', color: 'var(--gov-navy)', cursor: 'pointer', background: 'none', border: 'none' }}
              title="View Complete Scheme Directory & Sitemap"
            >
              <Network size={13} />
              <span>{t('sitemap')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN OFFICIAL HEADER */}
      <header className="edistrict-header">
        <div className="edistrict-header-inner">
          {/* Understated Public Service Identity */}
          <div 
            className="gov-logo-brand" 
            onClick={() => onNavigate('home')} 
            title="Go to Home Page"
          >
            <div style={{
              background: 'var(--gov-navy)',
              color: '#FFFFFF',
              width: '38px',
              height: '38px',
              borderRadius: 'var(--radius-sm)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <ShieldCheck size={22} color="var(--gov-saffron)" />
            </div>

            <div className="gov-brand-titles">
              <div className="gov-brand-main" style={{ display: 'flex', alignItems: 'baseline', gap: '0.4rem' }}>
                <span style={{ color: 'var(--gov-navy)', fontWeight: 800 }}>SchemeSaathi</span>
                <span style={{ color: 'var(--gov-saffron)', fontSize: '0.9rem', fontWeight: 700 }}>योजना साथी</span>
              </div>
              <div className="gov-brand-sub" style={{ fontSize: '0.74rem', color: 'var(--text-muted)', fontWeight: 500 }}>
                {language === 'hi' 
                  ? "कल्याणकारी योजना खोज एवं पात्रता सहायता" 
                  : "Welfare Scheme Discovery & Eligibility Assistance"}
              </div>
            </div>
          </div>

          {/* Navigation Links with Active Translation */}
          <nav aria-label="Portal Navigation">
            <ul className="gov-nav-menu">
              <li>
                <button 
                  className={currentPage === 'home' ? 'active' : ''} 
                  onClick={() => onNavigate('home')}
                >
                  {t('home')}
                </button>
              </li>
              <li>
                <button 
                  className={currentPage === 'eligibility' ? 'active' : ''} 
                  onClick={() => onNavigate('eligibility')}
                >
                  {language === 'hi' ? "योजनाएं खोजें" : "Find Schemes"}
                </button>
              </li>
              <li>
                <button 
                  className={currentPage === 'housing' ? 'active' : ''} 
                  onClick={() => onNavigate('housing')}
                >
                  {language === 'hi' ? "आवास (PMAY)" : "Housing (PMAY)"}
                </button>
              </li>
              <li>
                <button 
                  className={currentPage === 'passport' ? 'active' : ''} 
                  onClick={() => onNavigate('passport')}
                >
                  {language === 'hi' ? "दस्तावेज़ सूची" : "Document Checklist"}
                  {eligibleCount > 0 && (
                    <span style={{ marginLeft: 5, background: 'var(--status-eligible-text)', color: '#FFF', fontSize: '0.68rem', padding: '1px 5px', borderRadius: '3px', fontWeight: 700 }}>
                      {eligibleCount}
                    </span>
                  )}
                </button>
              </li>
              <li>
                <button 
                  className={currentPage === 'support' ? 'active' : ''} 
                  onClick={() => onNavigate('support')}
                >
                  {language === 'hi' ? "सहायता" : "Help / Support"}
                </button>
              </li>
              <li>
                {/* Understated Saved Schemes Link */}
                <button 
                  className="saved-schemes-nav-btn"
                  onClick={onOpenSaved}
                  title="View Shortlisted Schemes"
                  style={{ 
                    border: '1px solid var(--border-strong)',
                    background: savedCount > 0 ? 'var(--gov-saffron-light)' : '#FFFFFF',
                    color: savedCount > 0 ? 'var(--gov-saffron)' : 'var(--text-main)',
                    borderColor: savedCount > 0 ? 'var(--gov-saffron-border)' : 'var(--border-strong)',
                    padding: '0.35rem 0.75rem',
                    borderRadius: 'var(--radius-sm)',
                    fontWeight: 600,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    fontSize: '0.82rem'
                  }}
                >
                  <Bookmark size={13} fill={savedCount > 0 ? 'currentColor' : 'none'} />
                  <span>{language === 'hi' ? "सहेजी गई" : "Saved"} ({savedCount})</span>
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      {/* 3. COMPACT PRELIMINARY ELIGIBILITY NOTICE STRIP */}
      <div className="preliminary-notice-strip" role="note" aria-label="Portal Statutory Notice">
        <div className="notice-strip-inner">
          <Info size={14} color="var(--gov-saffron)" style={{ flexShrink: 0 }} />
          <span>
            {language === 'hi' 
              ? "प्रारंभिक पात्रता मार्गदर्शन: यह नागरिक सहायता प्रोटोटाइप है। कोई आधार या व्यक्तिगत डेटा संग्रह नहीं। अंतिम पात्रता व स्वीकृति संबंधित मंत्रालय द्वारा की जाती है।"
              : "Preliminary Guidance Notice: Prototype for civic scheme discovery. No Aadhaar or personal data stored. Final approval and disbursement are subject to official government verification."}
          </span>
        </div>
      </div>
    </>
  );
}
