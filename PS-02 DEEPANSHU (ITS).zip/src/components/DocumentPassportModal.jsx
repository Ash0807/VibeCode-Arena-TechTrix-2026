import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Copy, 
  Check, 
  FileCheck2, 
  AlertCircle, 
  Building,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export default function DocumentPassportModal({ 
  schemes, 
  savedSchemeIds, 
  onClose 
}) {
  const [filterMode, setFilterMode] = useState("all-eligible"); // 'all-eligible' | 'shortlisted'
  const [checkedDocs, setCheckedDocs] = useState(() => {
    try {
      const saved = localStorage.getItem("schemesathi_docs_readiness");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [copied, setCopied] = useState(false);

  // Filter schemes based on mode
  const relevantSchemes = schemes.filter(s => {
    if (filterMode === "shortlisted") {
      return savedSchemeIds.includes(s.id);
    }
    return s.evaluation.status === "eligible" || s.evaluation.status === "needs_info";
  });

  // Deduplicate documents and map which schemes require them
  const docMap = new Map();

  relevantSchemes.forEach(scheme => {
    scheme.requiredDocuments.forEach(doc => {
      const cleanKey = doc.name.trim().toLowerCase();
      if (!docMap.has(cleanKey)) {
        docMap.set(cleanKey, {
          name: doc.name,
          issuingAuthority: doc.issuingAuthority,
          description: doc.description,
          schemesNeeded: [scheme.name]
        });
      } else {
        const existing = docMap.get(cleanKey);
        if (!existing.schemesNeeded.includes(scheme.name)) {
          existing.schemesNeeded.push(scheme.name);
        }
      }
    });
  });

  const docList = Array.from(docMap.values());
  const completedCount = docList.filter(d => checkedDocs[d.name]).length;
  const readinessPercent = docList.length > 0 ? Math.round((completedCount / docList.length) * 100) : 0;

  const toggleCheck = (docName) => {
    const updated = {
      ...checkedDocs,
      [docName]: !checkedDocs[docName]
    };
    setCheckedDocs(updated);
    try {
      localStorage.setItem("schemesathi_docs_readiness", JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCopyText = () => {
    let text = `📋 SCHEMESAATHI DOCUMENT PASSPORT / दस्तावेज़ चेकलिस्ट\n`;
    text += `Readiness: ${completedCount}/${docList.length} documents (${readinessPercent}% ready)\n\n`;
    
    docList.forEach((d, idx) => {
      const isDone = checkedDocs[d.name] ? "[DONE]" : "[PENDING]";
      text += `${idx + 1}. ${isDone} ${d.name}\n`;
      text += `   • Where to get: ${d.issuingAuthority}\n`;
      text += `   • Unlocks: ${d.schemesNeeded.join(", ")}\n\n`;
    });

    text += `Generated via SchemeSaathi - Unified Government Scheme Portal\n`;

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-card" style={{ maxWidth: '800px' }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ 
              width: 40, 
              height: 40, 
              borderRadius: 8, 
              background: '#0B1B3D', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              color: '#FFFFFF' 
            }}>
              <FileCheck2 size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', color: '#0B1B3D' }}>
                Unified Document Passport
              </h2>
              <span style={{ fontSize: '0.8rem', color: '#EA580C', fontWeight: 600 }}>
                दस्तावेज़ पासपोर्ट • Single Consolidated Checklist
              </span>
            </div>
          </div>
          <button className="modal-close-btn" onClick={onClose} aria-label="Close document passport">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          {/* Readiness Progress Bar */}
          <div style={{ 
            background: '#F8FAFC', 
            border: '1px solid #E2E8F0', 
            borderRadius: '12px', 
            padding: '1rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.88rem', fontWeight: 700, color: '#0F172A' }}>
                Your Document Readiness: {completedCount} of {docList.length} ready
              </span>
              <span style={{ 
                fontSize: '0.82rem', 
                fontWeight: 700, 
                color: readinessPercent >= 80 ? '#15803D' : '#D97706',
                background: readinessPercent >= 80 ? '#DCFCE7' : '#FEF3C7',
                padding: '0.2rem 0.5rem',
                borderRadius: '6px'
              }}>
                {readinessPercent}% Prepared
              </span>
            </div>

            <div style={{ width: '100%', height: '8px', background: '#E2E8F0', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ 
                width: `${readinessPercent}%`, 
                height: '100%', 
                background: readinessPercent >= 80 ? '#16A34A' : '#EA580C', 
                transition: 'width 0.3s ease' 
              }} />
            </div>
            <p style={{ fontSize: '0.76rem', color: '#64748B' }}>
              Check off the documents you already have. This deduplicated checklist prevents multiple visits to offices.
            </p>
          </div>

          {/* Action and Scope Toolbar */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.75rem' }}>
            <div className="segmented-cards" style={{ width: 'auto', display: 'flex' }}>
              <button
                className={`segmented-card-btn ${filterMode === "all-eligible" ? "active" : ""}`}
                style={{ padding: '0.4rem 0.8rem', fontSize: '0.78rem' }}
                onClick={() => setFilterMode("all-eligible")}
              >
                All Eligible Schemes ({schemes.filter(s => s.evaluation.status === 'eligible').length})
              </button>
              <button
                className={`segmented-card-btn ${filterMode === "shortlisted" ? "active" : ""}`}
                style={{ padding: '0.4rem 0.8rem', fontSize: '0.78rem' }}
                onClick={() => setFilterMode("shortlisted")}
              >
                Shortlisted Schemes ({savedSchemeIds.length})
              </button>
            </div>

            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button 
                className="btn-secondary"
                onClick={handleCopyText}
                style={{ fontSize: '0.82rem', padding: '0.45rem 0.75rem' }}
                title="Copy checklist text for WhatsApp or SMS"
              >
                {copied ? <Check size={14} color="#16A34A" /> : <Copy size={14} />}
                <span>{copied ? "Copied!" : "Copy Text"}</span>
              </button>

              <button 
                className="btn-primary"
                onClick={handlePrint}
                style={{ fontSize: '0.82rem', padding: '0.45rem 0.85rem' }}
                title="Print official document preparation checklist"
              >
                <Printer size={14} />
                <span>Print Passport</span>
              </button>
            </div>
          </div>

          {/* Document Items List */}
          {docList.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '2rem', color: '#64748B' }}>
              <AlertCircle size={32} style={{ margin: '0 auto 0.5rem', color: '#94A3B8' }} />
              <p>No schemes selected in this view. Try switching to "All Eligible Schemes".</p>
            </div>
          ) : (
            <div className="doc-list" role="list">
              {docList.map((doc, idx) => {
                const isChecked = !!checkedDocs[doc.name];
                return (
                  <div 
                    key={idx} 
                    className={`doc-passport-item ${isChecked ? 'checked' : ''}`}
                    role="listitem"
                  >
                    <input 
                      type="checkbox" 
                      className="doc-checkbox" 
                      id={`doc-${idx}`}
                      checked={isChecked}
                      onChange={() => toggleCheck(doc.name)}
                      aria-label={`Mark ${doc.name} as ready`}
                    />
                    <div style={{ flex: 1 }}>
                      <div className="doc-title">{doc.name}</div>
                      <div className="doc-authority">
                        <span>Where to get / issuing body: </span>
                        <strong>{doc.issuingAuthority}</strong>
                      </div>
                      <div style={{ fontSize: '0.8rem', color: '#475569' }}>
                        {doc.description}
                      </div>

                      <div className="doc-schemes-tags">
                        <span style={{ fontSize: '0.7rem', color: '#64748B', alignSelf: 'center' }}>Required for:</span>
                        {doc.schemesNeeded.map((sn, i) => (
                          <span key={i} className="doc-scheme-tag">
                            {sn}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div style={{ 
            background: '#EFF6FF', 
            border: '1px solid #BFDBFE', 
            borderRadius: '8px', 
            padding: '0.75rem', 
            fontSize: '0.78rem', 
            color: '#1E3A8A' 
          }}>
            💡 <strong>Helpful Citizen Tip:</strong> Once these core documents are assembled in a single physical folder or stored in your DigiLocker account, you can apply for multiple central and state schemes without repeating document verification!
          </div>
        </div>
      </div>
    </div>
  );
}
