import React, { useState, useEffect, useMemo } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import SchemeDetailModal from './components/SchemeDetailModal';
import DocumentPassportModal from './components/DocumentPassportModal';
import ShortlistDrawer from './components/ShortlistDrawer';

// Dedicated Pages
import HomePage from './pages/HomePage';
import EligibilityPage from './pages/EligibilityPage';
import HousingPage from './pages/HousingPage';
import DocumentPassportPage from './pages/DocumentPassportPage';
import ServicesDirectoryPage from './pages/ServicesDirectoryPage';
import SupportPage from './pages/SupportPage';

import { SCHEMES } from './data/schemes';
import { PERSONAS } from './data/personas';
import { rankAndFilterSchemes } from './utils/eligibilityEngine';
import { Bot, HelpCircle, FileText, ArrowRight } from 'lucide-react';

export default function App() {
  // Navigation State for Multi-Page Architecture
  const [currentPage, setCurrentPage] = useState('home'); // 'home' | 'eligibility' | 'housing' | 'passport' | 'services' | 'support'
  const [scrollProgress, setScrollProgress] = useState(0);

  // Citizen Profile State (Initialized with Ramesh Kumar)
  const [profile, setProfile] = useState(() => PERSONAS[0].profile);
  const [activePersonaId, setActivePersonaId] = useState(PERSONAS[0].id);

  // Shortlisted Schemes
  const [savedSchemeIds, setSavedSchemeIds] = useState(() => {
    try {
      const saved = localStorage.getItem("schemesathi_saved_schemes");
      return saved ? JSON.parse(saved) : ["pmay-g", "pm-kisan"];
    } catch {
      return ["pmay-g", "pm-kisan"];
    }
  });

  // Filter & Search states
  const [activeFilter, setActiveFilter] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Modals & Drawers
  const [detailModalScheme, setDetailModalScheme] = useState(null);
  const [isPassportModalOpen, setIsPassportModalOpen] = useState(false);
  const [isShortlistOpen, setIsShortlistOpen] = useState(false);
  const [showBotHelp, setShowBotHelp] = useState(false);

  // Scroll Progress Tracking for Top Bar
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollTop;
      const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (windowHeight > 0) {
        setScrollProgress((totalScroll / windowHeight) * 100);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Sync saved schemes
  useEffect(() => {
    try {
      localStorage.setItem("schemesathi_saved_schemes", JSON.stringify(savedSchemeIds));
    } catch (e) {
      console.error(e);
    }
  }, [savedSchemeIds]);

  // Navigate handler with smooth scroll to top
  const handleNavigate = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Evaluate schemes
  const evaluatedSchemes = useMemo(() => {
    return rankAndFilterSchemes(SCHEMES, profile, "all", "all");
  }, [profile]);

  const eligibleCount = evaluatedSchemes.filter(s => s.evaluation.status === "eligible").length;

  // Filtered displayed list for Eligibility Page
  const displayedSchemes = useMemo(() => {
    return evaluatedSchemes.filter(s => {
      if (activeFilter === "eligible" && s.evaluation.status !== "eligible") return false;
      if (activeFilter === "needs_info" && s.evaluation.status !== "needs_info") return false;
      if (activeFilter === "ineligible" && s.evaluation.status !== "ineligible") return false;
      if (activeFilter === "housing" && !s.isHousingScheme) return false;

      if (selectedCategory !== "all" && s.category !== selectedCategory) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = s.name.toLowerCase().includes(q) || s.nameHindi.toLowerCase().includes(q);
        const matchMinistry = s.ministry.toLowerCase().includes(q);
        const matchCategory = s.category.toLowerCase().includes(q);
        const matchPurpose = s.purpose.toLowerCase().includes(q);
        if (!matchName && !matchMinistry && !matchCategory && !matchPurpose) return false;
      }

      return true;
    });
  }, [evaluatedSchemes, activeFilter, selectedCategory, searchQuery]);

  const handleToggleSave = (schemeId) => {
    setSavedSchemeIds(prev => {
      if (prev.includes(schemeId)) {
        return prev.filter(id => id !== schemeId);
      }
      return [...prev, schemeId];
    });
  };

  const savedSchemesList = useMemo(() => {
    return evaluatedSchemes.filter(s => savedSchemeIds.includes(s.id));
  }, [evaluatedSchemes, savedSchemeIds]);

  return (
    <div className="app-container">
      {/* Top Scroll-Driven Progress Bar */}
      <div 
        className="scroll-progress-line" 
        style={{ width: `${scrollProgress}%` }} 
        aria-hidden="true"
      />

      {/* Global Header with Multi-Page Navigation */}
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        savedCount={savedSchemeIds.length}
        eligibleCount={eligibleCount}
        onOpenSaved={() => setIsShortlistOpen(true)}
        onOpenPassport={() => handleNavigate('passport')}
      />

      {/* MULTI-PAGE VIEW ROUTER */}
      <main id="main-content">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectCategory={(cat) => {
              setSelectedCategory(cat);
              handleNavigate('eligibility');
            }}
            selectedCategory={selectedCategory}
            onOpenPassport={() => handleNavigate('passport')}
            onOpenShortlist={() => setIsShortlistOpen(true)}
          />
        )}

        {currentPage === 'eligibility' && (
          <EligibilityPage
            profile={profile}
            setProfile={setProfile}
            activePersonaId={activePersonaId}
            setActivePersonaId={setActivePersonaId}
            personas={PERSONAS}
            evaluatedSchemes={evaluatedSchemes}
            displayedSchemes={displayedSchemes}
            activeFilter={activeFilter}
            setActiveFilter={setActiveFilter}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            savedSchemeIds={savedSchemeIds}
            onToggleSave={handleToggleSave}
            onViewDetails={(s) => setDetailModalScheme(s)}
            onInspectAudit={(s) => setDetailModalScheme(s)}
          />
        )}

        {currentPage === 'housing' && (
          <HousingPage
            onNavigateToEligibility={() => {
              setSelectedCategory('Housing');
              handleNavigate('eligibility');
            }}
          />
        )}

        {currentPage === 'passport' && (
          <DocumentPassportPage
            schemes={evaluatedSchemes}
            savedSchemeIds={savedSchemeIds}
          />
        )}

        {currentPage === 'services' && (
          <ServicesDirectoryPage
            onViewDetails={(s) => setDetailModalScheme(s)}
            onToggleSave={handleToggleSave}
            savedSchemeIds={savedSchemeIds}
          />
        )}

        {currentPage === 'support' && (
          <SupportPage />
        )}
      </main>

      {/* Floating Citizen Assistant Bot */}
      <div 
        className="floating-saathi-bot" 
        onClick={() => setShowBotHelp(prev => !prev)}
        title="साथी सहायता / SchemeSaathi Citizen Bot"
        aria-label="Toggle Citizen Assistant"
      >
        <Bot size={26} />
        {showBotHelp && (
          <div className="floating-saathi-tooltip">
            <strong>नमस्ते! मैं आपका योजना साथी हूँ:</strong>
            <p style={{ marginTop: '0.25rem', fontSize: '0.74rem', color: '#E2E8F0' }}>
              किसी भी पृष्ठ पर जाने के लिए ऊपर नेविगेशन मेन्यू का उपयोग करें अथवा नीचे से सीधा पासपोर्ट देखें।
            </p>
            <div style={{ display: 'flex', gap: '0.4rem', marginTop: '0.5rem' }}>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setShowBotHelp(false);
                  handleNavigate('passport');
                }}
                style={{ background: '#ED5E1C', color: '#FFF', border: 'none', padding: '0.25rem 0.5rem', borderRadius: 4, fontSize: '0.7rem', fontWeight: 600, cursor: 'pointer' }}
              >
                दस्तावेज़ पासपोर्ट खोलें
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Scheme Detail & Rule Audit Modal */}
      {detailModalScheme && (
        <SchemeDetailModal
          scheme={detailModalScheme}
          isSaved={savedSchemeIds.includes(detailModalScheme.id)}
          onToggleSave={handleToggleSave}
          onClose={() => setDetailModalScheme(null)}
          onOpenPassport={() => {
            setDetailModalScheme(null);
            handleNavigate('passport');
          }}
        />
      )}

      {/* Quick Passport Modal (fallback if opened from header button) */}
      {isPassportModalOpen && (
        <DocumentPassportModal
          schemes={evaluatedSchemes}
          savedSchemeIds={savedSchemeIds}
          onClose={() => setIsPassportModalOpen(false)}
        />
      )}

      {/* Shortlist Drawer */}
      <ShortlistDrawer
        isOpen={isShortlistOpen}
        onClose={() => setIsShortlistOpen(false)}
        savedSchemes={savedSchemesList}
        onRemove={handleToggleSave}
        onViewDetails={(s) => {
          setIsShortlistOpen(false);
          setDetailModalScheme(s);
        }}
        onOpenPassport={() => {
          setIsShortlistOpen(false);
          handleNavigate('passport');
        }}
      />

      {/* Global Civic Footer with Navigation Hooks */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
