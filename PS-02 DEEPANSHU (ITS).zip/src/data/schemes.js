export const SCHEMES = [
  {
    id: "pmay-g",
    name: "Pradhan Mantri Awas Yojana - Gramin (PMAY-G)",
    nameHindi: "प्रधानमंत्री आवास योजना - ग्रामीण",
    ministry: "Ministry of Rural Development",
    category: "Housing",
    isHousingScheme: true,
    highlight: "flagship-housing",
    purpose: "To provide a pucca house with basic amenities to all homeless households and those living in kutcha and dilapidated houses in rural areas.",
    intendedBeneficiaries: "Rural homeless households, families living in 0, 1, or 2 room kutcha houses with kutcha roof/walls (SECC/Awaas+ priority).",
    benefits: [
      { type: "Financial", description: "Direct financial assistance of ₹1,20,000 in plain areas / ₹1,30,000 in hilly/difficult states." },
      { type: "Convergence", description: "Additional ₹12,000 for toilet construction under Swachh Bharat Mission (Grameen)." },
      { type: "Labor Support", description: "90 to 95 person-days of unskilled labor support under MGNREGA (~₹24,000)." },
      { type: "Basic Amenities", description: "Direct LPG connection under Ujjwala and electricity under Saubhagya." }
    ],
    rules: {
      location: ["rural"],
      maxIncome: 300000, // ₹3 Lakhs
      housingCondition: ["kutcha", "homeless", "dilapidated"],
      disqualifications: ["Owns a motorized 2/3/4 wheeler or agricultural equipment", "Has a pucca house registered anywhere in India", "Any family member is a government employee"],
      minAge: 18
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Identity verification of applicant and adult family members." },
      { name: "Bank Passbook with Account Number & IFSC", issuingAuthority: "Nationalized / Scheduled Commercial Bank", description: "Direct Benefit Transfer (DBT) account linked to Aadhaar." },
      { name: "SECC Family ID / Job Card Number", issuingAuthority: "Gram Panchayat / Block Office", description: "To cross-verify inclusion in rural household survey." },
      { name: "Land / Plot Ownership Document or Gram Sabha Allotment", issuingAuthority: "Revenue Dept / Gram Panchayat", description: "Proof of rights over the construction site." },
      { name: "Self-declaration of Not Owning a Pucca House", issuingAuthority: "Self-attested / Gram Sevak", description: "Affidavit verifying no pucca home exists across India." }
    ],
    officialLink: "https://pmayg.nic.in",
    applicationProcess: "Applications are coordinated via Gram Sabha and Gram Panchayat Awaas+ survey. Eligible citizens can verify their name on PMAY-G portal or approach the Village Block Development Office (BDO)."
  },
  {
    id: "pmay-u",
    name: "Pradhan Mantri Awas Yojana - Urban 2.0 (PMAY-U)",
    nameHindi: "प्रधानमंत्री आवास योजना - शहरी 2.0",
    ministry: "Ministry of Housing and Urban Affairs",
    category: "Housing",
    isHousingScheme: true,
    highlight: "flagship-housing",
    purpose: "To address urban housing shortages among EWS/LIG families, slum dwellers, and urban poor by facilitating affordable housing and interest subsidies.",
    intendedBeneficiaries: "Economically Weaker Section (EWS) and Low-Income Group (LIG) families living in statutory towns without a pucca house in their name.",
    benefits: [
      { type: "Subsidy", description: "Interest subsidy of up to 4% on home loans up to ₹25,00,000 (net subsidy up to ₹1.80 Lakh to ₹2.67 Lakh over 5-year tenure)." },
      { type: "Direct Construction", description: "Financial assistance of ₹1.50 Lakh to ₹2.50 Lakh per house for Beneficiary-led Individual House Construction (BLC)." },
      { type: "Rental Support", description: "Access to Affordable Rental Housing Complexes (ARHC) for migrant workers." }
    ],
    rules: {
      location: ["urban"],
      maxIncome: 600000, // EWS: <= 3L, LIG: <= 6L
      housingCondition: ["rented", "kutcha", "homeless"],
      disqualifications: ["Family already owns a pucca house anywhere in India", "Has previously availed Central Housing Subsidy"],
      minAge: 21
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Aadhaar authentication for all household members." },
      { name: "Income Certificate / Salary Slip / Form 16", issuingAuthority: "Tahsildar / Sub-Divisional Magistrate / Employer", description: "Verifying EWS (up to ₹3L) or LIG (up to ₹6L) status." },
      { name: "Proof of Address (Utility Bill / Rent Agreement)", issuingAuthority: "Municipal Corporation / Local Body", description: "Establishing residency in the urban local body area." },
      { name: "Bank Account Details & 6 Months Statement", issuingAuthority: "Bank", description: "For processing subsidy credit into loan account." },
      { name: "Affidavit of No Pucca House in India", issuingAuthority: "Notary / Executive Magistrate", description: "Statutory declaration on non-judicial stamp paper." }
    ],
    officialLink: "https://pmaymis.gov.in",
    applicationProcess: "Apply online through the PMAY-U official portal or via your local Urban Local Body (ULB) / Municipal Corporation or nearest Citizen Service Centre (CSC)."
  },
  {
    id: "pm-kisan",
    name: "PM Kisan Samman Nidhi (PM-KISAN)",
    nameHindi: "पीएम किसान सम्मान निधि",
    ministry: "Ministry of Agriculture & Farmers Welfare",
    category: "Agriculture",
    isHousingScheme: false,
    purpose: "To augment the income of all landholding farmer families across the country to procure agriculture inputs and support domestic needs.",
    intendedBeneficiaries: "All cultivable landholding farmer families in rural and semi-rural areas, subject to exclusion criteria.",
    benefits: [
      { type: "Income Support", description: "Direct Benefit Transfer (DBT) of ₹6,000 per year delivered in 3 equal installments of ₹2,000 every 4 months directly into bank account." }
    ],
    rules: {
      occupation: ["farmer", "agricultural-laborer"],
      landholdingRequired: true,
      disqualifications: ["Institutional landholders", "Family member paid Income Tax in previous assessment year", "Doctors, Engineers, Lawyers, Chartered Accountants holding land"],
      minAge: 18
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Mandatory Aadhaar linking with PM-KISAN portal (e-KYC)." },
      { name: "Land Record / Khatoni / RoR", issuingAuthority: "State Revenue Department / Patwari / Lekhpal", description: "Record of Rights showing applicant's cultivable landholding." },
      { name: "Aadhaar-Seeded Bank Passbook", issuingAuthority: "Bank / Post Office", description: "Active bank account linked with NPCI Aadhaar bridge." }
    ],
    officialLink: "https://pmkisan.gov.in",
    applicationProcess: "Register online on pmkisan.gov.in through 'New Farmer Registration' or visit the local Common Service Centre (CSC) or Agriculture Office."
  },
  {
    id: "ab-pmjay",
    name: "Ayushman Bharat - PM Jan Arogya Yojana (AB-PMJAY)",
    nameHindi: "आयुष्मान भारत - प्रधानमंत्री जन आरोग्य योजना",
    ministry: "National Health Authority / Ministry of Health & Family Welfare",
    category: "Healthcare",
    isHousingScheme: false,
    purpose: "To provide financial protection to vulnerable families against catastrophic health expenditure by offering secondary and tertiary inpatient healthcare coverage.",
    intendedBeneficiaries: "Bottom 40% vulnerable and poor families identified under rural and urban deprivation criteria of SECC, plus all senior citizens aged 70+ irrespective of income.",
    benefits: [
      { type: "Health Insurance", description: "Cashless health cover of up to ₹5,00,000 per family per year across 27,000+ empaneled public and private hospitals across India." },
      { type: "Pre & Post Hospitalization", description: "Covers 3 days pre-hospitalization and 15 days post-hospitalization diagnostic and medication costs." }
    ],
    rules: {
      maxIncome: 250000,
      disqualifications: ["Government employees with CGHS/ECHS cover", "Family paying regular income tax"],
      minAge: 0
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Primary biometric and identity proof." },
      { name: "Ration Card / NFSA Food Security Card", issuingAuthority: "State Food & Civil Supplies Department", description: "Proof of family membership and SECC eligibility linkage." },
      { name: "PMJAY Family ID / Ayushman Card Letter", issuingAuthority: "National Health Authority / CSC", description: "If already verified in beneficiary database." }
    ],
    officialLink: "https://beneficiary.nha.gov.in",
    applicationProcess: "Check eligibility on beneficiary.nha.gov.in with mobile number or Ration Card, then visit any empaneled hospital or CSC kiosk with Aadhaar to generate Ayushman Card."
  },
  {
    id: "mgnrega",
    name: "Mahatma Gandhi NREGA (MGNREGA)",
    nameHindi: "महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम",
    ministry: "Ministry of Rural Development",
    category: "Employment",
    isHousingScheme: false,
    purpose: "To guarantee livelihood security in rural areas by providing at least 100 days of guaranteed wage employment in every financial year to adult members willing to do unskilled manual work.",
    intendedBeneficiaries: "Any adult rural citizen residing in the Gram Panchayat area ready to undertake unskilled manual labor.",
    benefits: [
      { type: "Guaranteed Employment", description: "Legal guarantee of 100 days wage employment per household per year within 5 km of village (or extra travel allowance)." },
      { type: "Unemployment Allowance", description: "Cash allowance if employment is not provided within 15 days of applying." }
    ],
    rules: {
      location: ["rural"],
      minAge: 18,
      occupation: ["any", "agricultural-laborer", "daily-wage-worker", "unemployed", "farmer"],
      disqualifications: ["Urban residents", "Refusal of manual labor"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Identity and biometric authentication." },
      { name: "Ration Card / Proof of Rural Residence", issuingAuthority: "Gram Panchayat / Food Dept", description: "Proof that applicant resides in the Gram Panchayat jurisdiction." },
      { name: "Bank or Post Office Savings Account Passbook", issuingAuthority: "Bank or India Post Payments Bank", description: "Direct Benefit Transfer wage account." },
      { name: "Passport-size Photograph", issuingAuthority: "Self", description: "For pasting onto physical MGNREGA Job Card." }
    ],
    officialLink: "https://nrega.nic.in",
    applicationProcess: "Submit a plain-paper application or Form 1 to your local Gram Panchayat office. Job card is issued free of charge within 15 days."
  },
  {
    id: "pm-svanidhi",
    name: "PM SVANidhi (Street Vendor's AtmaNirbhar Nidhi)",
    nameHindi: "पीएम स्वनिधि योजना (स्ट्रीट वेंडर्स आत्मनिर्भर निधि)",
    ministry: "Ministry of Housing and Urban Affairs",
    category: "Employment",
    isHousingScheme: false,
    purpose: "To empower urban street vendors and micro-hawkers with collateral-free working capital micro-loans to restart and grow their livelihoods.",
    intendedBeneficiaries: "Urban street vendors, roadside sellers, and hawkers who have been vending in urban statutory towns.",
    benefits: [
      { type: "Working Capital Loan", description: "1st tranche: Up to ₹10,000 collateral-free (1-year term). On timely repayment: 2nd tranche up to ₹20,000 and 3rd tranche up to ₹50,000." },
      { type: "Interest Subsidy", description: "7% per annum interest subsidy directly credited to bank account quarterly upon timely repayment." },
      { type: "Digital Incentive", description: "Cashback of up to ₹1,200 per year on digital receipt transactions." }
    ],
    rules: {
      location: ["urban"],
      minAge: 18,
      occupation: ["street-vendor", "informal-worker", "daily-wage-worker", "self-employed"],
      disqualifications: ["Formal salaried employees", "Large business owners"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Identity proof linked with mobile number." },
      { name: "Certificate of Vending (CoV) / Vendor ID Card", issuingAuthority: "Urban Local Body (ULB) / Town Vending Committee (TVC)", description: "Identity card proving hawker/vendor status, or a Letter of Recommendation (LoR)." },
      { name: "Bank Account Passbook / UPI QR Handle", issuingAuthority: "Bank / Payment Aggregator", description: "For disbursal and digital cashback." }
    ],
    officialLink: "https://pmsvanidhi.mohua.gov.in",
    applicationProcess: "Apply online at pmsvanidhi.mohua.gov.in or approach the Urban Local Body (ULB) Office or nearest CSC with your vending certificate."
  },
  {
    id: "pm-vishwakarma",
    name: "PM Vishwakarma Scheme",
    nameHindi: "पीएम विश्वकर्मा योजना",
    ministry: "Ministry of Micro, Small & Medium Enterprises",
    category: "Employment",
    isHousingScheme: false,
    purpose: "To provide holistic end-to-end support to traditional artisans and craftspeople who work with hands and tools.",
    intendedBeneficiaries: "Artisans engaged in 18 traditional family-based trades (Carpenters, Blacksmiths, Masons/Rajmistri, Cobblers, Tailors, Potters, Barbers, Sculptors, etc.).",
    benefits: [
      { type: "Recognition", description: "PM Vishwakarma Certificate and ID Card." },
      { type: "Skill Upgrade", description: "Basic 5-7 days training with ₹500/day stipend, plus advanced training." },
      { type: "Toolkit Incentive", description: "Free digital voucher of ₹15,000 to purchase modern tools." },
      { type: "Enterprise Credit", description: "Collateral-free enterprise loan up to ₹1 Lakh (1st tranche) and ₹2 Lakh (2nd tranche) at concessional 5% interest rate." }
    ],
    rules: {
      minAge: 18,
      occupation: ["artisan", "mason", "carpenter", "tailor", "craftsman", "daily-wage-worker"],
      disqualifications: ["Family member having an active PMEGP/Mudra loan default", "Government employees and their immediate families"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Identity proof and e-KYC." },
      { name: "Active Bank Account Passbook", issuingAuthority: "Bank", description: "For credit of ₹500/day stipend and loan disbursal." },
      { name: "Ration Card", issuingAuthority: "Food and Civil Supplies Department", description: "Proof of family composition (only one member per family eligible)." },
      { name: "Trade Skill Proof / Self-Declaration", issuingAuthority: "Gram Panchayat / ULB Verification", description: "Verification by local body of practice in the 18 eligible trades." }
    ],
    officialLink: "https://pmvishwakarma.gov.in",
    applicationProcess: "Biometric-based registration at any Common Service Centre (CSC) followed by 3-stage verification (Gram Panchayat/ULB, District Implementation Committee, Screening Committee)."
  },
  {
    id: "post-matric-scholarship",
    name: "Post-Matric Scholarship for SC/ST/OBC Students",
    nameHindi: "पोस्ट-मैट्रिक छात्रवृत्ति (अनुसूचित जाति / जनजाति / अन्य पिछड़ा वर्ग)",
    ministry: "Ministry of Social Justice and Empowerment / Ministry of Tribal Affairs",
    category: "Education",
    isHousingScheme: false,
    purpose: "To provide financial assistance to students belonging to Scheduled Castes, Scheduled Tribes, and OBC communities pursuing post-matriculation or post-secondary education.",
    intendedBeneficiaries: "Students studying in class 11th, 12th, ITI, Diploma, Undergraduate, and Postgraduate programs whose parents' income does not exceed threshold.",
    benefits: [
      { type: "Tuition Reimbursement", description: "100% compulsory non-refundable fees reimbursed directly to institution/student." },
      { type: "Maintenance Allowance", description: "Monthly academic allowance of ₹2,500 to ₹13,500 per year depending on course category." }
    ],
    rules: {
      socialCategory: ["SC", "ST", "OBC"],
      maxIncome: 250000, // ₹2.5 Lakhs
      occupation: ["student"],
      minAge: 15,
      maxAge: 35,
      disqualifications: ["Students receiving full scholarship from another government source", "Parental income exceeding ₹2.5 Lakhs/year"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card", issuingAuthority: "UIDAI", description: "Aadhaar authentication." },
      { name: "Caste Certificate", issuingAuthority: "Tahsildar / Sub-Divisional Officer (SDO)", description: "Government verified SC/ST/OBC community certificate." },
      { name: "Income Certificate (Current Year)", issuingAuthority: "Revenue Officer / Tahsildar", description: "Certifying annual family income is under ₹2.5 Lakh." },
      { name: "Previous Academic Marksheet & College Fee Receipt", issuingAuthority: "School / College / University", description: "Proof of admission into recognized post-matric course." },
      { name: "Student's Bank Passbook (Aadhaar linked)", issuingAuthority: "Bank", description: "DBT account in student's own name." }
    ],
    officialLink: "https://scholarships.gov.in",
    applicationProcess: "Apply online at National Scholarship Portal (NSP - scholarships.gov.in) with One-Time Registration (OTR) and verify with institutional nodal officer."
  },
  {
    id: "nsap-ignoaps",
    name: "Indira Gandhi National Old Age Pension Scheme (IGNOAPS)",
    nameHindi: "इंदिरा गांधी राष्ट्रीय वृद्धावस्था पेंशन योजना",
    ministry: "Ministry of Rural Development",
    category: "Social Welfare",
    isHousingScheme: false,
    purpose: "To provide monthly social security pension to elderly citizens living below poverty line without sufficient family support.",
    intendedBeneficiaries: "Senior citizens aged 60 and above belonging to BPL households.",
    benefits: [
      { type: "Monthly Pension", description: "₹200 to ₹500/month Central contribution plus top-up by State Government (total varies between ₹1,000 to ₹2,500/month depending on state)." }
    ],
    rules: {
      minAge: 60,
      maxIncome: 120000,
      disqualifications: ["Receiving pension from Central/State Government", "Not in BPL/SECC list"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card / Voter ID Card", issuingAuthority: "UIDAI / ECI", description: "Proof of age and identity (must be 60 years or above)." },
      { name: "BPL Ration Card / SECC Household Letter", issuingAuthority: "Food and Civil Supplies Department", description: "Proof of Below Poverty Line classification." },
      { name: "Bank Passbook / Post Office Account", issuingAuthority: "Bank / India Post", description: "Direct pension credit account." },
      { name: "Income Certificate / Non-pensioner Affidavit", issuingAuthority: "Tahsildar / Gram Sevak", description: "Affidavit that applicant receives no other government pension." }
    ],
    officialLink: "https://nsap.nic.in",
    applicationProcess: "Submit application to the local Gram Panchayat Secretary, Block Development Office (BDO), or Social Welfare Department office, or apply via state citizen service portal."
  },
  {
    id: "sukanya-samriddhi",
    name: "Sukanya Samriddhi Yojana (Beti Bachao Beti Padhao)",
    nameHindi: "सुकन्या समृद्धि योजना",
    ministry: "Ministry of Finance",
    category: "Social Welfare",
    isHousingScheme: false,
    purpose: "A high-interest government-backed savings scheme aimed at securing the financial future, higher education, and marriage expenses of girl children.",
    intendedBeneficiaries: "Families with a girl child aged 10 years or younger (maximum 2 accounts per family).",
    benefits: [
      { type: "High Interest & Security", description: "Guaranteed high interest rate (currently 8.2% per annum, compounded annually) with sovereign guarantee." },
      { type: "Tax Exemptions", description: "Triple tax exemption under Section 80C (EEE category: investment, interest, and withdrawal are 100% tax-free)." }
    ],
    rules: {
      minAge: 18, // Parent/guardian age
      hasGirlChildUnder10: true,
      disqualifications: ["Child is older than 10 years at account opening", "Non-resident Indians (NRI)"]
    },
    requiredDocuments: [
      { name: "Girl Child Birth Certificate", issuingAuthority: "Municipal Authority / Registrar of Births", description: "Official birth certificate mentioning child's name and date of birth." },
      { name: "Parent / Guardian Aadhaar Card & PAN Card", issuingAuthority: "UIDAI / Income Tax Department", description: "Identity and KYC proof of the guardian opening the account." },
      { name: "Proof of Residence", issuingAuthority: "Utility Provider / UIDAI / Ration Card", description: "Current residential address proof." },
      { name: "Passport-size Photographs of Child & Guardian", issuingAuthority: "Self", description: "For bank or post office account opening form." }
    ],
    officialLink: "https://www.indiapost.gov.in",
    applicationProcess: "Open account at any Post Office branch or authorized public/private commercial bank with initial minimum deposit of ₹250."
  },
  {
    id: "pm-mudra-shishu",
    name: "Pradhan Mantri Mudra Yojana (PMMY) - Shishu & Kishore",
    nameHindi: "प्रधानमंत्री मुद्रा योजना (शिशु एवं किशोर ऋण)",
    ministry: "Ministry of Finance / Department of Financial Services",
    category: "Employment",
    isHousingScheme: false,
    purpose: "To provide affordable collateral-free loans to micro and small non-corporate, non-farm enterprises for setting up new ventures or expanding existing ones.",
    intendedBeneficiaries: "Small business owners, shopkeepers, fruit/vegetable vendors, small manufacturing units, and service enterprise owners.",
    benefits: [
      { type: "Micro Credit", description: "Shishu: Loans up to ₹50,000 for startup micro-units. Kishore: Loans above ₹50,000 up to ₹5,00,000 for expansion." },
      { type: "Zero Collateral", description: "No collateral security or third-party guarantee required from the borrower." }
    ],
    rules: {
      minAge: 18,
      occupation: ["self-employed", "street-vendor", "artisan", "daily-wage-worker", "other"],
      disqualifications: ["Willful defaulter with any commercial bank", "Farm-crop production loans (covered under KCC)"]
    },
    requiredDocuments: [
      { name: "Aadhaar Card & PAN Card", issuingAuthority: "UIDAI / IT Department", description: "Identity and address proof." },
      { name: "Enterprise Proof / Registration (Udyam Registration)", issuingAuthority: "MSME Department", description: "Free Udyam Aadhaar certificate proving business existence." },
      { name: "Last 6 Months Bank Statement", issuingAuthority: "Bank", description: "Proof of cash flow and existing banking track record." },
      { name: "Project Report / Quotation of Machinery or Stock", issuingAuthority: "Supplier / Self", description: "Breakdown of intended use of loan funds." }
    ],
    officialLink: "https://www.mudra.org.in",
    applicationProcess: "Apply online at UdyamiMitra portal (udyamimitra.in) or submit Mudra application directly to any public sector, regional rural bank (RRB), or microfinance institution."
  },
  {
    id: "pmmvy",
    name: "Pradhan Mantri Matru Vandana Yojana (PMMVY)",
    nameHindi: "प्रधानमंत्री मातृ वंदना योजना",
    ministry: "Ministry of Women and Child Development",
    category: "Healthcare",
    isHousingScheme: false,
    purpose: "Maternity benefit cash incentive program to compensate for wage loss before and after childbirth and promote healthy institutional deliveries.",
    intendedBeneficiaries: "Pregnant women and lactating mothers for the birth of the first child, and for the second child if it is a girl.",
    benefits: [
      { type: "Maternity Cash Support", description: "Direct Benefit Transfer of ₹5,000 in two installments for 1st child, and ₹6,000 in one installment for 2nd child (if female) to improve sex ratio." }
    ],
    rules: {
      minAge: 19,
      gender: ["female", "any"],
      maxIncome: 800000,
      disqualifications: ["Women in regular employment with Central/State Govt or PSUs receiving paid maternity leave"]
    },
    requiredDocuments: [
      { name: "Mother's & Husband's Aadhaar Card", issuingAuthority: "UIDAI", description: "Biometric KYC and address authentication." },
      { name: "Mother and Child Protection (MCP) Card", issuingAuthority: "Anganwadi Centre / Public Health Centre (PHC)", description: "Proof of timely antenatal checkups (ANC) and registration." },
      { name: "Aadhaar-linked Bank Account Passbook", issuingAuthority: "Bank / India Post", description: "Must be in mother's sole name." },
      { name: "Child Birth Certificate", issuingAuthority: "Municipal / Hospital Registrar", description: "Showing institutional delivery." }
    ],
    officialLink: "https://pmmvy.wcd.gov.in",
    applicationProcess: "Register at the nearest Anganwadi Centre (AWC) or authorized government health facility within 270 days of pregnancy."
  }
];
