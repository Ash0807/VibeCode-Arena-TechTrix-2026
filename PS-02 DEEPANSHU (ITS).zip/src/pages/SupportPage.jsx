import React, { useState } from 'react';
import { 
  PhoneCall, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export default function SupportPage() {
  const { language, t } = useLanguage();
  useScrollReveal();

  const [openFaq, setOpenFaq] = useState(0);

  const faqs = language === 'hi' ? [
    {
      q: "क्या SchemeSaathi पोर्टल पर आवेदन करने के लिए आधार कार्ड या बैंक विवरण दर्ज करना अनिवार्य है?",
      a: "नहीं। SchemeSaathi पूरी तरह से गोपनीय और प्रारंभिक जांच मंच है। योजनाएं खोजने या पात्रता जांचने के लिए किसी भी नागरिक को अपना आधार नंबर, बैंक खाता विवरण अथवा ओटीपी दर्ज करने की आवश्यकता नहीं है।"
    },
    {
      q: "PMAY-G (ग्रामीण आवास) के अंतर्गत ₹1,20,000 की सहायता राशि प्राप्त करने की क्या शर्तें हैं?",
      a: "PMAY-G के लाभार्थी का चयन सामाजिक-आर्थिक जाति जनगणना (SECC) एवं ग्राम सभा द्वारा सत्यापित आवास+ सूची से किया जाता है। परिवार बेघर अथवा कच्चे मकान में रहता हो तथा देश में कहीं भी पक्का मकान न हो।"
    },
    {
      q: "PMAY-U 2.0 (शहरी आवास) में ब्याज सब्सिडी (Interest Subsidy) का लाभ कैसे मिलता है?",
      a: "PMAY-U 2.0 के अंतर्गत ₹3 लाख तक वार्षिक आय वाले EWS परिवारों तथा ₹6 लाख तक आय वाले LIG परिवारों को ₹25 लाख तक के गृह ऋण पर 4% तक की ब्याज सब्सिडी (अधिकतम ₹2.67 लाख) बैंकों के माध्यम से प्रदान की जाती है।"
    },
    {
      q: "दस्तावेज़ पासपोर्ट (Document Passport) क्या है और इसका उपयोग कैसे करें?",
      a: "दस्तावेज़ पासपोर्ट आपकी पात्र और सहेजी गई सभी योजनाओं के आवश्यक कागजात की एक संयुक्त सूची तैयार करता है। यह समान दस्तावेजों (जैसे आधार, आय प्रमाण पत्र, खतौनी) को दोहराता नहीं है, जिससे आप एक ही बार में सभी आवश्यक दस्तावेज तैयार कर सकते हैं।"
    },
    {
      q: "यदि मेरी पात्रता 'अधिक जानकारी आवश्यक (More Information Needed)' दर्शाती है तो क्या करें?",
      a: "इसका अर्थ है कि आपके मूल विवरण योजना के अनुकूल हैं, परंतु किसी विशिष्ट शर्त (जैसे भूमि स्वामित्व, पुत्री की आयु या आवास की स्थिति) की पुष्टि शेष है। फॉर्म में उस प्रश्न का उत्तर चुनते ही परिणाम तुरंत अद्यतन हो जाता है।"
    }
  ] : [
    {
      q: "Is entering Aadhaar numbers or bank details mandatory on SchemeSaathi?",
      a: "No. SchemeSaathi is completely confidential and requires zero sensitive personal identifiers. No Aadhaar numbers, bank account numbers, or OTPs are required just to explore possible welfare schemes."
    },
    {
      q: "What are the core conditions to claim ₹1,20,000 under PMAY-G (Rural)?",
      a: "Beneficiaries are identified based on the SECC and Gram Sabha verified Awaas+ list. The household must be homeless or residing in a 0, 1, or 2 room kutcha mud house with no pucca home registered anywhere in India."
    },
    {
      q: "How does the interest subsidy under PMAY-Urban 2.0 work?",
      a: "Eligible EWS households (income up to ₹3L) and LIG households (income up to ₹6L) receiving home loans up to ₹25 Lakhs receive up to 4% upfront interest subsidy (net subsidy up to ₹2.67 Lakhs) credited directly to their loan account."
    },
    {
      q: "What is the Document Passport and how should I use it?",
      a: "The Document Passport combines and deduplicates the documentation requirements of all your eligible schemes. Instead of visiting government offices multiple times with redundant papers, you assemble one unified portfolio with verified issuing authorities."
    },
    {
      q: "What should I do if a scheme status shows 'More Information Needed'?",
      a: "This means your broad parameters qualify, but confirmation of a specific condition (such as landholding size, girl child age, or pucca home ownership) is needed. Select that option in the form and the engine immediately recalculates."
    }
  ];

  return (
    <div className="page-container main-wrapper">
      {/* Title */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.25rem' }}>
          {t('home')} &gt; <strong style={{ color: '#0B4F8A' }}>{t('support')}</strong>
        </div>
        <h1 style={{ fontSize: '1.75rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
          {t('supportPageTitle')}
        </h1>
        <p style={{ fontSize: '0.88rem', color: '#475569' }}>
          {language === 'hi' 
            ? "सरकारी योजनाओं, आवेदन प्रक्रियाओं और दस्तावेज़ सत्यापन से संबंधित सभी शंकाओं का त्वरित समाधान।" 
            : "Instant resolution for government scheme questions, application procedures, and document verification."}
        </p>
      </div>

      {/* 24x7 Helplines Strip */}
      <section className="reveal-on-scroll" style={{ 
        background: 'var(--gov-navy)', 
        borderRadius: 'var(--radius-md)', 
        borderLeft: '4px solid var(--gov-saffron)',
        color: '#FFFFFF', 
        padding: '1.5rem', 
        marginBottom: '2rem',
        boxShadow: 'var(--shadow-subtle)'
      }}>
        <h2 style={{ fontSize: '1.2rem', color: '#FFFFFF', marginBottom: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <PhoneCall size={18} color="#FB923C" />
          <span>{t('helplinesHeading')}</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
          <div style={{ background: 'rgba(255,255,255,0.08)', padding: '0.85rem', borderRadius: '6px' }}>
            <span style={{ fontSize: '0.72rem', color: '#FED7AA', textTransform: 'uppercase' }}>PMAY ग्रामीण आवास</span>
            <div style={{ fontSize: '1.15rem', fontWeight: 800, marginTop: '0.2rem' }}>1800-11-6446</div>
            <small style={{ color: '#CBD5E1' }}>Ministry of Rural Development</small>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', padding: '0.85rem', borderRadius: '6px' }}>
            <span style={{ fontSize: '0.72rem', color: '#FED7AA', textTransform: 'uppercase' }}>PM किसान सम्मान निधि</span>
            <div style={{ fontSize: '1.15rem', fontWeight: 800, marginTop: '0.2rem' }}>155261 / 011-24300606</div>
            <small style={{ color: '#CBD5E1' }}>Agriculture & Farmers Welfare</small>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', padding: '0.85rem', borderRadius: '6px' }}>
            <span style={{ fontSize: '0.72rem', color: '#FED7AA', textTransform: 'uppercase' }}>आयुष्मान भारत (PM-JAY)</span>
            <div style={{ fontSize: '1.15rem', fontWeight: 800, marginTop: '0.2rem' }}>14555 / 1800-111-565</div>
            <small style={{ color: '#CBD5E1' }}>National Health Authority</small>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', padding: '0.85rem', borderRadius: '6px' }}>
            <span style={{ fontSize: '0.72rem', color: '#FED7AA', textTransform: 'uppercase' }}>जनसुनवाई / समाधान यूपी</span>
            <div style={{ fontSize: '1.15rem', fontWeight: 800, marginTop: '0.2rem' }}>1076 (CM Helpline)</div>
            <small style={{ color: '#CBD5E1' }}>Citizen Grievance Redressal</small>
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section className="reveal-on-scroll">
        <h2 style={{ fontSize: '1.3rem', color: 'var(--gov-navy-dark)', fontWeight: 800, marginBottom: '1rem' }}>
          {t('faqHeading')}
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div 
                key={index}
                style={{ 
                  background: '#FFFFFF', 
                  border: '1px solid var(--gov-border)', 
                  borderRadius: '6px',
                  boxShadow: 'var(--shadow-card)',
                  overflow: 'hidden'
                }}
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  style={{
                    width: '100%',
                    padding: '1rem 1.25rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    background: isOpen ? '#F8FAFC' : '#FFFFFF',
                    border: 'none',
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontWeight: 700,
                    fontSize: '0.92rem',
                    color: '#0F172A'
                  }}
                >
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <HelpCircle size={16} color="#0B4F8A" />
                    <span>{faq.q}</span>
                  </span>
                  {isOpen ? <ChevronUp size={18} color="#64748B" /> : <ChevronDown size={18} color="#64748B" />}
                </button>

                {isOpen && (
                  <div style={{ padding: '1rem 1.25rem', fontSize: '0.86rem', color: '#475569', lineHeight: 1.6, borderTop: '1px solid #E2E8F0', background: '#FFFFFF' }}>
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
