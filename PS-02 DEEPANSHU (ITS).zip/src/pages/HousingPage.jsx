import React, { useState } from 'react';
import { 
  Home, 
  Calculator, 
  ArrowRight
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export default function HousingPage({ onNavigateToEligibility }) {
  const { language, t } = useLanguage();
  useScrollReveal();

  const [calcLocation, setCalcLocation] = useState('rural');
  const [calcIncome, setCalcIncome] = useState(150000);

  const calculateSubsidy = () => {
    if (calcLocation === 'rural') {
      return {
        scheme: language === 'hi' ? "प्रधानमंत्री आवास योजना - ग्रामीण (PMAY-G)" : "Pradhan Mantri Awas Yojana - Gramin (PMAY-G)",
        grantAmount: language === 'hi' ? "₹1,20,000 (मैदानी) / ₹1,30,000 (पहाड़ी/दुर्गम)" : "₹1,20,000 (Plain) / ₹1,30,000 (Hilly/NE)",
        toiletGrant: language === 'hi' ? "₹12,000 (स्वच्छ भारत मिशन अभिसरण)" : "₹12,000 (Swachh Bharat Convergence)",
        mgnregaWage: language === 'hi' ? "90-95 दिन की अकुशल मजदूरी (~₹24,000)" : "90-95 person-days (~₹24,000 wages)",
        totalAssistance: language === 'hi' ? "कुल ₹1,56,000 तक प्रत्यक्ष सहायता" : "Up to ₹1,56,000 Direct Support",
        subsidyType: language === 'hi' ? "100% गैर-वापसी योग्य प्रत्यक्ष सरकारी अनुदान (DBT)" : "100% Direct Non-Repayable Grant (DBT)",
        notes: language === 'hi' ? "ग्राम पंचायत आवास+ प्राथमिकता सूची द्वारा लाभार्थी चयन।" : "Beneficiary identified through Gram Panchayat Awaas+ survey list."
      };
    } else {
      if (calcIncome <= 300000) {
        return {
          scheme: language === 'hi' ? "PMAY-शहरी 2.0 (ई.डब्ल्यू.एस श्रेणी)" : "PMAY-Urban 2.0 (EWS Category)",
          grantAmount: language === 'hi' ? "₹25 लाख तक गृह ऋण पर 4% ब्याज सब्सिडी (अधिकतम ₹2.67 लाख)" : "Interest Subsidy of 4% on loan up to ₹25 Lakhs (Net subsidy up to ₹2.67 Lakhs)",
          subsidyType: language === 'hi' ? "ब्याज सब्सिडी योजना (ISS) + BLC निर्माण अनुदान" : "Interest Subsidy Scheme (ISS) + BLC Construction Grant",
          totalAssistance: language === 'hi' ? "अधिकतम ₹2,67,000 नेट सब्सिडी" : "Up to ₹2,67,000 Net Subsidy",
          notes: language === 'hi' ? "परिवार के नाम देश में कहीं भी पक्का मकान न हो।" : "Applicant family must not own a pucca house anywhere in India."
        };
      } else if (calcIncome <= 600000) {
        return {
          scheme: language === 'hi' ? "PMAY-शहरी 2.0 (एल.आई.जी श्रेणी)" : "PMAY-Urban 2.0 (LIG Category)",
          grantAmount: language === 'hi' ? "₹25 लाख तक ऋण पर 3% ब्याज सब्सिडी" : "Interest Subsidy of 3% on loan up to ₹25 Lakhs",
          subsidyType: language === 'hi' ? "क्रेडिट-लिंक्ड ब्याज सब्सिडी (5 वर्षों में)" : "Credit-Linked Interest Subsidy over 5 years",
          totalAssistance: language === 'hi' ? "₹1,80,000 तक सब्सिडी" : "Up to ₹1,80,000 Subsidy Over 5 Years",
          notes: language === 'hi' ? "बैंकों व आवास वित्त संस्थानों के माध्यम से उपलब्ध।" : "Available through primary commercial and housing finance banks."
        };
      } else {
        return {
          scheme: language === 'hi' ? "PMAY-शहरी (आय सीमा से ऊपर)" : "PMAY-Urban (Above LIG Ceiling)",
          grantAmount: language === 'hi' ? "प्राथमिकता क्षेत्र ऋण लाभ" : "General affordable housing loan options",
          subsidyType: language === 'hi' ? "रियायती बैंक ऋण ब्याज दरें" : "Priority Sector Lending Benefits",
          totalAssistance: language === 'hi' ? "सस्ती बैंक ऋण दरें" : "Concessional Bank Loan Interest Rates",
          notes: language === 'hi' ? "आय सीमा ₹6,00,000/वर्ष से अधिक है।" : "Income exceeds EWS/LIG subsidy bracket of ₹6,00,000/yr."
        };
      }
    }
  };

  const subsidyResult = calculateSubsidy();

  return (
    <div className="page-container main-wrapper">
      {/* Breadcrumb & Header */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.25rem' }}>
          {t('home')} &gt; <strong style={{ color: '#0B4F8A' }}>{t('housing')}</strong>
        </div>
        <h1 style={{ fontSize: '1.75rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
          {t('housingPageTitle')}
        </h1>
        <p style={{ fontSize: '0.88rem', color: '#475569' }}>
          {t('housingPageSubtitle')}
        </p>
      </div>

      {/* Hero Banner */}
      <section className="housing-hero-banner reveal-on-scroll">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.5rem' }}>
          <Home size={26} />
          <h2 style={{ fontSize: '1.4rem', color: '#FFFFFF', fontWeight: 800 }}>
            {language === 'hi' ? "प्रधानमंत्री आवास योजना (PMAY Flagship Assistance)" : "Pradhan Mantri Awas Yojana (PMAY Flagship Assistance)"}
          </h2>
        </div>
        <p style={{ fontSize: '0.95rem', color: '#FEF3C7', lineHeight: 1.6, maxWidth: '820px', marginBottom: '1rem' }}>
          {language === 'hi'
            ? "PMAY दो प्रमुख घटकों में विभाजित है: PMAY-ग्रामीण (ग्रामीण बेघर परिवारों हेतु प्रत्यक्ष गैर-वापसी योग्य नकद अनुदान) और PMAY-शहरी 2.0 (शहरी नगरों हेतु क्रेडिट-लिंक्ड ब्याज सब्सिडी एवं BLC निर्माण अनुदान)।"
            : "PMAY is divided into two distinct components: PMAY-Gramin (direct cash grants for rural homeless families) and PMAY-Urban 2.0 (credit-linked interest subsidies and construction grants for urban town residents)."}
        </p>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button 
            className="btn-primary"
            style={{ background: '#FFFFFF', color: '#B45309', fontWeight: 700 }}
            onClick={onNavigateToEligibility}
          >
            <span>{language === 'hi' ? "मेरी आवास पात्रता जांचें" : "Check My PMAY Eligibility"}</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </section>

      {/* Interactive Housing Subsidy Calculator */}
      <section className="housing-calc-box reveal-on-scroll" aria-label="Subsidy Calculator">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem' }}>
          <Calculator size={20} color="#EA580C" />
          <h2 style={{ fontSize: '1.2rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
            {t('housingCalcHeading')}
          </h2>
        </div>
        <p style={{ fontSize: '0.84rem', color: '#64748B', marginBottom: '1.25rem' }}>
          {language === 'hi'
            ? "अपना क्षेत्र और वार्षिक पारिवारिक आय दर्ज करें और अपनी अनुमानित PMAY सहायता राशि देखें:"
            : "Select your setting and annual income to see your approximate PMAY benefit entitlement:"}
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
          <div>
            <label className="form-label">
              <span>{t('labelArea')}</span>
            </label>
            <div className="segmented-cards">
              <button
                type="button"
                className={`segmented-card-btn ${calcLocation === 'rural' ? 'active' : ''}`}
                onClick={() => setCalcLocation('rural')}
              >
                {t('optRural')}
              </button>
              <button
                type="button"
                className={`segmented-card-btn ${calcLocation === 'urban' ? 'active' : ''}`}
                onClick={() => setCalcLocation('urban')}
              >
                {t('optUrban')}
              </button>
            </div>
          </div>

          <div>
            <label className="form-label">
              <span>{t('calcIncomeLabel')}: ₹{calcIncome.toLocaleString('en-IN')}</span>
            </label>
            <input 
              type="range"
              min="40000"
              max="900000"
              step="20000"
              value={calcIncome}
              onChange={(e) => setCalcIncome(parseInt(e.target.value, 10))}
              style={{ width: '100%', accentColor: '#EA580C' }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#64748B' }}>
              <span>₹40,000 (BPL)</span>
              <span>₹3,00,000 (EWS)</span>
              <span>₹6,00,000 (LIG)</span>
              <span>₹9,00,000+</span>
            </div>
          </div>
        </div>

        {/* Calculated Assistance Result Card */}
        <div style={{ 
          background: '#FFFBEB', 
          border: '1.5px solid #FCD34D', 
          borderRadius: '8px', 
          padding: '1.25rem',
          display: 'grid',
          gridTemplateColumns: '1.2fr 1fr',
          gap: '1.5rem',
          alignItems: 'center'
        }}>
          <div>
            <span style={{ fontSize: '0.72rem', fontWeight: 700, color: '#B45309', background: '#FEF3C7', padding: '0.15rem 0.5rem', borderRadius: '4px', textTransform: 'uppercase' }}>
              {language === 'hi' ? "अनुमानित पात्रता परिणाम" : "Calculated Entitlement"}
            </span>
            <h3 style={{ fontSize: '1.15rem', color: '#92400E', margin: '0.4rem 0' }}>
              {subsidyResult.scheme}
            </h3>
            <p style={{ fontSize: '0.85rem', color: '#475569', marginBottom: '0.5rem' }}>
              <strong>{language === 'hi' ? "वित्तीय लाभ: " : "Financial Benefit: "}</strong>{subsidyResult.grantAmount}
            </p>
            {subsidyResult.toiletGrant && (
              <p style={{ fontSize: '0.82rem', color: '#0D8A46' }}>
                <strong>{language === 'hi' ? "+ शौचालय अनुदान: " : "+ Toilet Grant: "}</strong>{subsidyResult.toiletGrant}
              </p>
            )}
            {subsidyResult.mgnregaWage && (
              <p style={{ fontSize: '0.82rem', color: '#0B4F8A' }}>
                <strong>{language === 'hi' ? "+ नरेगा मजदूरी: " : "+ MGNREGA Wages: "}</strong>{subsidyResult.mgnregaWage}
              </p>
            )}
            <p style={{ fontSize: '0.78rem', color: '#64748B', marginTop: '0.4rem' }}>
              ℹ️ {subsidyResult.notes}
            </p>
          </div>

          <div style={{ textAlign: 'center', background: '#FFFFFF', padding: '1.25rem', borderRadius: '8px', border: '1px solid #FDE68A' }}>
            <div style={{ fontSize: '0.74rem', color: '#64748B', fontWeight: 600, textTransform: 'uppercase' }}>
              {t('totalBenefitLabel')}
            </div>
            <div style={{ fontSize: '1.45rem', fontWeight: 800, color: '#B45309', margin: '0.25rem 0' }}>
              {subsidyResult.totalAssistance}
            </div>
            <span style={{ fontSize: '0.72rem', color: '#15803D', fontWeight: 600 }}>
              {subsidyResult.subsidyType}
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
