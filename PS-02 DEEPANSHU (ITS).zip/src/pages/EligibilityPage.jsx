import React from 'react';
import PersonaSelector from '../components/PersonaSelector';
import ProfileForm from '../components/ProfileForm';
import SchemeCard from '../components/SchemeCard';
import { 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  Home, 
  Search, 
  Filter
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export default function EligibilityPage({
  profile,
  setProfile,
  activePersonaId,
  setActivePersonaId,
  personas,
  evaluatedSchemes,
  displayedSchemes,
  activeFilter,
  setActiveFilter,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  savedSchemeIds,
  onToggleSave,
  onViewDetails,
  onInspectAudit
}) {
  const { language, t } = useLanguage();
  useScrollReveal(displayedSchemes);

  const eligibleCount = evaluatedSchemes.filter(s => s.evaluation.status === "eligible").length;
  const needsInfoCount = evaluatedSchemes.filter(s => s.evaluation.status === "needs_info").length;
  const ineligibleCount = evaluatedSchemes.filter(s => s.evaluation.status === "ineligible").length;
  const housingCount = evaluatedSchemes.filter(s => s.isHousingScheme).length;

  const handleSelectPersona = (persona) => {
    setActivePersonaId(persona.id);
    setProfile(persona.profile);
  };

  const handleResetProfile = () => {
    setActivePersonaId(null);
    setProfile({
      state: "Uttar Pradesh",
      location: "rural",
      ageGroup: "36-50",
      age: 42,
      gender: "any",
      occupation: "farmer",
      incomeRange: "100001-200000",
      incomeAmount: 140000,
      socialCategory: "OBC",
      familySize: 4,
      housingType: "kutcha",
      ownsPuccaHouse: "no",
      hasCultivableLand: "no",
      landSizeAcres: 0,
      hasGirlChildUnder10: "no",
      hasSeniorCitizen: "no",
      isStudent: "no",
      isPregnantOrLactating: "no"
    });
  };

  return (
    <div className="page-container main-wrapper">
      {/* Page Title & Breadcrumb */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.25rem' }}>
          {t('home')} &gt; <strong style={{ color: '#0B4F8A' }}>{t('eligibility')}</strong>
        </div>
        <h1 style={{ fontSize: '1.65rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
          {t('finderHeading')}
        </h1>
        <p style={{ fontSize: '0.88rem', color: '#475569' }}>
          {t('finderSubtitle')}
        </p>
      </div>

      {/* 1-Click Citizen Demos */}
      <div className="reveal-on-scroll">
        <PersonaSelector
          personas={personas}
          activePersonaId={activePersonaId}
          onSelectPersona={handleSelectPersona}
        />
      </div>

      {/* Two-Column Grid */}
      <div className="app-grid">
        {/* Left: Profile Form */}
        <aside aria-label="Citizen Intake Form">
          <ProfileForm
            profile={profile}
            onChange={(updated) => {
              setActivePersonaId(null);
              setProfile(updated);
            }}
            onReset={handleResetProfile}
          />
        </aside>

        {/* Right: Results Stream */}
        <section aria-label="Matching Scheme Results">
          <div className="results-header-bar reveal-on-scroll">
            <div className="results-stats-row">
              <div className="results-count-title">
                <h2>
                  <span>{t('resultsHeading')}</span>
                  <span className="results-count-badge">
                    {displayedSchemes.length} {language === 'hi' ? "योजनाएं" : "Schemes"}
                  </span>
                </h2>
              </div>

              {/* Search Bar */}
              <div style={{ position: 'relative', minWidth: '240px' }}>
                <Search size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }} />
                <input 
                  type="text" 
                  placeholder={t('searchPlaceholder')}
                  className="input-text"
                  style={{ paddingLeft: '2rem', fontSize: '0.82rem' }}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Filter Tabs */}
            <div className="filter-tabs-row" role="tablist">
              <button
                className={`filter-tab-btn ${activeFilter === "all" ? "active" : ""}`}
                onClick={() => setActiveFilter("all")}
              >
                {t('filterAll')} ({evaluatedSchemes.length})
              </button>

              <button
                className={`filter-tab-btn ${activeFilter === "eligible" ? "active" : ""}`}
                style={{ color: activeFilter === "eligible" ? '#FFF' : 'var(--status-eligible-text)' }}
                onClick={() => setActiveFilter("eligible")}
              >
                <CheckCircle2 size={13} />
                {t('filterEligible')} ({eligibleCount})
              </button>

              <button
                className={`filter-tab-btn ${activeFilter === "needs_info" ? "active" : ""}`}
                style={{ color: activeFilter === "needs_info" ? '#FFF' : 'var(--status-needs-text)' }}
                onClick={() => setActiveFilter("needs_info")}
              >
                <AlertCircle size={13} />
                {t('filterNeedsInfo')} ({needsInfoCount})
              </button>

              <button
                className={`filter-tab-btn ${activeFilter === "ineligible" ? "active" : ""}`}
                style={{ color: activeFilter === "ineligible" ? '#FFF' : 'var(--status-ineligible-text)' }}
                onClick={() => setActiveFilter("ineligible")}
              >
                <XCircle size={13} />
                {t('filterIneligible')} ({ineligibleCount})
              </button>

              <button
                className={`filter-tab-btn housing-tab ${activeFilter === "housing" ? "active" : ""}`}
                onClick={() => setActiveFilter("housing")}
              >
                <Home size={13} />
                {t('filterHousing')} ({housingCount})
              </button>
            </div>

            {/* Department Filter Chips */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginTop: '0.75rem', overflowX: 'auto', paddingBottom: '0.2rem' }}>
              <span style={{ fontSize: '0.74rem', color: 'var(--text-faint)', fontWeight: 700, whiteSpace: 'nowrap' }}>{t('deptLabel')}</span>
              {["all", "Housing", "Agriculture", "Healthcare", "Employment", "Education", "Social Welfare"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  style={{
                    fontSize: '0.74rem',
                    padding: '0.25rem 0.6rem',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border-strong)',
                    background: selectedCategory === cat ? 'var(--gov-navy)' : '#FFFFFF',
                    color: selectedCategory === cat ? '#FFFFFF' : 'var(--text-main)',
                    fontWeight: selectedCategory === cat ? 700 : 500,
                    cursor: 'pointer',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {cat === "all" ? t('deptAll') : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Scheme Cards Stream */}
          <div className="schemes-list">
            {displayedSchemes.length === 0 ? (
              <div style={{ background: '#FFF', padding: '3rem 1.5rem', textAlign: 'center', borderRadius: '8px', border: '1px solid #CBD5E1' }}>
                <Filter size={32} style={{ margin: '0 auto 0.75rem', color: '#94A3B8' }} />
                <h3 style={{ fontSize: '1.05rem', color: '#1E293B', marginBottom: '0.35rem' }}>
                  {language === 'hi' ? "इस फ़िल्टर से कोई योजना मेल नहीं खाती" : "No schemes match your filter"}
                </h3>
                <p style={{ fontSize: '0.82rem', color: '#64748B', marginBottom: '1rem' }}>
                  {language === 'hi' ? "खोज क्वेरी रीसेट करें या 'सभी' फ़िल्टर चुनें।" : "Reset search query or select 'All'."}
                </p>
                <button 
                  className="btn-secondary"
                  onClick={() => {
                    setActiveFilter("all");
                    setSelectedCategory("all");
                    setSearchQuery("");
                  }}
                >
                  {language === 'hi' ? "फ़िल्टर रीसेट करें" : "Reset Filters"}
                </button>
              </div>
            ) : (
              displayedSchemes.map((scheme) => (
                <div key={scheme.id} className="reveal-on-scroll">
                  <SchemeCard
                    scheme={scheme}
                    isSaved={savedSchemeIds.includes(scheme.id)}
                    onToggleSave={onToggleSave}
                    onViewDetails={onViewDetails}
                    onInspectAudit={onInspectAudit}
                  />
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
