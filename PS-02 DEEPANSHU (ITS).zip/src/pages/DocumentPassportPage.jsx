import React, { useState } from 'react';
import { 
  Printer, 
  Copy, 
  Check
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export default function DocumentPassportPage({ 
  schemes, 
  savedSchemeIds 
}) {
  const { language, t } = useLanguage();
  useScrollReveal();

  const [filterMode, setFilterMode] = useState("all-eligible");
  const [checkedDocs, setCheckedDocs] = useState(() => {
    try {
      const saved = localStorage.getItem("schemesathi_docs_readiness");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [copied, setCopied] = useState(false);

  // Filter schemes
  const relevantSchemes = schemes.filter(s => {
    if (filterMode === "shortlisted") return savedSchemeIds.includes(s.id);
    if (filterMode === "all-12") return true;
    return s.evaluation?.status === "eligible" || s.evaluation?.status === "needs_info";
  });

  // Deduplicate documents
  const docMap = new Map();
  relevantSchemes.forEach(scheme => {
    scheme.requiredDocuments.forEach(doc => {
      const cleanKey = doc.name.trim().toLowerCase();
      if (!docMap.has(cleanKey)) {
        docMap.set(cleanKey, {
          name: doc.name,
          issuingAuthority: doc.issuingAuthority,
          description: doc.description,
          schemesNeeded: [language === 'hi' ? scheme.nameHindi : scheme.name]
        });
      } else {
        const existing = docMap.get(cleanKey);
        const schemeTitle = language === 'hi' ? scheme.nameHindi : scheme.name;
        if (!existing.schemesNeeded.includes(schemeTitle)) {
          existing.schemesNeeded.push(schemeTitle);
        }
      }
    });
  });

  const docList = Array.from(docMap.values());
  const completedCount = docList.filter(d => checkedDocs[d.name]).length;
  const readinessPercent = docList.length > 0 ? Math.round((completedCount / docList.length) * 100) : 0;

  const toggleCheck = (docName) => {
    const updated = {
      ...checkedDocs,
      [docName]: !checkedDocs[docName]
    };
    setCheckedDocs(updated);
    try {
      localStorage.setItem("schemesathi_docs_readiness", JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCopyText = () => {
    let text = `📋 SCHEMESAATHI DOCUMENT PASSPORT / एकीकृत दस्तावेज़ पासपोर्ट\n`;
    text += `Readiness Level: ${completedCount}/${docList.length} (${readinessPercent}% Prepared)\n\n`;
    
    docList.forEach((d, idx) => {
      const isDone = checkedDocs[d.name] ? "[✓ Ready / तैयार]" : "[⌛ Pending / शेष]";
      text += `${idx + 1}. ${isDone} ${d.name}\n`;
      text += `   • Issuing Authority: ${d.issuingAuthority}\n`;
      text += `   • Required for: ${d.schemesNeeded.join(", ")}\n\n`;
    });

    text += `Generated via SchemeSaathi • eDistrict Portal\n`;

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="page-container main-wrapper">
      {/* Breadcrumb & Title */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.25rem' }}>
          {t('home')} &gt; <strong style={{ color: '#0B4F8A' }}>{t('passport')}</strong>
        </div>
        <h1 style={{ fontSize: '1.75rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
          {t('passportPageTitle')}
        </h1>
        <p style={{ fontSize: '0.88rem', color: '#475569' }}>
          {t('passportPageSubtitle')}
        </p>
      </div>

      {/* Progress & Readiness Banner */}
      <section className="reveal-on-scroll" style={{ 
        background: '#FFFFFF', 
        border: '1px solid var(--gov-border)', 
        borderRadius: '8px', 
        padding: '1.25rem', 
        boxShadow: 'var(--shadow-card)',
        marginBottom: '1.5rem'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.65rem' }}>
          <div>
            <span style={{ fontSize: '0.78rem', fontWeight: 700, color: '#0B4F8A', textTransform: 'uppercase' }}>
              {t('passportReadiness')}
            </span>
            <h3 style={{ fontSize: '1.15rem', color: '#0F172A', marginTop: '0.15rem' }}>
              {language === 'hi'
                ? `आपके ${docList.length} में से ${completedCount} दस्तावेज़ तैयार हैं`
                : `${completedCount} of ${docList.length} documents ready`}
            </h3>
          </div>
          <div style={{ 
            fontSize: '1.2rem', 
            fontWeight: 800, 
            color: readinessPercent >= 80 ? '#0D8A46' : '#EA580C',
            background: readinessPercent >= 80 ? '#DCFCE7' : '#FEF3C7',
            padding: '0.35rem 0.85rem',
            borderRadius: '6px'
          }}>
            {readinessPercent}% {t('passportComplete')}
          </div>
        </div>

        <div style={{ width: '100%', height: '10px', background: '#E2E8F0', borderRadius: '5px', overflow: 'hidden' }}>
          <div style={{ 
            width: `${readinessPercent}%`, 
            height: '100%', 
            background: readinessPercent >= 80 ? '#10B981' : '#EA580C', 
            transition: 'width 0.4s ease' 
          }} />
        </div>
        <p style={{ fontSize: '0.78rem', color: '#64748B', marginTop: '0.45rem' }}>
          {language === 'hi' 
            ? "दस्तावेज़ तैयार होने पर नीचे चेकबॉक्स टिक करें। यह पासपोर्ट आपके ब्राउज़र में सुरक्षित रहता है।"
            : "Check off items as you assemble them. Your checklist is safely remembered on your device."}
        </p>
      </section>

      {/* Action Toolbar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '1.25rem' }}>
        <div className="segmented-cards" style={{ width: 'auto', display: 'flex' }}>
          <button
            className={`segmented-card-btn ${filterMode === "all-eligible" ? "active" : ""}`}
            onClick={() => setFilterMode("all-eligible")}
          >
            {language === 'hi' ? "पात्र योजनाएं" : "Eligible Schemes"} ({schemes.filter(s => s.evaluation?.status === 'eligible').length})
          </button>
          <button
            className={`segmented-card-btn ${filterMode === "shortlisted" ? "active" : ""}`}
            onClick={() => setFilterMode("shortlisted")}
          >
            {language === 'hi' ? "सहेजी गई योजनाएं" : "Shortlisted"} ({savedSchemeIds.length})
          </button>
          <button
            className={`segmented-card-btn ${filterMode === "all-12" ? "active" : ""}`}
            onClick={() => setFilterMode("all-12")}
          >
            {language === 'hi' ? "सभी 12 योजनाएं" : "All 12 Schemes"}
          </button>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button 
            className="btn-secondary"
            onClick={handleCopyText}
            style={{ fontSize: '0.82rem' }}
            title="Copy checklist text for WhatsApp or SMS"
          >
            {copied ? <Check size={14} color="#0D8A46" /> : <Copy size={14} />}
            <span>{copied ? t('passportCopied') : t('passportCopyBtn')}</span>
          </button>

          <button 
            className="btn-primary"
            onClick={() => window.print()}
            style={{ fontSize: '0.82rem' }}
            title="Print official document preparation checklist"
          >
            <Printer size={14} />
            <span>{t('passportPrintBtn')}</span>
          </button>
        </div>
      </div>

      {/* Documents Stream */}
      <div className="doc-list" role="list">
        {docList.map((doc, idx) => {
          const isChecked = !!checkedDocs[doc.name];
          return (
            <div 
              key={idx} 
              className={`doc-passport-item reveal-on-scroll ${isChecked ? 'checked' : ''}`}
              role="listitem"
            >
              <input 
                type="checkbox" 
                className="doc-checkbox" 
                id={`doc-page-${idx}`}
                checked={isChecked}
                onChange={() => toggleCheck(doc.name)}
                aria-label={`Mark ${doc.name} as ready`}
              />
              <div style={{ flex: 1 }}>
                <div className="doc-title">{doc.name}</div>
                <div className="doc-authority">
                  <span>{t('whereToGet')}</span>
                  <strong>{doc.issuingAuthority}</strong>
                </div>
                <div style={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.45 }}>
                  {doc.description}
                </div>

                <div className="doc-schemes-tags">
                  <span style={{ fontSize: '0.72rem', color: '#64748B', alignSelf: 'center', fontWeight: 600 }}>
                    {t('unlocksSchemes')}
                  </span>
                  {doc.schemesNeeded.map((sn, i) => (
                    <span key={i} className="doc-scheme-tag">
                      {sn}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
