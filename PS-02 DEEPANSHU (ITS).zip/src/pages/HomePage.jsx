import React from 'react';
import EDistrictHero from '../components/EDistrictHero';
import { 
  Home, 
  Wheat, 
  Stethoscope, 
  GraduationCap, 
  Briefcase, 
  HeartHandshake, 
  ArrowRight, 
  CheckCircle2, 
  FileText,
  HelpCircle,
  ShieldCheck,
  Check
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export default function HomePage({ 
  onNavigate, 
  onSelectCategory, 
  selectedCategory,
  onOpenPassport,
  onOpenShortlist
}) {
  const { language, t } = useLanguage();
  useScrollReveal();

  return (
    <div className="page-container">
      {/* 1. Compact Service Portal Introduction with Restrained Facts Strip */}
      <EDistrictHero
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          onSelectCategory(cat);
          onNavigate('eligibility');
        }}
        onOpenPassport={onOpenPassport}
        onOpenShortlist={onOpenShortlist}
        onScrollToForm={() => onNavigate('eligibility')}
      />

      <div className="main-wrapper">
        {/* 2. Major Department Services Grid */}
        <section aria-labelledby="dept-heading" style={{ marginTop: '1.5rem' }}>
          <div className="reveal-on-scroll">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '0.5rem' }}>
              <div>
                <span style={{ fontSize: '0.74rem', fontWeight: 700, color: 'var(--gov-saffron)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  {language === 'hi' ? "विभागीय योजनाएं (Government Departments)" : "Departmental Welfare Services"}
                </span>
                <h2 id="dept-heading" style={{ fontSize: '1.35rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
                  {language === 'hi' ? "प्रमुख कल्याणकारी सेवाएं एवं योजनाएं" : "Welfare Schemes Directory by Category"}
                </h2>
              </div>
              <button 
                className="btn-secondary"
                onClick={() => onNavigate('eligibility')}
                style={{ fontSize: '0.82rem' }}
              >
                <span>{language === 'hi' ? "सभी 12 योजनाएं देखें" : "View All 12 Schemes"}</span>
                <ArrowRight size={14} />
              </button>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem', maxWidth: '800px' }}>
              {language === 'hi' 
                ? "पात्रता मापदंडों, मिलने वाली सहायता राशि और आवश्यक दस्तावेजों की विस्तृत जानकारी हेतु किसी भी विभाग का चयन करें।" 
                : "Select a department to review eligibility criteria, benefit entitlement, and verified official application portals."}
            </p>
          </div>

          <div className="dept-services-grid" style={{ marginTop: '1.25rem' }}>
            {/* Dept 1: Housing */}
            <div className="dept-card reveal-on-scroll" style={{ borderTop: '3px solid var(--gov-saffron)' }}>
              <div>
                <div className="dept-card-top">
                  <div className="dept-icon-box" style={{ background: 'var(--gov-saffron-light)', color: 'var(--gov-saffron)' }}>
                    <Home size={20} />
                  </div>
                  <div>
                    <h3 className="dept-card-title">{language === 'hi' ? "आवास एवं शहरी कार्य" : "Housing & Urban Affairs"}</h3>
                    <span className="dept-card-hindi">PMAY-Gramin & Urban 2.0</span>
                  </div>
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  {language === 'hi' 
                    ? "ग्रामीण एवं शहरी बेघर व कच्चे मकानों में रहने वाले पात्र परिवारों के लिए नकद निर्माण अनुदान एवं ब्याज सब्सिडी।" 
                    : "Direct construction grants and interest subsidies for eligible rural and urban households without pucca homes."}
                </p>
                <ul className="dept-schemes-list">
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> PMAY-G (Rural Housing: ₹1.2L grant + ₹12K toilet)</li>
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> PMAY-U 2.0 (Urban Housing: Interest subsidy up to ₹2.67L)</li>
                </ul>
              </div>
              <button 
                className="btn-secondary" 
                style={{ justifyContent: 'center', width: '100%', borderColor: 'var(--gov-saffron)', color: 'var(--gov-saffron)' }}
                onClick={() => onNavigate('housing')}
              >
                <span>{language === 'hi' ? "आवास मिशन विवरण →" : "View Housing Assistance →"}</span>
              </button>
            </div>

            {/* Dept 2: Agriculture */}
            <div className="dept-card reveal-on-scroll" style={{ borderTop: '3px solid #237A45' }}>
              <div>
                <div className="dept-card-top">
                  <div className="dept-icon-box" style={{ background: '#EDF7EE', color: '#237A45' }}>
                    <Wheat size={20} />
                  </div>
                  <div>
                    <h3 className="dept-card-title">{language === 'hi' ? "कृषि एवं किसान कल्याण" : "Agriculture & Farmers Welfare"}</h3>
                    <span className="dept-card-hindi">PM-KISAN Samman Nidhi</span>
                  </div>
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  {language === 'hi'
                    ? "कृषि योग्य भूमि वाले छोटे एवं सीमांत किसान परिवारों को ₹6,000 प्रति वर्ष की प्रत्यक्ष आय सहायता (DBT)।"
                    : "Direct income support of ₹6,000 per year in 3 equal installments for landholding farmer families."}
                </p>
                <ul className="dept-schemes-list">
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> PM-KISAN (₹6,000/yr direct bank transfer)</li>
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> PM-KMY (₹3,000/mo farmer pension after age 60)</li>
                </ul>
              </div>
              <button 
                className="btn-secondary" 
                style={{ justifyContent: 'center', width: '100%' }}
                onClick={() => {
                  onSelectCategory('Agriculture');
                  onNavigate('eligibility');
                }}
              >
                <span>{language === 'hi' ? "कृषि योजनाएं देखें →" : "Explore Agriculture Schemes →"}</span>
              </button>
            </div>

            {/* Dept 3: Healthcare */}
            <div className="dept-card reveal-on-scroll" style={{ borderTop: '3px solid var(--gov-navy)' }}>
              <div>
                <div className="dept-card-top">
                  <div className="dept-icon-box" style={{ background: '#EFF6FF', color: 'var(--gov-navy)' }}>
                    <Stethoscope size={20} />
                  </div>
                  <div>
                    <h3 className="dept-card-title">{language === 'hi' ? "स्वास्थ्य एवं परिवार कल्याण" : "Health & Family Welfare"}</h3>
                    <span className="dept-card-hindi">AB-PMJAY & Matru Vandana</span>
                  </div>
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  {language === 'hi'
                    ? "द्वितीयक एवं तृतीयक अस्पताल भर्ती हेतु ₹5 लाख प्रति परिवार का वार्षिक कैशलेस स्वास्थ्य कवर।"
                    : "Cashless secondary and tertiary hospitalization cover of up to ₹5 Lakh per eligible family per year."}
                </p>
                <ul className="dept-schemes-list">
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> Ayushman Bharat (₹5 Lakh annual hospital cover)</li>
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> PMMVY (₹5,000 maternity cash benefit)</li>
                </ul>
              </div>
              <button 
                className="btn-secondary" 
                style={{ justifyContent: 'center', width: '100%' }}
                onClick={() => {
                  onSelectCategory('Healthcare');
                  onNavigate('eligibility');
                }}
              >
                <span>{language === 'hi' ? "स्वास्थ्य योजनाएं देखें →" : "Explore Health Schemes →"}</span>
              </button>
            </div>

            {/* Dept 4: Social Welfare & Pension */}
            <div className="dept-card reveal-on-scroll" style={{ borderTop: '3px solid #78350F' }}>
              <div>
                <div className="dept-card-top">
                  <div className="dept-icon-box" style={{ background: '#FFFBEB', color: '#92400E' }}>
                    <HeartHandshake size={20} />
                  </div>
                  <div>
                    <h3 className="dept-card-title">{language === 'hi' ? "सामाजिक न्याय एवं अधिकारिता" : "Social Security & Pensions"}</h3>
                    <span className="dept-card-hindi">IGNOAPS, Sukanya & Vishwakarma</span>
                  </div>
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  {language === 'hi'
                    ? "बुजुर्गों के लिए मासिक पेंशन, बालिकाओं हेतु उच्च-ब्याज बचत और पारंपरिक कारीगरों हेतु टूलकिट सहायता।"
                    : "Monthly old age pensions, girl-child long-term savings, and toolkit financial support for traditional artisans."}
                </p>
                <ul className="dept-schemes-list">
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> Old Age Pension (₹1,000/mo for BPL seniors 60+)</li>
                  <li><CheckCircle2 size={13} color="var(--status-eligible-text)" /> Sukanya Samriddhi (8.2% sovereign return for girl child)</li>
                </ul>
              </div>
              <button 
                className="btn-secondary" 
                style={{ justifyContent: 'center', width: '100%' }}
                onClick={() => {
                  onSelectCategory('Social Welfare');
                  onNavigate('eligibility');
                }}
              >
                <span>{language === 'hi' ? "पेंशन व कल्याण देखें →" : "Explore Pension Schemes →"}</span>
              </button>
            </div>
          </div>
        </section>

        {/* 3. How SchemeSaathi Works (Practical, Civic Workflow) */}
        <section style={{ marginTop: '2.5rem', background: '#FFFFFF', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: '1.5rem' }} aria-label="How SchemeSaathi Works">
          <div style={{ marginBottom: '1rem' }}>
            <span style={{ fontSize: '0.74rem', fontWeight: 700, color: 'var(--gov-navy)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
              {language === 'hi' ? "कार्यप्रणाली / Service Process" : "How It Works"}
            </span>
            <h3 style={{ fontSize: '1.2rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
              {language === 'hi' ? "तीन सरल चरणों में पात्रता जांचें और आवेदन की तैयारी करें" : "Three Simple Steps to Discover and Prepare"}
            </h3>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem' }}>
            <div style={{ borderLeft: '3px solid var(--gov-navy)', paddingLeft: '0.85rem' }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--gov-navy)', marginBottom: '0.2rem' }}>
                {language === 'hi' ? "चरण 1: बुनियादी विवरण दर्ज करें" : "Step 1: Share Basic Household Details"}
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                {language === 'hi' 
                  ? "राज्य, ग्रामीण/शहरी क्षेत्र, व्यवसाय, वार्षिक आय और आवास की स्थिति चुनें। कोई नाम या आधार नंबर आवश्यक नहीं है।"
                  : "Select state, rural/urban setting, occupation, income range, and housing status. No name or ID number required."}
              </p>
            </div>

            <div style={{ borderLeft: '3px solid var(--gov-saffron)', paddingLeft: '0.85rem' }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--gov-saffron)', marginBottom: '0.2rem' }}>
                {language === 'hi' ? "चरण 2: पारदर्शी नियम-आधारित परिणाम" : "Step 2: Transparent Rule Matching"}
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                {language === 'hi'
                  ? "सिस्टम प्रत्येक योजना के आधिकारिक नियमों के विरुद्ध आपकी स्थिति का मूल्यांकन करता है और स्पष्ट कारण बताता है।"
                  : "The system compares your inputs against official criteria and clearly explains why you may or may not qualify."}
              </p>
            </div>

            <div style={{ borderLeft: '3px solid #237A45', paddingLeft: '0.85rem' }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#237A45', marginBottom: '0.2rem' }}>
                {language === 'hi' ? "चरण 3: दस्तावेज़ चेकलिस्ट व आधिकारिक लिंक" : "Step 3: Document Checklist & Links"}
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                {language === 'hi'
                  ? "एकल एकीकृत दस्तावेज़ पासपोर्ट से आवश्यक प्रमाणपत्र तैयार करें और आधिकारिक पोर्टल पर सीधे आवेदन करें।"
                  : "Get a single unified document checklist across all qualifying schemes and visit official portals directly."}
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
