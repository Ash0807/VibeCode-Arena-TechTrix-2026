import React, { useState } from 'react';
import { SCHEMES } from '../data/schemes';
import { 
  Building2, 
  ExternalLink, 
  Search, 
  Filter, 
  FileText, 
  CheckCircle2, 
  ArrowRight,
  Home
} from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';

export default function ServicesDirectoryPage({ onViewDetails, onToggleSave, savedSchemeIds }) {
  useScrollReveal();

  const [activeDept, setActiveDept] = useState("all");
  const [search, setSearch] = useState("");

  const departments = [
    { id: "all", name: "सभी विभाग (All Departments)" },
    { id: "Housing", name: "आवास एवं शहरी नियोजन (Housing)" },
    { id: "Agriculture", name: "कृषि एवं किसान कल्याण (Agriculture)" },
    { id: "Healthcare", name: "चिकित्सा, स्वास्थ्य व परिवार कल्याण (Health)" },
    { id: "Social Welfare", name: "महिला व समाज कल्याण (Social Security)" },
    { id: "Education", name: "उच्च शिक्षा एवं छात्रवृत्ति (Education)" },
    { id: "Employment", name: "सूक्ष्म उद्यम, कौशल व आजीविका (MSME/Labor)" }
  ];

  const filtered = SCHEMES.filter(s => {
    if (activeDept !== "all" && s.category !== activeDept) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const match = s.name.toLowerCase().includes(q) || s.nameHindi.toLowerCase().includes(q) || s.ministry.toLowerCase().includes(q) || s.purpose.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="page-container main-wrapper">
      {/* Title */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.78rem', color: '#64748B', marginBottom: '0.25rem' }}>
          मुख्य पृष्ठ &gt; <strong style={{ color: '#0B4F8A' }}>विभागीय सेवाएं एवं योजना निर्देशिका</strong>
        </div>
        <h1 style={{ fontSize: '1.75rem', color: 'var(--gov-navy-dark)', fontWeight: 800 }}>
          केंद्रीय व राज्य कल्याणकारी योजनाओं की निर्देशिका
        </h1>
        <p style={{ fontSize: '0.88rem', color: '#475569' }}>
          भारत सरकार एवं उत्तर प्रदेश शासन की प्रमुख 12 लोक कल्याणकारी योजनाओं का संपूर्ण विवरण, उद्देश्य, देय लाभ और आधिकारिक आवेदन लिंक।
        </p>
      </div>

      {/* Search & Department Selector */}
      <div style={{ 
        background: '#FFFFFF', 
        border: '1px solid var(--gov-border)', 
        borderRadius: '8px', 
        padding: '1.25rem', 
        boxShadow: 'var(--shadow-card)',
        marginBottom: '1.75rem' 
      }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center', marginBottom: '1rem' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '260px' }}>
            <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }} />
            <input 
              type="text"
              placeholder="योजना का नाम या कीवर्ड खोजें (Search scheme by name or purpose)..."
              className="input-text"
              style={{ paddingLeft: '2.2rem' }}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div style={{ fontSize: '0.85rem', color: '#64748B', fontWeight: 600 }}>
            कुल उपलब्ध: <strong style={{ color: '#0B4F8A' }}>{filtered.length} योजनाएं</strong>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.45rem', flexWrap: 'wrap' }}>
          {departments.map(dept => (
            <button
              key={dept.id}
              onClick={() => setActiveDept(dept.id)}
              style={{
                fontSize: '0.76rem',
                padding: '0.35rem 0.75rem',
                borderRadius: '4px',
                border: '1px solid #CBD5E1',
                background: activeDept === dept.id ? '#0B4F8A' : '#F8FAFC',
                color: activeDept === dept.id ? '#FFFFFF' : '#334155',
                fontWeight: activeDept === dept.id ? 700 : 500,
                cursor: 'pointer'
              }}
            >
              {dept.name}
            </button>
          ))}
        </div>
      </div>

      {/* Directory Grid with Scroll Reveals */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.25rem' }}>
        {filtered.map(scheme => {
          const isSaved = savedSchemeIds.includes(scheme.id);
          return (
            <div 
              key={scheme.id}
              className="reveal-on-scroll"
              style={{ 
                background: '#FFFFFF', 
                border: scheme.isHousingScheme ? '1.5px solid #F59E0B' : '1px solid var(--gov-border)', 
                borderRadius: '8px', 
                padding: '1.25rem',
                boxShadow: 'var(--shadow-card)',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative'
              }}
            >
              {scheme.isHousingScheme && (
                <div style={{ position: 'absolute', top: 10, right: 10, background: '#FEF3C7', color: '#92400E', fontSize: '0.68rem', fontWeight: 700, padding: '0.15rem 0.45rem', borderRadius: '4px', border: '1px solid #FCD34D' }}>
                  आवास मिशन (PMAY)
                </div>
              )}

              <div>
                <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#0B4F8A', textTransform: 'uppercase' }}>
                  {scheme.ministry}
                </span>
                <h3 style={{ fontSize: '1.05rem', color: '#0F172A', marginTop: '0.2rem', lineHeight: 1.3 }}>
                  {scheme.name}
                </h3>
                <span style={{ fontSize: '0.8rem', color: '#EA580C', fontWeight: 600, display: 'block', marginBottom: '0.5rem' }}>
                  {scheme.nameHindi}
                </span>

                <p style={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.45, marginBottom: '0.75rem' }}>
                  {scheme.purpose}
                </p>

                <div style={{ background: '#F8FAFC', padding: '0.65rem', borderRadius: '6px', fontSize: '0.8rem', marginBottom: '0.85rem' }}>
                  <strong style={{ color: '#0B4F8A' }}>मुख्य लाभ: </strong>
                  <span>{scheme.benefits[0]?.description}</span>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '0.75rem', borderTop: '1px solid #E2E8F0' }}>
                <button 
                  className="btn-primary"
                  style={{ fontSize: '0.8rem', padding: '0.45rem 0.85rem' }}
                  onClick={() => onViewDetails({ ...scheme, evaluation: { status: 'eligible', auditTrail: [], shortReason: 'Manual directory view' } })}
                >
                  <span>विस्तार से देखें</span>
                  <ArrowRight size={13} />
                </button>

                <a 
                  href={scheme.officialLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                  style={{ fontSize: '0.78rem', padding: '0.45rem 0.75rem' }}
                >
                  <span>आधिकारिक पोर्टल ↗</span>
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
