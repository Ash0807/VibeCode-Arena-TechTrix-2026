/**
 * Transparent Rule-Based Eligibility Engine for SchemeSaathi
 * 
 * Classifies schemes into:
 * 1. "eligible" -> Potentially Eligible — संभावित पात्र
 * 2. "needs_info" -> More Information Needed — अधिक जानकारी आवश्यक
 * 3. "ineligible" -> Criteria Not Met — पात्रता की शर्त पूरी नहीं हुई
 */

export function evaluateSchemeEligibility(scheme, profile) {
  const auditTrail = [];
  let status = "eligible"; // Tentative starting point
  let shortReason = "";
  let missingQuestions = [];

  const userAge = parseInt(profile.age, 10) || (profile.ageGroup === "60+" ? 65 : profile.ageGroup === "36-50" ? 40 : profile.ageGroup === "26-35" ? 30 : profile.ageGroup === "18-25" ? 21 : 16);
  const userIncome = typeof profile.incomeAmount === "number" ? profile.incomeAmount : (
    profile.incomeRange === "0-100000" ? 75000 :
    profile.incomeRange === "100001-200000" ? 150000 :
    profile.incomeRange === "200001-300000" ? 250000 :
    profile.incomeRange === "300001-600000" ? 450000 :
    profile.incomeRange === "600001-800000" ? 700000 : 950000
  );

  // 1. EVALUATE LOCATION (Rural vs Urban)
  if (scheme.rules.location) {
    if (!profile.location) {
      auditTrail.push({
        criterion: "Location (Rural / Urban)",
        status: "missing",
        detail: `Scheme is restricted to ${scheme.rules.location.join(" or ")} areas. Please specify your location.`
      });
      missingQuestions.push("location");
    } else if (scheme.rules.location.includes(profile.location)) {
      auditTrail.push({
        criterion: "Location",
        status: "pass",
        detail: `Matches your location (${profile.location === "rural" ? "Rural / ग्रामीण" : "Urban / शहरी"}).`
      });
    } else {
      auditTrail.push({
        criterion: "Location",
        status: "fail",
        detail: `Requires ${scheme.rules.location.join("/")} residence, but profile is set to ${profile.location}.`
      });
      status = "ineligible";
      shortReason = `This scheme is exclusively for ${scheme.rules.location.join("/")} areas, while you are currently located in an ${profile.location} area.`;
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // 2. EVALUATE AGE
  if (scheme.rules.minAge !== undefined) {
    if (userAge < scheme.rules.minAge) {
      auditTrail.push({
        criterion: "Minimum Age",
        status: "fail",
        detail: `Minimum age required is ${scheme.rules.minAge} years (current profile age is ~${userAge} years).`
      });
      status = "ineligible";
      shortReason = `Minimum age requirement is ${scheme.rules.minAge} years, while your recorded age is ${userAge} years.`;
      return { status, auditTrail, shortReason, missingQuestions };
    } else {
      auditTrail.push({
        criterion: "Minimum Age",
        status: "pass",
        detail: `Applicant meets the minimum age requirement of ${scheme.rules.minAge} years.`
      });
    }
  }

  if (scheme.rules.maxAge !== undefined) {
    if (userAge > scheme.rules.maxAge) {
      auditTrail.push({
        criterion: "Maximum Age Ceiling",
        status: "fail",
        detail: `Upper age limit is ${scheme.rules.maxAge} years (current profile age is ~${userAge} years).`
      });
      status = "ineligible";
      shortReason = `Age exceeds the maximum eligibility ceiling of ${scheme.rules.maxAge} years.`;
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // 3. EVALUATE INCOME CEILING
  if (scheme.rules.maxIncome) {
    if (userIncome > scheme.rules.maxIncome) {
      auditTrail.push({
        criterion: "Annual Household Income",
        status: "fail",
        detail: `Annual family income exceeds scheme ceiling of ₹${scheme.rules.maxIncome.toLocaleString('en-IN')} (profile is ~₹${userIncome.toLocaleString('en-IN')}).`
      });
      status = "ineligible";
      shortReason = `Family annual income (₹${userIncome.toLocaleString('en-IN')}) is above the threshold ceiling of ₹${scheme.rules.maxIncome.toLocaleString('en-IN')}.`;
      return { status, auditTrail, shortReason, missingQuestions };
    } else {
      auditTrail.push({
        criterion: "Annual Household Income",
        status: "pass",
        detail: `Family income (~₹${userIncome.toLocaleString('en-IN')}) is within the allowable limit of ₹${scheme.rules.maxIncome.toLocaleString('en-IN')}.`
      });
    }
  }

  // 4. HOUSING-SPECIFIC EVALUATIONS (PMAY-G / PMAY-U)
  if (scheme.id === "pmay-g") {
    if (profile.ownsPuccaHouse === "yes") {
      auditTrail.push({
        criterion: "Pucca House Exclusion",
        status: "fail",
        detail: "PMAY-G excludes any household that already owns a pucca (permanent concrete) house."
      });
      status = "ineligible";
      shortReason = "Not eligible because household already owns a pucca (permanent) home.";
      return { status, auditTrail, shortReason, missingQuestions };
    } else if (profile.housingType === "kutcha" || profile.housingType === "homeless") {
      auditTrail.push({
        criterion: "Housing Deprivation Criterion",
        status: "pass",
        detail: "Household resides in a kutcha / unbuilt structure, fulfilling prime PMAY-G beneficiary priority."
      });
    } else if (!profile.housingType || profile.housingType === "not-specified") {
      auditTrail.push({
        criterion: "Housing Structure Verification",
        status: "missing",
        detail: "Need confirmation whether your current rural dwelling is kutcha (mud/thatch) or dilapidated."
      });
      missingQuestions.push("housingType");
    }
  }

  if (scheme.id === "pmay-u") {
    if (profile.ownsPuccaHouse === "yes") {
      auditTrail.push({
        criterion: "Pucca House Exclusion",
        status: "fail",
        detail: "PMAY-U requires that no family member owns a pucca house in any statutory town in India."
      });
      status = "ineligible";
      shortReason = "Ineligible as PMAY-U requires that the applicant family does not own a pucca house anywhere in India.";
      return { status, auditTrail, shortReason, missingQuestions };
    } else if (profile.housingType === "rented" || profile.housingType === "kutcha" || profile.housingType === "homeless") {
      auditTrail.push({
        criterion: "Urban Housing Status",
        status: "pass",
        detail: `Currently living in ${profile.housingType} accommodation without home ownership.`
      });
    } else {
      auditTrail.push({
        criterion: "Urban Housing Status",
        status: "missing",
        detail: "Confirm whether you currently rent, live in a slum/kutcha dwelling, or own land for BLC construction."
      });
      missingQuestions.push("housingType");
    }
  }

  // 5. OCCUPATION & DOMAIN-SPECIFIC RULES
  // PM-KISAN
  if (scheme.id === "pm-kisan") {
    if (profile.occupation === "farmer") {
      if (profile.hasCultivableLand === "yes") {
        auditTrail.push({
          criterion: "Landholding Farmer Status",
          status: "pass",
          detail: `Cultivable land verified (~${profile.landSizeAcres || "marginal"} acres).`
        });
      } else if (profile.hasCultivableLand === "no") {
        auditTrail.push({
          criterion: "Cultivable Land Record (RoR)",
          status: "fail",
          detail: "PM-KISAN requires ownership of cultivable land in the name of the farmer."
        });
        status = "ineligible";
        shortReason = "Ineligible because PM-KISAN mandates ownership of cultivable agricultural land.";
        return { status, auditTrail, shortReason, missingQuestions };
      } else {
        auditTrail.push({
          criterion: "Cultivable Land Record",
          status: "missing",
          detail: "Please confirm whether you hold cultivable agricultural land registered in your family name."
        });
        missingQuestions.push("hasCultivableLand");
      }
    } else if (profile.occupation === "agricultural-laborer") {
      auditTrail.push({
        criterion: "Land Title Ownership",
        status: "missing",
        detail: "Agricultural laborers without land titles are not eligible for PM-KISAN, but may be eligible if land is registered."
      });
      missingQuestions.push("hasCultivableLand");
    } else {
      auditTrail.push({
        criterion: "Agricultural Occupation",
        status: "fail",
        detail: "PM-KISAN is exclusively for cultivable landholding farmers."
      });
      status = "ineligible";
      shortReason = "Requires farmer occupation with cultivable agricultural land records.";
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // PM SVANIDHI
  if (scheme.id === "pm-svanidhi") {
    if (profile.occupation === "street-vendor") {
      auditTrail.push({
        criterion: "Vendor / Hawker Activity",
        status: "pass",
        detail: "Applicant is engaged in street vending in urban area."
      });
    } else if (["informal-worker", "daily-wage-worker", "self-employed"].includes(profile.occupation)) {
      auditTrail.push({
        criterion: "Vending Certificate / LoR",
        status: "missing",
        detail: "Requires Certificate of Vending (CoV) or Letter of Recommendation (LoR) from Town Vending Committee."
      });
      missingQuestions.push("vendingProof");
    } else {
      auditTrail.push({
        criterion: "Street Vending Occupation",
        status: "fail",
        detail: "Scheme is specifically designed for urban street hawkers and roadside vendors."
      });
      status = "ineligible";
      shortReason = "Designed specifically for urban street vendors and roadside micro-merchants.";
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // PM VISHWAKARMA
  if (scheme.id === "pm-vishwakarma") {
    const artisanTrades = ["artisan", "mason", "carpenter", "tailor", "craftsman"];
    if (artisanTrades.includes(profile.occupation)) {
      auditTrail.push({
        criterion: "Traditional Artisan Trade",
        status: "pass",
        detail: `Trade matches eligible traditional artisan category (${profile.occupation}).`
      });
    } else if (profile.occupation === "daily-wage-worker") {
      auditTrail.push({
        criterion: "Artisan Trade Verification",
        status: "missing",
        detail: "Need to verify if your daily work involves one of the 18 traditional crafts (e.g., masonry, carpentry, pottery)."
      });
      missingQuestions.push("artisanTrade");
    } else {
      auditTrail.push({
        criterion: "Traditional Trade Practice",
        status: "fail",
        detail: "Scheme is reserved for artisans working in 18 specified traditional family crafts."
      });
      status = "ineligible";
      shortReason = "Exclusively meant for traditional craftsmen & artisans across 18 notified trades.";
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // POST-MATRIC SCHOLARSHIP
  if (scheme.id === "post-matric-scholarship") {
    if (profile.isStudent === "yes" || profile.occupation === "student") {
      auditTrail.push({
        criterion: "Enrolled Student Status",
        status: "pass",
        detail: "Applicant is actively pursuing post-matriculation studies."
      });

      if (["SC", "ST", "OBC"].includes(profile.socialCategory)) {
        auditTrail.push({
          criterion: "Reserved Social Category (SC/ST/OBC)",
          status: "pass",
          detail: `Verified community category: ${profile.socialCategory}.`
        });
      } else if (!profile.socialCategory) {
        auditTrail.push({
          criterion: "Social Category Verification",
          status: "missing",
          detail: "Please provide caste/social category (SC, ST, or OBC certificate needed)."
        });
        missingQuestions.push("socialCategory");
      } else {
        auditTrail.push({
          criterion: "Social Category",
          status: "fail",
          detail: `This specific scholarship is designated for SC/ST/OBC students (profile: ${profile.socialCategory}).`
        });
        status = "ineligible";
        shortReason = "Reserved for SC, ST, and OBC category students (General category can check Central Sector Scholarship).";
        return { status, auditTrail, shortReason, missingQuestions };
      }
    } else {
      auditTrail.push({
        criterion: "Student Status",
        status: "fail",
        detail: "Scholarship is only available for active post-matric students."
      });
      status = "ineligible";
      shortReason = "Applicant must be an actively enrolled post-matric / college student.";
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // SUKANYA SAMRIDDHI YOJANA
  if (scheme.id === "sukanya-samriddhi") {
    if (profile.hasGirlChildUnder10 === "yes") {
      auditTrail.push({
        criterion: "Girl Child <= 10 Years in Household",
        status: "pass",
        detail: "Household has at least one eligible girl child under 10 years of age."
      });
    } else if (profile.hasGirlChildUnder10 === "no") {
      auditTrail.push({
        criterion: "Girl Child Requirement",
        status: "fail",
        detail: "Account can only be opened for a girl child who has not yet reached 10 years of age."
      });
      status = "ineligible";
      shortReason = "Account opening requires having a daughter aged 10 years or younger.";
      return { status, auditTrail, shortReason, missingQuestions };
    } else {
      auditTrail.push({
        criterion: "Family Composition",
        status: "missing",
        detail: "Confirm if your family includes a daughter aged 10 years or younger."
      });
      missingQuestions.push("hasGirlChildUnder10");
    }
  }

  // IGNOAPS OLD AGE PENSION
  if (scheme.id === "nsap-ignoaps") {
    if (userAge >= 60 || profile.hasSeniorCitizen === "yes") {
      auditTrail.push({
        criterion: "Senior Citizen Age (60+)",
        status: "pass",
        detail: `Applicant is ${userAge >= 60 ? userAge : "60+"} years old.`
      });
    } else {
      auditTrail.push({
        criterion: "Senior Citizen Age (60+)",
        status: "fail",
        detail: `IGNOAPS pension requires the applicant to be at least 60 years old (current age is ${userAge}).`
      });
      status = "ineligible";
      shortReason = `Requires applicant to be at least 60 years old (current age is ${userAge}).`;
      return { status, auditTrail, shortReason, missingQuestions };
    }
  }

  // PMMVY MATERNITY
  if (scheme.id === "pmmvy") {
    if (profile.gender === "female") {
      if (profile.isPregnantOrLactating === "yes") {
        auditTrail.push({
          criterion: "Maternity Condition",
          status: "pass",
          detail: "Confirmed pregnant or lactating mother with eligible parity."
        });
      } else if (profile.isPregnantOrLactating === "no") {
        auditTrail.push({
          criterion: "Active Maternity Status",
          status: "fail",
          detail: "Scheme offers benefits exclusively during active pregnancy and lactation phases."
        });
        status = "ineligible";
        shortReason = "Only applicable during pregnancy or immediate post-natal lactation period.";
        return { status, auditTrail, shortReason, missingQuestions };
      } else {
        auditTrail.push({
          criterion: "Pregnancy / Lactation Status",
          status: "missing",
          detail: "Specify if applicant or spouse is currently pregnant or nursing an infant under 6 months."
        });
        missingQuestions.push("isPregnantOrLactating");
      }
    } else {
      auditTrail.push({
        criterion: "Beneficiary Gender",
        status: "missing",
        detail: "Benefit is disbursed to the mother; can be claimed for spouse if applicant is male."
      });
      missingQuestions.push("isPregnantOrLactating");
    }
  }

  // MGNREGA
  if (scheme.id === "mgnrega") {
    if (profile.location === "rural") {
      auditTrail.push({
        criterion: "Rural Adult Readiness",
        status: "pass",
        detail: "Applicant lives in rural Gram Panchayat and is an adult ready for wage work."
      });
    }
  }

  // 6. FINALIZE STATUS
  if (missingQuestions.length > 0) {
    status = "needs_info";
    shortReason = `Your basic profile qualifies, but confirmation is needed regarding: ${missingQuestions.join(", ")}.`;
  } else if (status === "eligible") {
    if (scheme.id === "pmay-g") {
      shortReason = "Strong match: Rural resident with kutcha dwelling and eligible income. You can claim up to ₹1.2L plus ₹12K toilet grant.";
    } else if (scheme.id === "pmay-u") {
      shortReason = "Strong match: Urban resident without home ownership in EWS/LIG bracket. Eligible for interest subsidy up to ₹2.67 Lakh.";
    } else if (scheme.id === "pm-kisan") {
      shortReason = "Eligible: Verified farmer with cultivable land record. Eligible for ₹6,000/year direct transfer in 3 installments.";
    } else if (scheme.id === "ab-pmjay") {
      shortReason = "Eligible: Income and household category qualify for ₹5 Lakh/year cashless health hospitalization cover.";
    } else {
      shortReason = "All mandatory eligibility criteria verified successfully against your profile parameters.";
    }
  }

  return {
    status,
    auditTrail,
    shortReason,
    missingQuestions
  };
}

/**
 * Evaluates all schemes and sorts with high priority for:
 * 1. Housing Schemes (as required by hackathon)
 * 2. Potentially Eligible
 * 3. More Information Needed
 * 4. Ineligible
 */
export function rankAndFilterSchemes(schemes, profile, activeFilter = "all", selectedCategory = "all") {
  const evaluated = schemes.map(scheme => {
    const result = evaluateSchemeEligibility(scheme, profile);
    return {
      ...scheme,
      evaluation: result
    };
  });

  return evaluated.filter(scheme => {
    // Status filter
    if (activeFilter === "eligible" && scheme.evaluation.status !== "eligible") return false;
    if (activeFilter === "needs_info" && scheme.evaluation.status !== "needs_info") return false;
    if (activeFilter === "ineligible" && scheme.evaluation.status !== "ineligible") return false;
    if (activeFilter === "housing" && !scheme.isHousingScheme) return false;

    // Category filter
    if (selectedCategory !== "all" && scheme.category !== selectedCategory) return false;

    return true;
  }).sort((a, b) => {
    // Housing flagship always pinned on top when matching
    if (a.isHousingScheme && !b.isHousingScheme) return -1;
    if (!a.isHousingScheme && b.isHousingScheme) return 1;

    // Sort by status: eligible -> needs_info -> ineligible
    const statusOrder = { eligible: 1, needs_info: 2, ineligible: 3 };
    return (statusOrder[a.evaluation.status] || 4) - (statusOrder[b.evaluation.status] || 4);
  });
}
