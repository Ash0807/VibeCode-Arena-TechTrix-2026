require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { filterXSS } = require('xss');
const path = require('path');
const crypto = require('crypto');
const DB = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Security Middleware ---
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      frameAncestors: ["'none'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"]
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  referrerPolicy: { policy: 'no-referrer' }
}));

app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  next();
});

// Allow up to 25MB for local screenshot attachments
app.use(express.json({ limit: '25mb' }));
app.use(express.static(path.join(__dirname, 'public'), { dotfiles: 'deny' }));

const apiLimiter = rateLimit({ windowMs: 60000, max: 120, message: { error: 'Too many requests. Please wait a moment.' } });
const chatLimiter = rateLimit({ windowMs: 60000, max: 20, message: { error: 'Too many chat requests. Please wait.' } });
app.use('/api', apiLimiter);

function sanitize(s) { return typeof s === 'string' ? filterXSS(s.trim()) : ''; }
function genId() { return Date.now().toString(36) + crypto.randomBytes(4).toString('hex'); }

// Validation Helpers
function isValidYear(dateStr) {
  if (!dateStr) return true;
  const match = dateStr.match(/^(\d{4})-\d{2}-\d{2}$/);
  if (!match) return false;
  const y = parseInt(match[1], 10);
  const currentYear = new Date().getFullYear();
  return y >= 2000 && y <= currentYear;
}

function hasInvalidLongNumbers(str) {
  if (!str) return false;
  // Match any sequence of 5 or more consecutive digits (e.g. "22222")
  return /\b\d{5,}\b/.test(str);
}

// --- Report API ---
app.post('/api/report', (req, res) => {
  const { session_id, data } = req.body;
  if (!session_id || typeof session_id !== 'string') {
    return res.status(400).json({ error: 'Missing or invalid session' });
  }
  if (!data || typeof data !== 'object') {
    return res.status(400).json({ error: 'Missing report data' });
  }

  const sid = sanitize(session_id);
  const step = parseInt(data.step, 10) || 0;

  // Strict Validation: Prevent submitting blank or corrupt data
  if (step >= 1) {
    if (!data.type || !['morphed', 'impersonation', 'fabricated', 'other'].includes(data.type)) {
      return res.status(400).json({ error: 'Please select a valid abuse type' });
    }
    if (data.type === 'other' && (!data.typeOther || data.typeOther.trim().length < 3)) {
      return res.status(400).json({ error: 'Please briefly describe the abuse type (at least 3 characters)' });
    }
  }

  if (step >= 2) {
    if (!Array.isArray(data.platforms) || data.platforms.length === 0) {
      return res.status(400).json({ error: 'Please select at least one platform' });
    }
  }

  if (step >= 3) {
    if (!data.dateUnsure) {
      if (!data.date) {
        return res.status(400).json({ error: 'Please select a valid date or choose approximate date' });
      }
      if (!isValidYear(data.date)) {
        return res.status(400).json({ error: 'Year must be a 4-digit year between 2000 and current year' });
      }
    } else {
      if (!data.dateApprox || data.dateApprox.trim().length < 2) {
        return res.status(400).json({ error: 'Please provide an approximate timeframe' });
      }
      if (hasInvalidLongNumbers(data.dateApprox)) {
        return res.status(400).json({ error: 'Year or numbers cannot exceed 4 digits (e.g. 2024)' });
      }
    }
  }

  if (step >= 5) {
    // Final review step: Description cannot be blank or low-effort junk
    if (!data.description || data.description.trim().length < 15) {
      return res.status(400).json({ error: 'Description must be at least 15 characters to explain what occurred' });
    }
    if (/^(.)\1+$/.test(data.description.trim())) {
      return res.status(400).json({ error: 'Description cannot be repetitive characters' });
    }
  }

  const cleanData = {
    id: sanitize(data.id || genId()),
    type: sanitize(data.type || ''),
    typeOther: sanitize(data.typeOther || ''),
    platforms: (data.platforms || []).map(sanitize),
    platformOther: sanitize(data.platformOther || ''),
    date: sanitize(data.date || ''),
    dateUnsure: !!data.dateUnsure,
    dateApprox: sanitize(data.dateApprox || ''),
    urls: sanitize(data.urls || ''),
    description: sanitize(data.description || ''),
    step
  };

  const saved = DB.saveReport(sid, cleanData);
  res.json({ ok: true, id: saved.id, ml: saved.ml });
});

app.get('/api/report/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const data = DB.getReport(sid);
  res.json({ data });
});

// --- Timeline API ---
app.get('/api/timeline/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const events = DB.getTimeline(sid);
  res.json({ events });
});

app.post('/api/timeline', (req, res) => {
  const { session_id, date, description, type, demo } = req.body;
  if (!session_id || !description || !description.trim()) {
    return res.status(400).json({ error: 'Event description cannot be blank' });
  }

  const cleanDate = sanitize(date || '');
  if (hasInvalidLongNumbers(cleanDate)) {
    return res.status(400).json({ error: 'Year or number in date cannot exceed 4 digits' });
  }

  const cleanDesc = sanitize(description);
  if (cleanDesc.length < 3) {
    return res.status(400).json({ error: 'Event description must be at least 3 characters' });
  }

  const sid = sanitize(session_id);
  const id = genId();
  DB.addTimelineEvent(sid, {
    id,
    date: cleanDate,
    description: cleanDesc,
    type: sanitize(type || 'event'),
    demo: !!demo
  });

  res.json({ ok: true, id });
});

app.delete('/api/timeline/:session_id/:id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const id = sanitize(req.params.id);
  DB.deleteTimelineEvent(sid, id);
  res.json({ ok: true });
});

app.put('/api/timeline/reorder', (req, res) => {
  const { session_id, order } = req.body;
  if (!session_id || !Array.isArray(order)) return res.status(400).json({ error: 'Invalid order list' });
  const sid = sanitize(session_id);
  DB.reorderTimeline(sid, order.map(sanitize));
  res.json({ ok: true });
});

// --- Evidence Checklist API ---
app.get('/api/evidence/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const data = DB.getEvidence(sid);
  res.json({ data });
});

app.post('/api/evidence', (req, res) => {
  const { session_id, data } = req.body;
  if (!session_id || !data) return res.status(400).json({ error: 'Missing session or checklist data' });
  const sid = sanitize(session_id);
  DB.saveEvidence(sid, data);
  res.json({ ok: true });
});

// --- Screenshot Evidence API ---
app.get('/api/screenshots/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const screenshots = DB.getScreenshots(sid);
  res.json({ screenshots });
});

app.post('/api/screenshots', (req, res) => {
  const { session_id, file_name, file_type, file_size, caption, notes, date_taken, image_data } = req.body;
  if (!session_id) return res.status(400).json({ error: 'Missing session' });
  if (!image_data || typeof image_data !== 'string') {
    return res.status(400).json({ error: 'No image data provided' });
  }

  // Verify that it is a valid image base64 data URL
  if (!image_data.startsWith('data:image/')) {
    return res.status(400).json({ error: 'Uploaded file must be a valid image (PNG, JPG, WEBP)' });
  }

  const sid = sanitize(session_id);
  const id = genId();
  const item = {
    id,
    fileName: sanitize(file_name || 'evidence-screenshot.png'),
    fileType: sanitize(file_type || 'image/png'),
    fileSize: parseInt(file_size, 10) || 0,
    caption: sanitize(caption || ''),
    notes: sanitize(notes || ''),
    dateTaken: sanitize(date_taken || new Date().toLocaleDateString()),
    imageData: image_data // Base64 data URL stored in SQLite & JSON
  };

  DB.addScreenshot(sid, item);
  res.json({ ok: true, id });
});

app.delete('/api/screenshots/:session_id/:id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const id = sanitize(req.params.id);
  DB.deleteScreenshot(sid, id);
  res.json({ ok: true });
});

// --- Data Store Info & Stats ---
app.get('/api/db/info/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  const stats = DB.getStats(sid);
  res.json({
    ok: true,
    engine: DB.isSqlite() ? 'SQLite 3 (Built-in Relational DB)' : 'JSON Document Store',
    dbFile: 'data/narisuraksha.db',
    backupFile: 'data/db.json',
    storageDescription: 'Data is stored locally in your project workspace database (data/narisuraksha.db) and locally encrypted in your browser. No data is ever sent to external cloud servers or third parties.',
    stats
  });
});

// --- Delete All Data ---
app.delete('/api/data/:session_id', (req, res) => {
  const sid = sanitize(req.params.session_id);
  DB.deleteAll(sid);
  res.json({ ok: true });
});

// --- AI Chat ---
const SYSTEM_PROMPT = `You are NariSuraksha AI, a compassionate assistant helping women and girls in India who face morphed image abuse, online impersonation, or fabricated content.

HARD RULES YOU MUST NEVER BREAK:
1. NEVER claim to verify the authenticity of any image
2. NEVER give legal verdicts or cite specific law section numbers
3. NEVER automatically submit any official complaint
4. NEVER ask for or process personal details, names, phone numbers, Aadhaar, or URLs
5. If the user shows distress (mentions suicide, self-harm, hopelessness), IMMEDIATELY provide helpline numbers:
   - Women Helpline: 181
   - Vandrevala Foundation: 1860-2662-345 (24/7)
   - iCall: 9152987821
   - Emergency: 112

BEHAVIOR:
- Respond in the same language the user writes in (Hindi or English)
- Keep responses concise (max 3 short paragraphs)
- Be gentle, warm, supportive, and never blame the user
- Guide users to relevant platform sections: Evidence Checklist, Reporting Guide, Content Removal, Secure My Accounts, Timeline
- Mention cybercrime.gov.in and helpline 1930 when relevant
- Always add: "This is general information only."
- Remind users: "Please do not share personal details in this chat."`;

async function callGemini(message, lang) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your-gemini-api-key-here') return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{ role: 'user', parts: [{ text: `[Language: ${lang === 'hi' ? 'Hindi' : 'English'}]\n\n${message}` }] }],
        generationConfig: { maxOutputTokens: 400, temperature: 0.4 },
        safetySettings: [
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
        ]
      }),
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const json = await resp.json();
    return json.candidates?.[0]?.content?.parts?.[0]?.text || null;
  } catch { return null; }
}

function fallbackResponse(msg, ln) {
  const lo = msg.toLowerCase();
  const hi = ln === 'hi';
  const distress = ['suicide','kill myself','end my life','die','hopeless','marna','khatam','jaan de'];
  if (distress.some(w => lo.includes(w)))
    return hi ? 'Aap akeli nahi hain. Kripya abhi helpline ko call karein:\n\nWomen Helpline: 181\nVandrevala Foundation: 1860-2662-345 (24/7)\niCall: 9152987821\nEmergency: 112\n\nTrained counselors aapki madad ke liye tayyar hain.'
      : 'You are not alone. Please call a helpline now:\n\nWomen Helpline: 181\nVandrevala Foundation: 1860-2662-345 (24/7)\niCall: 9152987821\nEmergency: 112\n\nTrained counsellors are ready to help you.';
  if (lo.match(/report|complaint|shikayat|fir/))
    return hi ? 'Aap cybercrime.gov.in par online shikayat darj kar sakti hain, ya helpline 1930 par call karein. "Reporting Guide" mein step-by-step guide hai.\n\nYeh assistant aapki taraf se shikayat darj nahi kar sakta. Yeh sirf samanya jaankari hai.'
      : 'You can file a complaint at cybercrime.gov.in or call helpline 1930. The Reporting Guide section has step-by-step instructions.\n\nThis assistant cannot file complaints on your behalf. This is general information only.';
  if (lo.match(/evidence|screenshot|proof|saboot/))
    return hi ? 'Screenshots lein, URLs save karein, dates note karein. "Evidence Checklist" mein aapko step-by-step guide aur screenshot vault milega.\n\nSensitive photos is platform par kisi external server par upload nahi hoti -- sab kuch aapke local secure database mein rehta hai.'
      : 'Take screenshots, save URLs, and note dates. The Evidence Checklist has a step-by-step guide and local screenshot vault.\n\nSensitive photos are never sent to external servers -- everything stays in your local secure database.';
  if (lo.match(/remove|delete|takedown|hatao/))
    return hi ? '"Content Removal" section mein har platform ke liye reporting steps hain. Agar content nahi hata toh cybercrime.gov.in par shikayat karein.\n\nYeh sirf samanya jaankari hai.'
      : 'The Content Removal section has reporting steps for each platform. If content is not removed, file a complaint at cybercrime.gov.in.\n\nThis is general information only.';
  if (lo.match(/safe|account|password|suraksha|secure|hack/))
    return hi ? 'Sabhi accounts ke passwords turant badlein. Two-factor authentication enable karein. "Secure My Accounts" mein detailed guide hai.\n\nYeh sirf samanya jaankari hai.'
      : 'Change passwords on all accounts immediately. Enable two-factor authentication. The Secure My Accounts section has a detailed guide.\n\nThis is general information only.';
  if (lo.match(/legal|law|kanoon|section|dhara|ipc|it act/))
    return hi ? 'Bharat mein morphed images banana aur share karna IT Act aur BNS ke tahat aparadh hai. Sahi legal salah ke liye vakeel se milein.\n\nYeh assistant legal advice nahi de sakta.'
      : 'Creating and sharing morphed images is a criminal offence under the IT Act and BNS in India. Consult a lawyer for specific advice.\n\nThis assistant cannot provide legal advice.';
  if (lo.match(/hello|hi|namaste|help|madad|kya kar/))
    return hi ? 'Namaste. Main aapki madad ke liye yahan hoon. Aap mujhse reporting, evidence collection, content removal, ya account security ke baare mein pooch sakti hain.\n\nKripya chat mein koi personal jaankari na daalein.'
      : 'Hello. I am here to help. You can ask me about reporting, evidence collection, content removal, or account security.\n\nPlease do not type any personal information into this chat.';
  return hi ? 'Main aapki madad ke liye yahan hoon. Reporting, evidence, content removal, ya account security ke baare mein poochein.\n\nKripya chat mein koi personal jaankari na daalein. Yeh sirf samanya jaankari hai.'
    : 'I am here to help. Ask me about reporting, evidence, content removal, or account security.\n\nPlease do not type personal information into this chat. This is general information only.';
}

app.post('/api/chat', chatLimiter, async (req, res) => {
  const { message, lang } = req.body;
  if (!message || typeof message !== 'string') return res.status(400).json({ error: 'Invalid message' });
  const clean = sanitize(message.slice(0, 500));
  const aiResponse = await callGemini(clean, lang || 'en');
  res.json({ response: aiResponse || fallbackResponse(clean, lang || 'en'), ai: !!aiResponse });
});

// --- 404 & Error Handling ---
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', 'index.html')));
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

app.listen(PORT, () => console.log(`✓ NariSuraksha AI server running on http://localhost:${PORT}`));
