import { pageRenderers, pageSetups } from './pages.js';

let lang = localStorage.getItem('ns-lang') || 'en';
const t = (en, hi) => lang === 'hi' ? hi : en;

// --- Session ---
let sessionId = localStorage.getItem('ns-session');
if (!sessionId) { sessionId = crypto.randomUUID(); localStorage.setItem('ns-session', sessionId); }

// --- Crypto (AES-GCM) ---
const ENC = new TextEncoder(), DEC = new TextDecoder();
let _key;
async function getKey() {
  if (_key) return _key;
  const raw = await crypto.subtle.importKey('raw', ENC.encode('NariSuraksha-local'), 'PBKDF2', false, ['deriveKey']);
  _key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt: ENC.encode('ns-salt-v1'), iterations: 100000, hash: 'SHA-256' }, raw, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  return _key;
}
async function encrypt(data) {
  const key = await getKey(), iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, ENC.encode(JSON.stringify(data)));
  return JSON.stringify({ iv: [...iv], ct: [...new Uint8Array(ct)] });
}
async function decrypt(str) {
  try { const key = await getKey(), { iv, ct } = JSON.parse(str);
    return JSON.parse(DEC.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: new Uint8Array(iv) }, key, new Uint8Array(ct))));
  } catch { return null; }
}
async function localSave(k, v) { localStorage.setItem(k, await encrypt(v)); }
async function localLoad(k) { const s = localStorage.getItem(k); return s ? await decrypt(s) : null; }

// --- API ---
async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  return (await fetch('/api' + path, opts)).json();
}

// --- Toast ---
function toast(msg, type = 'info', duration = 3500) {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => { el.style.animation = 'toastOut .25s ease forwards'; setTimeout(() => el.remove(), 250); }, duration);
}

function deleteAll() {
  const ln = localStorage.getItem('ns-lang');
  localStorage.clear();
  if (ln) localStorage.setItem('ns-lang', ln);
  sessionId = crypto.randomUUID();
  localStorage.setItem('ns-session', sessionId);
  api('DELETE', `/data/${sessionId}`);
}

window._ns = { t, localSave, localLoad, deleteAll, lang: () => lang, api, toast, session: () => sessionId };

// --- Nav scroll effect ---
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 10);
});

// --- Desktop nav active state ---
const navIds = { '/report': 'nl-report', '/evidence': 'nl-evidence', '/timeline': 'nl-timeline', '/guide': 'nl-guide', '/chat': 'nl-chat', '/resources': 'nl-resources' };
function updateNavActive() {
  const path = window.location.hash.slice(1) || '/home';
  Object.entries(navIds).forEach(([p, id]) => {
    document.getElementById(id)?.classList.toggle('active', path === p);
  });
}

// --- Mobile menu ---
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
const mobileItems = [
  { path: '/home', en: 'Home', hi: 'होम' },
  { path: '/report', en: 'Start a Report', hi: 'रिपोर्ट शुरू करें' },
  { path: '/evidence', en: 'Evidence Checklist', hi: 'सबूत सूची' },
  { path: '/timeline', en: 'My Timeline', hi: 'मेरी टाइमलाइन' },
  { path: '/guide', en: 'Reporting Guide', hi: 'रिपोर्टिंग गाइड' },
  { path: '/removal', en: 'Content Removal', hi: 'कॉन्टेंट हटाएं' },
  { path: '/security', en: 'Account Security', hi: 'अकाउंट सुरक्षा' },
  { path: '/chat', en: 'AI Chat', hi: 'AI चैट' },
  { path: '/resources', en: 'Helplines', hi: 'हेल्पलाइन' },
  { path: '/privacy', en: 'Privacy', hi: 'गोपनीयता' },
  { path: '/about', en: 'About', hi: 'परिचय' },
];

function renderMobileNav() {
  document.getElementById('mobileNavLinks').innerHTML = mobileItems.map(item =>
    `<li><a href="#${item.path}">${t(item.en, item.hi)}</a></li>`
  ).join('');
}

hamburger.addEventListener('click', () => {
  const open = mobileMenu.classList.toggle('open');
  hamburger.classList.toggle('open', open);
  hamburger.setAttribute('aria-expanded', open);
  mobileMenu.setAttribute('aria-hidden', !open);
  document.body.style.overflow = open ? 'hidden' : '';
});
mobileMenu.addEventListener('click', e => {
  if (e.target.tagName === 'A') {
    mobileMenu.classList.remove('open');
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    mobileMenu.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
});

// --- Language ---
function setLang(l) {
  lang = l;
  localStorage.setItem('ns-lang', l);
  document.documentElement.lang = l === 'hi' ? 'hi' : 'en';
  document.getElementById('langBtn').textContent = l === 'hi' ? 'HI' : 'EN';
  // Desktop nav
  const nl = { report: t('Report', 'रिपोर्ट'), evidence: t('Evidence', 'सबूत'), timeline: t('Timeline', 'टाइमलाइन'), guide: t('Guide', 'गाइड'), chat: t('AI Chat', 'AI चैट'), resources: t('Helplines', 'हेल्पलाइन') };
  Object.entries(nl).forEach(([k, v]) => { const el = document.getElementById('nl-' + k); if (el) el.textContent = v; });
  document.getElementById('navCta').textContent = t('Start a Report', 'रिपोर्ट शुरू करें');
  // Footer
  document.getElementById('footerTagline').textContent = t('Privacy-first abuse reporting assistant', 'गोपनीयता-प्रथम दुरुपयोग रिपोर्टिंग सहायक');
  document.getElementById('fColTools').textContent = t('Tools', 'उपकरण');
  document.getElementById('fColInfo').textContent = t('Information', 'जानकारी');
  document.getElementById('fColLegal').textContent = t('Legal', 'कानूनी');
  const fl = { report: t('Report', 'रिपोर्ट'), evidence: t('Evidence', 'सबूत'), timeline: t('Timeline', 'टाइमलाइन'), chat: t('AI Chat', 'AI चैट'), guide: t('Reporting Guide', 'रिपोर्टिंग गाइड'), removal: t('Content Removal', 'कॉन्टेंट हटाएं'), security: t('Account Security', 'अकाउंट सुरक्षा'), resources: t('Helplines', 'हेल्पलाइन'), privacy: t('Privacy', 'गोपनीयता'), about: t('About', 'परिचय'), notice: t('Prototype', 'प्रोटोटाइप') };
  Object.entries(fl).forEach(([k, v]) => { const el = document.getElementById('fl-' + k); if (el) el.textContent = v; });
  document.getElementById('footerProto').textContent = t('PROTOTYPE -- For demonstration only', 'प्रोटोटाइप -- केवल प्रदर्शन के लिए');
  document.getElementById('deleteBtnText').textContent = t('Delete All My Data', 'मेरा सारा डेटा हटाएं');
  document.getElementById('skipLink').textContent = t('Skip to content', 'सामग्री पर जाएं');
  window._ns.t = t;
  renderMobileNav();
  render();
}
document.getElementById('langBtn').addEventListener('click', () => setLang(lang === 'hi' ? 'en' : 'hi'));

// --- Delete All ---
const modal = document.getElementById('modalOverlay');
document.getElementById('deleteBtn').addEventListener('click', () => {
  document.getElementById('modalTitle').textContent = t('Delete all data?', 'सारा डेटा हटाएं?');
  document.getElementById('modalBody').textContent = t('This will permanently erase all your saved reports, checklist progress, and timeline entries. This cannot be undone.', 'इससे आपकी सभी रिपोर्ट, चेकलिस्ट और टाइमलाइन मिट जाएंगी। यह वापस नहीं किया जा सकता।');
  document.getElementById('modalCancel').textContent = t('Cancel', 'रद्द करें');
  document.getElementById('modalConfirm').textContent = t('Delete Everything', 'सब कुछ हटाएं');
  modal.setAttribute('aria-hidden', 'false');
  document.getElementById('modalConfirm').onclick = () => {
    deleteAll();
    modal.setAttribute('aria-hidden', 'true');
    toast(t('All data deleted.', 'सारा डेटा हटा दिया गया।'), 'success');
    render();
  };
});
document.getElementById('modalCancel').addEventListener('click', () => modal.setAttribute('aria-hidden', 'true'));
modal.addEventListener('click', e => { if (e.target === modal) modal.setAttribute('aria-hidden', 'true'); });

// --- Router ---
function render() {
  const path = window.location.hash.slice(1) || '/home';
  const renderer = pageRenderers[path];
  const main = document.getElementById('main-content');
  main.innerHTML = renderer ? renderer(t) : pageRenderers['/home'](t);
  updateNavActive();
  window.scrollTo(0, 0);
  const setup = pageSetups[path];
  if (setup) setup(t);
  // Animate stat counters on home
  if (path === '/home' || !window.location.hash) {
    document.querySelectorAll('.stat-num[data-target]').forEach(el => {
      const target = parseInt(el.dataset.target);
      if (target === 0) { el.textContent = '0'; return; }
      let c = 0;
      const step = Math.max(1, Math.floor(target / 25));
      const timer = setInterval(() => { c = Math.min(c + step, target); el.textContent = c; if (c >= target) clearInterval(timer); }, 30);
    });
  }
}

window.addEventListener('hashchange', render);
setLang(lang);
