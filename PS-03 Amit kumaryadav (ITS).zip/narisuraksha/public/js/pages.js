const api = (...a) => window._ns.api(...a);
const toast = (...a) => window._ns.toast(...a);
const session = () => window._ns.session();
const lang = () => window._ns.lang();
const localSave = (k, v) => window._ns.localSave(k, v);
const localLoad = (k) => window._ns.localLoad(k);

function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

// ====================== HOME ======================
function renderHome(t) {
  const marqueeItems = [
    t('Evidence Collection','सबूत संग्रह'), t('Incident Reporting','घटना रिपोर्टिंग'), t('AI Guidance','AI मार्गदर्शन'),
    t('Content Removal','कॉन्टेंट हटाना'), t('Account Security','अकाउंट सुरक्षा'), t('Timeline Export','टाइमलाइन निर्यात'),
    t('Privacy First','गोपनीयता प्रथम'), t('Helpline Access','हेल्पलाइन पहुंच'),
  ];
  const marquee = [...marqueeItems, ...marqueeItems].map(s => `<span>${s}</span><span class="sep">--</span>`).join('');

  return `
    <section class="hero">
      <div class="hero-grid"></div>
      <div class="hero-glow hero-glow-1"></div>
      <div class="hero-glow hero-glow-2"></div>
      <div class="hero-content">
        <div class="hero-badge"><span class="dot"></span>${t('Privacy-First Platform','गोपनीयता-प्रथम प्लेटफॉर्म')}</div>
        <h1>${t('You are safe here.<br>We are <em>with</em> you.','आप यहां सुरक्षित हैं।<br>हम आपके <em>साथ</em> हैं।')}</h1>
        <p class="hero-sub">${t(
          'Document incidents. Preserve evidence. Understand your options. Everything stays private, encrypted, and under your control.',
          'घटनाएं दर्ज करें। सबूत सुरक्षित रखें। विकल्प समझें। सब कुछ निजी, एन्क्रिप्टेड और आपके नियंत्रण में।'
        )}</p>
        <div class="hero-actions">
          <a href="#/report" class="btn btn-primary">${t('Start a Report','रिपोर्ट शुरू करें')}</a>
          <a href="#/chat" class="btn btn-ghost">${t('Talk to AI Assistant','AI सहायक से बात करें')} &rarr;</a>
        </div>
      </div>
      <div class="hero-stats">
        <div class="stat"><span class="stat-num" data-target="100">0</span><span class="stat-label">${t('% Private','% निजी')}</span></div>
        <div class="stat-divider"></div>
        <div class="stat"><span class="stat-num" data-target="0">0</span><span class="stat-label">${t('Data Uploaded','डेटा अपलोड')}</span></div>
        <div class="stat-divider"></div>
        <div class="stat"><span class="stat-num" data-target="6">0</span><span class="stat-label">${t('Tools','उपकरण')}</span></div>
      </div>
    </section>

    <div class="marquee"><div class="marquee-track">${marquee}</div></div>

    <div class="page-section">
      <div class="eyebrow">${t('How We Help','हम कैसे मदद करते हैं')}</div>
      <h2>${t('Everything you need,<br>nothing you don\'t.','सब कुछ जो चाहिए,<br>कुछ भी अनावश्यक नहीं।')}</h2>
      <p class="subtitle">${t('Six focused tools to help you take the next step. No account needed. No data leaves your device without your knowledge.','छह केंद्रित उपकरण अगला कदम उठाने में मदद के लिए। कोई अकाउंट नहीं। बिना आपकी जानकारी के कोई डेटा नहीं जाता।')}</p>

      <div class="cta-grid">
        <a href="#/report" class="cta-card"><span class="cta-icon teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg></span><span><span class="cta-text">${t('Start a Report','रिपोर्ट शुरू करें')}</span><br><span class="cta-desc">${t('Step-by-step incident form with auto-save','ऑटो-सेव के साथ चरण-दर-चरण फॉर्म')}</span></span></a>
        <a href="#/evidence" class="cta-card"><span class="cta-icon teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg></span><span><span class="cta-text">${t('Evidence Checklist','सबूत सूची')}</span><br><span class="cta-desc">${t('Track screenshots, links, and records','स्क्रीनशॉट, लिंक और रिकॉर्ड ट्रैक करें')}</span></span></a>
        <a href="#/timeline" class="cta-card"><span class="cta-icon plum"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span><span><span class="cta-text">${t('My Timeline','मेरी टाइमलाइन')}</span><br><span class="cta-desc">${t('Organise and export a printable summary','व्यवस्थित और प्रिंट योग्य सारांश')}</span></span></a>
        <a href="#/chat" class="cta-card"><span class="cta-icon plum"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg></span><span><span class="cta-text">${t('AI Assistant','AI सहायक')}</span><br><span class="cta-desc">${t('Get guidance in Hindi or English','हिंदी या अंग्रेज़ी में मार्गदर्शन')}</span></span></a>
        <a href="#/guide" class="cta-card"><span class="cta-icon teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg></span><span><span class="cta-text">${t('Reporting Guide','रिपोर्टिंग गाइड')}</span><br><span class="cta-desc">${t('Police and cybercrime portal steps','पुलिस और साइबर पोर्टल चरण')}</span></span></a>
        <a href="#/resources" class="cta-card"><span class="cta-icon plum"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg></span><span><span class="cta-text">${t('Helplines','हेल्पलाइन')}</span><br><span class="cta-desc">${t('Verified numbers and support links','सत्यापित नंबर और सहायता लिंक')}</span></span></a>
      </div>

      <div class="card card-accent mt-lg" style="text-align:center">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" style="margin-bottom:8px"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        <h3>${t('Your Privacy is Protected','आपकी गोपनीयता सुरक्षित है')}</h3>
        <p>${t('No account needed. No tracking. Data encrypted. Delete anytime.','कोई अकाउंट नहीं। कोई ट्रैकिंग नहीं। डेटा एन्क्रिप्टेड। कभी भी हटाएं।')}</p>
      </div>

      <p class="consent-text mt-lg text-center">${t('By using this platform, you agree to our <a href="#/privacy">privacy notice</a>.','इस प्लेटफॉर्म का उपयोग करके, आप हमारी <a href="#/privacy">गोपनीयता सूचना</a> से सहमत हैं।')}</p>
    </div>`;
}

// ====================== REPORT ======================
const STEPS = () => [
  { key: 'type', label: window._ns.t('Type of Abuse','दुरुपयोग का प्रकार') },
  { key: 'platform', label: window._ns.t('Platform','प्लेटफॉर्म') },
  { key: 'date', label: window._ns.t('Date','तारीख') },
  { key: 'urls', label: window._ns.t('URLs','लिंक') },
  { key: 'describe', label: window._ns.t('Description','विवरण') },
  { key: 'review', label: window._ns.t('Review','समीक्षा') },
];

function renderReport(t) {
  return `<div class="page-section"><h1>${t('Start a Report','रिपोर्ट शुरू करें')}</h1>
    <p class="subtitle">${t('Answer step by step. All data is validated, encrypted, and saved in your local database.','चरण दर चरण उत्तर दें। सभी डेटा सत्यापित, एन्क्रिप्टेड और स्थानीय डेटाबेस में सहेजा गया है।')}</p>
    <div class="notice notice-info mb-lg">${t('Your progress is saved automatically in your local secure database. Complete all steps to file your timeline record.','आपकी प्रगति स्थानीय डेटाबेस में स्वचालित रूप से सहेजी जाती है। टाइमलाइन रिकॉर्ड दर्ज करने के लिए सभी चरण पूरे करें।')}</div>
    <div id="reportProgress" class="progress-bar"></div>
    <div id="reportForm"></div></div>`;
}

function setupReport(t) {
  let step = 0, data = { type:'', typeOther:'', platforms:[], platformOther:'', date:'', dateUnsure:false, dateApprox:'', urls:'', description:'', id:'' };

  async function init() {
    try {
      const res = await api('GET', `/report/${session()}`);
      if (res.data) {
        const r = res.data;
        data = {
          id: r.id || '',
          type: r.type || '',
          typeOther: r.typeOther || r.type_other || '',
          platforms: r.platforms || [],
          platformOther: r.platformOther || r.platform_other || '',
          date: r.date || '',
          dateUnsure: !!r.dateUnsure || !!r.date_unsure,
          dateApprox: r.dateApprox || r.date_approx || '',
          urls: r.urls || '',
          description: r.description || ''
        };
        step = typeof r.step === 'number' ? r.step : 0;
      }
    } catch (err) {
      console.warn('Failed to load report state:', err);
    }
    renderStep();
  }

  async function saveState() {
    if (!data.id) data.id = Date.now().toString(36) + Math.random().toString(36).slice(2,6);
    try {
      await api('POST', '/report', { session_id: session(), data: { ...data, step } });
    } catch (err) {
      console.error('Save state error:', err);
    }
  }

  function progress() {
    const steps = STEPS();
    document.getElementById('reportProgress').innerHTML = steps.map((s,i) => {
      const cls = i < step ? 'done' : i === step ? 'active' : '';
      const dot = i < step ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polyline points="20 6 9 17 4 12" fill="none" stroke="currentColor" stroke-width="3"/></svg>' : (i+1);
      return `<div class="progress-step ${cls}"><span class="step-dot">${dot}</span></div>${i<steps.length-1?`<div class="progress-line ${i<step?'done':''}"></div>`:''}`;
    }).join('');
  }

  function showError(msg) {
    let errEl = document.getElementById('stepErrorMsg');
    if (!errEl) {
      errEl = document.createElement('div');
      errEl.id = 'stepErrorMsg';
      errEl.className = 'form-error mb-md';
      const container = document.getElementById('reportForm');
      container.insertBefore(errEl, container.querySelector('.btn-group') || container.lastChild);
    }
    errEl.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><span>${msg}</span>`;
  }

  function clearError() {
    document.getElementById('stepErrorMsg')?.remove();
  }

  function renderStep() {
    progress();
    const form = document.getElementById('reportForm');
    const steps = STEPS();
    const back = `<button class="btn btn-secondary" id="backBtn">${t('Back','पीछे')}</button>`;
    const next = `<button class="btn btn-primary" id="nextBtn">${t('Next','आगे')}</button>`;

    if (step === 0) {
      const types = [
        { v:'morphed', l:t('Morphed or manipulated image','मॉर्फ्ड या छेड़छाड़ तस्वीर') },
        { v:'impersonation', l:t('Online impersonation (fake profile)','ऑनलाइन प्रतिरूपण (नकली प्रोफ़ाइल)') },
        { v:'fabricated', l:t('Fabricated or AI-generated content','बनावटी या AI-जनित कॉन्टेंट') },
        { v:'other', l:t('Other (specify below)','अन्य (नीचे बताएं)') },
      ];
      form.innerHTML = `<h2>${steps[0].label}</h2><p class="form-hint mb-md">${t('Select which best describes what happened (Required).','जो सबसे अच्छा बताता है कि क्या हुआ उसे चुनें (आवश्यक)।')}</p>
        ${types.map(tp => `<label class="check-item"><input type="radio" name="abuseType" value="${tp.v}" ${data.type===tp.v?'checked':''}><span>${tp.l}</span></label>`).join('')}
        <div id="typeOtherWrap" style="display:${data.type==='other'?'block':'none'}" class="mt-md">
          <label class="form-label">${t('Describe briefly (minimum 3 characters)','संक्षेप में बताएं (कम से कम 3 अक्षर)')}</label>
          <input class="form-input" id="typeOther" value="${esc(data.typeOther)}" maxlength="200" placeholder="${t('e.g. Defamatory video clip','जैसे अपमानजनक वीडियो')}">
        </div>
        <div class="btn-group">${next}</div>`;

      form.querySelectorAll('[name="abuseType"]').forEach(r => r.addEventListener('change', e => {
        clearError();
        data.type = e.target.value;
        document.getElementById('typeOtherWrap').style.display = data.type === 'other' ? 'block' : 'none';
      }));

      document.getElementById('nextBtn').addEventListener('click', () => {
        clearError();
        if (!data.type) {
          return showError(t('Please select the type of abuse before proceeding.','आगे बढ़ने से पहले कृपया दुरुपयोग का प्रकार चुनें।'));
        }
        if (data.type === 'other') {
          const otherVal = document.getElementById('typeOther')?.value.trim() || '';
          if (otherVal.length < 3) {
            return showError(t('Please briefly describe what happened (at least 3 characters).','कृपया संक्षेप में बताएं क्या हुआ (कम से कम 3 अक्षर)।'));
          }
          data.typeOther = otherVal;
        }
        step = 1;
        saveState();
        renderStep();
      });

    } else if (step === 1) {
      const pl = ['Instagram','WhatsApp','Facebook','Twitter/X','Telegram','YouTube',t('Snapchat','स्नैपचैट'),t('Other','अन्य')];
      form.innerHTML = `<h2>${steps[1].label}</h2><p class="form-hint mb-md">${t('Select at least one platform where the content was seen (Required).','कम से कम एक प्लेटफॉर्म चुनें जहाँ कॉन्टेंट देखा गया (आवश्यक)।')}</p>
        ${pl.map(p => `<label class="check-item"><input type="checkbox" value="${p}" ${data.platforms.includes(p)?'checked':''}><span>${p}</span></label>`).join('')}
        <div class="btn-group">${back}${next}</div>`;

      document.getElementById('backBtn').addEventListener('click', () => { clearError(); step = 0; renderStep(); });
      document.getElementById('nextBtn').addEventListener('click', () => {
        clearError();
        const selected = [...form.querySelectorAll('input[type="checkbox"]:checked')].map(c => c.value);
        if (selected.length === 0) {
          return showError(t('Please select at least one platform where this occurred.','कृपया कम से कम एक प्लेटफॉर्म चुनें जहाँ यह घटना हुई।'));
        }
        data.platforms = selected;
        step = 2;
        saveState();
        renderStep();
      });

    } else if (step === 2) {
      const today = new Date().toISOString().split('T')[0];
      const curYear = new Date().getFullYear();

      form.innerHTML = `<h2>${steps[2].label}</h2><p class="form-hint mb-md">${t('When did this happen? Year must be 4 digits (e.g. 2024).','यह कब हुआ? वर्ष 4 अंकों का होना चाहिए (जैसे 2024)।')}</p>
        <label class="check-item mb-sm"><input type="checkbox" id="dateUnsure" ${data.dateUnsure?'checked':''}><span>${t('I am not sure of the exact date','मुझे सही तारीख पता नहीं')}</span></label>
        
        <div id="dateExact" style="display:${data.dateUnsure?'none':'block'}">
          <label class="form-label">${t('Exact Date (Year between 2000 and current year)','सटीक तारीख (वर्ष 2000 और वर्तमान वर्ष के बीच)')}</label>
          <input type="date" class="form-input" id="dateInput" min="2000-01-01" max="${today}" value="${esc(data.date)}">
        </div>

        <div id="dateApproxWrap" style="display:${data.dateUnsure?'block':'none'}" class="mt-md">
          <label class="form-label">${t('Approximate timeframe or choose a quick option','अनुमानित समय सीमा या तुरंत विकल्प चुनें')}</label>
          <div class="chip-group">
            <button type="button" class="chip" data-val="${t('Within last 24 hours','पिछले 24 घंटों में')}">${t('Last 24 Hours','24 घंटे')}</button>
            <button type="button" class="chip" data-val="${t('Past week','पिछले हफ्ते')}">${t('Past Week','पिछला हफ्ता')}</button>
            <button type="button" class="chip" data-val="${t('This month','इस महीने')}">${t('This Month','यह महीना')}</button>
            <button type="button" class="chip" data-val="${t('1-3 months ago','1-3 महीने पहले')}">${t('1-3 Months Ago','1-3 महीने पहले')}</button>
            <button type="button" class="chip" data-val="${t('More than 6 months ago','6 महीने से अधिक पहले')}">${t('6+ Months Ago','6+ महीने पहले')}</button>
          </div>
          <input class="form-input mt-sm" id="dateApprox" value="${esc(data.dateApprox)}" maxlength="50" placeholder="${t('Or type e.g. July 2024','या लिखें जैसे जुलाई 2024')}">
        </div>
        <div class="btn-group">${back}${next}</div>`;

      // Year clamping on input
      const dateInput = document.getElementById('dateInput');
      dateInput?.addEventListener('input', e => {
        clearError();
        const val = e.target.value;
        if (val) {
          const parts = val.split('-');
          if (parts[0] && parts[0].length > 4) {
            parts[0] = parts[0].slice(0, 4);
            e.target.value = parts.join('-');
          }
        }
      });

      // Quick chip clicks
      form.querySelectorAll('.chip').forEach(btn => {
        btn.addEventListener('click', () => {
          clearError();
          form.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
          btn.classList.add('active');
          const input = document.getElementById('dateApprox');
          if (input) input.value = btn.dataset.val;
        });
      });

      document.getElementById('dateUnsure').addEventListener('change', e => {
        clearError();
        data.dateUnsure = e.target.checked;
        document.getElementById('dateExact').style.display = e.target.checked ? 'none' : 'block';
        document.getElementById('dateApproxWrap').style.display = e.target.checked ? 'block' : 'none';
      });

      document.getElementById('backBtn').addEventListener('click', () => { clearError(); step = 1; renderStep(); });
      document.getElementById('nextBtn').addEventListener('click', () => {
        clearError();
        if (!data.dateUnsure) {
          const val = document.getElementById('dateInput')?.value || '';
          if (!val) {
            return showError(t('Please select an incident date or check "I am not sure of the exact date".','कृपया घटना की तारीख चुनें या "मुझे सही तारीख पता नहीं" चुनें।'));
          }
          const yr = parseInt(val.split('-')[0], 10);
          if (isNaN(yr) || yr < 2000 || yr > curYear || val.split('-')[0].length !== 4) {
            return showError(t(`Year must be a valid 4-digit year between 2000 and ${curYear}.`,`वर्ष 2000 और ${curYear} के बीच 4 अंकों का मान्य वर्ष होना चाहिए।`));
          }
          data.date = val;
          data.dateApprox = '';
        } else {
          const approx = document.getElementById('dateApprox')?.value.trim() || '';
          if (approx.length < 2) {
            return showError(t('Please provide an approximate timeframe or pick one of the options above.','कृपया अनुमानित समय सीमा प्रदान करें या ऊपर दिए गए विकल्पों में से एक चुनें।'));
          }
          // Prevent >4 digit years or random long numbers like 22222
          if (/\b\d{5,}\b/.test(approx)) {
            return showError(t('Year or number cannot exceed 4 digits (e.g. 2024).','वर्ष या संख्या 4 अंकों से अधिक नहीं हो सकती (जैसे 2024)।'));
          }
          data.dateApprox = approx;
          data.date = '';
        }
        step = 3;
        saveState();
        renderStep();
      });

    } else if (step === 3) {
      form.innerHTML = `<h2>${steps[3].label}</h2><p class="form-hint mb-md">${t('Paste any relevant URLs or web links. Leave blank if not available.','प्रासंगिक URL या लिंक पेस्ट करें। उपलब्ध न होने पर खाली छोड़ दें।')}</p>
        <textarea class="form-textarea" id="urlsInput" rows="4" placeholder="https://instagram.com/p/...&#10;https://t.me/...">${esc(data.urls)}</textarea>
        <p class="form-hint mt-sm text-sm">${t('Note: If you provide a link, make sure it is a valid web address (e.g., https://... or contains a domain like .com).','नोट: यदि आप लिंक प्रदान करते हैं, तो सुनिश्चित करें कि वह एक मान्य वेब पता है।')}</p>
        <div class="btn-group">${back}${next}</div>`;

      document.getElementById('backBtn').addEventListener('click', () => { clearError(); step = 2; renderStep(); });
      document.getElementById('nextBtn').addEventListener('click', () => {
        clearError();
        const urlsVal = document.getElementById('urlsInput')?.value.trim() || '';
        if (urlsVal) {
          // If user typed numbers like "22222" or random nonsense without dot or protocol
          const lines = urlsVal.split('\n').map(l => l.trim()).filter(Boolean);
          const hasInvalid = lines.some(line => !line.includes('.') && !line.startsWith('http'));
          if (hasInvalid || /\b\d{5,}\b/.test(urlsVal)) {
            return showError(t('Please enter valid URLs (e.g. https://instagram.com/p/...) or leave the field blank.','कृपया मान्य URL दर्ज करें (जैसे https://instagram.com/p/...) या फ़ील्ड खाली छोड़ें।'));
          }
        }
        data.urls = urlsVal;
        step = 4;
        saveState();
        renderStep();
      });

    } else if (step === 4) {
      form.innerHTML = `<h2>${steps[4].label}</h2><p class="form-hint mb-md">${t('Describe what happened in your own words (Minimum 15 characters required).','अपने शब्दों में बताएं कि क्या हुआ (कम से कम 15 अक्षर आवश्यक हैं)।')}</p>
        <textarea class="form-textarea" id="descInput" rows="5" placeholder="${t('Describe what occurred, any threats received, or actions taken...','बताएं क्या हुआ, कोई धमकी मिली या कोई कार्रवाई की गई...')}">${esc(data.description)}</textarea>
        <div class="char-count ${data.description.length>=15?'valid':'invalid'}" id="descCharCount">${data.description.length} / 15 ${t('min characters','न्यूनतम अक्षर')}</div>
        <div class="btn-group">${back}${next}</div>`;

      const descInput = document.getElementById('descInput');
      const countEl = document.getElementById('descCharCount');

      descInput.addEventListener('input', e => {
        clearError();
        const len = e.target.value.trim().length;
        countEl.textContent = `${len} / 15 ${t('min characters','न्यूनतम अक्षर')}`;
        countEl.className = `char-count ${len >= 15 ? 'valid' : 'invalid'}`;
      });

      document.getElementById('backBtn').addEventListener('click', () => { clearError(); step = 3; renderStep(); });
      document.getElementById('nextBtn').addEventListener('click', () => {
        clearError();
        const desc = descInput.value.trim();
        if (!desc || desc.length < 15) {
          return showError(t('Please describe what happened in at least 15 characters so we can assist effectively.','कृपया कम से कम 15 अक्षरों में बताएं कि क्या हुआ ताकि हम प्रभावी सहायता कर सकें।'));
        }
        if (/^(.)\1+$/.test(desc) || /\b\d{6,}\b/.test(desc)) {
          return showError(t('Please provide a meaningful description rather than repetitive characters or numbers.','कृपया दोहराव वाले अक्षरों या संख्याओं के बजाय एक सार्थक विवरण प्रदान करें।'));
        }
        data.description = desc;
        step = 5;
        saveState();
        renderStep();
      });

    } else if (step === 5) {
      const tl = {
        morphed: t('Morphed image abuse','मॉर्फ्ड तस्वीर दुरुपयोग'),
        impersonation: t('Online impersonation (fake profile)','ऑनलाइन प्रतिरूपण (नकली प्रोफ़ाइल)'),
        fabricated: t('Fabricated AI-generated content','बनावटी AI-जनित कॉन्टेंट'),
        other: data.typeOther || t('Other incident','अन्य घटना')
      };

      const dateText = data.dateUnsure ? (data.dateApprox || t('Not sure','पता नहीं')) : (data.date || t('Not specified','निर्दिष्ट नहीं'));

      form.innerHTML = `<h2>${t('Review Your Report','अपनी रिपोर्ट की समीक्षा करें')}</h2>
        <p class="form-hint mb-md">${t('All information has been verified and saved into your local database.','सभी जानकारी सत्यापित की गई है और आपके स्थानीय डेटाबेस में सहेजी गई है।')}</p>
        
        <div class="card card-accent">
          <h3>${t('Type of Abuse','दुरुपयोग का प्रकार')}</h3>
          <p><strong>${esc(tl[data.type] || t('Not specified','निर्दिष्ट नहीं'))}</strong></p>
        </div>

        <div class="card">
          <h3>${t('Platforms Involved','शामिल प्लेटफॉर्म')}</h3>
          <p>${data.platforms.length ? esc(data.platforms.join(', ')) : t('None','कोई नहीं')}</p>
        </div>

        <div class="card">
          <h3>${t('Date of Incident','घटना की तारीख')}</h3>
          <p>${esc(dateText)}</p>
        </div>

        <div class="card">
          <h3>${t('Preserved URLs','सहेजे गए लिंक')}</h3>
          <p style="word-break:break-all">${esc(data.urls || t('None provided','कोई नहीं दिया गया'))}</p>
        </div>

        <div class="card">
          <h3>${t('Incident Description','घटना का विवरण')}</h3>
          <p>${esc(data.description || t('None','कोई नहीं'))}</p>
        </div>

        <div class="notice notice-info mt-md">
          <strong>💾 ${t('Data Storage Confirmation:','डेटा संग्रह पुष्टि:')}</strong> ${t('This report is stored locally in SQLite database (data/narisuraksha.db) and your encrypted browser storage. Zero data uploaded to cloud.','यह रिपोर्ट स्थानीय रूप से SQLite डेटाबेस (data/narisuraksha.db) और आपके एन्क्रिप्टेड ब्राउज़र स्टोरेज में सहेजी गई है।')}
        </div>

        <div class="btn-group">${back}<button class="btn btn-primary" id="addToTimeline">${t('Save & Add to Timeline','सहेजें और टाइमलाइन में जोड़ें')}</button></div>`;

      document.getElementById('backBtn').addEventListener('click', () => { clearError(); step = 4; renderStep(); });

      document.getElementById('addToTimeline').addEventListener('click', async () => {
        clearError();
        // Validation check to prevent blank submission
        if (!data.type || !data.platforms.length || !data.description || data.description.length < 15) {
          return showError(t('Incomplete report data. Please review the previous steps before saving.','अपूर्ण रिपोर्ट डेटा। कृपया सहेजने से पहले पिछले चरणों की समीक्षा करें।'));
        }

        const dateVal = data.dateUnsure ? data.dateApprox : data.date;
        const desc = `${tl[data.type] || t('Incident','घटना')} [${data.platforms.join(', ')}]: ${data.description.slice(0, 200)}`;

        const res = await api('POST', '/timeline', {
          session_id: session(),
          date: dateVal,
          description: desc,
          type: 'incident'
        });

        if (res.error) {
          return showError(res.error);
        }

        toast(t('Report saved to SQLite database and added to timeline!','रिपोर्ट SQLite डेटाबेस में सहेजी गई और टाइमलाइन में जोड़ी गई!'), 'success');

        // Reset report state
        step = 0;
        data = { type:'', typeOther:'', platforms:[], platformOther:'', date:'', dateUnsure:false, dateApprox:'', urls:'', description:'', id:'' };
        await api('POST', '/report', { session_id: session(), data: { ...data, step: 0, id: Date.now().toString(36) } });
        window.location.hash = '#/timeline';
      });
    }
  }

  init();
}

// ====================== EVIDENCE & SCREENSHOT VAULT ======================
function renderEvidence(t) {
  return `<div class="page-section">
    <h1>${t('Evidence Checklist & Screenshot Vault','सबूत सूची और स्क्रीनशॉट वॉल्ट')}</h1>
    <p class="subtitle">${t('Document and store your evidence securely. Nothing is uploaded to public cloud servers. Everything is stored in your local workspace database.','अपने सबूत सुरक्षित रूप से एकत्र और संग्रहीत करें। सार्वजनिक क्लाउड सर्वर पर कुछ भी अपलोड नहीं होता है। सब कुछ स्थानीय डेटाबेस में रहता है।')}</p>
    
    <!-- Screenshot Vault Card -->
    <div class="vault-card">
      <div class="vault-header">
        <div>
          <h2>${t('Screenshot Evidence Vault','स्क्रीनशॉट सबूत वॉल्ट')}</h2>
          <p class="form-hint">${t('Attach screenshots of morphed images, threatening chats, or abuser profiles. Stored in your local database.','मॉर्फ्ड तस्वीरों, धमकी भरे चैट या दुरुपयोगकर्ता प्रोफ़ाइल के स्क्रीनशॉट संलग्न करें।')}</p>
        </div>
        <span class="vault-badge"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>${t('Local SQLite DB','स्थानीय SQLite DB')}</span>
      </div>

      <div class="upload-dropzone" id="uploadDropzone">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        <div class="upload-prompt">${t('Click or drag & drop screenshots here','स्क्रीनशॉट यहाँ क्लिक करें या खींचकर छोड़ें')}</div>
        <div class="upload-sub">${t('Supports PNG, JPG, JPEG, WEBP (Max 15MB)','PNG, JPG, JPEG, WEBP समर्थित (अधिकतम 15MB)')}</div>
        <input type="file" id="ssFileInput" accept="image/png,image/jpeg,image/webp" style="display:none">
      </div>

      <div id="ssUploadMeta" style="display:none" class="card mb-md">
        <div class="form-group mb-sm">
          <label class="form-label">${t('Screenshot Title / Caption (Optional)','स्क्रीनशॉट शीर्षक / विवरण (वैकल्पिक)')}</label>
          <input type="text" class="form-input" id="ssCaption" placeholder="${t('e.g. Post on Instagram with morphed photo by @user','जैसे @user द्वारा मॉर्फ्ड फोटो के साथ इंस्टाग्राम पोस्ट')}" maxlength="150">
        </div>
        <div class="btn-group">
          <button class="btn btn-primary btn-sm" id="btnSaveScreenshot">${t('Save Screenshot to Database','डेटाबेस में स्क्रीनशॉट सहेजें')}</button>
          <button class="btn btn-ghost btn-sm" id="btnCancelScreenshot">${t('Cancel','रद्द करें')}</button>
        </div>
      </div>

      <div id="screenshotGalleryLoading" style="display:none" class="text-center"><span class="loading-spinner"></span></div>
      <div id="screenshotGrid" class="screenshot-grid"></div>
      <p id="screenshotEmpty" class="text-sec text-center mt-md text-sm" style="display:none">${t('No screenshots attached yet. Use the area above to add your first screenshot.','अभी तक कोई स्क्रीनशॉट नहीं जोड़ा गया। ऊपर दिए गए क्षेत्र का उपयोग करके पहला स्क्रीनशॉट जोड़ें।')}</p>
    </div>

    <!-- Lightbox Modal -->
    <div id="screenshotLightbox" class="lightbox-modal" aria-hidden="true">
      <button class="lightbox-close" id="lightboxClose" aria-label="${t('Close','बंद करें')}">&times;</button>
      <div class="lightbox-content">
        <img id="lightboxImg" class="lightbox-img" src="" alt="Screenshot Evidence">
        <div id="lightboxCaption" class="lightbox-caption"></div>
      </div>
    </div>

    <!-- Checklist Section -->
    <div class="eyebrow mt-lg">${t('Preservation Checklist','संरक्षण चेकलिस्ट')}</div>
    <h2>${t('Evidence Checklist','सबूत सूची')}</h2>
    <div class="notice notice-info mb-md">${t('Use this checklist to track critical evidence on your device.','अपने डिवाइस पर महत्वपूर्ण सबूत ट्रैक करने के लिए इस चेकलिस्ट का उपयोग करें।')}</div>
    <div id="checklistItems"></div>

    <!-- Storage Transparency Card -->
    <div class="storage-card mt-lg">
      <h3><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>${t('Where is your data stored?','आपका डेटा कहाँ संग्रहीत है?')}</h3>
      <p class="storage-details" id="dbInfoText">
        ${t('Loading database storage status...','डेटाबेस स्थिति लोड हो रही है...')}
      </p>
      <div class="storage-tags" id="storageTags">
        <span class="storage-tag">🗄️ SQLite: data/narisuraksha.db</span>
        <span class="storage-tag">📄 JSON Backup: data/db.json</span>
        <span class="storage-tag">🔐 AES-256-GCM Browser Encryption</span>
        <span class="storage-tag">🚫 Zero Cloud Uploads</span>
      </div>
    </div>
  </div>`;
}

function setupEvidence(t) {
  let pendingFile = null;

  // --- Screenshot Vault Management ---
  const dropzone = document.getElementById('uploadDropzone');
  const fileInput = document.getElementById('ssFileInput');
  const metaBox = document.getElementById('ssUploadMeta');
  const captionInput = document.getElementById('ssCaption');
  const saveBtn = document.getElementById('btnSaveScreenshot');
  const cancelBtn = document.getElementById('btnCancelScreenshot');
  const grid = document.getElementById('screenshotGrid');
  const emptyMsg = document.getElementById('screenshotEmpty');
  const lightbox = document.getElementById('screenshotLightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');

  dropzone?.addEventListener('click', () => fileInput?.click());

  dropzone?.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone?.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
  dropzone?.addEventListener('drop', e => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files?.length) handleFile(e.dataTransfer.files[0]);
  });

  fileInput?.addEventListener('change', e => {
    if (e.target.files?.length) handleFile(e.target.files[0]);
  });

  function handleFile(file) {
    if (!file.type.startsWith('image/')) {
      return toast(t('Please select an image file (PNG, JPG, WEBP).','कृपया एक छवि फ़ाइल (PNG, JPG, WEBP) चुनें।'), 'error');
    }
    if (file.size > 15 * 1024 * 1024) {
      return toast(t('Image size exceeds 15MB limit.','छवि का आकार 15MB सीमा से अधिक है।'), 'error');
    }

    pendingFile = file;
    metaBox.style.display = 'block';
    captionInput.value = file.name.replace(/\.[^/.]+$/, '');
    captionInput.focus();
  }

  cancelBtn?.addEventListener('click', () => {
    pendingFile = null;
    metaBox.style.display = 'none';
    if (fileInput) fileInput.value = '';
  });

  saveBtn?.addEventListener('click', () => {
    if (!pendingFile) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result;
      const payload = {
        session_id: session(),
        file_name: pendingFile.name,
        file_type: pendingFile.type,
        file_size: pendingFile.size,
        caption: captionInput.value.trim() || pendingFile.name,
        image_data: base64,
        date_taken: new Date().toLocaleDateString()
      };

      const res = await api('POST', '/screenshots', payload);
      if (res.ok) {
        toast(t('Screenshot saved to SQLite database!','स्क्रीनशॉट SQLite डेटाबेस में सहेजा गया!'), 'success');
        pendingFile = null;
        metaBox.style.display = 'none';
        if (fileInput) fileInput.value = '';
        loadScreenshots();
        loadDBInfo();
      } else {
        toast(res.error || t('Failed to save screenshot.','स्क्रीनशॉट सहेजने में विफल।'), 'error');
      }
    };
    reader.readAsDataURL(pendingFile);
  });

  async function loadScreenshots() {
    try {
      const res = await api('GET', `/screenshots/${session()}`);
      const list = res.screenshots || [];
      if (!list.length) {
        grid.innerHTML = '';
        emptyMsg.style.display = 'block';
        return;
      }
      emptyMsg.style.display = 'none';
      grid.innerHTML = list.map(item => `
        <div class="screenshot-card">
          <div class="screenshot-thumb-wrap" data-img="${item.imageData}" data-caption="${esc(item.caption)}">
            <img class="screenshot-thumb" src="${item.imageData}" alt="${esc(item.caption)}" loading="lazy">
            <div class="screenshot-zoom-overlay">${t('View Full Size','पूरा आकार देखें')}</div>
          </div>
          <div class="screenshot-info">
            <div class="screenshot-caption">${esc(item.caption || item.fileName)}</div>
            <div class="screenshot-meta">${esc(item.dateTaken || '')} &bull; ${(item.fileSize / 1024).toFixed(0)} KB</div>
            <div class="screenshot-actions">
              <button class="btn-delete-ss" data-del="${item.id}">${t('Delete','हटाएं')}</button>
            </div>
          </div>
        </div>
      `).join('');

      // Zoom click handler
      grid.querySelectorAll('.screenshot-thumb-wrap').forEach(wrap => {
        wrap.addEventListener('click', () => {
          lightboxImg.src = wrap.dataset.img;
          lightboxCaption.textContent = wrap.dataset.caption;
          lightbox.setAttribute('aria-hidden', 'false');
        });
      });

      // Delete click handler
      grid.querySelectorAll('[data-del]').forEach(btn => {
        btn.addEventListener('click', async e => {
          e.stopPropagation();
          const id = btn.dataset.del;
          await api('DELETE', `/screenshots/${session()}/${id}`);
          toast(t('Screenshot deleted.','स्क्रीनशॉट हटा दिया गया।'), 'info');
          loadScreenshots();
          loadDBInfo();
        });
      });
    } catch (err) {
      console.warn('Screenshot load error:', err);
    }
  }

  lightboxClose?.addEventListener('click', () => lightbox.setAttribute('aria-hidden', 'true'));
  lightbox?.addEventListener('click', e => { if (e.target === lightbox) lightbox.setAttribute('aria-hidden', 'true'); });

  // --- Checklist Management ---
  const items = [
    { key:'screenshots', label:t('Screenshots of the content','कॉन्टेंट के स्क्रीनशॉट'), help:t('Take a screenshot showing the full post including date, time, and profile name. On most phones: power + volume-down.','पूरी पोस्ट का स्क्रीनशॉट लें जिसमें तारीख, समय और प्रोफ़ाइल नाम दिखे। अधिकांश फोन: पावर + वॉल्यूम-डाउन।') },
    { key:'urls', label:t('URLs/links saved','URL/लिंक सहेजे'), help:t('Copy the web address of the page or post. In a browser, tap the address bar and copy.','पेज या पोस्ट का वेब पता कॉपी करें। ब्राउज़र में एड्रेस बार टैप करें और कॉपी करें।') },
    { key:'messages', label:t('Related messages saved','संबंधित संदेश सहेजे'), help:t('Screenshot threatening or relevant messages with timestamps and sender info.','धमकी भरे या प्रासंगिक संदेशों का टाइमस्टैम्प और भेजने वाले की जानकारी के साथ स्क्रीनशॉट लें।') },
    { key:'timestamps', label:t('Dates and times noted','तारीखें और समय नोट किए'), help:t('Write down when you first saw the content, when it was posted, and when you collected evidence.','लिखें कब आपने कॉन्टेंट पहली बार देखा, कब पोस्ट हुआ, और कब सबूत लिए।') },
    { key:'profile', label:t('Abuser profile info saved','दुरुपयोगकर्ता प्रोफ़ाइल जानकारी सहेजी'), help:t('Screenshot the profile sharing the content. Note username, display name, and profile URL.','कॉन्टेंट साझा करने वाले की प्रोफ़ाइल का स्क्रीनशॉट लें। यूज़रनेम, नाम और URL नोट करें।') },
    { key:'witnesses', label:t('Witnesses noted','गवाह नोट किए'), help:t('Note if anyone else saw the content. Only note names of people who consent.','नोट करें कि क्या किसी और ने देखा। केवल सहमत लोगों के नाम नोट करें।') },
  ];

  async function renderChecklist() {
    const res = await api('GET', `/evidence/${session()}`);
    const state = res.data || {};
    document.getElementById('checklistItems').innerHTML = items.map(item => {
      const s = state[item.key] || { done:false, notes:'' };
      return `<div class="checklist-item"><div class="checklist-header"><input type="checkbox" id="chk-${item.key}" ${s.done?'checked':''} aria-label="${item.label}"><span class="checklist-title">${item.label}</span>
        <button class="checklist-toggle" data-key="${item.key}" aria-label="Toggle"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button></div>
        <div class="checklist-body" id="body-${item.key}"><p>${item.help}</p><textarea class="checklist-notes" id="notes-${item.key}" placeholder="${t('Your notes...','आपके नोट्स...')}">${esc(s.notes)}</textarea></div></div>`;
    }).join('');

    items.forEach(item => {
      document.getElementById(`chk-${item.key}`)?.addEventListener('change', saveChecklist);
      document.getElementById(`notes-${item.key}`)?.addEventListener('input', debounce(saveChecklist, 500));
      document.querySelector(`[data-key="${item.key}"]`)?.addEventListener('click', function() {
        const body = document.getElementById(`body-${item.key}`);
        const open = body.classList.toggle('open');
        this.classList.toggle('open', open);
      });
    });
  }

  async function saveChecklist() {
    const state = {};
    items.forEach(item => {
      state[item.key] = {
        done: document.getElementById(`chk-${item.key}`)?.checked || false,
        notes: document.getElementById(`notes-${item.key}`)?.value || ''
      };
    });
    await api('POST', '/evidence', { session_id: session(), data: state });
    loadDBInfo();
  }

  // --- Load DB Info & Transparency ---
  async function loadDBInfo() {
    try {
      const res = await api('GET', `/db/info/${session()}`);
      const textEl = document.getElementById('dbInfoText');
      if (res.ok && textEl) {
        const s = res.stats;
        textEl.innerHTML = t(
          `Your data is stored in a <strong>${res.engine}</strong> located at <code>${res.dbFile}</code> in your local project workspace, backed up in <code>${res.backupFile}</code>, and encrypted in your browser (AES-256-GCM).<br><br>
          <strong>Current Session Records:</strong> ${s.totalRecords} total entries (${s.hasReport ? '1 incident report' : '0 reports'}, ${s.screenshotsCount} screenshots, ${s.timelineEventsCount} timeline events, ${s.evidenceCheckedCount} verified checklist items). ML Severity Assessment: <strong>${s.mlSeverity}</strong>.`,
          `आपका डेटा आपके स्थानीय प्रोजेक्ट वर्कस्पेस में <code>${res.dbFile}</code> पर स्थित एक <strong>${res.engine}</strong> में संग्रहीत है, <code>${res.backupFile}</code> में बैकअप किया गया है, और आपके ब्राउज़र (AES-256-GCM) में एन्क्रिप्टेड है।<br><br>
          <strong>वर्तमान सत्र रिकॉर्ड:</strong> ${s.totalRecords} कुल प्रविष्टियाँ (${s.hasReport ? '1 घटना रिपोर्ट' : '0 रिपोर्ट'}, ${s.screenshotsCount} स्क्रीनशॉट, ${s.timelineEventsCount} टाइमलाइन घटनाएँ, ${s.evidenceCheckedCount} सत्यापित चेकलिस्ट आइटम)। एमएल गंभीरता आकलन: <strong>${s.mlSeverity}</strong>।`
        );
      }
    } catch (err) {
      console.warn('DB info load error:', err);
    }
  }

  loadScreenshots();
  renderChecklist();
  loadDBInfo();
}

function debounce(fn, ms) { let timer; return (...a) => { clearTimeout(timer); timer = setTimeout(() => fn(...a), ms); }; }

// ====================== TIMELINE ======================
function renderTimeline(t) {
  return `<div class="page-section"><h1>${t('My Timeline','मेरी टाइमलाइन')}</h1>
    <p class="subtitle">${t('Organise events in chronological order. Reorder, edit, and export a printable summary. All data is saved in your local SQLite database.','घटनाओं को कालानुक्रमिक क्रम में व्यवस्थित करें। पुनर्व्यवस्थित करें और प्रिंट करने योग्य सारांश निर्यात करें।')}</p>
    <div class="btn-group mb-lg">
      <button class="btn btn-primary btn-sm" id="addEvent">${t('Add Event','घटना जोड़ें')}</button>
      <button class="btn btn-secondary btn-sm" id="exportTimeline">${t('Print / Export','प्रिंट / निर्यात')}</button>
      <button class="btn btn-secondary btn-sm" id="loadDemo">${t('Load Demo','डेमो लोड करें')}</button>
    </div>
    <div id="addEventForm" style="display:none" class="card mb-lg">
      <h3>${t('New Event','नई घटना')}</h3>
      <div class="form-group">
        <label class="form-label">${t('Date (4-digit year, e.g. 15 Jan 2024)','तारीख (4 अंकों का वर्ष, जैसे 15 Jan 2024)')}</label>
        <input type="text" class="form-input" id="eventDate" placeholder="${t('e.g. 15 Jan 2024','जैसे 15 Jan 2024')}" maxlength="40">
      </div>
      <div class="form-group">
        <label class="form-label">${t('What happened (Required, min 4 characters)','क्या हुआ (आवश्यक, कम से कम 4 अक्षर)')}</label>
        <textarea class="form-textarea" id="eventDesc" rows="3" maxlength="500" placeholder="${t('Describe the event clearly...','घटना का स्पष्ट रूप से वर्णन करें...')}"></textarea>
      </div>
      <div class="btn-group">
        <button class="btn btn-primary btn-sm" id="saveEvent">${t('Save Event','घटना सहेजें')}</button>
        <button class="btn btn-text btn-sm" id="cancelEvent">${t('Cancel','रद्द करें')}</button>
      </div>
    </div>
    <div id="timelineList"></div>
    <p id="timelineEmpty" class="text-sec text-center mt-lg" style="display:none">${t('No events yet.','अभी कोई घटना नहीं।')}</p></div>`;
}

function setupTimeline(t) {
  async function renderList() {
    const res = await api('GET', `/timeline/${session()}`);
    const events = res.events || [];
    const empty = document.getElementById('timelineEmpty');
    const list = document.getElementById('timelineList');
    empty.style.display = events.length ? 'none' : 'block';
    if (!events.length) { list.innerHTML = ''; return; }
    list.innerHTML = `<div class="tl-list">${events.map((ev,i) => `
      <div class="tl-item"><div class="tl-date">${esc(ev.date||t('No date',''))} ${ev.demo?'<span class="tl-demo">[DEMO]</span>':''}</div>
        <div class="tl-content"><p>${esc(ev.description)}</p><div class="tl-actions">
          ${i>0?`<button data-action="up" data-id="${ev.id}">${t('Up','ऊपर')}</button>`:''}
          ${i<events.length-1?`<button data-action="down" data-id="${ev.id}">${t('Down','नीचे')}</button>`:''}
          <button data-action="del" data-id="${ev.id}">${t('Remove','हटाएं')}</button>
        </div></div></div>`).join('')}</div>`;
    list.querySelectorAll('[data-action]').forEach(btn => btn.addEventListener('click', async () => {
      const res2 = await api('GET', `/timeline/${session()}`);
      const evts = res2.events || [];
      const idx = evts.findIndex(e => e.id === btn.dataset.id);
      if (btn.dataset.action === 'del') {
        await api('DELETE', `/timeline/${session()}/${btn.dataset.id}`);
        toast(t('Event removed.','घटना हटाई गई।'), 'info');
      } else {
        const swap = btn.dataset.action === 'up' ? idx-1 : idx+1;
        if (swap < 0 || swap >= evts.length) return;
        const order = evts.map(e => e.id);
        [order[idx], order[swap]] = [order[swap], order[idx]];
        await api('PUT', '/timeline/reorder', { session_id: session(), order });
      }
      renderList();
    }));
  }

  document.getElementById('addEvent').addEventListener('click', () => {
    document.getElementById('addEventForm').style.display='block';
    document.getElementById('eventDate').focus();
  });
  document.getElementById('cancelEvent').addEventListener('click', () => {
    document.getElementById('addEventForm').style.display='none';
  });
  document.getElementById('saveEvent').addEventListener('click', async () => {
    const desc = document.getElementById('eventDesc').value.trim();
    const date = document.getElementById('eventDate').value.trim();
    if (!desc || desc.length < 4) {
      return toast(t('Please provide a description of the event (minimum 4 characters).','कृपया घटना का विवरण प्रदान करें (कम से कम 4 अक्षर)।'), 'error');
    }
    if (/\b\d{5,}\b/.test(date)) {
      return toast(t('Year cannot exceed 4 digits (e.g. 2024).','वर्ष 4 अंकों से अधिक नहीं हो सकता (जैसे 2024)।'), 'error');
    }

    const res = await api('POST', '/timeline', { session_id: session(), date, description: desc, type: 'event' });
    if (res.error) {
      return toast(res.error, 'error');
    }
    document.getElementById('addEventForm').style.display='none';
    document.getElementById('eventDate').value='';
    document.getElementById('eventDesc').value='';
    toast(t('Event saved to database!','घटना डेटाबेस में सहेजी गई!'), 'success');
    renderList();
  });

  document.getElementById('loadDemo').addEventListener('click', async () => {
    const demos = [
      { date:'10 Jan 2024', desc:t('Noticed a manipulated image on social media.','सोशल मीडिया पर छेड़छाड़ तस्वीर देखी।') },
      { date:'10 Jan 2024', desc:t('Took screenshots of the post and profile. Saved URL.','पोस्ट और प्रोफ़ाइल के स्क्रीनशॉट लिए। URL सहेजा।') },
      { date:'11 Jan 2024', desc:t('Reported the post to the platform.','प्लेटफॉर्म पर पोस्ट की रिपोर्ट की।') },
      { date:'12 Jan 2024', desc:t('Filed complaint on cybercrime.gov.in.','cybercrime.gov.in पर शिकायत दर्ज की।') },
    ];
    for (const d of demos) await api('POST', '/timeline', { session_id: session(), date: d.date, description: d.desc, type: 'event', demo: true });
    toast(t('Demo data loaded!','डेमो डेटा लोड हो गया!'), 'success');
    renderList();
  });

  document.getElementById('exportTimeline').addEventListener('click', async () => {
    const res = await api('GET', `/timeline/${session()}`);
    const events = res.events || [];
    if (!events.length) return toast(t('No events to export.','निर्यात करने के लिए कोई घटना नहीं।'), 'error');
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${t('Timeline','टाइमलाइन')}</title><style>body{font-family:system-ui,sans-serif;max-width:700px;margin:40px auto;padding:0 20px;color:#2C2825}h1{font-size:1.5rem}h2{font-size:0.875rem;color:#888;margin-bottom:24px}.ev{margin-bottom:16px;padding:12px;border:1px solid #ddd;border-radius:8px}.date{font-size:0.8rem;color:#888;font-weight:600}.desc{margin-top:4px}.demo{color:#C07A28;font-size:0.7rem;font-weight:600}</style></head><body><h1>${t('Incident Timeline','घटना टाइमलाइन')}</h1><h2>${new Date().toLocaleDateString()}</h2>${events.map(ev=>`<div class="ev"><div class="date">${esc(ev.date)} ${ev.demo?'<span class="demo">[DEMO]</span>':''}</div><div class="desc">${esc(ev.description)}</div></div>`).join('')}<p style="font-size:0.75rem;color:#888;margin-top:24px">${t('Generated by NariSuraksha AI (prototype).','NariSuraksha AI (प्रोटोटाइप) द्वारा जनरेट।')}</p></body></html>`;
    const w = window.open('','_blank'); w.document.write(html); w.document.close(); w.print();
  });
  renderList();
}

// ====================== CHAT ======================
function renderChat(t) {
  return `<div class="page-section"><h1>${t('Ask for Guidance','मार्गदर्शन लें')}</h1>
    <div class="notice notice-danger mb-md">${t('This assistant gives general information only. It cannot verify images or file complaints.','यह सहायक केवल सामान्य जानकारी देता है। यह तस्वीरें सत्यापित नहीं कर सकता या शिकायत दर्ज नहीं कर सकता।')}</div>
    <div class="notice mb-lg">${t('Do not type personal details, names, or URLs into this chat.','इस चैट में व्यक्तिगत विवरण, नाम या URL न टाइप करें।')}</div>
    <div class="chat-container">
      <div class="chat-messages" id="chatMessages" aria-live="polite">
        <div class="chat-msg bot"><div class="chat-bubble">${t('Hello. I can help you understand your reporting options, evidence collection, content removal, and account security. What would you like to know?','नमस्ते। मैं आपको रिपोर्टिंग विकल्प, सबूत इकट्ठा करने, कॉन्टेंट हटाने और अकाउंट सुरक्षा के बारे में समझने में मदद कर सकती हूं। आप क्या जानना चाहेंगी?')}</div></div>
      </div>
      <div class="chat-input-area">
        <input type="text" class="chat-input" id="chatInput" placeholder="${t('Type your question...','अपना प्रश्न टाइप करें...')}" maxlength="500" aria-label="${t('Question','प्रश्न')}">
        <button class="chat-send" id="chatSend" aria-label="${t('Send','भेजें')}"></button>
      </div>
    </div></div>`;
}

function setupChat(t) {
  const messages = document.getElementById('chatMessages');
  const input = document.getElementById('chatInput');
  const send = document.getElementById('chatSend');

  function addMsg(text, role, isAi) {
    const div = document.createElement('div');
    div.className = `chat-msg ${role}`;
    let badge = role === 'bot' && isAi ? `<span class="ai-badge">AI</span>` : '';
    div.innerHTML = `<div class="chat-bubble">${esc(text)}${badge}</div>`;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
  }

  function showTyping() {
    const div = document.createElement('div');
    div.className = 'chat-msg bot';
    div.id = 'typingIndicator';
    div.innerHTML = '<div class="chat-bubble typing-indicator"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>';
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
  }

  function hideTyping() { document.getElementById('typingIndicator')?.remove(); }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
    addMsg(text, 'user');
    input.value = '';
    send.disabled = true;
    showTyping();
    try {
      const data = await api('POST', '/chat', { message: text, lang: lang() });
      hideTyping();
      addMsg(data.response || data.error, 'bot', data.ai);
    } catch {
      hideTyping();
      addMsg(t('Could not reach the server.','सर्वर से संपर्क नहीं हो सका।'), 'bot');
    }
    send.disabled = false;
    input.focus();
  }

  send.addEventListener('click', sendMessage);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(); });
}

// ====================== GUIDE ======================
function renderGuide(t) {
  return `<div class="page-section"><h1>${t('Reporting Guide','रिपोर्टिंग गाइड')}</h1>
    <p class="subtitle">${t('Steps to report morphed image abuse in India.','भारत में मॉर्फ्ड इमेज दुरुपयोग की रिपोर्ट करने के चरण।')}</p>
    <div class="notice">${t('All phone numbers and links must be verified before real use.','सभी फ़ोन नंबर और लिंक वास्तविक उपयोग से पहले सत्यापित करें।')}</div>
    <div class="section mt-lg"><h2 class="section-title">${t('Step 1: Preserve Evidence','चरण 1: सबूत सुरक्षित करें')}</h2>
      <ul class="content-list"><li>${t('Take screenshots with dates, URLs, and profile names.','तारीखों, URL और प्रोफ़ाइल नामों के साथ स्क्रीनशॉट लें।')}</li><li>${t('Save URLs before content is removed.','कॉन्टेंट हटाए जाने से पहले URL सहेजें।')}</li><li>${t('Use the <a href="#/evidence">Evidence Checklist</a>.','<a href="#/evidence">सबूत सूची</a> का उपयोग करें।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('Step 2: Report to Platform','चरण 2: प्लेटफॉर्म पर रिपोर्ट करें')}</h2>
      <ul class="content-list"><li>${t('Use the "Report" button on the post or profile.','पोस्ट या प्रोफ़ाइल पर "रिपोर्ट" बटन का उपयोग करें।')}</li><li>${t('See <a href="#/removal">Content Removal</a> for platform-specific steps.','<a href="#/removal">कॉन्टेंट हटाएं</a> में प्लेटफॉर्म-विशिष्ट चरण देखें।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('Step 3: File Cybercrime Complaint','चरण 3: साइबर अपराध शिकायत दर्ज करें')}</h2>
      <div class="card card-teal"><h3>${t('National Cybercrime Portal','राष्ट्रीय साइबर अपराध पोर्टल')}</h3><p>cybercrime.gov.in <span class="verify-badge">${t('Verify','सत्यापित करें')}</span></p><p class="mt-md">${t('File complaints online for crimes against women and children.','महिलाओं और बच्चों के खिलाफ अपराधों के लिए ऑनलाइन शिकायत दर्ज करें।')}</p></div>
      <div class="card card-teal"><h3>${t('Cybercrime Helpline','साइबर अपराध हेल्पलाइन')}</h3><p>1930 <span class="verify-badge">${t('Verify','सत्यापित करें')}</span></p><p class="mt-md">${t('Toll-free number to report online abuse.','ऑनलाइन दुरुपयोग की रिपोर्ट करने के लिए टोल-फ्री नंबर।')}</p></div></div>
    <div class="section"><h2 class="section-title">${t('Step 4: Police Complaint (Optional)','चरण 4: पुलिस शिकायत (वैकल्पिक)')}</h2>
      <ul class="content-list"><li>${t('Visit nearest police station or Cyber Cell with evidence.','सबूतों के साथ निकटतम पुलिस स्टेशन या साइबर सेल जाएं।')}</li><li>${t('Carry your printed timeline and screenshots.','प्रिंटेड टाइमलाइन और स्क्रीनशॉट साथ ले जाएं।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('Step 5: Secure Accounts','चरण 5: अकाउंट सुरक्षित करें')}</h2>
      <ul class="content-list"><li>${t('Change passwords and enable 2FA. See <a href="#/security">Secure My Accounts</a>.','पासवर्ड बदलें और 2FA चालू करें। <a href="#/security">अकाउंट सुरक्षित करें</a> देखें।')}</li></ul></div>
    <div class="notice notice-info mt-lg">${t('This is general information only. Consult a lawyer for specific advice.','यह केवल सामान्य जानकारी है। विशेष सलाह के लिए वकील से परामर्श करें।')}</div></div>`;
}

// ====================== REMOVAL ======================
function renderRemoval(t) {
  const p = [
    { n:'Facebook / Meta', s:[t('Tap three dots on post > Report.','पोस्ट पर तीन बिंदु > रिपोर्ट।'),t('For intimate images: facebook.com/help, search "non-consensual".','अंतरंग तस्वीरें: facebook.com/help में "non-consensual" खोजें।'),t('Impersonation: report as "Pretending to be someone".','प्रतिरूपण: "किसी का नाटक" के रूप में रिपोर्ट करें।')] },
    { n:'Instagram', s:[t('Tap three dots on post > Report.','पोस्ट पर तीन बिंदु > रिपोर्ट।'),t('Impersonation: profile > three dots > Report > "Pretending to be someone else".','प्रतिरूपण: प्रोफ़ाइल > तीन बिंदु > रिपोर्ट > "किसी और का नाटक"।')] },
    { n:'Twitter / X', s:[t('Three dots on tweet > Report Tweet.','ट्वीट पर तीन बिंदु > ट्वीट रिपोर्ट करें।'),t('For intimate media: select "private information" or search "non-consensual nudity".','अंतरंग मीडिया: "निजी जानकारी" चुनें।')] },
    { n:'WhatsApp', s:[t('Open chat > contact name > scroll down > Report. Block sender.','चैट खोलें > संपर्क नाम > नीचे स्क्रॉल > रिपोर्ट। प्रेषक ब्लॉक करें।'),t('Take screenshots before blocking.','ब्लॉक करने से पहले स्क्रीनशॉट लें।')] },
    { n:'YouTube', s:[t('Below video > Report (flag icon).','वीडियो के नीचे > रिपोर्ट (झंडा)।'),t('Privacy violations: use YouTube Privacy Complaint process.','गोपनीयता: YouTube गोपनीयता शिकायत प्रक्रिया।')] },
    { n:'Telegram', s:[t('Hold message > Report. For channels: channel name > Report.','संदेश दबाएं > रिपोर्ट। चैनल: चैनल नाम > रिपोर्ट।'),t('Email abuse@telegram.org for severe cases.','गंभीर: abuse@telegram.org पर ईमेल करें।')] },
  ];
  return `<div class="page-section"><h1>${t('Content Removal','कॉन्टेंट हटाएं')}</h1>
    <p class="subtitle">${t('Steps to request removal on each platform.','हर प्लेटफॉर्म पर हटाने का अनुरोध करने के चरण।')}</p>
    <div class="notice">${t('Platform interfaces change. Verify on the actual platform.','प्लेटफॉर्म इंटरफेस बदलते हैं। वास्तविक प्लेटफॉर्म पर सत्यापित करें।')}</div>
    ${p.map(x=>`<div class="section"><h2 class="section-title">${x.n}</h2><ol class="content-list">${x.s.map(s=>`<li>${s}</li>`).join('')}</ol></div>`).join('')}
    <div class="card card-warn mt-lg"><h3>${t('If the platform does not act','अगर प्लेटफॉर्म कार्रवाई नहीं करता')}</h3><p>${t('Escalate via cybercrime.gov.in or helpline 1930.','cybercrime.gov.in या हेल्पलाइन 1930 से बढ़ाएं।')} <span class="verify-badge">${t('Verify','सत्यापित करें')}</span></p></div></div>`;
}

// ====================== SECURITY ======================
function renderSecurity(t) {
  return `<div class="page-section"><h1>${t('Secure My Accounts','अकाउंट सुरक्षित करें')}</h1>
    <p class="subtitle">${t('Steps to protect your accounts after an incident.','किसी घटना के बाद अकाउंट्स सुरक्षित करने के कदम।')}</p>
    <div class="section"><h2 class="section-title">${t('1. Change Passwords','1. पासवर्ड बदलें')}</h2><ul class="content-list"><li>${t('Change on all accounts, starting with email.','सभी अकाउंट्स पर बदलें, ईमेल से शुरू।')}</li><li>${t('Use unique, long passwords (12+ characters).','अलग, लंबे पासवर्ड (12+ अक्षर)।')}</li><li>${t('Avoid personal info in passwords.','पासवर्ड में व्यक्तिगत जानकारी न रखें।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('2. Enable 2FA','2. 2FA चालू करें')}</h2><ul class="content-list"><li>${t('Requires a second step (code to phone) when logging in.','लॉगिन में दूसरा चरण (फोन पर कोड)।')}</li><li>${t('Settings > Security on each platform.','हर प्लेटफॉर्म पर Settings > Security।')}</li><li>${t('Authenticator app is more secure than SMS.','ऑथेंटिकेटर ऐप SMS से अधिक सुरक्षित।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('3. Check Active Sessions','3. सक्रिय सत्र जांचें')}</h2><ul class="content-list"><li>${t('Check Settings > Security > Active Sessions.','Settings > Security > Active Sessions जांचें।')}</li><li>${t('Log out of sessions you do not recognise.','अपरिचित सत्रों से लॉग आउट करें।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('4. Review Privacy Settings','4. गोपनीयता सेटिंग्स जांचें')}</h2><ul class="content-list"><li>${t('Set profiles to private. Disable location sharing.','प्रोफ़ाइल निजी करें। लोकेशन बंद करें।')}</li><li>${t('Remove unnecessary app permissions.','अनावश्यक ऐप अनुमतियां हटाएं।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('5. Secure Email','5. ईमेल सुरक्षित करें')}</h2><ul class="content-list"><li>${t('Email is the key to all accounts. Secure it first.','ईमेल सभी अकाउंट्स की कुंजी है।')}</li><li>${t('Add recovery phone and backup email.','रिकवरी फोन और बैकअप ईमेल जोड़ें।')}</li><li>${t('Check email forwarding for unknown addresses.','अज्ञात पतों के लिए ईमेल फ़ॉरवर्डिंग जांचें।')}</li></ul></div></div>`;
}

// ====================== RESOURCES ======================
function renderResources(t) {
  const r = [
    { n:t('National Cybercrime Helpline','राष्ट्रीय साइबर अपराध हेल्पलाइन'), d:'1930', h:t('Toll-free. Report cyber fraud and abuse.','टोल-फ्री। साइबर धोखाधड़ी और दुरुपयोग रिपोर्ट करें।') },
    { n:t('Cybercrime Portal','साइबर अपराध पोर्टल'), d:'cybercrime.gov.in', h:t('File complaints online.','ऑनलाइन शिकायत दर्ज करें।') },
    { n:t('Women Helpline','महिला हेल्पलाइन'), d:'181', h:t('24/7 helpline for women in distress.','संकट में महिलाओं के लिए 24/7।') },
    { n:t('NCW','राष्ट्रीय महिला आयोग'), d:'ncw.nic.in', h:t('National Commission for Women.','राष्ट्रीय महिला आयोग।') },
    { n:t('Vandrevala Foundation','वंद्रेवाला फाउंडेशन'), d:'1860-2662-345', h:t('24/7 mental health helpline.','24/7 मानसिक स्वास्थ्य हेल्पलाइन।') },
    { n:t('iCall Helpline','iCall हेल्पलाइन'), d:'9152987821', h:t('Counselling and emotional support.','परामर्श और भावनात्मक सहायता।') },
    { n:t('Child Helpline','चाइल्ड हेल्पलाइन'), d:'1098', h:t('24/7 for children in need.','जरूरतमंद बच्चों के लिए 24/7।') },
    { n:t('Emergency','आपातकालीन'), d:'112', h:t('Police, fire, ambulance.','पुलिस, अग्निशमन, एम्बुलेंस।') },
  ];
  return `<div class="page-section"><h1>${t('Resources & Helplines','संसाधन और हेल्पलाइन')}</h1>
    <p class="subtitle">${t('All numbers and links must be verified before use.','सभी नंबर और लिंक उपयोग से पहले सत्यापित करें।')}</p>
    ${r.map(x=>`<div class="resource-item"><span class="resource-name">${x.n} <span class="verify-badge">${t('Verify','सत्यापित करें')}</span></span><span class="resource-desc"><strong>${x.d}</strong></span><span class="resource-desc">${x.h}</span></div>`).join('')}
    <div class="notice notice-info mt-lg">${t('If in immediate danger, call 112 or nearest police station.','तत्काल खतरे में हों तो 112 या निकटतम पुलिस स्टेशन को कॉल करें।')}</div></div>`;
}

// ====================== PRIVACY ======================
function renderPrivacy(t) {
  return `<div class="page-section"><h1>${t('What We Store and How','हम क्या और कैसे रखते हैं')}</h1>
    <div class="card card-teal"><h3>${t('The short version','संक्षिप्त')}</h3><p>${t('Your data is encrypted and stored in your browser and our secure database. We do not track you. You can delete everything at any time.','आपका डेटा एन्क्रिप्ट होकर आपके ब्राउज़र और हमारे सुरक्षित डेटाबेस में रहता है। हम आपको ट्रैक नहीं करते।')}</p></div>
    <div class="section mt-lg"><h2 class="section-title">${t('What is stored','क्या संग्रहीत होता है')}</h2>
      <ul class="content-list"><li><strong>${t('Reports:','रिपोर्ट:')}</strong> ${t('Type, platform, date, URLs, description.','प्रकार, प्लेटफॉर्म, तारीख, URL, विवरण।')}</li><li><strong>${t('Evidence checklist:','सबूत सूची:')}</strong> ${t('Checkbox states and notes.','चेकबॉक्स और नोट्स।')}</li><li><strong>${t('Timeline:','टाइमलाइन:')}</strong> ${t('Dated events.','दिनांकित घटनाएं।')}</li><li><strong>${t('Language:','भाषा:')}</strong> ${t('Hindi or English preference.','हिंदी या अंग्रेज़ी।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('Where it is stored','कहां संग्रहीत होता है')}</h2>
      <ul class="content-list"><li>${t('Encrypted in your browser (AES-256-GCM) and in our server database (SQLite).','आपके ब्राउज़र में एन्क्रिप्टेड (AES-256-GCM) और हमारे सर्वर डेटाबेस (SQLite) में।')}</li><li>${t('Data is linked to an anonymous session ID, not your identity.','डेटा एक गुमनाम सत्र ID से जुड़ा है, आपकी पहचान से नहीं।')}</li><li>${t('No data in URLs, cookies, or server logs.','URL, कुकीज़ या सर्वर लॉग में कोई डेटा नहीं।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('What is NOT collected','क्या एकत्र नहीं किया जाता')}</h2>
      <ul class="content-list"><li>${t('No photographs or media files.','कोई तस्वीर या मीडिया फ़ाइलें नहीं।')}</li><li>${t('No identity info (name, Aadhaar, phone).','कोई पहचान जानकारी नहीं।')}</li><li>${t('No account or login required.','कोई अकाउंट या लॉगिन नहीं।')}</li><li>${t('No advertising, analytics, or tracking.','कोई विज्ञापन, एनालिटिक्स या ट्रैकिंग नहीं।')}</li><li>${t('Chat messages are not logged.','चैट संदेश लॉग नहीं किए जाते।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('AI and Your Data','AI और आपका डेटा')}</h2>
      <ul class="content-list"><li>${t('Form data, names, URLs are never sent to the AI.','फॉर्म डेटा, नाम, URL कभी AI को नहीं भेजे जाते।')}</li><li>${t('Only chat text goes to the AI for a response. Not stored.','केवल चैट टेक्स्ट AI को जाता है। संग्रहीत नहीं।')}</li><li>${t('AI cannot verify images, give verdicts, or file complaints.','AI तस्वीरें सत्यापित नहीं कर सकता।')}</li></ul></div>
    <div class="notice notice-info">${t('In line with India\'s Digital Personal Data Protection Act, 2023.','भारत के डिजिटल व्यक्तिगत डेटा संरक्षण अधिनियम, 2023 के अनुरूप।')}</div></div>`;
}

// ====================== ABOUT ======================
function renderAbout(t) {
  return `<div class="page-section"><h1>${t('About NariSuraksha AI','NariSuraksha AI के बारे में')}</h1>
    <p class="subtitle">${t('A privacy-first platform to help women and girls document morphed image abuse and understand reporting options.','महिलाओं और लड़कियों को मॉर्फ्ड इमेज दुरुपयोग दर्ज करने और रिपोर्टिंग विकल्प समझने में मदद के लिए।')}</p>
    <div class="section"><h2 class="section-title">${t('What It Does','क्या करता है')}</h2><ul class="content-list"><li>${t('Guides incident documentation step by step.','चरण दर चरण घटना दर्ज करने में मार्गदर्शन।')}</li><li>${t('Helps organise evidence and build a timeline.','सबूत व्यवस्थित करने और टाइमलाइन बनाने में मदद।')}</li><li>${t('Provides reporting and support information.','रिपोर्टिंग और सहायता जानकारी।')}</li><li>${t('AI assistant for general guidance.','सामान्य मार्गदर्शन के लिए AI सहायक।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('What It Does NOT Do','क्या नहीं करता')}</h2><ul class="content-list"><li>${t('Does NOT verify image authenticity.','तस्वीर प्रामाणिकता सत्यापित नहीं करता।')}</li><li>${t('Does NOT submit official complaints.','आधिकारिक शिकायत दर्ज नहीं करता।')}</li><li>${t('Does NOT upload sensitive photographs.','संवेदनशील तस्वीरें अपलोड नहीं करता।')}</li><li>${t('Does NOT provide legal advice.','कानूनी सलाह नहीं देता।')}</li><li>${t('Does NOT track or identify users.','उपयोगकर्ताओं को ट्रैक नहीं करता।')}</li></ul></div>
    <div class="notice notice-info">${t('This is a prototype. See <a href="#/notice">Prototype Notice</a>.','यह प्रोटोटाइप है। <a href="#/notice">प्रोटोटाइप सूचना</a> देखें।')}</div></div>`;
}

// ====================== NOTICE ======================
function renderNotice(t) {
  return `<div class="page-section"><h1>${t('Prototype Notice','प्रोटोटाइप सूचना')}</h1>
    <div class="card card-warn"><h3>${t('This is a demonstration prototype','यह एक प्रदर्शन प्रोटोटाइप है')}</h3><p>${t('NariSuraksha AI is a working prototype. It is not a live service.','NariSuraksha AI एक कार्यशील प्रोटोटाइप है। यह लाइव सेवा नहीं है।')}</p></div>
    <div class="section mt-lg"><h2 class="section-title">${t('What this means','इसका मतलब')}</h2><ul class="content-list"><li>${t('All sample reports are fictional.','सभी नमूना रिपोर्ट काल्पनिक हैं।')}</li><li>${t('No real user data or images used.','कोई वास्तविक डेटा या तस्वीरें नहीं।')}</li><li>${t('Phone numbers and links must be verified.','फ़ोन नंबर और लिंक सत्यापित करें।')}</li><li>${t('AI provides pre-written or API-based guidance, not professional advice.','AI पूर्व-लिखित या API-आधारित मार्गदर्शन देता है।')}</li><li>${t('Legal references are general only.','कानूनी संदर्भ केवल सामान्य हैं।')}</li></ul></div>
    <div class="section"><h2 class="section-title">${t('Before deployment','तैनाती से पहले')}</h2><ul class="content-list"><li>${t('Verify all helpline numbers and URLs.','सभी हेल्पलाइन नंबर और URL सत्यापित करें।')}</li><li>${t('Content review by legal professionals.','कानूनी पेशेवरों द्वारा कॉन्टेंट समीक्षा।')}</li><li>${t('HTTPS certificate for production.','प्रोडक्शन के लिए HTTPS प्रमाणपत्र।')}</li><li>${t('Self-host fonts.','फॉन्ट स्वयं होस्ट करें।')}</li><li>${t('Security audit and pen testing.','सुरक्षा ऑडिट और पेन टेस्टिंग।')}</li></ul></div></div>`;
}

// ====================== EXPORTS ======================
export const pageRenderers = { '/home':renderHome, '/report':renderReport, '/evidence':renderEvidence, '/timeline':renderTimeline, '/guide':renderGuide, '/removal':renderRemoval, '/security':renderSecurity, '/chat':renderChat, '/resources':renderResources, '/privacy':renderPrivacy, '/about':renderAbout, '/notice':renderNotice };
export const pageSetups = { '/report':setupReport, '/evidence':setupEvidence, '/timeline':setupTimeline, '/chat':setupChat };
