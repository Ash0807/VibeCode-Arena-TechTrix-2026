# NariSuraksha AI -- Deployment Notes

## Running the Prototype

```bash
cd narisuraksha
cp .env.example .env     # configure environment
npm install              # install dependencies
npm start                # runs on port 3000
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `PORT` | No | Server port (default: 3000) |
| `AI_API_KEY` | No (prototype) | API key for real AI service. Prototype uses canned responses. |

## Before Real Deployment

### 1. HTTPS Certificate
- Configure a TLS certificate for the production domain.
- The server already sets HSTS headers. Ensure HTTP-to-HTTPS redirect at the load balancer or reverse proxy.

### 2. Self-Host Fonts
- Download Noto Sans and Noto Sans Devanagari from Google Fonts.
- Place in `/public/fonts/` and update `main.css` to use `@font-face` declarations.
- Remove `fonts.googleapis.com` and `fonts.gstatic.com` from the CSP `style-src` and `font-src`.

### 3. Real AI Integration
- Set `AI_API_KEY` in `.env` to a real API key (e.g. Gemini, OpenAI).
- Update the `/api/chat` handler in `server.js` to call the AI API.
- Implement system prompt that enforces all hard limits (no image verification, no legal verdicts, no complaint filing).
- Ensure chat messages are not logged.

### 4. Content Review
- All page content must be reviewed by legal professionals.
- Helpline numbers and URLs must be verified against official sources.
- Hindi content should be reviewed by a native Hindi speaker.

### 5. Security Audit
- Conduct penetration testing.
- Run `npm audit` and address any vulnerabilities.
- Review CSP for production domain specifics.
- Consider adding a `nonce` to the CSP `script-src` for additional security.

### 6. Accessibility Audit
- Run Lighthouse accessibility audit.
- Test with screen readers (NVDA, VoiceOver).
- Test keyboard-only navigation end to end.

## Links and Phone Numbers to Verify Before Real Use

| Item | Value | Source to Verify |
|---|---|---|
| National Cybercrime Helpline | 1930 | Ministry of Home Affairs |
| Cybercrime Reporting Portal | cybercrime.gov.in | Ministry of Home Affairs |
| Women Helpline | 181 | Ministry of Women & Child Development |
| National Commission for Women | ncw.nic.in | NCW official site |
| Vandrevala Foundation | 1860-2662-345 | vandrevalafoundation.com |
| iCall Helpline | 9152987821 | icallhelpline.org |
| Cyber Crime Cell (Delhi) | cybercellindia.com | Delhi Police |
| Child Helpline | 1098 | childlineindia.org |
| Emergency Services | 112 | Government of India |
| Facebook/Meta reporting | facebook.com/help | Meta |
| Instagram reporting | In-app | Meta |
| Twitter/X reporting | In-app + help center | X Corp |
| YouTube privacy complaints | YouTube Help | Google |
| Telegram abuse reporting | abuse@telegram.org | Telegram |
| Google content removal | Google Help | Google |

All of the above are marked with a "Verify before use" badge in the prototype UI.

## Production Architecture Recommendations

- Reverse proxy (nginx/Caddy) for TLS termination.
- Rate limiting at the proxy level in addition to Express.
- Consider a CDN for static assets.
- Monitor server uptime and error rates.
- Regularly update dependencies (`npm audit fix`).
