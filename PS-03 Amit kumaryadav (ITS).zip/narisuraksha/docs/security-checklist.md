# NariSuraksha AI -- Privacy & Security Checklist

## Privacy Implementation

| Requirement | Status | How |
|---|---|---|
| Data stays in user's browser | Done | All data stored in `localStorage`, encrypted. No server-side storage. |
| No account required | Done | No login, registration, or identity collection. |
| No advertising scripts | Done | Zero third-party scripts. CSP blocks external script sources. |
| No tracking of individuals | Done | No analytics, no cookies, no fingerprinting. |
| Delete All My Data button | Done | Footer button, confirmation modal, clears all `localStorage`. |
| Quick Exit button | Done | Header button on every page. `location.replace()` prevents back-button return. |
| Minimum data collection | Done | All form fields optional except none. Each field explains its purpose via hint text. |
| Plain-language privacy page (EN/HI) | Done | `#/privacy` page, linked from every page footer. Both languages. |
| Consent notice (DPDP Act 2023) | Done | Inline consent text on home page referencing the privacy notice. |
| No sensitive data in URLs | Done | Hash routing only. No query parameters with user data. |
| No sensitive data in cookies | Done | No cookies used. |
| No sensitive data in logs | Done | Server logs only startup message. Chat messages are not logged. |
| Sensitive photos never uploaded | Done | No file upload UI exists. Evidence checklist is text-only. |
| AI never receives form data | Done | Chat sends only typed message to `/api/chat`. Form/timeline data never included. |
| Chat privacy warning | Done | Notice shown above chat: "Do not type personal details." |
| AI disclaimers | Done | "Cannot verify images or file complaints" shown on chat page. |

## Security Implementation

| Requirement | Status | How |
|---|---|---|
| HTTPS + HSTS | Done | `helmet` sets `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`. HTTP auto-upgrade via CSP `upgrade-insecure-requests`. |
| Content-Security-Policy | Done | `default-src 'self'`, restrictive directives for script, style, font, img, connect, frame, object. |
| X-Content-Type-Options | Done | `nosniff` via helmet. |
| Frame-ancestors | Done | `'none'` -- site cannot be embedded in iframes. |
| Referrer-Policy | Done | `no-referrer` -- no referrer sent on navigation. |
| Permissions-Policy | Done | `camera=(), microphone=(), geolocation=(), payment=()` -- all denied. |
| Input validation (server) | Done | Chat input: type-checked, length-limited (500 chars), XSS-filtered via `xss` library. |
| Input validation (client) | Done | `maxlength` on all text inputs. Output escaped via `esc()` function. |
| XSS prevention | Done | All user content escaped with `textContent`-based `esc()` before insertion. CSP blocks inline scripts. |
| Encrypted local storage | Done | AES-256-GCM via Web Crypto API (PBKDF2 key derivation, 100k iterations). |
| API key server-side only | Done | `AI_API_KEY` in `.env`, never in frontend code. |
| Rate limiting on chat | Done | `express-rate-limit`: 10 requests/minute per IP on `/api/chat`. |
| No user message logging | Done | Server responds to chat but does not log or store the message. |
| Secrets in env variables | Done | `.env` file with `.env.example` template. |
| Generic error messages | Done | Server returns `"Something went wrong."` on 500. No stack traces. |
| Custom 404 | Done | 404 returns `index.html` (SPA routing handles unknown paths). |
| No directory listing | Done | `express.static` with `dotfiles: 'deny'`. |
| No default credentials | Done | No authentication system; no credentials to default. |
| Pinned dependencies | Done | `package.json` uses `^` semver. `package-lock.json` pins exact versions. |
| No unnecessary third-party scripts | Done | Only essential server dependencies. No client-side third-party JS. |
| JSON body limit | Done | `/api` routes limited to `1kb` request body. |
| HPP protection | Removed | `hpp` was in dependencies but server uses `express.json` parsing which handles this. |

## Hard Limits Verification

| Limit | Status |
|---|---|
| Never claims to verify image authenticity | Enforced. AI responses include explicit disclaimers. No image analysis code exists. |
| Never automatically submits official complaints | Enforced. No external API calls to any government portal. No form submission on behalf of user. |
| Never uploads sensitive photographs | Enforced. No file upload input exists anywhere in the UI. Evidence is checklist-only. |
