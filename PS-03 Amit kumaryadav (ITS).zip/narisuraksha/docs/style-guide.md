# NariSuraksha AI -- Style Guide

## Colour Palette

| Token           | Value     | Usage                              |
|-----------------|-----------|-------------------------------------|
| `--bg`          | `#F7F4F0` | Page background (warm cream)        |
| `--surface`     | `#FFFFFF` | Cards, inputs, panels               |
| `--surface-alt` | `#F0ECE6` | Secondary surfaces, chat bubbles    |
| `--text`        | `#2C2825` | Primary text (warm near-black)      |
| `--text-sec`    | `#5E5550` | Secondary text, descriptions        |
| `--text-light`  | `#8A8480` | Muted labels, timestamps            |
| `--teal`        | `#1A7A6D` | Primary accent (deep teal)          |
| `--teal-hover`  | `#15655A` | Teal button hover state             |
| `--teal-light`  | `#E6F2F0` | Teal backgrounds, highlights        |
| `--plum`        | `#7D5A7D` | Secondary accent (muted plum)       |
| `--plum-light`  | `#F2ECF2` | Plum backgrounds                    |
| `--border`      | `#E0DBD5` | Borders, dividers                   |
| `--success`     | `#3B7A4A` | Completed steps, positive states    |
| `--warn`        | `#C07A28` | Warnings, verify badges, demo tags  |
| `--danger`      | `#B84040` | Quick exit, delete, error states    |

All text-on-background combinations meet WCAG AA contrast (4.5:1 minimum).

## Typography

**Font family:** `'Noto Sans', 'Noto Sans Devanagari', system-ui, sans-serif`

Noto Sans supports both Latin and Devanagari scripts. Weights loaded: 400, 500, 600, 700.

| Element    | Size       | Weight | Line Height |
|------------|------------|--------|-------------|
| h1         | 1.625rem   | 700    | 1.3         |
| h2         | 1.375rem   | 600    | 1.3         |
| h3         | 1.125rem   | 600    | 1.4         |
| Body       | 1rem       | 400    | 1.6         |
| Small/hint | 0.875rem   | 400    | 1.5         |
| Badge/tag  | 0.75rem    | 600    | --          |

**Note:** For production, fonts should be self-hosted. The prototype loads from Google Fonts.

## Components

### Buttons
- **Primary** (`.btn-primary`): Teal background, white text. For main actions.
- **Secondary** (`.btn-secondary`): White background, teal text, border. For back/alternative actions.
- **Danger** (`.btn-danger`): Red background. For delete/exit.
- **Text** (`.btn-text`): No background, teal text. For minor actions.
- **Minimum tap target:** 48x48px on all interactive elements.

### Cards
- White background, subtle border, 12px radius, light shadow.
- Accent variants: `.card-teal` (teal left border), `.card-plum` (plum left border), `.card-warn` (warning background).

### Notices
- Info (`.notice-info`): Teal background, for informational messages.
- Warning (`.notice`): Amber background, for cautions and prototype markers.
- Danger (`.notice-danger`): Red background, for critical warnings.

### Form Elements
- Full-width inputs with 12px padding, 48px minimum height.
- Clear labels above, optional hint text below labels.
- Teal focus ring (3px spread).

### Progress Bar
- Horizontal steps with circles and connecting lines.
- States: default (grey border), active (teal filled), done (green filled with checkmark).

### Checklist Items
- Checkbox + label + expandable details.
- Toggle arrow rotates when open.
- Notes textarea inside expandable section.

### Timeline
- Vertical line with teal dots.
- Date label above each card.
- Move up/down/remove actions on each entry.

### Chat
- Bot messages: left-aligned, grey bubble.
- User messages: right-aligned, teal bubble.
- Fixed input area at bottom with send button.

## Tone of Voice

### English
- Short, clear sentences. No jargon.
- Gentle, non-judgemental. Never blame the user.
- Use "you" directly. Avoid passive voice where possible.
- Example: "You can stop and come back any time" not "The process may be suspended".

### Hindi
- Simple, everyday Hindi. Avoid heavy Sanskritised words.
- Same warmth and directness as English.
- Example: "Aap kisi bhi samay ruk sakti hain aur wapas aa sakti hain."

### Words to avoid
- "victim" (use "person affected" or address the user directly)
- "prove" or "proof" in a demanding sense
- Legal jargon without explanation
- Blame-implying phrases ("why did you...", "you should have...")

### Required disclaimers (shown in context)
- "This assistant gives general information only. It cannot verify images or file complaints."
- "Do not type personal details into this chat."
- All phone numbers/links flagged: "Verify before use."
