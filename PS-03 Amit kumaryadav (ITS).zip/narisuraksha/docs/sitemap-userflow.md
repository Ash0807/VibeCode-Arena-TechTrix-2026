# NariSuraksha AI -- Site Map & User Flow

## Site Map

```
Home (#/home)
|
|-- Start a Report (#/report)
|   Step 1: Type of abuse
|   Step 2: Platform
|   Step 3: Date
|   Step 4: URLs
|   Step 5: Description
|   Step 6: Review --> Save & Add to Timeline
|
|-- Evidence Checklist (#/evidence)
|   - Screenshots
|   - URLs/links
|   - Messages
|   - Timestamps
|   - Profile info
|   - Witnesses
|
|-- My Timeline (#/timeline)
|   - Add/edit/reorder/delete events
|   - Load demo data
|   - Print/export summary
|
|-- Reporting Guide (#/guide)
|-- Content Removal Checklists (#/removal)
|   Per platform: Facebook, Instagram, Twitter/X, WhatsApp, YouTube, Telegram, Google
|
|-- Secure My Accounts (#/security)
|-- Ask for Guidance (#/chat)   --> /api/chat (server, rate-limited)
|-- Resources & Helplines (#/resources)
|-- What We Store and How (#/privacy)
|-- About (#/about)
|-- Prototype Notice (#/notice)
```

## Global Elements (every page)

- **Prototype banner** (top, always visible)
- **Header**: menu button, logo, language toggle (EN/HI), Quick Exit button
- **Nav drawer**: all page links, grouped with dividers
- **Footer**: privacy link, about link, prototype notice link, Delete All My Data button
- **Delete confirmation modal**

## Primary User Flow

```
User arrives at Home
  |
  v
Reads overview, sees CTA cards
  |
  +--> Start a Report (step-by-step form, save & resume)
  |       |
  |       v
  |    Review --> Save & Add to Timeline
  |
  +--> Evidence Checklist (track collected evidence)
  |
  +--> My Timeline (organise, reorder, export/print)
  |
  +--> Reporting Guide (learn how to file complaints)
  |       |
  |       +--> Content Removal (per-platform steps)
  |       +--> Secure My Accounts (password, 2FA, privacy)
  |
  +--> Ask for Guidance (AI chat for questions)
  |
  +--> Resources & Helplines (phone numbers, links)
```

## Quick Exit Flow

Any page --> Quick Exit button --> google.com (replaces history, no back-button return)

## Delete All Data Flow

Any page --> Footer "Delete All My Data" --> Confirmation modal --> Confirm --> All localStorage cleared --> Home page reload

## Language Toggle Flow

Any page --> Header "EN"/"HI" button --> All UI text switches language --> Preference saved in localStorage
