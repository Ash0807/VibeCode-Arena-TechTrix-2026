# NariSuraksha AI -- Testing Notes

## Accessibility

| Check | Status | Notes |
|---|---|---|
| Skip-to-content link | Pass | Hidden until focused, jumps to `#main-content`. |
| Keyboard navigation | Pass | All interactive elements reachable via Tab. Buttons, links, inputs all focusable. |
| Visible focus states | Pass | `:focus-visible` with 2px teal outline on all interactive elements. |
| ARIA labels | Pass | Menu button, close button, chat input, send button, checklist items all labelled. |
| ARIA landmarks | Pass | `role="banner"`, `role="main"`, `role="contentinfo"`, `role="navigation"`. |
| ARIA live region | Pass | Chat messages container has `aria-live="polite"`. |
| ARIA expanded states | Pass | Menu button, nav drawer, checklist toggles use `aria-expanded`. |
| Screen reader support | Pass | Semantic HTML (h1-h3, ul/ol, nav, main, footer). SVG icons have `aria-hidden="true"`. |
| Alt text for images | Pass | No images used; icons are inline SVG with `aria-hidden`. |
| Reduced motion | Pass | `@media (prefers-reduced-motion: reduce)` disables all animations/transitions. |
| Colour contrast (WCAG AA) | Pass | Primary text #2C2825 on #F7F4F0 = ~12:1. Teal #1A7A6D on #F7F4F0 = ~4.8:1. |
| Minimum tap targets | Pass | All buttons/inputs have `min-height: 48px`, `min-width: 48px`. |
| Form labels | Pass | All inputs have associated `<label>` elements or `aria-label`. |

## Performance

| Check | Status | Notes |
|---|---|---|
| Mobile-first CSS | Pass | Base styles target mobile. `@media (min-width)` for desktop. |
| Minimal JS payload | Pass | 2 JS files (app.js ~4KB, pages.js ~25KB), no framework overhead. |
| No unnecessary libraries | Pass | Zero client-side dependencies. Server has 6 essential packages. |
| Font loading | Pass | `display=swap` prevents FOIT. Only needed weights loaded (400-700). |
| No images to load | Pass | All icons are inline SVG. No external image requests. |
| CSP blocks external resources | Pass | Only `fonts.googleapis.com` and `fonts.gstatic.com` allowed externally. |
| Printable export | Pass | Timeline export generates lightweight HTML, triggers `window.print()`. |
| Encrypted storage perf | Acceptable | PBKDF2 with 100k iterations adds ~50-100ms on first key derivation. Subsequent ops use cached key. |

## Hindi/English Content

| Check | Status | Notes |
|---|---|---|
| All UI labels bilingual | Pass | Navigation, buttons, form labels, headings all switch with language toggle. |
| All page content bilingual | Pass | Every page has full Hindi and English versions of body text. |
| Language persisted | Pass | Saved in `localStorage` (unencrypted, non-sensitive). |
| HTML lang attribute | Pass | Switches between `lang="en"` and `lang="hi"` on `<html>` element. |
| Devanagari font loaded | Pass | Noto Sans Devanagari included in font stack. |
| Hindi readability | Pass | Simple, everyday Hindi. No heavy Sanskritised vocabulary. |
| No emojis | Pass | Zero emojis in any UI text, content, or code comments. |

## Functional Testing

| Feature | Status | Notes |
|---|---|---|
| Report form save/resume | Pass | State saved to encrypted localStorage after each step. Restored on return. |
| Report form all-optional | Pass | User can click "Next" through all steps without entering anything. |
| Evidence checklist persistence | Pass | Checkbox and notes state saved on change. |
| Timeline CRUD | Pass | Add, reorder (up/down), delete events. All persisted. |
| Timeline export/print | Pass | Opens new tab with printable HTML, triggers print dialog. |
| Demo data load | Pass | Loads 4 fictional [DEMO]-tagged events. |
| Chat send/receive | Pass | Messages sent to `/api/chat`, responses displayed. Rate-limited. |
| Chat distress detection | Pass | Keywords trigger helpline information response. |
| Language toggle | Pass | All text switches. Preference saved. |
| Quick Exit | Pass | Navigates to google.com via `location.replace()`. |
| Delete All Data | Pass | Confirmation modal. Clears localStorage (preserves language pref). |
| Nav drawer open/close | Pass | Opens on menu click, closes on overlay/close/link click. |
| Deep linking | Pass | Hash routes work directly (e.g. `#/evidence`). |
