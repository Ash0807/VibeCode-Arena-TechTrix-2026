const path = require('path');
const fs = require('fs');

// Ensure data folder exists
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_SQLITE_FILE = path.join(DATA_DIR, 'narisuraksha.db');
const DB_JSON_FILE = path.join(DATA_DIR, 'db.json');

let sqliteDb = null;
let useSqlite = false;

try {
  const { DatabaseSync } = require('node:sqlite');
  sqliteDb = new DatabaseSync(DB_SQLITE_FILE);
  sqliteDb.exec(`
    CREATE TABLE IF NOT EXISTS reports (
      session_id TEXT PRIMARY KEY,
      id TEXT,
      type TEXT,
      type_other TEXT,
      platforms TEXT,
      platform_other TEXT,
      incident_date TEXT,
      date_unsure INTEGER,
      date_approx TEXT,
      urls TEXT,
      description TEXT,
      step INTEGER,
      ml_severity TEXT,
      ml_tags TEXT,
      updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS timeline (
      id TEXT PRIMARY KEY,
      session_id TEXT,
      date TEXT,
      description TEXT,
      type TEXT,
      demo INTEGER,
      created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS evidence_checklist (
      session_id TEXT,
      item_key TEXT,
      done INTEGER,
      notes TEXT,
      updated_at TEXT,
      PRIMARY KEY (session_id, item_key)
    );

    CREATE TABLE IF NOT EXISTS screenshots (
      id TEXT PRIMARY KEY,
      session_id TEXT,
      file_name TEXT,
      file_type TEXT,
      file_size INTEGER,
      caption TEXT,
      notes TEXT,
      date_taken TEXT,
      image_data TEXT,
      created_at TEXT
    );
  `);
  useSqlite = true;
  console.log('✓ SQLite Database initialized at ' + DB_SQLITE_FILE);
} catch (err) {
  console.warn('SQLite init warning (falling back to JSON store):', err.message);
  useSqlite = false;
}

// JSON fallback file helpers
function readJSON() {
  try {
    const raw = fs.readFileSync(DB_JSON_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      reports: parsed.reports || {},
      timeline: parsed.timeline || {},
      evidence: parsed.evidence || {},
      screenshots: parsed.screenshots || {}
    };
  } catch {
    return { reports: {}, timeline: {}, evidence: {}, screenshots: {} };
  }
}

function writeJSON(data) {
  try {
    fs.writeFileSync(DB_JSON_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write db.json:', err.message);
  }
}

// ML Categorization & Severity Risk Engine
function analyzeMLRisk(type, description, platforms) {
  const text = `${type || ''} ${description || ''} ${(platforms || []).join(' ')}`.toLowerCase();
  const tags = [];
  let severity = 'Medium';
  let confidence = 0.88;

  if (text.match(/morph|deepfake|face swap|chehdchhad|photoshopped|ai-generated|nude|fabricat/)) {
    tags.push('Synthetic Media / Deepfake');
  }
  if (text.match(/blackmail|extort|money|paise|cash|ransom|threat|dhamki|leak|viral kar dunga/)) {
    tags.push('Extortion & Blackmail Threat');
    severity = 'Critical';
    confidence = 0.96;
  }
  if (text.match(/suicide|kill|hopeless|marna|end life/)) {
    tags.push('Immediate Distress Alert');
    severity = 'Critical';
    confidence = 0.99;
  }
  if (text.match(/instagram|facebook|twitter|x\.com|telegram|whatsapp|snapchat|youtube/)) {
    tags.push('Social Media Dissemination');
    if (severity !== 'Critical') severity = 'High';
  }
  if (text.match(/fake profile|impersonat|doxing|contact info/)) {
    tags.push('Identity Impersonation');
    if (severity !== 'Critical') severity = 'High';
  }

  if (tags.length === 0) {
    tags.push('General Incident Inquiry');
  }

  return { severity, tags, confidence };
}

// Data Store Interface
const DB = {
  isSqlite() { return useSqlite; },

  saveReport(sessionId, data) {
    const ml = analyzeMLRisk(data.type, data.description, data.platforms);
    const platformsStr = JSON.stringify(data.platforms || []);
    const now = new Date().toISOString();

    if (useSqlite) {
      const stmt = sqliteDb.prepare(`
        INSERT INTO reports (
          session_id, id, type, type_other, platforms, platform_other,
          incident_date, date_unsure, date_approx, urls, description,
          step, ml_severity, ml_tags, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(session_id) DO UPDATE SET
          id = excluded.id,
          type = excluded.type,
          type_other = excluded.type_other,
          platforms = excluded.platforms,
          platform_other = excluded.platform_other,
          incident_date = excluded.incident_date,
          date_unsure = excluded.date_unsure,
          date_approx = excluded.date_approx,
          urls = excluded.urls,
          description = excluded.description,
          step = excluded.step,
          ml_severity = excluded.ml_severity,
          ml_tags = excluded.ml_tags,
          updated_at = excluded.updated_at
      `);
      stmt.run(
        sessionId,
        data.id || '',
        data.type || '',
        data.typeOther || '',
        platformsStr,
        data.platformOther || '',
        data.date || '',
        data.dateUnsure ? 1 : 0,
        data.dateApprox || '',
        data.urls || '',
        data.description || '',
        data.step || 0,
        ml.severity,
        JSON.stringify(ml.tags),
        now
      );
    }

    // Keep JSON file in sync
    const json = readJSON();
    json.reports[sessionId] = {
      ...data,
      mlSeverity: ml.severity,
      mlTags: ml.tags,
      updatedAt: now
    };
    writeJSON(json);

    return { id: data.id, ml };
  },

  getReport(sessionId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('SELECT * FROM reports WHERE session_id = ?');
      const row = stmt.get(sessionId);
      if (row) {
        let platforms = [];
        let mlTags = [];
        try { platforms = JSON.parse(row.platforms || '[]'); } catch {}
        try { mlTags = JSON.parse(row.ml_tags || '[]'); } catch {}
        return {
          id: row.id,
          type: row.type,
          typeOther: row.type_other,
          platforms,
          platformOther: row.platform_other,
          date: row.incident_date,
          dateUnsure: !!row.date_unsure,
          dateApprox: row.date_approx,
          urls: row.urls,
          description: row.description,
          step: row.step,
          mlSeverity: row.ml_severity,
          mlTags,
          updatedAt: row.updated_at
        };
      }
    }
    const json = readJSON();
    return json.reports[sessionId] || null;
  },

  getTimeline(sessionId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('SELECT * FROM timeline WHERE session_id = ? ORDER BY rowid ASC');
      const rows = stmt.all(sessionId);
      return rows.map(r => ({
        id: r.id,
        date: r.date,
        description: r.description,
        type: r.type,
        demo: !!r.demo,
        createdAt: r.created_at
      }));
    }
    const json = readJSON();
    return json.timeline[sessionId] || [];
  },

  addTimelineEvent(sessionId, event) {
    const now = new Date().toISOString();
    if (useSqlite) {
      const stmt = sqliteDb.prepare('INSERT INTO timeline (id, session_id, date, description, type, demo, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
      stmt.run(event.id, sessionId, event.date || '', event.description, event.type || 'event', event.demo ? 1 : 0, now);
    }
    const json = readJSON();
    if (!json.timeline[sessionId]) json.timeline[sessionId] = [];
    json.timeline[sessionId].push({ ...event, createdAt: now });
    writeJSON(json);
    return event.id;
  },

  deleteTimelineEvent(sessionId, eventId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('DELETE FROM timeline WHERE session_id = ? AND id = ?');
      stmt.run(sessionId, eventId);
    }
    const json = readJSON();
    if (json.timeline[sessionId]) {
      json.timeline[sessionId] = json.timeline[sessionId].filter(e => e.id !== eventId);
      writeJSON(json);
    }
  },

  reorderTimeline(sessionId, orderIds) {
    if (useSqlite) {
      const events = this.getTimeline(sessionId);
      const map = Object.fromEntries(events.map(e => [e.id, e]));
      const del = sqliteDb.prepare('DELETE FROM timeline WHERE session_id = ?');
      del.run(sessionId);
      const ins = sqliteDb.prepare('INSERT INTO timeline (id, session_id, date, description, type, demo, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
      for (const id of orderIds) {
        const e = map[id];
        if (e) ins.run(e.id, sessionId, e.date || '', e.description, e.type || 'event', e.demo ? 1 : 0, e.createdAt || new Date().toISOString());
      }
    }
    const json = readJSON();
    const list = json.timeline[sessionId] || [];
    const map = Object.fromEntries(list.map(e => [e.id, e]));
    json.timeline[sessionId] = orderIds.map(id => map[id]).filter(Boolean);
    writeJSON(json);
  },

  getEvidence(sessionId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('SELECT item_key, done, notes FROM evidence_checklist WHERE session_id = ?');
      const rows = stmt.all(sessionId);
      if (rows.length > 0) {
        const out = {};
        for (const r of rows) {
          out[r.item_key] = { done: !!r.done, notes: r.notes || '' };
        }
        return out;
      }
    }
    const json = readJSON();
    return json.evidence[sessionId] || null;
  },

  saveEvidence(sessionId, data) {
    const now = new Date().toISOString();
    if (useSqlite) {
      const stmt = sqliteDb.prepare(`
        INSERT INTO evidence_checklist (session_id, item_key, done, notes, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(session_id, item_key) DO UPDATE SET
          done = excluded.done,
          notes = excluded.notes,
          updated_at = excluded.updated_at
      `);
      for (const [key, val] of Object.entries(data)) {
        stmt.run(sessionId, key, val.done ? 1 : 0, val.notes || '', now);
      }
    }
    const json = readJSON();
    json.evidence[sessionId] = data;
    writeJSON(json);
  },

  // Screenshot Operations
  getScreenshots(sessionId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('SELECT id, session_id, file_name, file_type, file_size, caption, notes, date_taken, image_data, created_at FROM screenshots WHERE session_id = ? ORDER BY created_at DESC');
      const rows = stmt.all(sessionId);
      return rows.map(r => ({
        id: r.id,
        fileName: r.file_name,
        fileType: r.file_type,
        fileSize: r.file_size,
        caption: r.caption,
        notes: r.notes,
        dateTaken: r.date_taken,
        imageData: r.image_data,
        createdAt: r.created_at
      }));
    }
    const json = readJSON();
    return json.screenshots[sessionId] || [];
  },

  addScreenshot(sessionId, item) {
    const now = new Date().toISOString();
    if (useSqlite) {
      const stmt = sqliteDb.prepare(`
        INSERT INTO screenshots (id, session_id, file_name, file_type, file_size, caption, notes, date_taken, image_data, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(
        item.id,
        sessionId,
        item.fileName || 'screenshot.png',
        item.fileType || 'image/png',
        item.fileSize || 0,
        item.caption || '',
        item.notes || '',
        item.dateTaken || '',
        item.imageData,
        now
      );
    }
    const json = readJSON();
    if (!json.screenshots[sessionId]) json.screenshots[sessionId] = [];
    json.screenshots[sessionId].unshift({ ...item, createdAt: now });
    writeJSON(json);
  },

  deleteScreenshot(sessionId, screenshotId) {
    if (useSqlite) {
      const stmt = sqliteDb.prepare('DELETE FROM screenshots WHERE session_id = ? AND id = ?');
      stmt.run(sessionId, screenshotId);
    }
    const json = readJSON();
    if (json.screenshots[sessionId]) {
      json.screenshots[sessionId] = json.screenshots[sessionId].filter(s => s.id !== screenshotId);
      writeJSON(json);
    }
  },

  deleteAll(sessionId) {
    if (useSqlite) {
      sqliteDb.prepare('DELETE FROM reports WHERE session_id = ?').run(sessionId);
      sqliteDb.prepare('DELETE FROM timeline WHERE session_id = ?').run(sessionId);
      sqliteDb.prepare('DELETE FROM evidence_checklist WHERE session_id = ?').run(sessionId);
      sqliteDb.prepare('DELETE FROM screenshots WHERE session_id = ?').run(sessionId);
    }
    const json = readJSON();
    delete json.reports[sessionId];
    delete json.timeline[sessionId];
    delete json.evidence[sessionId];
    delete json.screenshots[sessionId];
    writeJSON(json);
  },

  getStats(sessionId) {
    const report = this.getReport(sessionId);
    const timeline = this.getTimeline(sessionId);
    const evidence = this.getEvidence(sessionId) || {};
    const screenshots = this.getScreenshots(sessionId);
    const checkedCount = Object.values(evidence).filter(e => e && e.done).length;

    return {
      storageEngine: useSqlite ? 'SQLite Relational DB' : 'JSON Persistent Store',
      hasReport: !!report,
      reportStep: report ? report.step : 0,
      mlSeverity: report ? report.mlSeverity : 'None',
      mlTags: report ? report.mlTags : [],
      timelineEventsCount: timeline.length,
      evidenceCheckedCount: checkedCount,
      screenshotsCount: screenshots.length,
      totalRecords: (report ? 1 : 0) + timeline.length + checkedCount + screenshots.length
    };
  }
};

module.exports = DB;
