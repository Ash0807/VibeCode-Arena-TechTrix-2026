# TechTrix - SchemeSaathi Localhost Running Guide 🚀

This document provides complete instructions for launching, configuring, and verifying the **SchemeSaathi** application on your local machine.

---

## ⚡ Quick Start (One Command)

From the project root:

```bash
npm run dev
```

The application will start on:
👉 **http://localhost:3000** (or **http://127.0.0.1:3000**)

---

## 📋 Step-by-Step Instructions

### 1. Open Terminal or PowerShell
Ensure your terminal is in the project root directory:
```powershell
cd C:\Users\shoai\.gemini\antigravity\scratch\schemesaathi
```

### 2. Verify Node.js Environment
Make sure Node.js (v18+) is available:
```powershell
node -v
npm -v
```

### 3. Verify Dependencies
Dependencies are already installed. If running on a fresh clone:
```powershell
npm install
```

### 4. Configure Environment Variables (Optional)
Check the [`.env`](file:///C:/Users/shoai/.gemini/antigravity/scratch/schemesaathi/.env) file:
```env
PORT=3000

# Optional: To enable live Gemini AI assistance, paste your API key below:
# GEMINI_API_KEY=your_gemini_api_key_here
```

> **Offline Mode**: If `GEMINI_API_KEY` is not provided, SchemeSaathi automatically runs using its intelligent built-in knowledge engine (providing full advisory guidance for PMAY, PM-KISAN, Ayushman Bharat, PM SVANidhi, etc.).

### 5. Launch the Full-Stack Server
```powershell
npm run dev
```

Output:
```text
◇ injected env (1) from .env
SchemeSaathi server running on http://0.0.0.0:3000
```

### 6. Access the Application
Open your browser and navigate to:
- **Web App**: [http://localhost:3000](http://localhost:3000)
- **AI Guidance API Endpoint**: [http://localhost:3000/api/ai/guidance](http://localhost:3000/api/ai/guidance)

---

## 🧪 Available Scripts

| Command | Purpose |
| :--- | :--- |
| `npm run dev` | Starts the Express backend + Vite frontend in HMR development mode on port 3000 |
| `npm test` | Runs the 5/5 automated eligibility rule engine test suite (`eligibilityEngine.test.ts`) |
| `npm run lint` | Runs TypeScript type checking (`tsc --noEmit`) |
| `npm run build` | Compiles and bundles production static assets to `dist/` |
| `npm run preview` | Previews the production build locally |

---

## 🛠️ Troubleshooting

- **Port 3000 already in use**:
  Change `PORT=3001` in [`.env`](file:///C:/Users/shoai/.gemini/antigravity/scratch/schemesaathi/.env) and re-run `npm run dev`.
- **Browser cannot reach server**:
  Try opening `http://127.0.0.1:3000` instead of `http://localhost:3000`.
- **Testing without UI**:
  You can verify backend API health with curl or PowerShell:
  ```powershell
  Invoke-RestMethod -Uri "http://localhost:3000/api/ai/guidance" -Method Post -ContentType "application/json" -Body '{"query": "PMAY housing eligibility"}'
  ```

