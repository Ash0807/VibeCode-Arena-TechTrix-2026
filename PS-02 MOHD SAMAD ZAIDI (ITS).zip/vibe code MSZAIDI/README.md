# SchemeSaathi (स्कीम साथी) 🇮🇳

**SchemeSaathi** is an intelligent, accessible citizen welfare and housing assistance platform designed to empower citizens across India. It helps users discover, verify eligibility for, and navigate central and state government schemes through transparent rule matching, multilingual support, voice assistance, and AI guidance.

---

## 🌟 Key Features

### 1. 🎯 Dynamic Eligibility Matching Engine
- **Transparent Evaluations**: Deterministic, rule-based matching engine ([`src/utils/eligibilityEngine.ts`](file:///C:/Users/shoai/.gemini/antigravity/scratch/schemesaathi/src/utils/eligibilityEngine.ts)) evaluating location (rural vs. urban), age, gender, social category, occupation, income bracket, housing condition, landholding, and ration card type.
- **Explainable Results**: Provides itemized rule breakdown, passing/warning/failing reasons, and actionable suggestions to qualify.
- **Categories Supported**:
  - 🏠 **Housing**: PMAY-Gramin (Rural ₹1.2L-₹1.3L grant), PMAY-Urban 2.0 (Subsidy & Interest Subvention)
  - 🌾 **Agriculture**: PM-KISAN, PM Fasal Bima Yojana (PMFBY), Kisan Credit Card (KCC)
  - 🩺 **Healthcare**: Ayushman Bharat PM-JAY (₹5 Lakh cover), Ayushman Vay Vandana (Seniors 70+), Pradhan Mantri Bhartiya Janaushadhi Pariyojana (PMBJP)
  - 💼 **Livelihood & Employment**: PM SVANidhi (Street Vendor microloans), PM Vishwakarma (Artisan support), MGNREGA (100 days wage guarantee)
  - 🛡️ **Social Welfare & Security**: Atal Pension Yojana (APY), Sukanya Samriddhi Yojana (SSY), Post-Matric Scholarships

### 2. 🌐 Multilingual & Regional Accessibility
- Native support for **5 Indian languages**:
  - English (`en`)
  - हिन्दी (`hi` - Hindi)
  - বাংলা (`bn` - Bengali)
  - ਪੰਜਾਬੀ (`pa` - Punjabi)
  - தமிழ் (`ta` - Tamil)
- **Voice Navigation & Speech Synthesis**: High-clarity Web Speech synthesis with native speech prompts and regional accents.
- **Touch-to-Read (Audio Assistance)**: Point-and-listen interface designed for low-literacy users to read aloud any UI element.
- **Accessibility Controls**: High-contrast mode, dark mode toggle, and adjustable font scaling.

### 3. 🤖 Hybrid AI Guidance & Offline Knowledge Engine
- **Gemini 3.8 Integration**: Real-time natural language answers to user queries regarding eligibility, documentation, and grievance redressal via server-side Gemini SDK.
- **Offline Fallback Engine**: If no API key or internet connection is present, an intelligent local rule-based advisory engine provides immediate, structured assistance for major welfare schemes.

### 4. 📋 Document Readiness Checklist
- Interactive checklist covering required identity and verification documents (Aadhaar, Ration Card, Bank Passbook, Land Records/Khatauni, Income Certificate, Caste Certificate).
- Highlights specific documentation needed per scheme with clear instructions on where to apply (Gram Panchayat, CSC Centers, Municipal Ward Offices, or direct portals).

---

## 🏗️ Architecture & Tech Stack

```
schemesaathi/
├── server.ts                       # Express backend + Vite middleware + Gemini AI endpoint
├── index.html                      # HTML entrypoint
├── package.json                    # Dependencies and build scripts
├── tsconfig.json                   # TypeScript configuration
├── vite.config.ts                  # Vite 8 config with Tailwind v4 & React plugin
└── src/
    ├── main.tsx                    # React client entrypoint
    ├── App.tsx                     # Core application layout and state management
    ├── index.css                   # Global Tailwind v4 styling
    ├── types/
    │   └── scheme.ts               # Core domain models, CitizenProfile, EligibilityResult
    ├── data/
    │   ├── schemesData.ts          # Comprehensive welfare schemes database
    │   └── translations.ts         # Multilingual translations (en, hi, bn, pa, ta)
    ├── utils/
    │   ├── eligibilityEngine.ts    # Deterministic citizen eligibility evaluator
    │   ├── eligibilityEngine.test.ts # Built-in Node test suite
    │   └── speechHelper.ts         # Speech synthesis and voice recognition utilities
    └── components/
        ├── Header.tsx              # Accessibility toolbar, language picker, dark mode
        ├── CitizenProfileForm.tsx  # Dynamic citizen demographic and financial profile form
        ├── SchemeCard.tsx          # Card displaying scheme match score and details
        ├── SchemeDetailsModal.tsx  # Modal breakdown of criteria, benefits & application steps
        ├── DocumentChecklistModal.tsx # Document preparation checklist modal
        ├── VoiceAssistantModal.tsx # Regional voice assistant modal
        ├── AIGuidanceDrawer.tsx    # Slide-over AI / offline guidance chat drawer
        └── DisclaimerBanner.tsx    # Government advisory and non-affiliation notice
```

### Stack Highlights
- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React, Motion
- **Build Tool**: Vite 8
- **Backend**: Express, tsx
- **AI**: `@google/genai` (Gemini 3.8 Flash)

---

## 🚀 Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (v18 or higher recommended, tested on Node v24)
- npm or pnpm

### 1. Installation
Clone or navigate to the project directory:
```bash
cd C:\Users\shoai\.gemini\antigravity\scratch\schemesaathi
npm install
```

### 2. Environment Configuration
Create or configure `.env` in the project root:
```env
PORT=3000

# Optional: Add your Gemini API Key to enable live Gemini AI guidance
# If omitted, SchemeSaathi runs seamlessly using its offline knowledge engine
GEMINI_API_KEY=your_gemini_api_key_here
```

### 3. Development Server
Start the full-stack server (runs Express API + Vite dev server):
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Running Tests
Run the deterministic eligibility engine test suite:
```bash
npm test
```

### 5. Production Build
Compile TypeScript and bundle static assets:
```bash
npm run build
```
Build output is saved to the `dist/` directory.

---

## 🛡️ Disclaimer
SchemeSaathi is an independent informational and advisory technology designed to help Indian citizens understand government welfare schemes and eligibility guidelines. SchemeSaathi does not process government applications directly; all applications must be submitted through official government portals (e.g., pmaymis.gov.in, pmkisan.gov.in, beneficiary.nha.gov.in), Common Service Centres (CSCs), or local administrative offices.
