@echo off
title TechTrix - SchemeSaathi Localhost Launcher
echo ========================================================
echo   TechTrix - Launching SchemeSaathi on Localhost
echo ========================================================
echo.

cd /d "%~dp0"

echo [1/2] Checking Node.js environment...
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js is not found in PATH. Please install Node.js.
    pause
    exit /b 1
)

echo [2/2] Starting SchemeSaathi development server...
echo.
echo Application will be accessible at: http://localhost:3000
echo Press Ctrl+C in this window to stop the server anytime.
echo.

npm run dev

