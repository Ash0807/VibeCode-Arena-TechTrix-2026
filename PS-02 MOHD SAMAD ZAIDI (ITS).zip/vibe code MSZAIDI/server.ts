/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  try {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  } catch (err) {
    console.error('Error initializing GoogleGenAI:', err);
  }
}

// Fallback intelligent response generator for offline / without API key mode
function generateOfflineSchemeGuidance(query: string, language: string): string {
  const q = query.toLowerCase();

  if (q.includes('pmay') || q.includes('housing') || q.includes('awas') || q.includes('makan') || q.includes('ghar') || q.includes('ঘর') || q.includes('வீடு')) {
    return `### Pradhan Mantri Awas Yojana (PMAY) Guidance:
1. **Rural (PMAY-G)**: If you live in a rural area in a kutcha, thatch, or dilapidated house and do not own a pucca house anywhere, you can get ₹1,20,000 (plain) to ₹1,30,000 (hilly/NE) direct grant + 95 days MGNREGA wages (~₹25,000) + ₹12,000 toilet grant under SBM. Contact your Gram Panchayat Secretary or register on the AwaasApp portal.
2. **Urban (PMAY-U 2.0)**: For urban residents with income under ₹3 Lakh (EWS) or ₹6 Lakh (LIG) living in rented or kutcha houses, you can get up to ₹2.5 Lakh subsidy or 4% interest subvention. Apply through your local Municipality / Nagar Nigam or pmay-urban.gov.in.
- **Key Documents Needed**: Aadhaar Card of all family members, Bank Passbook, Ration Card, and Land/Ownership or Rental Affidavit.
- **Helpline**: PMAY-G (1800-11-6446) / PMAY-U (1800-11-3377).`;
  }

  if (q.includes('kisan') || q.includes('farmer') || q.includes('fasal') || q.includes('agriculture') || q.includes('কৃষক') || q.includes('விவசாயி')) {
    return `### PM-KISAN & Agriculture Guidance:
- **PM-KISAN**: Every landholder farmer family receives ₹6,000/year in 3 equal installments of ₹2,000 via DBT. Make sure your Aadhaar is linked to your bank account and land record (Khatauni) is updated.
- **PM Fasal Bima (PMFBY)**: Protect crops against drought, flood, or hailstorm at just 1.5% - 2% premium. Claims are paid directly to your bank account within 30 days of damage assessment.
- **Kisan Credit Card (KCC)**: Avail loans up to ₹3 Lakh at an effective 4% subsidized interest rate.
- **Helpline**: 155261 (PM-Kisan) / 14447 (Kisan Call Centre).`;
  }

  if (q.includes('ayushman') || q.includes('health') || q.includes('hospital') || q.includes('bima') || q.includes('card') || q.includes('স্বাস্থ্য') || q.includes('மருத்துவம்')) {
    return `### Ayushman Bharat PM-JAY Healthcare Guidance:
- **Benefits**: Provides ₹5,00,000 free cashless hospitalization per family per year across 28,000+ empaneled government and private hospitals.
- **New Senior Citizen Benefit (Ayushman Vay Vandana)**: All senior citizens aged 70 years and above are eligible for this ₹5 Lakh top-up card regardless of family income or ration card status!
- **How to Get Card**: Visit any CSC center, government hospital Ayushman Mitra desk, or visit beneficiary.nha.gov.in with your Aadhaar and Ration Card.
- **Helpline**: 14555 (Toll-Free 24x7).`;
  }

  if (q.includes('svanidhi') || q.includes('vendor') || q.includes('loan') || q.includes('rehri') || q.includes('street') || q.includes('হকার') || q.includes('வியாபாரி')) {
    return `### PM SVANidhi (Street Vendor Loan) Guidance:
- **First Loan**: ₹10,000 collateral-free working capital loan.
- **Second Loan**: ₹20,000 on timely repayment of the first.
- **Third Loan**: Up to ₹50,000.
- **Benefits**: 7% interest subsidy deposited in bank account + up to ₹1,200/year cashback on digital UPI transactions!
- **Where to apply**: Visit your local Municipal Ward Office or apply online on pmsvanidhi.mohua.gov.in.`;
  }

  return `### SchemeSaathi Advisory:
- To identify eligible schemes, fill out your age, state, rural/urban status, occupation, and approximate income in the Finder tab.
- **Housing**: Explore PMAY-G (rural ₹1.2L-₹1.3L grant) or PMAY-U (urban subsidy).
- **Livelihood**: Check MGNREGA (100 days guaranteed wages), PM Vishwakarma (for artisans), or PM SVANidhi (for vendors).
- **Health**: Check Ayushman Bharat (₹5 Lakh free health cover).
- **Documents**: Always keep your Aadhaar (linked with mobile & bank), Ration Card, and Income Certificate ready.
- **Helpline Assistance**: Dial 14555 for Ayushman Bharat, 1800-11-6446 for PMAY-G, or 155261 for PM-KISAN.`;
}

// API endpoint for AI Guidance
app.post('/api/ai/guidance', async (req: Request, res: Response) => {
  const { query, language = 'en', userProfile } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  // If Gemini API client is available and key is configured
  if (aiClient && process.env.GEMINI_API_KEY) {
    try {
      const systemInstruction = `You are "SchemeSaathi Sahayak", an empathetic, highly knowledgeable digital guide for Indian citizens seeking central and state government welfare schemes and housing assistance.
The user speaks or asks in: ${language}.
Always provide responses in clear, accessible, structured formatting (using bullet points and bold headers).
Focus on:
1. Clarifying eligibility criteria for programmes like PMAY-Gramin, PMAY-Urban 2.0, PM-KISAN, Ayushman Bharat, MGNREGA, PM SVANidhi, PM Vishwakarma, Atal Pension Yojana, Sukanya Samriddhi Yojana, and Post-Matric Scholarships.
2. Step-by-step instructions on where to apply (e.g. Gram Panchayat, Municipal Office, CSC Center, online portal).
3. Exact document preparation (Aadhaar, Ration Card, Income Certificate, Bank Passbook, Land records).
4. Grievance redressal and toll-free helpline numbers.
5. Emphasize that results are preliminary advisory and require formal administrative verification.
If the user provides their profile: ${JSON.stringify(userProfile || {})}, customize the advice specifically to their location, occupation, and housing status.
Respond in the language requested (${language}).`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: query,
        config: {
          systemInstruction,
          temperature: 0.7
        }
      });

      const text = response.text || '';
      return res.json({ guidance: text, source: 'gemini' });
    } catch (err: unknown) {
      console.error('Gemini API call failed, using offline fallback:', err);
      const fallback = generateOfflineSchemeGuidance(query, language);
      return res.json({ guidance: fallback, source: 'knowledge_engine' });
    }
  } else {
    // Intelligent offline rule engine fallback
    const fallback = generateOfflineSchemeGuidance(query, language);
    return res.json({ guidance: fallback, source: 'knowledge_engine' });
  }
});

// Mount Vite middleware in dev mode, or serve static dist in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SchemeSaathi server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
