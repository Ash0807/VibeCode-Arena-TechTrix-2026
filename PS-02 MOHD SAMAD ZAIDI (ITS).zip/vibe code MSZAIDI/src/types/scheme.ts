/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type LanguageCode = 'en' | 'hi' | 'pa' | 'bn' | 'ta';

export type AreaType = 'rural' | 'urban' | 'any';

export type Gender = 'all' | 'female' | 'male' | 'transgender';

export type SocialCategory = 'general' | 'obc' | 'sc' | 'st' | 'ews' | 'minority';

export type OccupationType =
  | 'farmer'
  | 'agricultural_labourer'
  | 'daily_wage_worker'
  | 'street_vendor'
  | 'artisan_craftsperson'
  | 'small_business_owner'
  | 'student'
  | 'unemployed'
  | 'homemaker'
  | 'senior_citizen'
  | 'salaried_worker'
  | 'other';

export type IncomeRange =
  | 'below_1_lakh' // < ₹1,00,000 (BPL / Antyodaya)
  | '1_to_2_5_lakh' // ₹1,00,000 - ₹2,50,000
  | '2_5_to_5_lakh' // ₹2,50,000 - ₹5,00,000
  | '5_to_8_lakh' // ₹5,00,000 - ₹8,00,000 (EWS ceiling)
  | 'above_8_lakh'; // > ₹8,00,000

export type HousingStatus =
  | 'homeless'
  | 'kutcha' // Mud, thatch, tin sheets
  | 'semi_pucca'
  | 'rented'
  | 'own_pucca';

export type Landholding =
  | 'landless'
  | 'marginal' // < 1 hectare (< 2.5 acres)
  | 'small' // 1 - 2 hectares (2.5 - 5 acres)
  | 'medium_large'; // > 2 hectares

export type RationCardType =
  | 'antyodaya' // AAY (poorest of poor)
  | 'bpl' // Below poverty line
  | 'priority_phh' // Priority Household (National Food Security)
  | 'apl_none'; // Above poverty line or no card

export interface CitizenProfile {
  state: string;
  areaType: AreaType;
  age: number;
  gender: Gender;
  socialCategory: SocialCategory;
  occupation: OccupationType;
  incomeRange: IncomeRange;
  housingStatus: HousingStatus;
  landholding: Landholding;
  hasDisability: boolean;
  rationCard: RationCardType;
  familyMembersCount: number;
  hasGirlChildUnder10: boolean;
  isStudent: boolean;
  hasKisanCreditCard?: boolean;
}

export type EligibilityStatus = 'ELIGIBLE' | 'MORE_INFO_NEEDED' | 'NOT_ELIGIBLE';

export interface RuleEvaluation {
  ruleId: string;
  name: string;
  description: string;
  status: 'pass' | 'warn' | 'fail';
  detail: string;
}

export interface EligibilityResult {
  schemeId: string;
  status: EligibilityStatus;
  matchScore: number; // 0 to 100
  ruleBreakdown: RuleEvaluation[];
  summaryExplanation: string;
  unmetKeyReasons: string[];
  missingInfoPrompts: string[];
}

export type SchemeCategory =
  | 'housing'
  | 'agriculture'
  | 'employment'
  | 'healthcare'
  | 'education'
  | 'social_welfare';

export interface SchemeDocument {
  id: string;
  name: string;
  description: string;
  isMandatory: boolean;
  issuingAuthority: string;
  howToGet: string;
  digitalPortalUrl?: string;
}

export interface Scheme {
  id: string;
  category: SchemeCategory;
  name: string;
  nameTranslations?: Partial<Record<LanguageCode, string>>;
  shortCode: string;
  ministry: string;
  tagline: string;
  taglineTranslations?: Partial<Record<LanguageCode, string>>;
  purpose: string;
  purposeTranslations?: Partial<Record<LanguageCode, string>>;
  intendedBeneficiaries: string[];
  availableBenefits: {
    financialAmount?: string;
    description: string;
    frequency?: string; // One-time, Annual, Monthly
  };
  keyHighlights: string[];
  eligibilityCriteria: {
    minAge?: number;
    maxAge?: number;
    allowedGenders?: Gender[];
    allowedAreaTypes?: AreaType[];
    allowedSocialCategories?: SocialCategory[];
    allowedOccupations?: OccupationType[];
    maxIncomeRange?: IncomeRange;
    allowedHousingStatuses?: HousingStatus[];
    allowedLandholdings?: Landholding[];
    requiresDisability?: boolean;
    requiresGirlChild?: boolean;
    allowedRationCards?: RationCardType[];
    applicableStates?: string[]; // Empty means Pan-India
    customRuleCheck?: (profile: CitizenProfile) => { passed: boolean; status: 'pass' | 'warn' | 'fail'; detail: string };
  };
  requiredDocuments: SchemeDocument[];
  officialPortalUrl: string;
  applyOnlineUrl?: string;
  helplineNumber?: string;
  grievancePortalUrl?: string;
}
