/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LanguageCode } from '../types/scheme';

export interface Translations {
  appName: string;
  tagline: string;
  disclaimerTitle: string;
  disclaimerText: string;
  tabs: {
    finder: string;
    allSchemes: string;
    housingFocus: string;
    shortlisted: string;
    documentChecklist: string;
    aiAssistant: string;
  };
  form: {
    title: string;
    subtitle: string;
    quickPresets: string;
    presetRuralFarmer: string;
    presetUrbanVendor: string;
    presetStudent: string;
    presetSenior: string;
    stateLabel: string;
    areaLabel: string;
    rural: string;
    urban: string;
    ageLabel: string;
    genderLabel: string;
    categoryLabel: string;
    occupationLabel: string;
    incomeLabel: string;
    housingLabel: string;
    landLabel: string;
    rationCardLabel: string;
    disabilityLabel: string;
    girlChildLabel: string;
    studentLabel: string;
    findButton: string;
    resetButton: string;
  };
  results: {
    title: string;
    summaryCount: (eligible: number, review: number, notEligible: number) => string;
    filterAll: string;
    filterEligible: string;
    filterReview: string;
    filterNotEligible: string;
    sortMatch: string;
    sortName: string;
    badgeEligible: string;
    badgeReview: string;
    badgeNotEligible: string;
    ruleBreakdownTitle: string;
    benefitsTitle: string;
    documentsNeeded: string;
    applyButton: string;
    shortlistButton: string;
    shortlistedButton: string;
    speakCardButton: string;
    viewDetailsButton: string;
    aiExplainButton: string;
    noSchemesFound: string;
  };
  accessibility: {
    touchToRead: string;
    touchToReadOn: string;
    touchToReadOff: string;
    highContrast: string;
    darkMode: string;
    fontSize: string;
    voiceAssistant: string;
    listening: string;
    speakNow: string;
    stopSpeaking: string;
  };
  detailsModal: {
    purpose: string;
    beneficiaries: string;
    benefits: string;
    eligibilityRules: string;
    documentsRequired: string;
    officialWebsite: string;
    helpline: string;
    grievance: string;
    close: string;
  };
  checklist: {
    title: string;
    subtitle: string;
    statusIHave: string;
    statusNeedToGet: string;
    howToGet: string;
    issuingOffice: string;
    printButton: string;
    close: string;
    emptyPrompt: string;
  };
  aiModal: {
    title: string;
    subtitle: string;
    placeholder: string;
    sendButton: string;
    suggestedQueries: string[];
    officialAdviceNote: string;
  };
}

export const TRANSLATIONS: Record<LanguageCode, Translations> = {
  en: {
    appName: 'SchemeSaathi',
    tagline: 'Unified Government Scheme & Housing Assistance Portal',
    disclaimerTitle: 'Official Public Advisory & Preliminary Results Notice',
    disclaimerText:
      'SchemeSaathi is an independent citizen advisory portal. Results generated are preliminary indicators based on your self-reported inputs and do not constitute an official sanction or formal guarantee of financial assistance. Final sanction is subject to physical verification and official approval by competent government departments.',
    tabs: {
      finder: 'Find Schemes',
      allSchemes: 'All Schemes Directory',
      housingFocus: 'Housing Assistance (PMAY)',
      shortlisted: 'Saved Schemes',
      documentChecklist: 'Document Checklist',
      aiAssistant: 'AI Scheme Sahayak'
    },
    form: {
      title: 'Your Citizen & Family Profile',
      subtitle: 'Enter basic details to evaluate eligibility against 15+ central welfare programmes',
      quickPresets: 'Quick Sample Profiles:',
      presetRuralFarmer: '🌾 Rural Small Farmer',
      presetUrbanVendor: '🛒 Urban Street Vendor',
      presetStudent: '🎓 SC/OBC College Student',
      presetSenior: '👵 Rural Elderly Citizen',
      stateLabel: 'State / Union Territory',
      areaLabel: 'Location Type',
      rural: 'Rural (Gram Panchayat)',
      urban: 'Urban (Municipality/City)',
      ageLabel: 'Age of Applicant',
      genderLabel: 'Gender',
      categoryLabel: 'Social Category',
      occupationLabel: 'Primary Occupation',
      incomeLabel: 'Approximate Annual Family Income',
      housingLabel: 'Current Housing Status',
      landLabel: 'Agricultural Landholding',
      rationCardLabel: 'Ration / Food Security Card',
      disabilityLabel: 'Any Benchmark Disability (40%+)',
      girlChildLabel: 'Have a Daughter Aged 10 or Younger?',
      studentLabel: 'Currently Enrolled as Student?',
      findButton: 'Evaluate Scheme Eligibility',
      resetButton: 'Reset to Default'
    },
    results: {
      title: 'Eligible Schemes & Housing Assistance',
      summaryCount: (e, r, n) => `${e} Potentially Eligible • ${r} More Info Needed • ${n} Criteria Not Met`,
      filterAll: 'All Categorized',
      filterEligible: 'Potentially Eligible',
      filterReview: 'More Info Needed',
      filterNotEligible: 'Criteria Not Met',
      sortMatch: 'Best Match Score',
      sortName: 'Scheme Name (A-Z)',
      badgeEligible: 'Potentially Eligible',
      badgeReview: 'More Information Required',
      badgeNotEligible: 'Eligibility Criteria Not Met',
      ruleBreakdownTitle: 'Transparent Rule Evaluation Breakdown',
      benefitsTitle: 'Key Benefits & Financial Assistance',
      documentsNeeded: 'Required Documents',
      applyButton: 'Apply on Official Portal',
      shortlistButton: 'Save Scheme',
      shortlistedButton: 'Saved in Shortlist',
      speakCardButton: 'Read Out Loud',
      viewDetailsButton: 'View Full Details & Process',
      aiExplainButton: 'Explain with AI',
      noSchemesFound: 'No schemes match the selected filter.'
    },
    accessibility: {
      touchToRead: 'Touch / Hover to Read Out Loud',
      touchToReadOn: 'Read Out Loud Mode: ON',
      touchToReadOff: 'Read Out Loud Mode: OFF',
      highContrast: 'High Contrast Mode',
      darkMode: 'Dark Mode',
      fontSize: 'Text Size',
      voiceAssistant: 'Voice Assistant',
      listening: 'Listening... Speak in your language',
      speakNow: 'Speak a command (e.g., "Housing schemes", "I am a farmer", "Ayushman Bharat")',
      stopSpeaking: 'Stop Audio'
    },
    detailsModal: {
      purpose: 'Scheme Purpose & National Objective',
      beneficiaries: 'Intended Beneficiaries',
      benefits: 'Financial & Welfare Benefits',
      eligibilityRules: 'Mandatory Eligibility Criteria',
      documentsRequired: 'Complete Document Checklist',
      officialWebsite: 'Official Government Portal',
      helpline: 'Toll-Free Helpline',
      grievance: 'Grievance Redressal Portal',
      close: 'Close Window'
    },
    checklist: {
      title: 'Your Consolidated Document Checklist',
      subtitle: 'Complete list of documents required across your eligible & shortlisted government schemes',
      statusIHave: 'I have this document',
      statusNeedToGet: 'Need to obtain / renew',
      howToGet: 'Where & How to Obtain:',
      issuingOffice: 'Issuing Authority:',
      printButton: 'Print / Save Checklist',
      close: 'Close',
      emptyPrompt: 'Shortlist schemes or view eligible programmes to generate your personalized document checklist.'
    },
    aiModal: {
      title: 'AI Scheme Saathi Assistant',
      subtitle: 'Instant multilingual guidance on scheme rules, application steps, and document procurement',
      placeholder: 'Ask anything (e.g. How do I get PMAY if I live in a mud house in Bihar?)...',
      sendButton: 'Ask Question',
      suggestedQueries: [
        'How do I apply for PMAY Rural house assistance?',
        'Can I get Ayushman Bharat card if I have no ration card?',
        'What loans are available under PM SVANidhi for vendors?',
        'How to get Income Certificate for scholarships?'
      ],
      officialAdviceNote: 'AI guidance is for informational support. Always verify guidelines on official ministry portals.'
    }
  },

  hi: {
    appName: 'स्कीम साथी',
    tagline: 'एकीकृत सरकारी योजना एवं आवास सहायता पोर्टल',
    disclaimerTitle: 'आधिकारिक नागरिक परामर्श एवं प्रारंभिक परिणाम सूचना',
    disclaimerText:
      'स्कीम साथी एक नागरिक सूचना पोर्टल है। प्रदर्शित परिणाम आपके द्वारा भरी गई जानकारी के आधार पर प्रारंभिक पात्रता दर्शाते हैं। यह वित्तीय सहायता की अंतिम कानूनी गारंटी नहीं है। अंतिम स्वीकृति संबंधित सरकारी विभाग द्वारा सत्यापन के बाद ही दी जाती है।',
    tabs: {
      finder: 'योजनाएं खोजें',
      allSchemes: 'सभी योजनाओं की सूची',
      housingFocus: 'आवास योजनाएं (PMAY)',
      shortlisted: 'सुरक्षित योजनाएं',
      documentChecklist: 'दस्तावेज़ चेकलिस्ट',
      aiAssistant: 'एआई योजना सहायक'
    },
    form: {
      title: 'नागरिक एवं पारिवारिक प्रोफाइल',
      subtitle: '15+ प्रमुख सरकारी योजनाओं में अपनी पात्रता जांचने के लिए मूलभूत विवरण भरें',
      quickPresets: 'त्वरित नमूना प्रोफाइल:',
      presetRuralFarmer: '🌾 ग्रामीण लघु किसान',
      presetUrbanVendor: '🛒 शहरी रेहड़ी-पटरी विक्रेता',
      presetStudent: '🎓 आरक्षित वर्ग का छात्र',
      presetSenior: '👵 ग्रामीण वृद्ध नागरिक',
      stateLabel: 'राज्य / केंद्र शासित प्रदेश',
      areaLabel: 'क्षेत्र का प्रकार',
      rural: 'ग्रामीण (ग्राम पंचायत)',
      urban: 'शहरी (नगर निगम/नगर पालिका)',
      ageLabel: 'आवेदक की आयु',
      genderLabel: 'लिंग',
      categoryLabel: 'सामाजिक श्रेणी (वर्ग)',
      occupationLabel: 'मुख्य व्यवसाय / कार्य',
      incomeLabel: 'अनुमानित वार्षिक पारिवारिक आय',
      housingLabel: 'वर्तमान आवास की स्थिति',
      landLabel: 'कृषि भूमि का स्वामित्व',
      rationCardLabel: 'राशन कार्ड का प्रकार',
      disabilityLabel: 'क्या कोई दिव्यांगता (40%+) है?',
      girlChildLabel: 'क्या परिवार में 10 वर्ष तक की बेटी है?',
      studentLabel: 'क्या वर्तमान में नियमित छात्र हैं?',
      findButton: 'पात्रता की जांच करें',
      resetButton: 'रीसेट करें'
    },
    results: {
      title: 'पात्र सरकारी योजनाएं एवं आवास सहायता',
      summaryCount: (e, r, n) => `${e} संभावित पात्र • ${r} अधिक जानकारी अपेक्षित • ${n} शर्तें अपूर्ण`,
      filterAll: 'सभी योजनाएं',
      filterEligible: 'संभावित पात्र',
      filterReview: 'अधिक जानकारी आवश्यक',
      filterNotEligible: 'शर्तें अपूर्ण',
      sortMatch: 'सर्वश्रेष्ठ मैच स्कोर',
      sortName: 'योजना का नाम',
      badgeEligible: 'संभावित पात्र',
      badgeReview: 'अधिक जानकारी अपेक्षित',
      badgeNotEligible: 'पात्रता शर्तें पूरी नहीं हैं',
      ruleBreakdownTitle: 'पारदर्शी पात्रता नियम विश्लेषण',
      benefitsTitle: 'मुख्य लाभ एवं वित्तीय सहायता',
      documentsNeeded: 'आवश्यक दस्तावेज़',
      applyButton: 'आधिकारिक पोर्टल पर आवेदन करें',
      shortlistButton: 'सुरक्षित करें',
      shortlistedButton: 'सुरक्षित किया गया',
      speakCardButton: 'बोलकर सुनाएं',
      viewDetailsButton: 'विस्तृत विवरण एवं प्रक्रिया',
      aiExplainButton: 'एआई से समझें',
      noSchemesFound: 'चयनित फिल्टर में कोई योजना नहीं मिली।'
    },
    accessibility: {
      touchToRead: 'छूकर या माउस लाकर सुनने की सुविधा',
      touchToReadOn: 'ऑडियो वाचन: चालू',
      touchToReadOff: 'ऑडियो वाचन: बंद',
      highContrast: 'उच्च कंट्रास्ट मोड',
      darkMode: 'डार्क मोड',
      fontSize: 'अक्षर का आकार',
      voiceAssistant: 'वॉयस असिस्टेंट',
      listening: 'सुन रहे हैं... अपनी भाषा में बोलें',
      speakNow: 'बोलें (जैसे: "आवास योजना", "मैं किसान हूँ", "आयुष्मान कार्ड")',
      stopSpeaking: 'ध्वनि रोकें'
    },
    detailsModal: {
      purpose: 'योजना का उद्देश्य एवं लक्ष्य',
      beneficiaries: 'लक्षित लाभार्थी',
      benefits: 'वित्तीय एवं कल्याणकारी लाभ',
      eligibilityRules: 'अनिवार्य पात्रता शर्तें',
      documentsRequired: 'आवश्यक दस्तावेजों की सूची',
      officialWebsite: 'आधिकारिक सरकारी पोर्टल',
      helpline: 'टोल-फ्री हेल्पलाइन नंबर',
      grievance: 'शिकायत निवारण पोर्टल',
      close: 'बंद करें'
    },
    checklist: {
      title: 'एकीकृत दस्तावेज़ चेकलिस्ट',
      subtitle: 'आपकी चुनी हुई योजनाओं के लिए आवश्यक प्रमाण पत्रों की पूरी सूची',
      statusIHave: 'मेरे पास यह दस्तावेज़ है',
      statusNeedToGet: 'बनवाना या नवीनीकरण कराना है',
      howToGet: 'कहाँ और कैसे बनवाएं:',
      issuingOffice: 'जारी करने वाला विभाग:',
      printButton: 'चेकलिस्ट प्रिंट करें / सेव करें',
      close: 'बंद करें',
      emptyPrompt: 'चेकलिस्ट तैयार करने के लिए योजनाओं को सुरक्षित करें या पात्रता जांचें।'
    },
    aiModal: {
      title: 'एआई स्कीम साथी सहायक',
      subtitle: 'सरकारी योजनाओं, पात्रता नियमों और आवेदन प्रक्रियाओं पर तत्काल सहायता',
      placeholder: 'अपना प्रश्न पूछें (जैसे: मुझे पीएम आवास ग्रामीण कैसे मिलेगा?)...',
      sendButton: 'पूछें',
      suggestedQueries: [
        'पीएम आवास योजना ग्रामीण के लिए क्या शर्तें हैं?',
        'बिना राशन कार्ड के आयुष्मान कार्ड कैसे बनेगा?',
        'पीएम स्वनिधि में रेहड़ी वालों को कितना कर्ज मिलता है?',
        'छात्रवृत्ति के लिए आय प्रमाण पत्र कहाँ से बनवाएं?'
      ],
      officialAdviceNote: 'एआई केवल मार्गदर्शन हेतु है। अंतिम जानकारी के लिए आधिकारिक मंत्रालय की वेबसाइट देखें।'
    }
  },

  bn: {
    appName: 'স্কিম সাথী',
    tagline: 'একীভূত সরকারি প্রকল্প ও আবাসন সহায়তা পোর্টাল',
    disclaimerTitle: 'অফিসিয়াল নাগরিক পরামর্শ ও প্রাথমিক ফলাফল সংক্রান্ত নোটিশ',
    disclaimerText:
      'স্কিম সাথী একটি নাগরিক তথ্য পোর্টাল। ফলাফলে প্রদর্শিত তথ্য আপনার দেওয়া তথ্যের উপর ভিত্তি করে তৈরি এবং এটি কোনো আর্থিক সুবিধার আইনি গ্যারান্টি নয়। চূড়ান্ত অনুমোদন সরকারি নিয়ম ও তদন্ত সাপেক্ষ।',
    tabs: {
      finder: 'প্রকল্প খুঁজুন',
      allSchemes: 'সকল প্রকল্পের তালিকা',
      housingFocus: 'আবাসন প্রকল্প (PMAY)',
      shortlisted: 'সংরক্ষিত প্রকল্প',
      documentChecklist: 'নথিপত্র তালিকা',
      aiAssistant: 'এআই প্রকল্প সহায়ক'
    },
    form: {
      title: 'নাগরিক ও পারিবারিক বিবরণ',
      subtitle: '১৫টিরও বেশি কেন্দ্রীয় প্রকল্পের যোগ্যতা যাচাই করতে মৌলিক তথ্য দিন',
      quickPresets: 'নমুনা প্রোফাইল:',
      presetRuralFarmer: '🌾 গ্রামীণ ক্ষুদ্র কৃষক',
      presetUrbanVendor: '🛒 শহুরে হকার / বিক্রেতা',
      presetStudent: '🎓 সংরক্ষিত শ্রেণির ছাত্র',
      presetSenior: '👵 গ্রামীণ প্রবীণ নাগরিক',
      stateLabel: 'রাজ্য / কেন্দ্রশাসিত অঞ্চল',
      areaLabel: 'এলাকার ধরন',
      rural: 'গ্রামীণ (গ্রাম পঞ্চায়েত)',
      urban: 'শহুরে (পৌরসভা/সিটি)',
      ageLabel: 'আবেদনকারীর বয়স',
      genderLabel: 'লিঙ্গ',
      categoryLabel: 'সামাজিক শ্রেণি',
      occupationLabel: 'প্রধান জীবিকা',
      incomeLabel: 'আনুমানিক বার্ষিক পারিবারিক আয়',
      housingLabel: 'বর্তমান আবাসনের অবস্থা',
      landLabel: 'কৃষি জমির পরিমাণ',
      rationCardLabel: 'রেশন কার্ডের ধরন',
      disabilityLabel: 'কোনো প্রতিবন্ধকতা (৪০%+) আছে কি?',
      girlChildLabel: '১০ বছর বা তার কম বয়সী কন্যাসন্তান আছে কি?',
      studentLabel: 'বর্তমানে শিক্ষার্থী কি?',
      findButton: 'যোগ্যতা মূল্যায়ন করুন',
      resetButton: 'রিসেট করুন'
    },
    results: {
      title: 'যোগ্য সরকারি প্রকল্প ও আবাসন সহায়তা',
      summaryCount: (e, r, n) => `${e} সম্ভাব্য যোগ্য • ${r} অতিরিক্ত তথ্য প্রয়োজন • ${n} শর্ত পূরণ হয়নি`,
      filterAll: 'সকল প্রকল্প',
      filterEligible: 'সম্ভাব্য যোগ্য',
      filterReview: 'অতিরিক্ত তথ্য প্রয়োজন',
      filterNotEligible: 'শর্ত পূরণ হয়নি',
      sortMatch: 'সেরা ম্যাচ স্কোর',
      sortName: 'প্রকল্পের নাম',
      badgeEligible: 'সম্ভাব্য যোগ্য',
      badgeReview: 'অতিরিক্ত তথ্য প্রয়োজন',
      badgeNotEligible: 'শর্ত পূরণ হয়নি',
      ruleBreakdownTitle: 'স্বচ্ছ নিয়ম বিশ্লেষণ',
      benefitsTitle: 'মূল সুবিধা ও অনুদান',
      documentsNeeded: 'প্রয়োজনীয় নথিপত্র',
      applyButton: 'অফিসিয়াল পোর্টালে আবেদন করুন',
      shortlistButton: 'সংরক্ষণ করুন',
      shortlistedButton: 'সংরক্ষিত হয়েছে',
      speakCardButton: 'পড়ে শোনান',
      viewDetailsButton: 'বিস্তারিত ও আবেদন প্রক্রিয়া',
      aiExplainButton: 'এআই দিয়ে বুঝুন',
      noSchemesFound: 'কোনো প্রকল্প পাওয়া যায়নি।'
    },
    accessibility: {
      touchToRead: 'স্পর্শ বা মাউস নিয়ে পড়ে শোনানোর মোড',
      touchToReadOn: 'পড়ে শোনানো: চালু',
      touchToReadOff: 'পড়ে শোনানো: বন্ধ',
      highContrast: 'হাই কনট্রাস্ট মোড',
      darkMode: 'ডার্ক মোড',
      fontSize: 'অক্ষরের মাপ',
      voiceAssistant: 'ভয়েস সহকারী',
      listening: 'শুনছি... আপনার ভাষায় বলুন',
      speakNow: 'বলুন (যেমন: "আবাসন যোজনা", "আমি কৃষক", "আয়ুষ্মান কার্ড")',
      stopSpeaking: 'শব্দ বন্ধ করুন'
    },
    detailsModal: {
      purpose: 'প্রকল্পের উদ্দেশ্য',
      beneficiaries: 'উদ্দিষ্ট সুবিধাপ্রাপক',
      benefits: 'আর্থিক ও কল্যাণমূলক সুবিধা',
      eligibilityRules: 'বাধ্যতামূলক যোগ্যতার মাপকাঠি',
      documentsRequired: 'প্রয়োজনীয় নথিপত্রের সম্পূর্ণ তালিকা',
      officialWebsite: 'অফিসিয়াল সরকারি পোর্টাল',
      helpline: 'টোল-ফ্রি হেল্পলাইন',
      grievance: 'অভিযোগ প্রতিকার পোর্টাল',
      close: 'বন্ধ করুন'
    },
    checklist: {
      title: 'একত্রিত নথিপত্র চেকলিস্ট',
      subtitle: 'আপনার নির্বাচিত প্রকল্পের জন্য দরকারি কাগজপত্রের পূর্ণাঙ্গ তালিকা',
      statusIHave: 'আমার কাছে এই নথি আছে',
      statusNeedToGet: 'সংগ্রহ বা পুনর্নবীকরণ করতে হবে',
      howToGet: 'কোথায় ও কীভাবে পাবেন:',
      issuingOffice: 'ইস্যুকারী কর্তৃপক্ষ:',
      printButton: 'চেকলিস্ট প্রিন্ট / সেভ করুন',
      close: 'বন্ধ করুন',
      emptyPrompt: 'আপনার চেকলিস্ট দেখতে প্রকল্প সেভ করুন।'
    },
    aiModal: {
      title: 'এআই স্কিম সাথী সহায়ক',
      subtitle: 'সরকারি প্রকল্প ও আবেদন প্রক্রিয়া সংক্রান্ত তাৎক্ষণিক সমাধান',
      placeholder: 'যেকোনো প্রশ্ন করুন (যেমন: প্রধানমন্ত্রী আবাস যোজনায় কীভাবে ঘর পাব?)...',
      sendButton: 'জিজ্ঞাসা করুন',
      suggestedQueries: [
        'প্রধানমন্ত্রী গ্রামীণ আবাস যোজনার নিয়ম কী?',
        'রেশন কার্ড না থাকলে কি আয়ুষ্মান ভারত কার্ড পাব?',
        'পিএম স্বনিধি ঋণের প্রক্রিয়া কী?',
        'স্কলারশিপের জন্য ইনকাম সার্টিফিকেট কোথা থেকে পাব?'
      ],
      officialAdviceNote: 'এআই শুধুমাত্র পরামর্শের জন্য। সর্বদা অফিসিয়াল সরকারি ওয়েবসাইট অনুসরণ করুন।'
    }
  },

  pa: {
    appName: 'ਸਕੀਮ ਸਾਥੀ',
    tagline: 'ਸਰਕਾਰੀ ਸਕੀਮਾਂ ਅਤੇ ਆਵਾਸ ਸਹਾਇਤਾ ਲਈ ਏਕੀਕ੍ਰਿਤ ਪੋਰਟਲ',
    disclaimerTitle: 'ਅਧਿਕਾਰਤ ਨਾਗਰਿਕ ਸਲਾਹ ਅਤੇ ਮੁੱਢਲੇ ਨਤੀਜਿਆਂ ਸਬੰਧੀ ਸੂਚਨਾ',
    disclaimerText:
      'ਸਕੀਮ ਸਾਥੀ ਇੱਕ ਸੁਤੰਤਰ ਨਾਗਰਿਕ ਸੂਚਨਾ ਪੋਰਟਲ ਹੈ। ਦਿਖਾਏ ਗਏ ਨਤੀਜੇ ਤੁਹਾਡੇ ਵੱਲੋਂ ਦਿੱਤੀ ਜਾਣਕਾਰੀ ਤੇ ਆਧਾਰਿਤ ਮੁੱਢਲੀ ਯੋਗਤਾ ਦਰਸਾਉਂਦੇ ਹਨ ਅਤੇ ਕਿਸੇ ਵਿੱਤੀ ਸਹਾਇਤਾ ਦੀ ਪੱਕੀ ਗਾਰੰਟੀ ਨਹੀਂ ਹਨ। ਅੰਤਿਮ ਪ੍ਰਵਾਨਗੀ ਸਬੰਧਤ ਸਰਕਾਰੀ ਵਿਭਾਗ ਵੱਲੋਂ ਜਾਂਚ ਤੋਂ ਬਾਅਦ ਹੀ ਦਿੱਤੀ ਜਾਵੇਗੀ।',
    tabs: {
      finder: 'ਸਕੀਮਾਂ ਲੱਭੋ',
      allSchemes: 'ਸਾਰੀਆਂ ਸਕੀਮਾਂ ਦੀ ਸੂਚੀ',
      housingFocus: 'ਮਕਾਨ ਸਹਾਇਤਾ (PMAY)',
      shortlisted: 'ਸੰਭਾਲੀਆਂ ਸਕੀਮਾਂ',
      documentChecklist: 'ਦਸਤਾਵੇਜ਼ ਚੈੱਕਲਿਸਟ',
      aiAssistant: 'ਏਆਈ ਸਕੀਮ ਸਹਾਇਕ'
    },
    form: {
      title: 'ਨਾਗਰਿਕ ਅਤੇ ਪਰਿਵਾਰਕ ਪ੍ਰੋਫਾਈਲ',
      subtitle: '15+ ਪ੍ਰਮੁੱਖ ਸਰਕਾਰੀ ਭਲਾਈ ਸਕੀਮਾਂ ਲਈ ਆਪਣੀ ਯੋਗਤਾ ਦੀ ਜਾਂਚ ਕਰੋ',
      quickPresets: 'ਤੇਜ਼ ਨਮੂਨਾ ਪ੍ਰੋਫਾਈਲ:',
      presetRuralFarmer: '🌾 ਪੇਂਡੂ ਛੋਟਾ ਕਿਸਾਨ',
      presetUrbanVendor: '🛒 ਸ਼ਹਿਰੀ ਰੇਹੜੀ ਵਾਲਾ',
      presetStudent: '🎓 ਰਿਜ਼ਰਵ ਸ਼੍ਰੇਣੀ ਵਿਦਿਆਰਥੀ',
      presetSenior: '👵 ਪੇਂਡੂ ਬਜ਼ੁਰਗ ਨਾਗਰਿਕ',
      stateLabel: 'ਰਾਜ / ਕੇਂਦਰ ਸ਼ਾਸਿਤ ਪ੍ਰਦੇਸ਼',
      areaLabel: 'ਖੇਤਰ ਦੀ ਕਿਸਮ',
      rural: 'ਪੇਂਡੂ (ਗ੍ਰਾਮ ਪੰਚਾਇਤ)',
      urban: 'ਸ਼ਹਿਰੀ (ਨਗਰ ਕੌਂਸਲ/ਨਿਗਮ)',
      ageLabel: 'ਬਿਨੈਕਾਰ ਦੀ ਉਮਰ',
      genderLabel: 'ਲਿੰਗ',
      categoryLabel: 'ਸਮਾਜਿਕ ਸ਼੍ਰੇਣੀ (ਵਰਗ)',
      occupationLabel: 'ਮੁੱਖ ਕਿੱਤਾ',
      incomeLabel: 'ਅਨੁਮਾਨਿਤ ਸਾਲਾਨਾ ਪਰਿਵਾਰਕ ਆਮਦਨ',
      housingLabel: 'ਮੌਜੂਦਾ ਮਕਾਨ ਦੀ ਹਾਲਤ',
      landLabel: 'ਖੇਤੀਬਾੜੀ ਜ਼ਮੀਨ ਦੀ ਮਲਕੀਅਤ',
      rationCardLabel: 'ਰਾਸ਼ਨ ਕਾਰਡ ਦੀ ਕਿਸਮ',
      disabilityLabel: 'ਕੀ ਕੋਈ ਦਿਵਿਆਂਗਤਾ (40%+) ਹੈ?',
      girlChildLabel: 'ਕੀ ਪਰਿਵਾਰ ਵਿੱਚ 10 ਸਾਲ ਤੱਕ ਦੀ ਧੀ ਹੈ?',
      studentLabel: 'ਕੀ ਇਸ ਵੇਲੇ ਵਿਦਿਆਰਥੀ ਹੋ?',
      findButton: 'ਯੋਗਤਾ ਦੀ ਜਾਂਚ ਕਰੋ',
      resetButton: 'ਮੁੜ ਸੈੱਟ ਕਰੋ'
    },
    results: {
      title: 'ਯੋਗ ਸਰਕਾਰੀ ਸਕੀਮਾਂ ਅਤੇ ਮਕਾਨ ਸਹਾਇਤਾ',
      summaryCount: (e, r, n) => `${e} ਸੰਭਾਵੀ ਯੋਗ • ${r} ਹੋਰ ਜਾਣਕਾਰੀ ਲੋੜੀਂਦੀ • ${n} ਸ਼ਰਤਾਂ ਅਧੂਰੀਆਂ`,
      filterAll: 'ਸਾਰੀਆਂ ਸਕੀਮਾਂ',
      filterEligible: 'ਸੰਭਾਵੀ ਯੋਗ',
      filterReview: 'ਹੋਰ ਜਾਣਕਾਰੀ ਲੋੜੀਂਦੀ',
      filterNotEligible: 'ਸ਼ਰਤਾਂ ਅਧੂਰੀਆਂ',
      sortMatch: 'ਵਧੀਆ ਮੈਚ ਸਕੋਰ',
      sortName: 'ਸਕੀਮ ਦਾ ਨਾਂ',
      badgeEligible: 'ਸੰਭਾਵੀ ਯੋਗ',
      badgeReview: 'ਹੋਰ ਜਾਣਕਾਰੀ ਲੋੜੀਂਦੀ',
      badgeNotEligible: 'ਯੋਗਤਾ ਸ਼ਰਤਾਂ ਪੂਰੀਆਂ ਨਹੀਂ ਹਨ',
      ruleBreakdownTitle: 'ਨਿਯਮਾਂ ਦਾ ਪਾਰਦਰਸ਼ੀ ਵਿਸ਼ਲੇਸ਼ਣ',
      benefitsTitle: 'ਮੁੱਖ ਲਾਭ ਅਤੇ ਵਿੱਤੀ ਸਹਾਇਤਾ',
      documentsNeeded: 'ਲੋੜੀਂਦੇ ਦਸਤਾਵੇਜ਼',
      applyButton: 'ਸਰਕਾਰੀ ਪੋਰਟਲ ਤੇ ਅਪਲਾਈ ਕਰੋ',
      shortlistButton: 'ਸੇਵ ਕਰੋ',
      shortlistedButton: 'ਸੇਵ ਕੀਤੀ ਗਈ',
      speakCardButton: 'ਬੋਲ ਕੇ ਸੁਣਾਓ',
      viewDetailsButton: 'ਵੇਰਵੇ ਅਤੇ ਪ੍ਰਕਿਰਿਆ',
      aiExplainButton: 'ਏਆਈ ਤੋਂ ਸਮਝੋ',
      noSchemesFound: 'ਕੋਈ ਸਕੀਮ ਨਹੀਂ ਮਿਲੀ।'
    },
    accessibility: {
      touchToRead: 'ਛੂਹ ਕੇ ਜਾਂ ਮਾਊਸ ਲਿਆ ਕੇ ਸੁਣਨ ਦੀ ਸਹੂਲਤ',
      touchToReadOn: 'ਆਡੀਓ ਪੜ੍ਹਨਾ: ਚਾਲੂ',
      touchToReadOff: 'ਆਡੀਓ ਪੜ੍ਹਨਾ: ਬੰਦ',
      highContrast: 'ਹਾਈ ਕੰਟ੍ਰਾਸਟ ਮੋਡ',
      darkMode: 'ਡਾਰਕ ਮੋਡ',
      fontSize: 'ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',
      voiceAssistant: 'ਵੌਇਸ ਸਹਾਇਕ',
      listening: 'ਸੁਣ ਰਹੇ ਹਾਂ... ਆਪਣੀ ਬੋਲੀ ਵਿੱਚ ਬੋਲੋ',
      speakNow: 'ਬੋਲੋ (ਜਿਵੇਂ: "ਆਵਾਸ ਯੋਜਨਾ", "ਮੈਂ ਕਿਸਾਨ ਹਾਂ", "ਆਯੁਸ਼ਮਾਨ ਕਾਰਡ")',
      stopSpeaking: 'ਆਵਾਜ਼ ਬੰਦ ਕਰੋ'
    },
    detailsModal: {
      purpose: 'ਸਕੀਮ ਦਾ ਮੰਤਵ',
      beneficiaries: 'ਲਾਭਪਾਤਰੀ',
      benefits: 'ਵਿੱਤੀ ਅਤੇ ਭਲਾਈ ਲਾਭ',
      eligibilityRules: 'ਜ਼ਰੂਰੀ ਯੋਗਤਾ ਸ਼ਰਤਾਂ',
      documentsRequired: 'ਲੋੜੀਂਦੇ ਦਸਤਾਵੇਜ਼ਾਂ ਦੀ ਸੂਚੀ',
      officialWebsite: 'ਸਰਕਾਰੀ ਪੋਰਟਲ ਲਿੰਕ',
      helpline: 'ਟੋਲ-ਫ੍ਰੀ ਹੈਲਪਲਾਈਨ',
      grievance: 'ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ ਪੋਰਟਲ',
      close: 'ਬੰਦ ਕਰੋ'
    },
    checklist: {
      title: 'ਇਕੱਠੀ ਕੀਤੀ ਦਸਤਾਵੇਜ਼ ਚੈੱਕਲਿਸਟ',
      subtitle: 'ਤੁਹਾਡੀਆਂ ਚੁਣੀਆਂ ਸਕੀਮਾਂ ਲਈ ਲੋੜੀਂਦੇ ਕਾਗਜ਼ਾਤਾਂ ਦੀ ਪੂਰੀ ਸੂਚੀ',
      statusIHave: 'ਮੇਰੇ ਕੋਲ ਇਹ ਦਸਤਾਵੇਜ਼ ਹੈ',
      statusNeedToGet: 'ਬਣਵਾਉਣਾ ਜਾਂ ਨਵਿਆਉਣਾ ਹੈ',
      howToGet: 'ਕਿੱਥੋਂ ਅਤੇ ਕਿਵੇਂ ਬਣਵਾਉਣਾ ਹੈ:',
      issuingOffice: 'ਜਾਰੀ ਕਰਨ ਵਾਲਾ ਅਦਾਰਾ:',
      printButton: 'ਚੈੱਕਲਿਸਟ ਪ੍ਰਿੰਟ / ਸੇਵ ਕਰੋ',
      close: 'ਬੰਦ ਕਰੋ',
      emptyPrompt: 'ਚੈੱਕਲਿਸਟ ਵੇਖਣ ਲਈ ਸਕੀਮਾਂ ਸੇਵ ਕਰੋ।'
    },
    aiModal: {
      title: 'ਏਆਈ ਸਕੀਮ ਸਾਥੀ ਸਹਾਇਕ',
      subtitle: 'ਸਰਕਾਰੀ ਸਕੀਮਾਂ ਅਤੇ ਅਰਜ਼ੀ ਪ੍ਰਕਿਰਿਆ ਬਾਰੇ ਤੁਰੰਤ ਮਦਦ',
      placeholder: 'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ (ਜਿਵੇਂ: ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਆਵਾਸ ਯੋਜਨਾ ਦਾ ਘਰ ਕਿਵੇਂ ਮਿਲੇਗਾ?)...',
      sendButton: 'ਪੁੱਛੋ',
      suggestedQueries: [
        'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਗ੍ਰਾਮੀਣ ਆਵਾਸ ਯੋਜਨਾ ਦੀਆਂ ਸ਼ਰਤਾਂ ਕੀ ਹਨ?',
        'ਕੀ ਬਿਨਾਂ ਰਾਸ਼ਨ ਕਾਰਡ ਦੇ ਆਯੁਸ਼ਮਾਨ ਕਾਰਡ ਬਣ ਸਕਦਾ ਹੈ?',
        'ਪੀਐਮ ਸਵਨਿਧੀ ਯੋਜਨਾ ਵਿੱਚ ਕਿੰਨਾ ਕਰਜ਼ਾ ਮਿਲਦਾ ਹੈ?',
        'ਸਕਾਲਰਸ਼ਿਪ ਲਈ ਆਮਦਨ ਸਰਟੀਫਿਕੇਟ ਕਿਵੇਂ ਬਣਵਾਈਏ?'
      ],
      officialAdviceNote: 'ਏਆਈ ਸਿਰਫ ਸਲਾਹ ਲਈ ਹੈ। ਅਧਿਕਾਰਤ ਸਰਕਾਰੀ ਵੈੱਬਸਾਈਟ ਤੋਂ ਪੁਸ਼ਟੀ ਕਰੋ।'
    }
  },

  ta: {
    appName: 'ஸ்கீம் சாதி',
    tagline: 'ஒருங்கிணைந்த அரசு திட்டங்கள் மற்றும் வீட்டு வசதி உதவி போர்ட்டல்',
    disclaimerTitle: 'அதிகாரப்பூர்வ குடிமக்கள் ஆலோசனை மற்றும் முதற்கட்ட முடிவுகள் அறிவிப்பு',
    disclaimerText:
      'ஸ்கீம் சாதி என்பது ஒரு பொது தகவல் போர்ட்டல் ஆகும். நீங்கள் உள்ளிட்ட தகவல்களின் அடிப்படையில் மட்டுமே முதற்கட்ட தகுதி கணக்கிடப்படுகிறது; இது நிதி உதவிக்கான இறுதி அரசு உத்தரவாதம் அல்ல. சம்பந்தப்பட்ட அரசு துறையின் நேரடி சரிபார்ப்பிற்குப் பிறகே இறுதி ஒப்புதல் வழங்கப்படும்.',
    tabs: {
      finder: 'திட்டங்களை கண்டறிக',
      allSchemes: 'அனைத்து திட்டங்களின் பட்டியல்',
      housingFocus: 'வீட்டு வசதி திட்டங்கள் (PMAY)',
      shortlisted: 'சேமிக்கப்பட்ட திட்டங்கள்',
      documentChecklist: 'ஆவண சரிபார்ப்பு பட்டியல்',
      aiAssistant: 'AI திட்ட உதவியாளர்'
    },
    form: {
      title: 'குடிமக்கள் மற்றும் குடும்ப விவரங்கள்',
      subtitle: '15+ முக்கிய அரசு நலத்திட்டங்களில் உங்கள் தகுதியை சோதிக்க அடிப்படை விவரங்களை உள்ளிடவும்',
      quickPresets: 'மாதிரி சுயவிவரங்கள்:',
      presetRuralFarmer: '🌾 கிராமப்புற சிறு விவசாயி',
      presetUrbanVendor: '🛒 நகர்ப்புற தெருவோர வியாபாரி',
      presetStudent: '🎓 கல்லூரி மாணவர்',
      presetSenior: '👵 கிராமப்புற மூத்த குடிமகன்',
      stateLabel: 'மாநிலம் / யூனியன் பிரதேசம்',
      areaLabel: 'வசிக்கும் பகுதி',
      rural: 'கிராமப்புறம் (ஊராட்சி)',
      urban: 'நகர்ப்புறம் (நகராட்சி/மாநகராட்சி)',
      ageLabel: 'விண்ணப்பதாரர் வயது',
      genderLabel: 'பாலினம்',
      categoryLabel: 'சமூக பிரிவு',
      occupationLabel: 'முதன்மை தொழில்',
      incomeLabel: 'தோராயமான ஆண்டு குடும்ப வருமானம்',
      housingLabel: 'தற்போதைய வீட்டின் நிலை',
      landLabel: 'விவசாய நில உரிமை',
      rationCardLabel: 'ரேஷன் அட்டை வகை',
      disabilityLabel: 'ஏதேனும் மாற்றுத்திறன் (40%+) உள்ளதா?',
      girlChildLabel: '10 வயதுக்குட்பட்ட பெண் குழந்தை உள்ளதா?',
      studentLabel: 'தற்போது பயிலும் மாணவரா?',
      findButton: 'தகுதியை சோதிக்கவும்',
      resetButton: 'மீட்டமைக்க'
    },
    results: {
      title: 'தகுதியான அரசு திட்டங்கள் & வீட்டு உதவி',
      summaryCount: (e, r, n) => `${e} தகுதி வாய்ப்பு • ${r} கூடுதல் தகவல் தேவை • ${n} தகுதி பொருந்தவில்லை`,
      filterAll: 'அனைத்து திட்டங்கள்',
      filterEligible: 'தகுதி வாய்ப்பு உள்ளவை',
      filterReview: 'கூடுதல் தகவல் தேவை',
      filterNotEligible: 'தகுதி பொருந்தாதவை',
      sortMatch: 'பொருத்தமான மதிப்பெண்',
      sortName: 'திட்டத்தின் பெயர்',
      badgeEligible: 'தகுதி வாய்ப்பு உள்ளது',
      badgeReview: 'கூடுதல் தகவல் தேவை',
      badgeNotEligible: 'தகுதி வரம்புகள் பூர்த்தியாகவில்லை',
      ruleBreakdownTitle: 'வெளிப்படையான தகுதி விதிமுறை பகுப்பாய்வு',
      benefitsTitle: 'முக்கிய நன்மைகள் மற்றும் நிதி உதவி',
      documentsNeeded: 'தேவையான ஆவணங்கள்',
      applyButton: 'அரசு இணையதளத்தில் விண்ணப்பிக்க',
      shortlistButton: 'சேமிக்க',
      shortlistedButton: 'சேமிக்கப்பட்டது',
      speakCardButton: 'குரலில் வாசிக்க',
      viewDetailsButton: 'முழு விவரங்கள் & செயல்முறை',
      aiExplainButton: 'AI மூலம் விளக்கம்',
      noSchemesFound: 'எந்த திட்டங்களும் கிடைக்கவில்லை.'
    },
    accessibility: {
      touchToRead: 'தொட்டு அல்லது சுட்டியை வைத்து வாசிக்கும் வசதி',
      touchToReadOn: 'வாசிப்பு பயன்முறை: ஆன்',
      touchToReadOff: 'வாசிப்பு பயன்முறை: ஆஃப்',
      highContrast: 'உயர் மாறுபட்ட பயன்முறை (High Contrast)',
      darkMode: 'டார்க் மோட் (Dark Mode)',
      fontSize: 'எழுத்து அளவு',
      voiceAssistant: 'குரல் உதவியாளர் (Voice Assistant)',
      listening: 'கேட்கிறது... உங்கள் மொழியில் பேசுங்கள்',
      speakNow: 'பேசுங்கள் (எ.கா: "வீட்டு வசதி திட்டம்", "நான் விவசாயி", "ஆயுஷ்மான் கார்டு")',
      stopSpeaking: 'ஆடியோவை நிறுத்து'
    },
    detailsModal: {
      purpose: 'திட்டத்தின் நோக்கம்',
      beneficiaries: 'பயனாளிகள்',
      benefits: 'நிதி மற்றும் நலத்திட்ட நன்மைகள்',
      eligibilityRules: 'கட்டாய தகுதி விதிகள்',
      documentsRequired: 'தேவையான ஆவணங்களின் முழு பட்டியல்',
      officialWebsite: 'அதிகாரப்பூர்வ அரசு இணையதளம்',
      helpline: 'கட்டணமில்லா உதவி எண்',
      grievance: 'குறைதீர்ப்பு போர்ட்டல்',
      close: 'மூடு'
    },
    checklist: {
      title: 'ஒருங்கிணைந்த ஆவண சரிபார்ப்பு பட்டியல்',
      subtitle: 'நீங்கள் தகுதிபெறும் மற்றும் சேமித்த திட்டங்களுக்கான தேவையான ஆவணங்கள்',
      statusIHave: 'இந்த ஆவணம் என்னிடம் உள்ளது',
      statusNeedToGet: 'பெற வேண்டும் / புதுப்பிக்க வேண்டும்',
      howToGet: 'எங்கு மற்றும் எப்படி பெறுவது:',
      issuingOffice: 'வழங்கும் அரசு துறை:',
      printButton: 'பட்டியலை அச்சிடுக / சேமிக்க',
      close: 'மூடு',
      emptyPrompt: 'சரிபார்ப்பு பட்டியலை உருவாக்க திட்டங்களை சேமிக்கவும்.'
    },
    aiModal: {
      title: 'AI திட்ட சாதி உதவியாளர்',
      subtitle: 'அரசு திட்டங்கள் மற்றும் விண்ணப்ப நடைமுறைகளுக்கான உடனடி வழிகாட்டல்',
      placeholder: 'உங்கள் கேள்வியை கேளுங்கள் (எ.கா: கிராமப்புற வீடு கட்ட அரசு உதவி பெறுவது எப்படி?)...',
      sendButton: 'கேட்க',
      suggestedQueries: [
        'பிரதம மந்திரி கிராமப்புற வீட்டு திட்டத்திற்கு விண்ணப்பிப்பது எப்படி?',
        'ரேஷன் கார்டு இல்லாமல் ஆயுஷ்மான் அட்டை பெற முடியுமா?',
        'தெருவோர வியாபாரிகளுக்கு பிஎம் ஸ்வாநிதி கடன் விவரங்கள் என்ன?',
        'கல்வி உதவித்தொகைக்கு வருமான சான்றிதழ் பெறுவது எப்படி?'
      ],
      officialAdviceNote: 'AI தகவல் வழிகாட்டலுக்கு மட்டுமே. அதிகாரப்பூர்வ அரசு இணையதளங்களை சரிபார்க்கவும்.'
    }
  }
};
