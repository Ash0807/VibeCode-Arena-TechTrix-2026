/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Scheme } from '../types/scheme';

export const ALL_INDIAN_STATES = [
  'All India (National)',
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Manipur',
  'Meghalaya',
  'Mizoram',
  'Nagaland',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Sikkim',
  'Tamil Nadu',
  'Telangana',
  'Tripura',
  'Uttar Pradesh',
  'Uttarakhand',
  'West Bengal',
  'Andaman and Nicobar Islands',
  'Chandigarh',
  'Dadra and Nagar Haveli and Daman and Diu',
  'Delhi (NCT)',
  'Jammu and Kashmir',
  'Ladakh',
  'Lakshadweep',
  'Puducherry'
];

export const COMMON_DOCUMENTS = {
  aadhaar: {
    id: 'doc_aadhaar',
    name: 'Aadhaar Card (UIDAI)',
    description: '12-digit unique citizen identification with linked mobile number for biometric authentication.',
    isMandatory: true,
    issuingAuthority: 'Unique Identification Authority of India (UIDAI)',
    howToGet: 'Enroll or update at any nearest Aadhaar Seva Kendra, Post Office, or Bank branch.',
    digitalPortalUrl: 'https://myaadhaar.uidai.gov.in'
  },
  rationCard: {
    id: 'doc_ration_card',
    name: 'Ration Card (NFSA / BPL / AAY)',
    description: 'Proof of family composition and socio-economic category (Antyodaya, BPL, or Priority Household).',
    isMandatory: true,
    issuingAuthority: 'Department of Food and Civil Supplies (State Government)',
    howToGet: 'Apply through your state e-District portal or local Food & Civil Supplies block office.',
    digitalPortalUrl: 'https://nfsa.gov.in'
  },
  incomeCert: {
    id: 'doc_income_cert',
    name: 'Income Certificate',
    description: 'Official revenue document showing annual household income verified by Tehsildar/Revenue Officer.',
    isMandatory: true,
    issuingAuthority: 'Tehsildar / Sub-Divisional Magistrate (Revenue Dept)',
    howToGet: 'Apply online on your state e-District / Citizen Service portal with salary slips or self-affidavit.',
    digitalPortalUrl: 'https://services.india.gov.in'
  },
  bankPassbook: {
    id: 'doc_bank_passbook',
    name: 'Bank Passbook / Cancelled Cheque',
    description: 'Active savings account linked with Aadhaar (DBT-enabled) for direct government benefit transfer.',
    isMandatory: true,
    issuingAuthority: 'Any Scheduled Commercial Bank, Post Office, or Regional Rural Bank',
    howToGet: 'Open zero-balance Jan Dhan account at nearest bank branch or Post Office with Aadhaar.',
    digitalPortalUrl: 'https://pmjdy.gov.in'
  },
  landRecords: {
    id: 'doc_land_record',
    name: 'Land Ownership Record (Khatauni / RoR / Khasra)',
    description: 'Official land title proving ownership, area, and cultivation rights in agricultural revenue records.',
    isMandatory: true,
    issuingAuthority: 'Revenue Department / Patwari / Lekhpal',
    howToGet: 'Download certified copy from state Bhulekh / Land Records digital portal or visit Tehsil office.',
    digitalPortalUrl: 'https://dilrmp.gov.in'
  },
  casteCert: {
    id: 'doc_caste_cert',
    name: 'Caste / Category Certificate (SC/ST/OBC/EWS)',
    description: 'Verification of reserved social category status issued by competent revenue authority.',
    isMandatory: false,
    issuingAuthority: 'Sub-Divisional Magistrate (SDM) / Tehsildar',
    howToGet: 'Submit application along with ancestral domicile proof at local CSC or e-District portal.',
    digitalPortalUrl: 'https://services.india.gov.in'
  },
  disabilityCert: {
    id: 'doc_disability_cert',
    name: 'UDID / Disability Certificate',
    description: 'Unique Disability ID card indicating 40% or more benchmark physical or sensory disability.',
    isMandatory: false,
    issuingAuthority: 'District Medical Board / Ministry of Social Justice & Empowerment',
    howToGet: 'Register online on Swavlamban card portal and attend medical assessment at district hospital.',
    digitalPortalUrl: 'https://www.swavlambancard.gov.in'
  },
  vendingCertificate: {
    id: 'doc_vending_cert',
    name: 'Certificate of Vending / Urban Local Body Identity Card',
    description: 'Proof of street vending recognized by the Municipal Corporation or Town Vending Committee.',
    isMandatory: true,
    issuingAuthority: 'Urban Local Body (Municipality / Nagar Nigam)',
    howToGet: 'Obtain from your local ward office, Town Vending Committee, or through Letter of Recommendation (LoR).',
    digitalPortalUrl: 'https://pmsvanidhi.mohua.gov.in'
  },
  studentId: {
    id: 'doc_student_id',
    name: 'School / College Bonafide Certificate & Marks Card',
    description: 'Proof of regular enrollment in recognized institution with previous year marksheets.',
    isMandatory: true,
    issuingAuthority: 'Head of Educational Institution / College Principal',
    howToGet: 'Request bonafide certificate from administrative office of school or college.',
    digitalPortalUrl: 'https://scholarships.gov.in'
  }
};

export const SCHEMES_DATABASE: Scheme[] = [
  // 1. PMAY-G (Rural Housing)
  {
    id: 'pmay-g',
    category: 'housing',
    name: 'Pradhan Mantri Awas Yojana - Gramin (PMAY-G)',
    nameTranslations: {
      hi: 'प्रधानमंत्री आवास योजना - ग्रामीण (PMAY-G)',
      bn: 'প্রধানমন্ত্রী আবাস যোজনা - গ্রামীণ (PMAY-G)',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਆਵਾਸ ਯੋਜਨਾ - ਗ੍ਰਾਮੀਣ (PMAY-G)',
      ta: 'பிரதம மந்திரி ஆவாஸ் யோஜனா - கிராமப்புறம் (PMAY-G)'
    },
    shortCode: 'PMAY-G',
    ministry: 'Ministry of Rural Development, Govt. of India',
    tagline: 'Pucca house with basic amenities for all rural homeless & kutcha house dwellers',
    taglineTranslations: {
      hi: 'सभी बेघर और कच्चे मकान वाले ग्रामीण परिवारों को पक्का मकान और बुनियादी सुविधाएं',
      bn: 'সকল গৃহহীন এবং কাঁচা বাড়ির বাসিন্দাদের জন্য পাকা বাড়ি',
      pa: 'ਸਾਰੇ ਬੇਘਰ ਅਤੇ ਕੱਚੇ ਮਕਾਨ ਵਾਲੇ ਪੇਂਡੂ ਪਰਿਵਾਰਾਂ ਲਈ ਪੱਕਾ ਘਰ',
      ta: 'கிராமப்புற வீடற்ற மற்றும் குடிசைவாழ் குடும்பங்களுக்கு பக்கா வீடு'
    },
    purpose: 'Provides direct financial assistance to rural households that are either homeless or living in kutcha, dilapidated houses to construct a resilient, disaster-safe pucca house equipped with toilet, LPG, and electricity connections.',
    intendedBeneficiaries: [
      'Rural households with no pucca house in the name of any family member',
      'Families residing in kutcha or dilapidated housing structures',
      'Families verified under Socio-Economic Caste Census (SECC) / Awaas+ survey'
    ],
    availableBenefits: {
      financialAmount: '₹1,20,000 (Plain areas) / ₹1,30,000 (Hilly/NE/IAP areas)',
      description: 'Direct cash grant in 3 installments + 90-95 person-days of unskilled labor wages under MGNREGA (~₹25,000) + ₹12,000 for toilet construction under Swachh Bharat Mission (Grameen).',
      frequency: 'Construction Milestone-Based Direct Bank Transfer'
    },
    keyHighlights: [
      'Minimum house size of 25 sq. meters including a hygienic cooking area',
      'Additional grant of ₹12,000 for toilet under SBM-G',
      'Up to 95 days of paid MGNREGA wages during construction',
      'No middleman; geotagged milestone verification through AwaasApp'
    ],
    eligibilityCriteria: {
      allowedAreaTypes: ['rural'],
      allowedHousingStatuses: ['homeless', 'kutcha', 'semi_pucca', 'rented'],
      maxIncomeRange: '2_5_to_5_lakh',
      allowedOccupations: [
        'farmer',
        'agricultural_labourer',
        'daily_wage_worker',
        'artisan_craftsperson',
        'unemployed',
        'homemaker',
        'senior_citizen',
        'other'
      ],
      customRuleCheck: (profile) => {
        if (profile.housingStatus === 'own_pucca') {
          return {
            passed: false,
            status: 'fail',
            detail: 'Applicant already owns a pucca house. PMAY-G strictly assists households without a pucca house.'
          };
        }
        if (profile.areaType === 'urban') {
          return {
            passed: false,
            status: 'fail',
            detail: 'PMAY-Gramin is strictly for rural residents. Urban residents should apply for PMAY-Urban.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Meets rural residency and housing need criteria.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.rationCard,
      COMMON_DOCUMENTS.incomeCert
    ],
    officialPortalUrl: 'https://pmayg.nic.in',
    applyOnlineUrl: 'https://pmayg.nic.in/netiay/RegistrationProcess.aspx',
    helplineNumber: '1800-11-6446 (Toll-Free)',
    grievancePortalUrl: 'https://pgportal.gov.in'
  },

  // 2. PMAY-U 2.0 (Urban Housing)
  {
    id: 'pmay-u',
    category: 'housing',
    name: 'Pradhan Mantri Awas Yojana - Urban 2.0 (PMAY-U)',
    nameTranslations: {
      hi: 'प्रधानमंत्री आवास योजना - शहरी 2.0 (PMAY-U)',
      bn: 'প্রধানমন্ত্রী আবাস যোজনা - নগর 2.0 (PMAY-U)',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਆਵਾਸ ਯੋਜਨਾ - ਸ਼ਹਿਰੀ 2.0 (PMAY-U)',
      ta: 'பிரதம மந்திரி ஆவாஸ் யோஜனா - நகர்ப்புறம் 2.0 (PMAY-U)'
    },
    shortCode: 'PMAY-U 2.0',
    ministry: 'Ministry of Housing and Urban Affairs, Govt. of India',
    tagline: 'Affordable, secure pucca housing for economically weaker & low-income urban families',
    taglineTranslations: {
      hi: 'शहरी आर्थिक कमजोर और निम्न आय वर्ग परिवारों के लिए किफायती पक्का आवास',
      bn: 'শহুরে অর্থনৈতিকভাবে দুর্বল ও নিম্ন আয়ের পরিবারের জন্য পাকা বাড়ি',
      pa: 'ਸ਼ਹਿਰੀ ਗਰੀਬ ਅਤੇ ਘੱਟ ਆਮਦਨ ਵਾਲੇ ਪਰਿਵਾਰਾਂ ਲਈ ਪੱਕਾ ਮਕਾਨ',
      ta: 'நகர்ப்புற ஏழை மற்றும் குறைந்த வருமானம் கொண்ட குடும்பங்களுக்கு மலிவு விலை வீடு'
    },
    purpose: 'Empowers urban homeless, slum dwellers, and economically weaker section (EWS) / lower income group (LIG) families in municipal areas to build or purchase affordable pucca homes with direct interest subsidies and construction grants.',
    intendedBeneficiaries: [
      'Urban families living in rented accommodation, slums, or non-pucca houses',
      'Economically Weaker Section (annual income up to ₹3 Lakh) & Lower Income Group (up to ₹6-9 Lakh)',
      'Female head or co-ownership prioritized'
    ],
    availableBenefits: {
      financialAmount: 'Up to ₹2,50,000 grant or ₹1.80 Lakh interest subsidy (4% interest subvention)',
      description: 'Direct central/state financial assistance for individual house construction (BLC), or subsidized purchase under Affordable Housing in Partnership (AHP) and Credit Linked Subsidy.',
      frequency: 'Direct Bank Subsidy'
    },
    keyHighlights: [
      'Mandatory female ownership or co-ownership for houses',
      'Credit Linked Interest Subsidy for home loans up to 20 years',
      'Water, electricity, and sanitation included',
      'Covers 5,000+ statutory towns across India'
    ],
    eligibilityCriteria: {
      allowedAreaTypes: ['urban'],
      allowedHousingStatuses: ['homeless', 'kutcha', 'semi_pucca', 'rented'],
      maxIncomeRange: '5_to_8_lakh',
      customRuleCheck: (profile) => {
        if (profile.areaType === 'rural') {
          return {
            passed: false,
            status: 'fail',
            detail: 'PMAY-Urban is applicable only to statutory urban local bodies and municipal towns.'
          };
        }
        if (profile.housingStatus === 'own_pucca') {
          return {
            passed: false,
            status: 'fail',
            detail: 'Beneficiary family must not own a pucca house anywhere in India.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Urban residency and housing qualification verified.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.incomeCert,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.rationCard
    ],
    officialPortalUrl: 'https://pmay-urban.gov.in',
    applyOnlineUrl: 'https://pmaymis.gov.in/Open/Check_Aadhar_Existence.aspx',
    helplineNumber: '011-23060484 / 1800-11-3377',
    grievancePortalUrl: 'https://pmaymis.gov.in'
  },

  // 3. PM-KISAN Samman Nidhi
  {
    id: 'pm-kisan',
    category: 'agriculture',
    name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    nameTranslations: {
      hi: 'पीएम-किसान सम्मान निधि (PM-KISAN)',
      bn: 'পিএম-কিষাণ সম্মান নিধি (PM-KISAN)',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਕਿਸਾਨ ਸਨਮਾਨ ਨਿਧੀ (PM-KISAN)',
      ta: 'பிரதம மந்திரி கிசான் சம்மான் நிதி (PM-KISAN)'
    },
    shortCode: 'PM-KISAN',
    ministry: 'Ministry of Agriculture and Farmers Welfare, Govt. of India',
    tagline: 'Guaranteed income support of ₹6,000/year directly to farmer bank accounts',
    taglineTranslations: {
      hi: 'किसान परिवारों के बैंक खातों में ₹6,000 प्रति वर्ष की सुनिश्चित आय सहायता',
      bn: 'কৃষক পরিবারগুলির অ্যাকাউন্টে বছরে ₹৬,০০০ সরাসরি আর্থিক সহায়তা',
      pa: 'ਕਿਸਾਨਾਂ ਦੇ ਬੈਂਕ ਖਾਤਿਆਂ ਵਿੱਚ ਸਾਲਾਨਾ ₹6,000 ਦੀ ਸਿੱਧੀ ਵਿੱਤੀ ਸਹਾਇਤਾ',
      ta: 'விவசாயிகளுக்கு ஆண்டுக்கு ₹6,000 நேரடி வங்கி பண உதவி'
    },
    purpose: 'Supplements the financial needs of landholding farmers in procuring various agricultural inputs related to agriculture and allied activities as well as domestic needs before cropping seasons.',
    intendedBeneficiaries: [
      'Small and marginal farmer families with cultivable landholding in revenue records',
      'Families registered with Aadhaar and e-KYC on the PM-Kisan portal'
    ],
    availableBenefits: {
      financialAmount: '₹6,000 per year',
      description: 'Disbursed in 3 equal installments of ₹2,000 every 4 months directly into the Aadhaar-seeded bank account through DBT.',
      frequency: '₹2,000 every 4 months (April-July, August-Nov, Dec-March)'
    },
    keyHighlights: [
      '100% centrally sponsored scheme with zero deduction',
      'Direct credit via NPCI Aadhaar Payment Bridge',
      'e-KYC can be completed via face authentication on PM-KISAN mobile app',
      'Integrated with Kisan Credit Card for easy loans'
    ],
    eligibilityCriteria: {
      allowedOccupations: ['farmer'],
      allowedLandholdings: ['marginal', 'small', 'medium_large'],
      customRuleCheck: (profile) => {
        if (profile.occupation !== 'farmer') {
          return {
            passed: false,
            status: 'fail',
            detail: 'Requires occupation to be a cultivator/farmer with cultivable land record.'
          };
        }
        if (profile.landholding === 'landless') {
          return {
            passed: false,
            status: 'fail',
            detail: 'PM-KISAN requires ownership of cultivable landholding in applicant name.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible cultivator with landholding.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.landRecords,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://pmkisan.gov.in',
    applyOnlineUrl: 'https://pmkisan.gov.in/RegistrationFormNew.aspx',
    helplineNumber: '155261 / 011-24300606',
    grievancePortalUrl: 'https://pmkisan.gov.in/Grievance.aspx'
  },

  // 4. Ayushman Bharat PM-JAY
  {
    id: 'ab-pmjay',
    category: 'healthcare',
    name: 'Ayushman Bharat - PM Jan Arogya Yojana (AB-PMJAY)',
    nameTranslations: {
      hi: 'आयुष्मान भारत - प्रधानमंत्री जन आरोग्य योजना (PM-JAY)',
      bn: 'আয়ুষ্মান ভারত - প্রধানমন্ত্রী জন আরোগ্য যোজনা (PM-JAY)',
      pa: 'ਆਯੁਸ਼ਮਾਨ ਭਾਰਤ - ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਜਨ ਅਰੋਗਿਆ ਯੋਜਨਾ (PM-JAY)',
      ta: 'ஆயுஷ்மான் பாரத் - பிரதம மந்திரி ஜன் ஆரோக்கிய யோஜனா'
    },
    shortCode: 'AB-PMJAY',
    ministry: 'National Health Authority, Ministry of Health and Family Welfare',
    tagline: 'World’s largest health insurance offering ₹5,00,000 cashless hospitalization per family per year',
    taglineTranslations: {
      hi: 'प्रति परिवार प्रति वर्ष ₹5 लाख का मुफ्त कैशलेस स्वास्थ्य बीमा',
      bn: 'প্রতি পরিবারে বছরে ₹৫ লাখের বিনামূল্যে ক্যাশলেস স্বাস্থ্য বীমা',
      pa: 'ਹਰ ਪਰਿਵਾਰ ਨੂੰ ਸਾਲਾਨਾ ₹5 ਲੱਖ ਦਾ ਮੁਫਤ ਕੈਸ਼ਲੈੱਸ ਸਿਹਤ ਬੀਮਾ',
      ta: 'ஆண்டுக்கு ₹5 லட்சம் இலவச பணமில்லா மருத்துவ காப்பீடு'
    },
    purpose: 'Provides financial risk protection against catastrophic health expenditures for secondary and tertiary care hospitalization across 28,000+ empaneled public and private hospitals across India.',
    intendedBeneficiaries: [
      'Economically vulnerable rural (deprivation criteria D1-D7) and urban (occupational criteria) families',
      'All citizens aged 70 years and above (Ayushman Vay Vandana Card) regardless of income',
      'Holders of Antyodaya / BPL / Priority Ration Cards'
    ],
    availableBenefits: {
      financialAmount: '₹5,00,000 cashless coverage per family per year',
      description: 'Covers medical examination, consultation, treatment, medicines, diagnostic tests, hospital stay, and 15 days post-hospitalization care for 1,900+ procedures including cardiac surgery, oncology, and joint replacement.',
      frequency: 'Annual Cashless Hospitalization Coverage'
    },
    keyHighlights: [
      'Cashless and paperless treatment across all empaneled hospitals across India',
      'No restriction on family size, age, or gender',
      'Pre-existing conditions covered from Day 1',
      'Senior citizens aged 70+ receive exclusive ₹5 Lakh top-up irrespective of income'
    ],
    eligibilityCriteria: {
      maxIncomeRange: '5_to_8_lakh',
      customRuleCheck: (profile) => {
        if (profile.age >= 70) {
          return {
            passed: true,
            status: 'pass',
            detail: 'Universal coverage: All senior citizens aged 70 and above are eligible for Ayushman Vay Vandana Card regardless of income!'
          };
        }
        if (['antyodaya', 'bpl', 'priority_phh'].includes(profile.rationCard)) {
          return {
            passed: true,
            status: 'pass',
            detail: 'Eligible based on state NFSA / BPL / Priority ration card database linkage.'
          };
        }
        if (profile.incomeRange === 'above_8_lakh') {
          return {
            passed: false,
            status: 'fail',
            detail: 'Income exceeds Ayushman Bharat socio-economic criteria (unless individual is age 70+).'
          };
        }
        return {
          passed: true,
          status: 'warn',
          detail: 'Check family inclusion on Mera PM-JAY portal using mobile number or ration card.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.rationCard
    ],
    officialPortalUrl: 'https://beneficiary.nha.gov.in',
    applyOnlineUrl: 'https://beneficiary.nha.gov.in',
    helplineNumber: '14555 (National Call Centre) / 1800-111-565',
    grievancePortalUrl: 'https://cgrms.pmjay.gov.in'
  },

  // 5. PM SVANidhi (Urban Micro-Credit)
  {
    id: 'pm-svanidhi',
    category: 'employment',
    name: 'PM SVANidhi (Street Vendor’s AtmaNirbhar Nidhi)',
    nameTranslations: {
      hi: 'पीएम स्वनिधि (स्ट्रीट वेंडर्स आत्मनिर्भर निधि)',
      bn: 'পিএম স্বনিধি (রাস্তার বিক্রেতাদের আত্মনির্ভর নিধি)',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਸਵਨਿਧੀ (ਸਟ੍ਰੀਟ ਵੈਂਡਰਾਂ ਲਈ ਕਰਜ਼ਾ ਯੋਜਨਾ)',
      ta: 'பிஎம் ஸ்வாநிதி (தெருவோர வியாபாரிகள் கடன் திட்டம்)'
    },
    shortCode: 'PM SVANidhi',
    ministry: 'Ministry of Housing and Urban Affairs, Govt. of India',
    tagline: 'Collateral-free working capital loan up to ₹50,000 with 7% interest subsidy for street vendors',
    taglineTranslations: {
      hi: 'रेहड़ी-पटरी वालों के लिए ₹50,000 तक का बिना गारंटी कार्यशील पूंजी ऋण व ब्याज सब्सिडी',
      bn: 'রাস্তার হকারদের জন্য ₹৫০,০০০ পর্যন্ত জামানতমুক্ত ঋণ',
      pa: 'ਰੇਹੜੀ-ਫੜ੍ਹੀ ਵਾਲਿਆਂ ਲਈ ₹50,000 ਤੱਕ ਬਿਨਾਂ ਗਰੰਟੀ ਕਾਰਜਕਾਰੀ ਕਰਜ਼ਾ',
      ta: 'தெருவோர வியாபாரிகளுக்கு பிணையற்ற ₹50,000 வரை மூலதனக் கடன்'
    },
    purpose: 'Offers micro-credit working capital loans to urban and peri-urban street vendors, vegetable sellers, fruit vendors, and artisan carts to restart and expand their livelihood without collateral.',
    intendedBeneficiaries: [
      'Street vendors in urban and semi-urban municipal areas',
      'Vendors possessing Certificate of Vending / ID card issued by Urban Local Body or Letter of Recommendation'
    ],
    availableBenefits: {
      financialAmount: '1st Tranche: ₹10,000, 2nd: ₹20,000, 3rd: ₹50,000',
      description: 'Collateral-free loan with 7% per annum interest subsidy credited directly to your bank account on timely repayment, plus cashback up to ₹1,200/year for digital transactions.',
      frequency: 'Progressive Loan Tranches'
    },
    keyHighlights: [
      'No collateral or security needed',
      '7% annual interest subsidy deposited in bank',
      'Digital payment incentives (UPI cashback up to ₹100/month)',
      'Builds official credit score for higher bank borrowing'
    ],
    eligibilityCriteria: {
      allowedAreaTypes: ['urban'],
      allowedOccupations: ['street_vendor', 'artisan_craftsperson', 'small_business_owner'],
      minAge: 18,
      customRuleCheck: (profile) => {
        if (profile.occupation !== 'street_vendor' && profile.occupation !== 'small_business_owner') {
          return {
            passed: false,
            status: 'warn',
            detail: 'Designed primarily for street hawkers, fruit/vegetable carts, and roadside service providers.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Qualified occupation and urban trade criteria satisfied.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.vendingCertificate,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://pmsvanidhi.mohua.gov.in',
    applyOnlineUrl: 'https://pmsvanidhi.mohua.gov.in/Home/VendorLogin',
    helplineNumber: '1800-11-1979',
    grievancePortalUrl: 'https://pmsvanidhi.mohua.gov.in'
  },

  // 6. MGNREGA (Rural Employment)
  {
    id: 'mgnrega',
    category: 'employment',
    name: 'Mahatma Gandhi NREGA (MGNREGA)',
    nameTranslations: {
      hi: 'महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी (MGNREGA)',
      bn: 'মহাত্মা গান্ধী জাতীয় গ্রামীণ কর্মসংস্থান নিশ্চয়তা প্রকল্প',
      pa: 'ਮਹਾਤਮਾ ਗਾਂਧੀ ਦਿਹਾਤੀ ਰੁਜ਼ਗਾਰ ਗਾਰੰਟੀ ਯੋਜਨਾ (ਮਨਰੇਗਾ)',
      ta: 'மகாத்மா காந்தி ஊரக வேலைவாய்ப்பு உறுதித் திட்டம் (100 நாள் வேலை)'
    },
    shortCode: 'MGNREGA',
    ministry: 'Ministry of Rural Development, Govt. of India',
    tagline: '100 days guaranteed wage employment per year for every rural household adult member',
    taglineTranslations: {
      hi: 'प्रत्येक ग्रामीण परिवार को वर्ष में 100 दिनों के अकुशल शारीरिक रोजगार की कानूनी गारंटी',
      bn: 'প্রতিটি গ্রামীণ পরিবারের জন্য বছরে ১০০ দিনের কাজের আইনি নিশ্চয়তা',
      pa: 'ਪੇਂਡੂ ਪਰਿਵਾਰਾਂ ਲਈ ਸਾਲ ਵਿੱਚ 100 ਦਿਨਾਂ ਦੇ ਗਾਰੰਟੀਸ਼ੁਦਾ ਰੁਜ਼ਗਾਰ',
      ta: 'ஒவ்வொரு கிராமப்புற குடும்பத்திற்கும் ஆண்டுக்கு 100 நாள் கூலி வேலை உத்தரவாதம்'
    },
    purpose: 'Guarantees the legal right to 100 days of unskilled manual work in a financial year to every rural adult who volunteers to do manual work within 5 km of their residence.',
    intendedBeneficiaries: [
      'Adult members (aged 18+) of rural households willing to perform unskilled manual labour',
      'Families issued a Job Card by the local Gram Panchayat'
    ],
    availableBenefits: {
      financialAmount: 'State-notified daily wages (₹234 to ₹374 per day depending on state)',
      description: 'Direct weekly/fortnightly wage transfer into the bank/post office account via Aadhaar-Based Payment System (ABPS). Additional unemployment allowance if work is not given within 15 days.',
      frequency: 'Daily Wage Paid Fortnightly'
    },
    keyHighlights: [
      'Statutory legal guarantee of 100 days work',
      'Unemployment allowance payable if work is not provided within 15 days of demand',
      'Equal wages for men and women',
      'Creche facilities, drinking water, and first aid provided at worksite'
    ],
    eligibilityCriteria: {
      allowedAreaTypes: ['rural'],
      minAge: 18,
      allowedOccupations: [
        'agricultural_labourer',
        'daily_wage_worker',
        'farmer',
        'artisan_craftsperson',
        'unemployed',
        'homemaker',
        'other'
      ],
      customRuleCheck: (profile) => {
        if (profile.areaType === 'urban') {
          return {
            passed: false,
            status: 'fail',
            detail: 'MGNREGA is legally restricted to rural areas administered by Gram Panchayats.'
          };
        }
        if (profile.age < 18) {
          return {
            passed: false,
            status: 'fail',
            detail: 'Applicant must be at least 18 years of age to register for a Job Card.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible rural adult household applicant.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.rationCard
    ],
    officialPortalUrl: 'https://nrega.nic.in',
    applyOnlineUrl: 'https://nrega.nic.in/netnrega/home.aspx',
    helplineNumber: '1800-345-6565 / State Toll-Free numbers',
    grievancePortalUrl: 'https://nrega.nic.in/netnrega/Grievance.aspx'
  },

  // 7. PM Vishwakarma Scheme
  {
    id: 'pm-vishwakarma',
    category: 'employment',
    name: 'PM Vishwakarma Scheme',
    nameTranslations: {
      hi: 'पीएम विश्वकर्मा योजना',
      bn: 'পিএম বিশ্বকর্মা যোজনা',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਵਿਸ਼ਵਕਰਮਾ ਯੋਜਨਾ',
      ta: 'பிரதம மந்திரி விஸ்வகர்மா திட்டம்'
    },
    shortCode: 'PM Vishwakarma',
    ministry: 'Ministry of Micro, Small and Medium Enterprises (MSME)',
    tagline: 'Holistic support, ₹15,000 toolkit incentive, and collateral-free credit at 5% for traditional artisans',
    taglineTranslations: {
      hi: 'पारंपरिक कारीगरों और शिल्पकारों के लिए ₹15,000 टूलकिट सहायता व 5% ब्याज पर ऋण',
      bn: 'ঐতিহ্যবাহী কারিগরদের জন্য ₹১৫,০০০ টুলকিট অনুদান ও ৫% সুদে ঋণ',
      pa: 'ਰਵਾਇਤੀ ਦਸਤਕਾਰਾਂ ਲਈ ₹15,000 ਟੂਲਕਿੱਟ ਅਤੇ 5% ਵਿਆਜ ਤੇ ਕਰਜ਼ਾ',
      ta: 'பாரம்பரிய கைவினைஞர்களுக்கு ₹15,000 உபகரண உதவி மற்றும் 5% வட்டியில் கடன்'
    },
    purpose: 'Recognizes and supports artisans and craftspeople engaged in 18 traditional trades (carpenters, blacksmiths, goldsmiths, potters, cobblers, weavers, tailors, etc.) with skill upgradation, modern toolkit grants, and concessional loans.',
    intendedBeneficiaries: [
      'Artisans working with hands and traditional tools in 18 notified family crafts',
      'Minimum age 18 years, not having availed benefits under PMEGP or PM SVANidhi simultaneously'
    ],
    availableBenefits: {
      financialAmount: '₹15,000 toolkit grant + up to ₹3,00,000 credit at subsidized 5% interest',
      description: 'Basic 5-7 days skill training with ₹500/day stipend, e-voucher of ₹15,000 for modern tools, first credit tranche of ₹1,00,000 (18 months) and second tranche of ₹2,00,000 (30 months) at only 5% interest.',
      frequency: 'Toolkit Grant + 2 Loan Tranches'
    },
    keyHighlights: [
      'Official PM Vishwakarma Certificate and ID Card',
      '₹500 daily stipend during skill training',
      '₹15,000 grant for modern precision toolkits',
      'Credit guarantee fees fully borne by Government of India'
    ],
    eligibilityCriteria: {
      minAge: 18,
      allowedOccupations: ['artisan_craftsperson', 'daily_wage_worker', 'small_business_owner'],
      maxIncomeRange: '5_to_8_lakh',
      customRuleCheck: (profile) => {
        if (profile.occupation !== 'artisan_craftsperson') {
          return {
            passed: true,
            status: 'warn',
            detail: 'Must be actively practicing one of the 18 traditional trades (carpentry, pottery, masonry, tailoring, etc.).'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Qualifies under traditional artisan and craftsperson trade requirements.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.rationCard
    ],
    officialPortalUrl: 'https://pmvishwakarma.gov.in',
    applyOnlineUrl: 'https://pmvishwakarma.gov.in/Home/HowToRegister',
    helplineNumber: '1800-267-7777 / 17923',
    grievancePortalUrl: 'https://pmvishwakarma.gov.in'
  },

  // 8. Sukanya Samriddhi Yojana (SSY)
  {
    id: 'sukanya-samriddhi',
    category: 'education',
    name: 'Sukanya Samriddhi Yojana (Beti Bachao Beti Padhao)',
    nameTranslations: {
      hi: 'सुकन्या समृद्धि योजना (बेटी बचाओ बेटी पढ़ाओ)',
      bn: 'সুকন্যা সমৃদ্ধি যোজনা',
      pa: 'ਸੁਕੰਨਿਆ ਸਮ੍ਰਿਧੀ ਯੋਜਨਾ',
      ta: 'சுகன்யா சம்ரித்தி யோஜனா (செல்வமகள் சேமிப்பு திட்டம்)'
    },
    shortCode: 'SSY',
    ministry: 'Ministry of Finance & Ministry of Women and Child Development',
    tagline: 'High interest savings scheme (8.2%) with triple tax exemption for girl child’s education & marriage',
    taglineTranslations: {
      hi: 'बालिकाओं की उच्च शिक्षा व भविष्य के लिए 8.2% ब्याज दर वाली सरकारी बचत योजना',
      bn: 'কন্যা সন্তানের উচ্চশিক্ষা ও ভবিষ্যতের জন্য ৮.২% সুদের সরকারি সঞ্চয় প্রকল্প',
      pa: 'ਧੀਆਂ ਦੀ ਉੱਚ ਸਿੱਖਿਆ ਅਤੇ ਵਿਆਹ ਲਈ 8.2% ਵਿਆਜ ਵਾਲੀ ਬਚਤ ਯੋਜਨਾ',
      ta: 'பெண் குழந்தைகளின் கல்வி மற்றும் எதிர்காலத்திற்கான 8.2% சேமிப்பு திட்டம்'
    },
    purpose: 'Enables parents to build a dedicated, inflation-beating fund for higher education and marriage of a girl child from her birth up to the age of 10 years, offering highest government-backed small savings interest rate.',
    intendedBeneficiaries: [
      'Parents or legal guardians of a girl child aged from birth up to 10 years',
      'Maximum of two girl children per family (or triplets/twins)'
    ],
    availableBenefits: {
      financialAmount: '8.2% compound interest + 100% Tax Exemption under Sec 80C',
      description: 'Deposit minimum ₹250 to maximum ₹1,50,000 per financial year. Complete tax exemption on deposits, accumulated interest, and maturity withdrawal. 50% withdrawal allowed after age 18 for higher education.',
      frequency: 'Annual Compound Interest Scheme'
    },
    keyHighlights: [
      'Highest sovereign interest rate among all postal savings schemes (currently 8.2%)',
      'EEE tax status: Exemption on investment, interest, and maturity amount',
      'Account operational at any Post Office or commercial bank across India',
      'Matures after 21 years or upon marriage after age 18'
    ],
    eligibilityCriteria: {
      requiresGirlChild: true,
      customRuleCheck: (profile) => {
        if (!profile.hasGirlChildUnder10) {
          return {
            passed: false,
            status: 'warn',
            detail: 'Requires having a daughter aged 10 years or younger in the household.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Household with eligible girl child under 10 years.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://www.indiapost.gov.in',
    applyOnlineUrl: 'https://www.indiapost.gov.in/Financial/Pages/Content/Sukanya-Samriddhi-Account.aspx',
    helplineNumber: '1800-266-6868 (India Post)',
    grievancePortalUrl: 'https://pgportal.gov.in'
  },

  // 9. Atal Pension Yojana (APY)
  {
    id: 'atal-pension-yojana',
    category: 'social_welfare',
    name: 'Atal Pension Yojana (APY)',
    nameTranslations: {
      hi: 'अटल पेंशन योजना (APY)',
      bn: 'অটল পেনশন যোজনা (APY)',
      pa: 'ਅਟਲ ਪੈਨਸ਼ਨ ਯੋਜਨਾ (APY)',
      ta: 'அடல் ஓய்வூதிய திட்டம் (APY)'
    },
    shortCode: 'APY',
    ministry: 'Pension Fund Regulatory and Development Authority (PFRDA)',
    tagline: 'Guaranteed lifetime monthly pension of ₹1,000 to ₹5,000 for unorganized workers from age 60',
    taglineTranslations: {
      hi: 'असंगठित क्षेत्र के नागरिकों के लिए 60 वर्ष की आयु से ₹1,000 से ₹5,000 की गारंटीकृत मासिक पेंशन',
      bn: '৬০ বছর বয়স থেকে মাসিক ₹১,০০০ থেকে ₹৫,০০০ নিশ্চিত পেনশন',
      pa: '60 ਸਾਲ ਦੀ ਉਮਰ ਤੋਂ ਮਹੀਨਾਵਾਰ ₹1,000 ਤੋਂ ₹5,000 ਦੀ ਗਰੰਟੀਸ਼ੁਦਾ ਪੈਨਸ਼ਨ',
      ta: '60 வயதுக்கு பின் ₹1,000 முதல் ₹5,000 வரை மாதாந்திர உத்தரவாத ஓய்வூதியம்'
    },
    purpose: 'Delivers universal old-age financial security for all citizens, especially workers in the unorganized sector such as domestic maids, drivers, farmers, and daily wage workers through government-guaranteed pensions.',
    intendedBeneficiaries: [
      'All Indian citizens aged between 18 and 40 years holding a savings bank account',
      'Citizens who are not income-tax payers'
    ],
    availableBenefits: {
      financialAmount: 'Guaranteed pension of ₹1,000, ₹2,000, ₹3,000, ₹4,000 or ₹5,000 per month',
      description: 'Fixed monthly pension guaranteed by Government of India from the age of 60 years till death. Same pension continues to spouse upon subscriber death, and full corpus returned to nominee.',
      frequency: 'Monthly Lifetime Pension'
    },
    keyHighlights: [
      'Government guarantees return if pension corpus earns lower yields',
      'Low monthly contribution (as low as ₹42/month if joined at age 18)',
      'Spouse gets lifelong same monthly pension in case of subscriber demise',
      'Tax benefit under Section 80CCD'
    ],
    eligibilityCriteria: {
      minAge: 18,
      maxAge: 40,
      maxIncomeRange: '5_to_8_lakh',
      customRuleCheck: (profile) => {
        if (profile.age < 18 || profile.age > 40) {
          return {
            passed: false,
            status: 'fail',
            detail: 'Entry age is strictly between 18 and 40 years. (Citizens 60+ should check IGNOAPS pension instead).'
          };
        }
        if (profile.incomeRange === 'above_8_lakh') {
          return {
            passed: false,
            status: 'fail',
            detail: 'Income tax payers are not eligible to subscribe to Atal Pension Yojana.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible age group (18-40) and income criteria satisfied.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://www.npscra.nsdl.co.in',
    applyOnlineUrl: 'https://enps.nsdl.com/eNPS/ApySubRegistration.html',
    helplineNumber: '1800-110-069 / 1800-180-1111',
    grievancePortalUrl: 'https://cgrms.cra-nsdl.com'
  },

  // 10. IGNOAPS (National Old Age Pension)
  {
    id: 'ignoaps-old-age',
    category: 'social_welfare',
    name: 'Indira Gandhi National Old Age Pension Scheme (IGNOAPS)',
    nameTranslations: {
      hi: 'इंदिरा गांधी राष्ट्रीय वृद्धावस्था पेंशन योजना (IGNOAPS)',
      bn: 'ইন্দিরা গান্ধী জাতীয় বার্ধক্য পেনশন প্রকল্প',
      pa: 'ਇੰਦਰਾ ਗਾਂਧੀ ਕੌਮੀ ਬੁਢਾਪਾ ਪੈਨਸ਼ਨ ਯੋਜਨਾ',
      ta: 'இந்திரா காந்தி தேசிய முதியோர் ஓய்வூதியத் திட்டம்'
    },
    shortCode: 'IGNOAPS',
    ministry: 'Ministry of Rural Development, Govt. of India (NSAP)',
    tagline: 'Monthly non-contributory social pension for senior citizens from BPL families',
    taglineTranslations: {
      hi: 'बीपीएल परिवारों के 60 वर्ष व उससे अधिक आयु के वरिष्ठ नागरिकों को मासिक सामाजिक पेंशन',
      bn: 'বিপিএল পরিবারের ৬০ বছর বা তার বেশি বয়সের প্রবীণ নাগরিকদের জন্য মাসিক সামাজিক পেনশন',
      pa: 'ਗਰੀਬ ਪਰਿਵਾਰਾਂ ਦੇ ਬਜ਼ੁਰਗਾਂ ਲਈ ਮਹੀਨਾਵਾਰ ਸਮਾਜਿਕ ਸੁਰੱਖਿਆ ਪੈਨਸ਼ਨ',
      ta: 'வறுமைக் கோட்டிற்கு கீழ் உள்ள முதியோருக்கான மாதாந்திர சமூக ஓய்வூதியம்'
    },
    purpose: 'Social assistance pension providing monthly income support to destitute and poor senior citizens aged 60 and above living below the poverty line.',
    intendedBeneficiaries: [
      'Citizens aged 60 years and above',
      'Belonging to a household living Below the Poverty Line (BPL / Antyodaya)'
    ],
    availableBenefits: {
      financialAmount: '₹500 to ₹2,500 per month (combined Central + State contribution)',
      description: 'Direct monthly pension deposited directly to the senior citizen’s savings bank or postal account without any intermediary.',
      frequency: 'Monthly Direct Bank Deposit'
    },
    keyHighlights: [
      'Non-contributory (no previous payments required)',
      'State governments augment the central grant, raising total monthly pension up to ₹2,000-₹3,000 in many states',
      'Elderly citizens aged 80+ receive enhanced central benefit'
    ],
    eligibilityCriteria: {
      minAge: 60,
      allowedRationCards: ['antyodaya', 'bpl', 'priority_phh'],
      maxIncomeRange: '1_to_2_5_lakh',
      customRuleCheck: (profile) => {
        if (profile.age < 60) {
          return {
            passed: false,
            status: 'fail',
            detail: 'Applicant must be at least 60 years of age.'
          };
        }
        if (profile.incomeRange === 'above_8_lakh' || profile.rationCard === 'apl_none') {
          return {
            passed: false,
            status: 'warn',
            detail: 'Requires BPL status or household income under poverty line guidelines.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible senior citizen from low-income / BPL household.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.rationCard,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.incomeCert
    ],
    officialPortalUrl: 'https://nsap.nic.in',
    applyOnlineUrl: 'https://nsap.nic.in/nsap/app/onlineApply',
    helplineNumber: '1800-111-555 / Local Social Welfare Office',
    grievancePortalUrl: 'https://nsap.nic.in'
  },

  // 11. Post-Matric Scholarship for SC/ST/OBC/EWS
  {
    id: 'post-matric-scholarship',
    category: 'education',
    name: 'Post-Matric Scholarship for Reserved & Economically Weaker Students',
    nameTranslations: {
      hi: 'अनुसूचित जाति/जनजाति/ओबीसी/ईडब्ल्यूएस उत्तर-मैट्रिक छात्रवृत्ति',
      bn: 'পোস্ট-ম্যাট্রিক স্কলারশিপ (তপশিলি জাতি/উপজাতি/ওবিসি/ইডব্লিউএস)',
      pa: 'ਪੋਸਟ-ਮੈਟ੍ਰਿਕ ਵਜ਼ੀਫ਼ਾ ਯੋਜਨਾ',
      ta: 'பத்தாம் வகுப்புக்கு பிந்தைய கல்வி உதவித்தொகை (Post-Matric Scholarship)'
    },
    shortCode: 'PMS',
    ministry: 'Ministry of Social Justice & Empowerment / Ministry of Tribal Affairs',
    tagline: '100% tuition fee reimbursement and monthly maintenance allowance for higher education',
    taglineTranslations: {
      hi: 'उच्च शिक्षा के लिए पूर्ण शिक्षण शुल्क प्रतिपूर्ति एवं मासिक रखरखाव भत्ता',
      bn: 'উচ্চশিক্ষার জন্য সম্পূর্ণ টিউশন ফি মকুব ও মাসিক ভাতা',
      pa: 'ਉੱਚ ਸਿੱਖਿਆ ਲਈ ਪੂਰੀ ਫੀਸ ਮੁਆਫੀ ਅਤੇ ਮਹੀਨਾਵਾਰ ਭੱਤਾ',
      ta: 'உயர்கல்விக்கான முழு கல்விக் கட்டணம் மற்றும் மாதாந்திர பராமரிப்பு உதவி'
    },
    purpose: 'Provides comprehensive financial assistance to meritorious students belonging to SC, ST, OBC, and EWS communities studying at post-matriculation or post-secondary stage to enable them to complete their graduation, engineering, medical, or vocational degrees.',
    intendedBeneficiaries: [
      'Students enrolled in Class 11, 12, ITI, Diploma, Undergraduate, or Postgraduate courses',
      'SC/ST with family income <= ₹2.5 Lakh; OBC/EWS with family income <= ₹1.5 - ₹2.5 Lakh'
    ],
    availableBenefits: {
      financialAmount: 'Full non-refundable course fees + up to ₹13,500/year maintenance allowance',
      description: 'Direct credit of compulsory fees and study tour, book allowance, and disability allowance paid via DBT directly into student bank account.',
      frequency: 'Annual Course Fee Reimbursement + Monthly Allowance'
    },
    keyHighlights: [
      'Covers tuition fees, exam fees, hostel charges, and essential books',
      'Direct application through unified National Scholarship Portal (NSP)',
      '60:40 fund sharing between Centre and State governments'
    ],
    eligibilityCriteria: {
      allowedSocialCategories: ['sc', 'st', 'obc', 'ews'],
      maxIncomeRange: '2_5_to_5_lakh',
      customRuleCheck: (profile) => {
        if (!profile.isStudent && profile.occupation !== 'student') {
          return {
            passed: false,
            status: 'warn',
            detail: 'Applicant must be a currently enrolled student in post-secondary education.'
          };
        }
        if (profile.socialCategory === 'general') {
          return {
            passed: false,
            status: 'warn',
            detail: 'Requires SC/ST/OBC/EWS category certification or equivalent minority status.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible student with recognized reservation category.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.casteCert,
      COMMON_DOCUMENTS.incomeCert,
      COMMON_DOCUMENTS.studentId,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://scholarships.gov.in',
    applyOnlineUrl: 'https://scholarships.gov.in/fresh/newstdRegfrmInstruction',
    helplineNumber: '0120-6619540 (NSP Helpdesk)',
    grievancePortalUrl: 'https://scholarships.gov.in'
  },

  // 12. PM Fasal Bima Yojana (PMFBY)
  {
    id: 'pm-fasal-bima',
    category: 'agriculture',
    name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    nameTranslations: {
      hi: 'प्रधानमंत्री फसल बीमा योजना (PMFBY)',
      bn: 'প্রধানমন্ত্রী ফসল বীমা যোজনা (PMFBY)',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਫਸਲ ਬੀਮਾ ਯੋਜਨਾ (PMFBY)',
      ta: 'பிரதம மந்திரி பயிர் காப்பீட்டுத் திட்டம் (PMFBY)'
    },
    shortCode: 'PMFBY',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt. of India',
    tagline: 'Comprehensive crop insurance against droughts, floods, and natural pests at lowest premium',
    taglineTranslations: {
      hi: 'सूखे, बाढ़ और प्राकृतिक आपदाओं से फसल नुकसान पर न्यूनतम प्रीमियम पर व्यापक बीमा सुरक्षा',
      bn: 'প্রাকৃতিক দুর্যোগ ও বন্যায় ফসলের ক্ষয়ক্ষতিতে ব্যাপক বীমা সুরক্ষা',
      pa: 'ਕੁਦਰਤੀ ਆਫ਼ਤਾਂ ਕਾਰਨ ਫਸਲੀ ਨੁਕਸਾਨ ਲਈ ਸਭ ਤੋਂ ਘੱਟ ਪ੍ਰੀਮੀਅਮ ਤੇ ਬੀਮਾ',
      ta: 'இயற்கை சீற்றங்களால் பயிர் சேதமடைந்தால் குறைந்த பிரீமியத்தில் முழு பயிர் காப்பீடு'
    },
    purpose: 'Offers end-to-end insurance protection for farmers across all non-preventable natural risks (drought, flood, unseasonal rainfall, hailstorm, localized landslide, pest attack) from pre-sowing to post-harvest.',
    intendedBeneficiaries: [
      'All farmers cultivating notified crops in notified areas (both loanee and non-loanee, tenant farmers, and sharecroppers)'
    ],
    availableBenefits: {
      financialAmount: 'Full insured sum for crop loss with only 1.5% to 2% farmer premium',
      description: 'Farmers pay only 1.5% for Rabi crops, 2% for Kharif food grains and oilseeds, and 5% for commercial/horticultural crops. The entire remaining premium subsidy is funded by Central and State Governments.',
      frequency: 'Per Cropping Season'
    },
    keyHighlights: [
      'Crop loss assessment using satellite imagery, drones, and smartphone CCE experiments',
      'Immediate 25% on-account claim payout in mid-season adversity',
      'Post-harvest loss covered up to 14 days for cyclone/unseasonal rains',
      'Seamless claim settlement credited directly to farmer bank account'
    ],
    eligibilityCriteria: {
      allowedOccupations: ['farmer', 'agricultural_labourer'],
      allowedLandholdings: ['marginal', 'small', 'medium_large'],
      customRuleCheck: (profile) => {
        if (profile.occupation !== 'farmer' && profile.occupation !== 'agricultural_labourer') {
          return {
            passed: false,
            status: 'warn',
            detail: 'Requires cultivating farmers (owner, tenant, or sharecropper) of notified crops.'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible cultivator with seasonal farming activity.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.landRecords,
      COMMON_DOCUMENTS.bankPassbook
    ],
    officialPortalUrl: 'https://pmfby.gov.in',
    applyOnlineUrl: 'https://pmfby.gov.in/farmerRegistrationForm',
    helplineNumber: '14447 (Kisan Call Centre)',
    grievancePortalUrl: 'https://pmfby.gov.in'
  },

  // 13. PM Bhartiya Janaushadhi Pariyojana
  {
    id: 'pm-janaushadhi',
    category: 'healthcare',
    name: 'Pradhan Mantri Bhartiya Janaushadhi Pariyojana (PMBJP)',
    nameTranslations: {
      hi: 'प्रधानमंत्री भारतीय जनऔषधि परियोजना (PMBJP)',
      bn: 'প্রধানমন্ত্রী ভারতীয় জনঔষধি পরিযোজনা',
      pa: 'ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਭਾਰਤੀ ਜਨਔਸ਼ਧੀ ਪ੍ਰੋਗਰਾਮ',
      ta: 'பிரதம மந்திரி பாரதிய மக்கள் மருந்தகம் (Janaushadhi)'
    },
    shortCode: 'PMBJP',
    ministry: 'Department of Pharmaceuticals, Ministry of Chemicals and Fertilizers',
    tagline: 'High quality generic medicines & surgical supplies at 50% to 90% lower prices for all citizens',
    taglineTranslations: {
      hi: 'सभी नागरिकों के लिए 50% से 90% तक कम कीमत पर उच्च गुणवत्ता वाली जेनेरिक दवाएं',
      bn: '৫০% থেকে ৯০% কম মূল্যে উন্নত মানের জেনেরিক ওষুধ',
      pa: '50% ਤੋਂ 90% ਤੱਕ ਘੱਟ ਕੀਮਤ ਤੇ ਮਿਆਰੀ ਦਵਾਈਆਂ',
      ta: 'அனைத்து குடிமக்களுக்கும் 50% முதல் 90% வரை குறைந்த விலையில் தரமான மருந்துகள்'
    },
    purpose: 'Makes quality unbranded generic medicines, healthcare devices, and surgical items accessible to all citizens at a fraction of the cost of branded alternatives through 10,000+ Janaushadhi Kendras.',
    intendedBeneficiaries: [
      'All Indian citizens, with special economic relief for chronic disease patients, senior citizens, and low-income families'
    ],
    availableBenefits: {
      financialAmount: '50% to 90% direct savings on prescription medicines',
      description: 'Over 2,000 medicines and 300 surgical instruments covering diabetes, hypertension, cardiology, oncology, gastrointestinal, antibiotics, and vitamins at rock-bottom statutory rates. Oxo-biodegradable sanitary pads at ₹1 each.',
      frequency: 'Direct Over-the-Counter Subsidized Purchase'
    },
    keyHighlights: [
      'Universal eligibility: No income certificate, BPL card, or registration required',
      'Tested in NABL accredited laboratories ensuring WHO-GMP quality benchmarks',
      'Jan Aushadhi Sugam mobile app to find nearest store and compare prices',
      'Suvidha sanitary napkins at only ₹1 per pad'
    ],
    eligibilityCriteria: {
      customRuleCheck: () => ({
        passed: true,
        status: 'pass',
        detail: 'Universal public healthcare initiative open to 100% of citizens across India.'
      })
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.aadhaar
    ],
    officialPortalUrl: 'https://janaushadhi.gov.in',
    applyOnlineUrl: 'https://janaushadhi.gov.in/KendraSearch.aspx',
    helplineNumber: '1800-180-8080 (Toll-Free)',
    grievancePortalUrl: 'https://janaushadhi.gov.in'
  },

  // 14. IGNDPS - National Disability Pension
  {
    id: 'igndps-disability',
    category: 'social_welfare',
    name: 'National Disability Pension Scheme (IGNDPS - NSAP)',
    nameTranslations: {
      hi: 'इंदिरा गांधी राष्ट्रीय दिव्यांगता पेंशन योजना (IGNDPS)',
      bn: 'ইন্দিরা গান্ধী জাতীয় প্রতিবন্ধী পেনশন প্রকল্প',
      pa: 'ਇੰਦਰਾ ਗਾਂਧੀ ਕੌਮੀ ਦਿਵਿਆਂਗ ਪੈਨਸ਼ਨ ਯੋਜਨਾ',
      ta: 'தேசிய மாற்றுத்திறனாளிகள் ஓய்வூதியத் திட்டம்'
    },
    shortCode: 'IGNDPS',
    ministry: 'Ministry of Rural Development, Govt. of India',
    tagline: 'Dignified monthly social assistance pension for individuals with severe disabilities',
    taglineTranslations: {
      hi: 'गंभीर दिव्यांगता वाले गरीब नागरिकों के लिए गरिमापूर्ण मासिक सामाजिक पेंशन',
      bn: 'গুরুতর প্রতিবন্ধী দরিদ্র নাগরিকদের জন্য মাসিক পেনশন',
      pa: 'ਗੰਭੀਰ ਦਿਵਿਆਂਗ ਗਰੀਬ ਨਾਗਰਿਕਾਂ ਲਈ ਮਹੀਨਾਵਾਰ ਪੈਨਸ਼ਨ',
      ta: 'தீவிர மாற்றுத்திறனாளிகளுக்கான மாதாந்திர சமூக பாதுகாப்பு ஓய்வூதியம்'
    },
    purpose: 'Provides direct monthly financial security and livelihood support to severely disabled persons aged 18 to 79 years living in households Below the Poverty Line.',
    intendedBeneficiaries: [
      'Persons aged 18 to 79 years with severe or multiple disabilities (80% or greater disability) or dwarfism',
      'Living below poverty line according to criteria prescribed by Govt. of India'
    ],
    availableBenefits: {
      financialAmount: '₹500 to ₹3,000 per month (combined Centre + State)',
      description: 'Monthly direct financial grant credited to the beneficiary’s bank account or postal savings account.',
      frequency: 'Monthly Social Grant'
    },
    keyHighlights: [
      'Lifelong monthly pension; automatically converts to Old Age Pension upon reaching age 80',
      'UDID portal enables fast-track online verification',
      'Can be clubbed with state assistive device schemes (wheelchairs, hearing aids)'
    ],
    eligibilityCriteria: {
      requiresDisability: true,
      minAge: 18,
      allowedRationCards: ['antyodaya', 'bpl', 'priority_phh'],
      customRuleCheck: (profile) => {
        if (!profile.hasDisability) {
          return {
            passed: false,
            status: 'fail',
            detail: 'Requires verified benchmark disability (UDID card / medical board certification).'
          };
        }
        return {
          passed: true,
          status: 'pass',
          detail: 'Eligible person with disability under NSAP guidelines.'
        };
      }
    },
    requiredDocuments: [
      COMMON_DOCUMENTS.disabilityCert,
      COMMON_DOCUMENTS.aadhaar,
      COMMON_DOCUMENTS.bankPassbook,
      COMMON_DOCUMENTS.rationCard
    ],
    officialPortalUrl: 'https://nsap.nic.in',
    applyOnlineUrl: 'https://nsap.nic.in/nsap/app/onlineApply',
    helplineNumber: '1800-111-555',
    grievancePortalUrl: 'https://nsap.nic.in'
  }
];
