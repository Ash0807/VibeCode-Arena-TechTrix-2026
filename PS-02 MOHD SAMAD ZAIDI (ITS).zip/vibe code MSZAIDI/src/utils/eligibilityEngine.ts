/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  CitizenProfile,
  EligibilityResult,
  EligibilityStatus,
  IncomeRange,
  RuleEvaluation,
  Scheme
} from '../types/scheme';

const INCOME_WEIGHTS: Record<IncomeRange, number> = {
  below_1_lakh: 1,
  '1_to_2_5_lakh': 2,
  '2_5_to_5_lakh': 3,
  '5_to_8_lakh': 4,
  above_8_lakh: 5
};

/**
 * Pure evaluation function matching a CitizenProfile against a Scheme.
 * Returns transparent status, match score, and detailed rule breakdown.
 */
export function evaluateEligibility(profile: CitizenProfile, scheme: Scheme): EligibilityResult {
  const rules: RuleEvaluation[] = [];
  const unmetKeyReasons: string[] = [];
  const missingInfoPrompts: string[] = [];

  const { eligibilityCriteria } = scheme;

  // 1. Area Type Rule (Rural vs Urban)
  if (eligibilityCriteria.allowedAreaTypes && eligibilityCriteria.allowedAreaTypes.length > 0) {
    const isAreaMatch =
      eligibilityCriteria.allowedAreaTypes.includes('any') ||
      eligibilityCriteria.allowedAreaTypes.includes(profile.areaType);

    if (isAreaMatch) {
      rules.push({
        ruleId: 'area_type',
        name: 'Location Requirement',
        description: `Applicable in ${eligibilityCriteria.allowedAreaTypes.join(' / ')} areas`,
        status: 'pass',
        detail: `Location matches: You are in a ${profile.areaType} region.`
      });
    } else {
      const reason = `Scheme is designed specifically for ${eligibilityCriteria.allowedAreaTypes.join(' / ')} areas, but profile is ${profile.areaType}.`;
      rules.push({
        ruleId: 'area_type',
        name: 'Location Requirement',
        description: `Requires ${eligibilityCriteria.allowedAreaTypes.join(' / ')} residency`,
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 2. Age Criteria
  if (eligibilityCriteria.minAge !== undefined || eligibilityCriteria.maxAge !== undefined) {
    const min = eligibilityCriteria.minAge ?? 0;
    const max = eligibilityCriteria.maxAge ?? 120;
    const isAgeMatch = profile.age >= min && profile.age <= max;

    if (isAgeMatch) {
      rules.push({
        ruleId: 'age_criteria',
        name: 'Age Criteria',
        description: `Age must be between ${min} and ${max} years`,
        status: 'pass',
        detail: `Age check passed: You are ${profile.age} years old.`
      });
    } else {
      const reason = `Age requirement not satisfied. Must be ${min} to ${max} years old (profile is ${profile.age}).`;
      rules.push({
        ruleId: 'age_criteria',
        name: 'Age Criteria',
        description: `Age requirement (${min}-${max} years)`,
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 3. Occupation Rule
  if (eligibilityCriteria.allowedOccupations && eligibilityCriteria.allowedOccupations.length > 0) {
    const isOccupationMatch = eligibilityCriteria.allowedOccupations.includes(profile.occupation);

    if (isOccupationMatch) {
      rules.push({
        ruleId: 'occupation',
        name: 'Occupation Match',
        description: `Open to designated occupations`,
        status: 'pass',
        detail: `Your occupation (${profile.occupation.replace(/_/g, ' ')}) is explicitly included.`
      });
    } else {
      // Check if it's an absolute block or conditional
      const reason = `Targeted for ${eligibilityCriteria.allowedOccupations.map((o) => o.replace(/_/g, ' ')).join(', ')}.`;
      rules.push({
        ruleId: 'occupation',
        name: 'Occupation Match',
        description: `Targeted beneficiary occupations`,
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 4. Income Ceiling Rule
  if (eligibilityCriteria.maxIncomeRange) {
    const maxWeight = INCOME_WEIGHTS[eligibilityCriteria.maxIncomeRange];
    const userWeight = INCOME_WEIGHTS[profile.incomeRange];

    if (userWeight <= maxWeight) {
      rules.push({
        ruleId: 'income_ceiling',
        name: 'Income Ceiling',
        description: `Household income up to ${eligibilityCriteria.maxIncomeRange.replace(/_/g, ' ')}`,
        status: 'pass',
        detail: `Income requirement met: Your bracket is within the eligible ceiling.`
      });
    } else {
      const reason = `Income ceiling exceeded. Maximum eligible category is ${eligibilityCriteria.maxIncomeRange.replace(/_/g, ' ')}.`;
      rules.push({
        ruleId: 'income_ceiling',
        name: 'Income Ceiling',
        description: `Income eligibility limit`,
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 5. Housing Status Rule (Crucial for PMAY-G & PMAY-U)
  if (eligibilityCriteria.allowedHousingStatuses && eligibilityCriteria.allowedHousingStatuses.length > 0) {
    const isHousingMatch = eligibilityCriteria.allowedHousingStatuses.includes(profile.housingStatus);

    if (isHousingMatch) {
      rules.push({
        ruleId: 'housing_status',
        name: 'Housing Status Requirement',
        description: 'Requires homeless or non-pucca housing condition',
        status: 'pass',
        detail: `Housing condition qualified: You currently reside in ${profile.housingStatus.replace(/_/g, ' ')} accommodation.`
      });
    } else {
      const reason = profile.housingStatus === 'own_pucca'
        ? 'Beneficiary already owns a pucca house. Assistance is strictly reserved for homeless or kutcha/temporary households.'
        : `Housing status (${profile.housingStatus}) does not meet the specified criteria.`;
      rules.push({
        ruleId: 'housing_status',
        name: 'Housing Status Requirement',
        description: 'Housing need criterion',
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 6. Landholding Rule (e.g. PM-KISAN, PMFBY)
  if (eligibilityCriteria.allowedLandholdings && eligibilityCriteria.allowedLandholdings.length > 0) {
    const isLandMatch = eligibilityCriteria.allowedLandholdings.includes(profile.landholding);

    if (isLandMatch) {
      rules.push({
        ruleId: 'landholding',
        name: 'Agricultural Land Requirement',
        description: 'Cultivable agricultural landholding in revenue record',
        status: 'pass',
        detail: `Landholding verified: ${profile.landholding} land recorded.`
      });
    } else {
      const reason = profile.landholding === 'landless'
        ? 'Requires ownership of cultivable agricultural land (Khatauni/Khasra record).'
        : `Landholding size (${profile.landholding}) is not eligible for this targeted scheme.`;
      rules.push({
        ruleId: 'landholding',
        name: 'Agricultural Land Requirement',
        description: 'Agricultural land eligibility',
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 7. Social Category Rule (e.g. Post Matric Scholarship)
  if (eligibilityCriteria.allowedSocialCategories && eligibilityCriteria.allowedSocialCategories.length > 0) {
    const isCategoryMatch = eligibilityCriteria.allowedSocialCategories.includes(profile.socialCategory);

    if (isCategoryMatch) {
      rules.push({
        ruleId: 'social_category',
        name: 'Social Category / Reservation',
        description: `Applicable to ${eligibilityCriteria.allowedSocialCategories.join(', ').toUpperCase()}`,
        status: 'pass',
        detail: `Social category (${profile.socialCategory.toUpperCase()}) satisfies the criteria.`
      });
    } else {
      const reason = `Reserved for ${eligibilityCriteria.allowedSocialCategories.join(', ').toUpperCase()} categories.`;
      rules.push({
        ruleId: 'social_category',
        name: 'Social Category / Reservation',
        description: 'Affirmative action criteria',
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 8. Disability Requirement
  if (eligibilityCriteria.requiresDisability) {
    if (profile.hasDisability) {
      rules.push({
        ruleId: 'disability_req',
        name: 'Disability Assistance Requirement',
        description: 'Benchmark disability certification required',
        status: 'pass',
        detail: 'Applicant has indicated benchmark disability.'
      });
    } else {
      const reason = 'Scheme is dedicated exclusively for persons with certified benchmark disabilities (UDID).';
      rules.push({
        ruleId: 'disability_req',
        name: 'Disability Assistance Requirement',
        description: 'Targeted disability support',
        status: 'fail',
        detail: reason
      });
      unmetKeyReasons.push(reason);
    }
  }

  // 9. Girl Child Requirement
  if (eligibilityCriteria.requiresGirlChild) {
    if (profile.hasGirlChildUnder10) {
      rules.push({
        ruleId: 'girl_child',
        name: 'Girl Child Welfare Criterion',
        description: 'Family with girl child under 10 years of age',
        status: 'pass',
        detail: 'Family has a daughter under 10 years of age.'
      });
    } else {
      const reason = 'Scheme requires having a daughter aged 10 years or younger in the family.';
      rules.push({
        ruleId: 'girl_child',
        name: 'Girl Child Welfare Criterion',
        description: 'Girl child requirement',
        status: 'warn',
        detail: reason
      });
      missingInfoPrompts.push('If you have a daughter aged 10 or younger, you can open an SSY account in her name.');
    }
  }

  // 10. Custom Rule Check
  if (eligibilityCriteria.customRuleCheck) {
    const customResult = eligibilityCriteria.customRuleCheck(profile);
    rules.push({
      ruleId: 'custom_check',
      name: 'Programme Specific Verification',
      description: 'Specific departmental guidelines check',
      status: customResult.status,
      detail: customResult.detail
    });

    if (customResult.status === 'fail') {
      unmetKeyReasons.push(customResult.detail);
    } else if (customResult.status === 'warn') {
      missingInfoPrompts.push(customResult.detail);
    }
  }

  // Determine Overall Status & Match Score
  const passCount = rules.filter((r) => r.status === 'pass').length;
  const failCount = rules.filter((r) => r.status === 'fail').length;
  const warnCount = rules.filter((r) => r.status === 'warn').length;
  const totalRules = rules.length > 0 ? rules.length : 1;

  let status: EligibilityStatus;
  let matchScore: number;

  if (failCount === 0 && warnCount === 0) {
    status = 'ELIGIBLE';
    matchScore = 100;
  } else if (failCount === 0 && warnCount > 0) {
    status = 'MORE_INFO_NEEDED';
    matchScore = Math.max(65, Math.round((passCount / totalRules) * 100));
  } else if (failCount === 1 && warnCount <= 1 && passCount >= 2) {
    // If only one minor rule failed or requires clarification
    status = 'MORE_INFO_NEEDED';
    matchScore = Math.max(45, Math.round((passCount / totalRules) * 100));
  } else {
    status = 'NOT_ELIGIBLE';
    matchScore = Math.min(40, Math.round((passCount / totalRules) * 100));
  }

  // Construct summary explanation
  let summaryExplanation = '';
  if (status === 'ELIGIBLE') {
    summaryExplanation = `Based on your profile, you satisfy all preliminary eligibility criteria for ${scheme.shortCode}.`;
  } else if (status === 'MORE_INFO_NEEDED') {
    summaryExplanation = `You may be conditionally eligible for ${scheme.shortCode}, but additional documentary verification or sub-criteria check is required.`;
  } else {
    summaryExplanation = `You do not currently satisfy key mandatory eligibility criteria for ${scheme.shortCode} (${unmetKeyReasons[0] || 'Criteria not met'}).`;
  }

  return {
    schemeId: scheme.id,
    status,
    matchScore,
    ruleBreakdown: rules,
    summaryExplanation,
    unmetKeyReasons,
    missingInfoPrompts
  };
}
