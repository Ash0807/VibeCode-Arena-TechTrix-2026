/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateEligibility } from './eligibilityEngine';
import { SCHEMES_DATABASE } from '../data/schemesData';
import { CitizenProfile } from '../types/scheme';

const getScheme = (id: string) => {
  const scheme = SCHEMES_DATABASE.find((s) => s.id === id);
  if (!scheme) throw new Error(`Scheme ${id} not found`);
  return scheme;
};

test('Rural Kutcha Farmer is eligible for PMAY-G and PM-KISAN', () => {
  const ruralFarmerProfile: CitizenProfile = {
    state: 'Uttar Pradesh',
    areaType: 'rural',
    age: 38,
    gender: 'male',
    socialCategory: 'obc',
    occupation: 'farmer',
    incomeRange: 'below_1_lakh',
    housingStatus: 'kutcha',
    landholding: 'marginal',
    hasDisability: false,
    rationCard: 'bpl',
    familyMembersCount: 5,
    hasGirlChildUnder10: true,
    isStudent: false
  };

  const pmayg = getScheme('pmay-g');
  const resultPmayG = evaluateEligibility(ruralFarmerProfile, pmayg);
  assert.equal(resultPmayG.status, 'ELIGIBLE');
  assert.equal(resultPmayG.matchScore, 100);

  const pmkisan = getScheme('pm-kisan');
  const resultPmKisan = evaluateEligibility(ruralFarmerProfile, pmkisan);
  assert.equal(resultPmKisan.status, 'ELIGIBLE');
});

test('Urban citizen owning a pucca house is NOT eligible for PMAY-G', () => {
  const urbanPuccaProfile: CitizenProfile = {
    state: 'Maharashtra',
    areaType: 'urban',
    age: 45,
    gender: 'female',
    socialCategory: 'general',
    occupation: 'salaried_worker',
    incomeRange: 'above_8_lakh',
    housingStatus: 'own_pucca',
    landholding: 'landless',
    hasDisability: false,
    rationCard: 'apl_none',
    familyMembersCount: 4,
    hasGirlChildUnder10: false,
    isStudent: false
  };

  const pmayg = getScheme('pmay-g');
  const result = evaluateEligibility(urbanPuccaProfile, pmayg);
  assert.equal(result.status, 'NOT_ELIGIBLE');
  assert.ok(result.unmetKeyReasons.length > 0);
  // Should report rural requirement and pucca house ownership
  assert.ok(result.ruleBreakdown.some((r) => r.ruleId === 'area_type' && r.status === 'fail'));
  assert.ok(result.ruleBreakdown.some((r) => r.ruleId === 'housing_status' && r.status === 'fail'));
});

test('Urban street vendor is eligible for PM SVANidhi', () => {
  const vendorProfile: CitizenProfile = {
    state: 'Delhi (NCT)',
    areaType: 'urban',
    age: 32,
    gender: 'male',
    socialCategory: 'general',
    occupation: 'street_vendor',
    incomeRange: '1_to_2_5_lakh',
    housingStatus: 'rented',
    landholding: 'landless',
    hasDisability: false,
    rationCard: 'priority_phh',
    familyMembersCount: 3,
    hasGirlChildUnder10: false,
    isStudent: false
  };

  const svanidhi = getScheme('pm-svanidhi');
  const result = evaluateEligibility(vendorProfile, svanidhi);
  assert.equal(result.status, 'ELIGIBLE');
});

test('Age restriction for Atal Pension Yojana (18-40 years)', () => {
  const elderlyProfile: CitizenProfile = {
    state: 'Punjab',
    areaType: 'rural',
    age: 52,
    gender: 'male',
    socialCategory: 'general',
    occupation: 'daily_wage_worker',
    incomeRange: '1_to_2_5_lakh',
    housingStatus: 'semi_pucca',
    landholding: 'landless',
    hasDisability: false,
    rationCard: 'bpl',
    familyMembersCount: 2,
    hasGirlChildUnder10: false,
    isStudent: false
  };

  const apy = getScheme('atal-pension-yojana');
  const resultApy = evaluateEligibility(elderlyProfile, apy);
  // Age is 52 > 40 maxAge, so should not be eligible for APY
  assert.equal(resultApy.status, 'NOT_ELIGIBLE');
  assert.ok(resultApy.ruleBreakdown.some((r) => r.ruleId === 'age_criteria' && r.status === 'fail'));
});

test('Universal eligibility for Janaushadhi (PMBJP)', () => {
  const anyProfile: CitizenProfile = {
    state: 'Tamil Nadu',
    areaType: 'urban',
    age: 28,
    gender: 'female',
    socialCategory: 'general',
    occupation: 'student',
    incomeRange: 'above_8_lakh',
    housingStatus: 'own_pucca',
    landholding: 'landless',
    hasDisability: false,
    rationCard: 'apl_none',
    familyMembersCount: 2,
    hasGirlChildUnder10: false,
    isStudent: true
  };

  const janaushadhi = getScheme('pm-janaushadhi');
  const result = evaluateEligibility(anyProfile, janaushadhi);
  assert.equal(result.status, 'ELIGIBLE');
});
