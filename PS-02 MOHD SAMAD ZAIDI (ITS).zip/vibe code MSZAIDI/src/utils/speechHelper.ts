/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LanguageCode } from '../types/scheme';

export const LANGUAGE_BCP47: Record<LanguageCode, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  pa: 'pa-IN',
  bn: 'bn-IN',
  ta: 'ta-IN'
};

export const LANGUAGE_LABELS: Record<LanguageCode, { label: string; nativeName: string }> = {
  en: { label: 'English', nativeName: 'English' },
  hi: { label: 'Hindi', nativeName: 'हिन्दी' },
  bn: { label: 'Bengali', nativeName: 'বাংলা' },
  pa: { label: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  ta: { label: 'Tamil', nativeName: 'தமிழ்' }
};

/**
 * Text-to-Speech using browser SpeechSynthesis with multilingual voice selection
 */
export function speakText(text: string, lang: LanguageCode = 'en', onEnd?: () => void): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return false;
  }

  window.speechSynthesis.cancel();

  // Strip excessive markdown / brackets before speaking
  const cleanText = text
    .replace(/[#*`_~]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleanText) return false;

  const utterance = new SpeechSynthesisUtterance(cleanText);
  const targetLang = LANGUAGE_BCP47[lang] || 'en-IN';
  utterance.lang = targetLang;
  utterance.rate = 0.95; // Slightly slower for clarity
  utterance.pitch = 1.0;

  // Attempt to select best matching voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(
    (v) =>
      v.lang.toLowerCase() === targetLang.toLowerCase() ||
      v.lang.toLowerCase().startsWith(targetLang.split('-')[0].toLowerCase())
  );
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  if (onEnd) {
    utterance.onend = () => onEnd();
    utterance.onerror = () => onEnd();
  }

  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Auto-detect language from script or text keywords
 */
export function detectLanguageFromText(text: string): LanguageCode {
  // Devanagari script (Hindi)
  if (/[\u0900-\u097F]/.test(text)) return 'hi';
  // Bengali script
  if (/[\u0980-\u09FF]/.test(text)) return 'bn';
  // Gurmukhi script (Punjabi)
  if (/[\u0A00-\u0A7F]/.test(text)) return 'pa';
  // Tamil script
  if (/[\u0B80-\u0BFF]/.test(text)) return 'ta';

  // Romanized keywords detection
  const lower = text.toLowerCase();
  if (/\b(ghar|makan|kisan|yojana|krishi|pension|shiksha|mahila)\b/.test(lower)) return 'hi';
  if (/\b(bari|krishi|prokolpo|sikkha|shasto)\b/.test(lower)) return 'bn';
  if (/\b(khet|ghar|kisan|shehar|pind)\b/.test(lower)) return 'pa';
  if (/\b(veedu|thittam|panam|aarokkiyam|kalvi)\b/.test(lower)) return 'ta';

  return 'en';
}

/**
 * Speech Recognition Wrapper
 */
export interface VoiceRecognitionOptions {
  lang: LanguageCode | 'auto';
  onResult: (transcript: string, detectedLang: LanguageCode) => void;
  onError: (error: string) => void;
  onStart?: () => void;
  onEnd?: () => void;
}

export function startSpeechRecognition(options: VoiceRecognitionOptions): { stop: () => void } | null {
  if (typeof window === 'undefined') return null;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    options.onError('Speech recognition is not supported in this browser. Please type your query.');
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;

  const targetLang = options.lang === 'auto' ? 'en-IN' : LANGUAGE_BCP47[options.lang];
  recognition.lang = targetLang;

  recognition.onstart = () => {
    if (options.onStart) options.onStart();
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  recognition.onresult = (event: any) => {
    const transcript = event.results[0][0].transcript;
    const detected = options.lang === 'auto' ? detectLanguageFromText(transcript) : options.lang;
    options.onResult(transcript, detected);
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  recognition.onerror = (event: any) => {
    options.onError(event.error || 'Speech input error');
  };

  recognition.onend = () => {
    if (options.onEnd) options.onEnd();
  };

  try {
    recognition.start();
  } catch (err) {
    options.onError(String(err));
    return null;
  }

  return {
    stop: () => {
      try {
        recognition.stop();
      } catch {
        // ignore
      }
    }
  };
}
