/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Printer,
  CheckSquare,
  Square,
  ExternalLink,
  Building,
  HelpCircle,
  FileText
} from 'lucide-react';
import { Scheme, SchemeDocument } from '../types/scheme';
import { Translations } from '../data/translations';

interface DocumentChecklistModalProps {
  schemes: Scheme[];
  onClose: () => void;
  t: Translations;
  onReadOutLoud: (text: string) => void;
}

export const DocumentChecklistModal: React.FC<DocumentChecklistModalProps> = ({
  schemes,
  onClose,
  t,
  onReadOutLoud
}) => {
  // Aggregate and deduplicate documents from provided schemes
  const docMap = new Map<string, { doc: SchemeDocument; requiredBySchemes: string[] }>();

  schemes.forEach((s) => {
    s.requiredDocuments.forEach((d) => {
      if (!docMap.has(d.id)) {
        docMap.set(d.id, { doc: d, requiredBySchemes: [s.shortCode] });
      } else {
        const existing = docMap.get(d.id)!;
        if (!existing.requiredBySchemes.includes(s.shortCode)) {
          existing.requiredBySchemes.push(s.shortCode);
        }
      }
    });
  });

  const allAggregatedDocs = Array.from(docMap.values());

  // Local state for tracking which documents user already possesses
  const [possessedDocIds, setPossessedDocIds] = useState<Record<string, boolean>>({});

  const toggleDocPossession = (id: string) => {
    setPossessedDocIds((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const possessedCount = allAggregatedDocs.filter((item) => possessedDocIds[item.doc.id]).length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-checklist-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="relative w-full max-w-3xl bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl my-8 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-stone-50 dark:bg-stone-800/80 px-5 py-4 border-b border-stone-200 dark:border-stone-800 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 id="modal-checklist-title" className="text-lg sm:text-xl font-extrabold text-stone-900 dark:text-stone-100">
                {t.checklist.title}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400 mt-0.5">
                {t.checklist.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 text-xs font-semibold transition-colors"
              title="Print document checklist"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">{t.checklist.printButton}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
              aria-label={t.checklist.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress status */}
        <div className="px-5 py-2.5 bg-emerald-50 dark:bg-emerald-950/30 border-b border-emerald-100 dark:border-emerald-900/60 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200 font-semibold">
          <span>
            Document Readiness: {possessedCount} of {allAggregatedDocs.length} documents ready
          </span>
          <div className="w-32 bg-emerald-200 dark:bg-emerald-900 rounded-full h-2 overflow-hidden">
            <div
              className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
              style={{
                width: `${allAggregatedDocs.length > 0 ? (possessedCount / allAggregatedDocs.length) * 100 : 0}%`
              }}
            />
          </div>
        </div>

        {/* List of documents */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {allAggregatedDocs.length === 0 ? (
            <div className="text-center py-8 text-stone-500 dark:text-stone-400">
              <p className="text-sm font-medium">{t.checklist.emptyPrompt}</p>
            </div>
          ) : (
            allAggregatedDocs.map(({ doc, requiredBySchemes }) => {
              const isChecked = !!possessedDocIds[doc.id];

              return (
                <div
                  key={doc.id}
                  className={`p-4 rounded-xl border transition-all ${
                    isChecked
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                      : 'bg-stone-50 dark:bg-stone-800/50 border-stone-200 dark:border-stone-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => toggleDocPossession(doc.id)}
                      className="flex items-start gap-3 text-left focus:outline-hidden"
                    >
                      <div className="mt-0.5 text-emerald-600 dark:text-emerald-400 shrink-0">
                        {isChecked ? (
                          <CheckSquare className="w-5 h-5" />
                        ) : (
                          <Square className="w-5 h-5 text-stone-400" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4
                            className={`text-sm font-bold ${
                              isChecked
                                ? 'text-emerald-950 dark:text-emerald-200 line-through'
                                : 'text-stone-900 dark:text-stone-100'
                            }`}
                          >
                            {doc.name}
                          </h4>
                          {doc.isMandatory && (
                            <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded-sm bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300">
                              Mandatory
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-600 dark:text-stone-400 mt-0.5">
                          {doc.description}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onReadOutLoud(`${doc.name}. ${doc.description}. Where to get: ${doc.howToGet}`)}
                      className="p-1 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
                      title="Read document info out loud"
                    >
                      🔊
                    </button>
                  </div>

                  {/* Required by schemes tags */}
                  <div className="mt-2.5 pt-2 border-t border-stone-200/60 dark:border-stone-700/60 flex items-center gap-1.5 flex-wrap text-xs">
                    <span className="text-stone-500 font-semibold text-[11px]">
                      Required for:
                    </span>
                    {requiredBySchemes.map((code) => (
                      <span
                        key={code}
                        className="px-2 py-0.5 rounded-md bg-stone-200 dark:bg-stone-700 text-stone-800 dark:text-stone-200 font-bold text-[11px]"
                      >
                        {code}
                      </span>
                    ))}
                  </div>

                  {/* How & where to obtain */}
                  <div className="mt-2 text-xs bg-white dark:bg-stone-800 p-2.5 rounded-lg border border-stone-200 dark:border-stone-700/70 space-y-1">
                    <p className="text-stone-700 dark:text-stone-300">
                      <strong className="text-stone-900 dark:text-stone-100 flex items-center gap-1">
                        <Building className="w-3 h-3 text-emerald-600" /> {t.checklist.issuingOffice}
                      </strong>{' '}
                      {doc.issuingAuthority}
                    </p>
                    <p className="text-stone-700 dark:text-stone-300">
                      <strong className="text-stone-900 dark:text-stone-100 flex items-center gap-1">
                        <HelpCircle className="w-3 h-3 text-amber-600" /> {t.checklist.howToGet}
                      </strong>{' '}
                      {doc.howToGet}
                    </p>
                    {doc.digitalPortalUrl && (
                      <div className="pt-1">
                        <a
                          href={doc.digitalPortalUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1 font-bold"
                        >
                          Official Online Portal <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="bg-stone-50 dark:bg-stone-800/80 px-5 py-3 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3">
          <span className="text-xs text-stone-500 dark:text-stone-400">
            Tip: Keep 3 physical photocopies & digital PDF copies on DigiLocker.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
          >
            {t.checklist.close}
          </button>
        </div>
      </div>
    </div>
  );
};
