/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  X,
  ExternalLink,
  PhoneCall,
  FileCheck2,
  AlertCircle,
  HelpCircle,
  Award,
  Landmark,
  Volume2
} from 'lucide-react';
import { LanguageCode, Scheme } from '../types/scheme';
import { Translations } from '../data/translations';

interface SchemeDetailsModalProps {
  scheme: Scheme | null;
  onClose: () => void;
  currentLanguage: LanguageCode;
  t: Translations;
  onReadOutLoud: (text: string) => void;
}

export const SchemeDetailsModal: React.FC<SchemeDetailsModalProps> = ({
  scheme,
  onClose,
  currentLanguage,
  t,
  onReadOutLoud
}) => {
  if (!scheme) return null;

  const displayName = scheme.nameTranslations?.[currentLanguage] || scheme.name;
  const displayTagline = scheme.taglineTranslations?.[currentLanguage] || scheme.tagline;

  const handleSpeech = () => {
    const text = `${displayName}. ${displayTagline}. Purpose: ${scheme.purpose}. Available Benefits: ${scheme.availableBenefits.financialAmount || ''}. ${scheme.availableBenefits.description}`;
    onReadOutLoud(text);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-scheme-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="relative w-full max-w-3xl bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl my-8 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-stone-50 dark:bg-stone-800/80 px-5 py-4 border-b border-stone-200 dark:border-stone-800 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  {scheme.category.replace('_', ' ')}
                </span>
                <span className="text-xs font-semibold text-stone-500 dark:text-stone-400">
                  Code: {scheme.shortCode}
                </span>
              </div>
              <h2 id="modal-scheme-title" className="text-lg sm:text-xl font-extrabold text-stone-900 dark:text-stone-100 mt-1">
                {displayName}
              </h2>
              <p className="text-xs text-stone-600 dark:text-stone-400 font-medium">
                {scheme.ministry}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleSpeech}
              className="p-2 rounded-lg text-stone-500 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
              title="Read scheme details out loud"
              aria-label="Read scheme details out loud"
            >
              <Volume2 className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
              aria-label={t.detailsModal.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm">
          {/* Tagline */}
          <div className="p-3.5 rounded-lg bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
            <p className="text-sm font-semibold text-stone-800 dark:text-stone-200">
              {displayTagline}
            </p>
          </div>

          {/* Purpose */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 mb-1.5 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              {t.detailsModal.purpose}
            </h3>
            <p className="text-stone-700 dark:text-stone-300 leading-relaxed text-sm">
              {scheme.purpose}
            </p>
          </div>

          {/* Available Benefits */}
          <div className="p-4 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 mb-1">
              {t.detailsModal.benefits}
            </h3>
            {scheme.availableBenefits.financialAmount && (
              <p className="text-base font-extrabold text-emerald-900 dark:text-emerald-200">
                {scheme.availableBenefits.financialAmount}
              </p>
            )}
            <p className="text-xs sm:text-sm text-emerald-900/90 dark:text-emerald-200/90 mt-1 leading-relaxed">
              {scheme.availableBenefits.description}
            </p>
          </div>

          {/* Intended Beneficiaries */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 mb-2 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              {t.detailsModal.beneficiaries}
            </h3>
            <ul className="space-y-1.5 list-disc list-inside text-stone-700 dark:text-stone-300">
              {scheme.intendedBeneficiaries.map((b, idx) => (
                <li key={idx} className="leading-relaxed">
                  {b}
                </li>
              ))}
            </ul>
          </div>

          {/* Key Programme Highlights */}
          {scheme.keyHighlights && scheme.keyHighlights.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 mb-2">
                Key Programme Highlights
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {scheme.keyHighlights.map((h, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/40 text-xs font-medium text-stone-700 dark:text-stone-300 flex items-start gap-2"
                  >
                    <span className="text-emerald-600 font-bold shrink-0">✦</span>
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Required Documents Checklist */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400 mb-2 flex items-center gap-1.5">
              <FileCheck2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              {t.detailsModal.documentsRequired}
            </h3>
            <div className="space-y-2">
              {scheme.requiredDocuments.map((doc) => (
                <div
                  key={doc.id}
                  className="p-3 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/40"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-stone-900 dark:text-stone-100">
                      {doc.name}
                    </span>
                    {doc.isMandatory && (
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-sm bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300">
                        Mandatory
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-600 dark:text-stone-400 mt-0.5">
                    {doc.description}
                  </p>
                  <div className="mt-1.5 pt-1.5 border-t border-stone-200/60 dark:border-stone-700/60 flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 flex-wrap gap-2">
                    <span>
                      <strong>Authority:</strong> {doc.issuingAuthority}
                    </span>
                    {doc.digitalPortalUrl && (
                      <a
                        href={doc.digitalPortalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                      >
                        Official Service Portal <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Helpline & Grievance Contact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-stone-200 dark:border-stone-800">
            {scheme.helplineNumber && (
              <div className="p-3 rounded-lg bg-stone-100 dark:bg-stone-800 flex items-center gap-3">
                <PhoneCall className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div>
                  <span className="text-xs text-stone-500 font-semibold uppercase">
                    {t.detailsModal.helpline}
                  </span>
                  <p className="text-sm font-bold text-stone-900 dark:text-stone-100">
                    {scheme.helplineNumber}
                  </p>
                </div>
              </div>
            )}
            {scheme.grievancePortalUrl && (
              <div className="p-3 rounded-lg bg-stone-100 dark:bg-stone-800 flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                <div>
                  <span className="text-xs text-stone-500 font-semibold uppercase">
                    {t.detailsModal.grievance}
                  </span>
                  <a
                    href={scheme.grievancePortalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs sm:text-sm font-bold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    Lodge Grievance Online <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-stone-50 dark:bg-stone-800/80 px-5 py-3 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-stone-300 dark:border-stone-700 text-xs font-semibold text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700"
          >
            {t.detailsModal.close}
          </button>
          <a
            href={scheme.applyOnlineUrl || scheme.officialPortalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs"
          >
            <span>{t.results.applyButton}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
