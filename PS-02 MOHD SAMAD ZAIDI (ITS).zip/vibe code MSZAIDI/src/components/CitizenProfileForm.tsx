/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Sparkles,
  MapPin,
  User,
  Briefcase,
  IndianRupee,
  Home,
  CheckCircle2,
  RotateCcw
} from 'lucide-react';
import {
  CitizenProfile,
  AreaType,
  Gender,
  SocialCategory,
  OccupationType,
  IncomeRange,
  HousingStatus,
  Landholding,
  RationCardType
} from '../types/scheme';
import { ALL_INDIAN_STATES } from '../data/schemesData';
import { Translations } from '../data/translations';

interface CitizenProfileFormProps {
  profile: CitizenProfile;
  onChange: (updated: CitizenProfile) => void;
  onSubmit: () => void;
  onReset: () => void;
  t: Translations;
  onReadOutLoud?: (text: string) => void;
}

export const CitizenProfileForm: React.FC<CitizenProfileFormProps> = ({
  profile,
  onChange,
  onSubmit,
  onReset,
  t,
  onReadOutLoud
}) => {
  // Preset 1: Rural Small Farmer
  const applyPresetRuralFarmer = () => {
    onChange({
      state: 'Uttar Pradesh',
      areaType: 'rural',
      age: 38,
      gender: 'male',
      socialCategory: 'obc',
      occupation: 'farmer',
      incomeRange: 'below_1_lakh',
      housingStatus: 'kutcha',
      landholding: 'marginal',
      hasDisability: false,
      rationCard: 'bpl',
      familyMembersCount: 5,
      hasGirlChildUnder10: true,
      isStudent: false
    });
  };

  // Preset 2: Urban Street Vendor
  const applyPresetUrbanVendor = () => {
    onChange({
      state: 'Delhi (NCT)',
      areaType: 'urban',
      age: 34,
      gender: 'female',
      socialCategory: 'general',
      occupation: 'street_vendor',
      incomeRange: '1_to_2_5_lakh',
      housingStatus: 'rented',
      landholding: 'landless',
      hasDisability: false,
      rationCard: 'priority_phh',
      familyMembersCount: 4,
      hasGirlChildUnder10: false,
      isStudent: false
    });
  };

  // Preset 3: College Student
  const applyPresetStudent = () => {
    onChange({
      state: 'Bihar',
      areaType: 'rural',
      age: 20,
      gender: 'male',
      socialCategory: 'sc',
      occupation: 'student',
      incomeRange: '1_to_2_5_lakh',
      housingStatus: 'semi_pucca',
      landholding: 'marginal',
      hasDisability: false,
      rationCard: 'bpl',
      familyMembersCount: 4,
      hasGirlChildUnder10: false,
      isStudent: true
    });
  };

  // Preset 4: Senior Citizen
  const applyPresetSenior = () => {
    onChange({
      state: 'Punjab',
      areaType: 'rural',
      age: 68,
      gender: 'female',
      socialCategory: 'general',
      occupation: 'senior_citizen',
      incomeRange: 'below_1_lakh',
      housingStatus: 'kutcha',
      landholding: 'landless',
      hasDisability: false,
      rationCard: 'antyodaya',
      familyMembersCount: 2,
      hasGirlChildUnder10: false,
      isStudent: false
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-4 sm:p-6 shadow-xs"
      aria-label={t.form.title}
    >
      {/* Title & Quick Presets */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-stone-900 dark:text-stone-100">
              {t.form.title}
            </h2>
            {onReadOutLoud && (
              <button
                type="button"
                onClick={() => onReadOutLoud(`${t.form.title}. ${t.form.subtitle}`)}
                className="text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 p-1"
                aria-label="Read form title out loud"
              >
                🔊
              </button>
            )}
          </div>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-0.5">
            {t.form.subtitle}
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-semibold text-stone-500 dark:text-stone-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            {t.form.quickPresets}
          </span>
          <button
            type="button"
            onClick={applyPresetRuralFarmer}
            className="text-xs px-2.5 py-1 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-md font-medium transition-colors"
          >
            {t.form.presetRuralFarmer}
          </button>
          <button
            type="button"
            onClick={applyPresetUrbanVendor}
            className="text-xs px-2.5 py-1 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-md font-medium transition-colors"
          >
            {t.form.presetUrbanVendor}
          </button>
          <button
            type="button"
            onClick={applyPresetStudent}
            className="text-xs px-2.5 py-1 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-md font-medium transition-colors"
          >
            {t.form.presetStudent}
          </button>
          <button
            type="button"
            onClick={applyPresetSenior}
            className="text-xs px-2.5 py-1 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-md font-medium transition-colors"
          >
            {t.form.presetSenior}
          </button>
        </div>
      </div>

      {/* Inputs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 mt-5">
        {/* 1. State / UT */}
        <div>
          <label htmlFor="field-state" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            {t.form.stateLabel} <span className="text-red-500">*</span>
          </label>
          <select
            id="field-state"
            value={profile.state}
            onChange={(e) => onChange({ ...profile, state: e.target.value })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
            required
          >
            {ALL_INDIAN_STATES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>

        {/* 2. Area Type (Rural vs Urban) */}
        <div>
          <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
            {t.form.areaLabel} <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onChange({ ...profile, areaType: 'rural' })}
              className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                profile.areaType === 'rural'
                  ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                  : 'bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-300 dark:border-stone-700 hover:bg-stone-100'
              }`}
              aria-pressed={profile.areaType === 'rural'}
            >
              🌳 {t.form.rural}
            </button>
            <button
              type="button"
              onClick={() => onChange({ ...profile, areaType: 'urban' })}
              className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                profile.areaType === 'urban'
                  ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                  : 'bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-300 dark:border-stone-700 hover:bg-stone-100'
              }`}
              aria-pressed={profile.areaType === 'urban'}
            >
              🏢 {t.form.urban}
            </button>
          </div>
        </div>

        {/* 3. Age & Gender */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label htmlFor="field-age" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              {t.form.ageLabel} <span className="text-red-500">*</span>
            </label>
            <input
              id="field-age"
              type="number"
              min={1}
              max={110}
              value={profile.age}
              onChange={(e) => onChange({ ...profile, age: Math.max(1, parseInt(e.target.value) || 18) })}
              className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
              required
            />
          </div>
          <div>
            <label htmlFor="field-gender" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
              {t.form.genderLabel}
            </label>
            <select
              id="field-gender"
              value={profile.gender}
              onChange={(e) => onChange({ ...profile, gender: e.target.value as Gender })}
              className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
            >
              <option value="male">Male (पुरुष)</option>
              <option value="female">Female (महिला)</option>
              <option value="transgender">Transgender (तृतीय लिंग)</option>
              <option value="all">Any / Other</option>
            </select>
          </div>
        </div>

        {/* 4. Social Category */}
        <div>
          <label htmlFor="field-category" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
            {t.form.categoryLabel}
          </label>
          <select
            id="field-category"
            value={profile.socialCategory}
            onChange={(e) => onChange({ ...profile, socialCategory: e.target.value as SocialCategory })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
          >
            <option value="general">General (सामान्य)</option>
            <option value="obc">OBC (अन्य पिछड़ा वर्ग)</option>
            <option value="sc">SC (अनुसूचित जाति)</option>
            <option value="st">ST (अनुसूचित जनजाति)</option>
            <option value="ews">EWS (आर्थिक रूप से कमजोर वर्ग)</option>
            <option value="minority">Minority Community (अल्पसंख्यक)</option>
          </select>
        </div>

        {/* 5. Occupation */}
        <div>
          <label htmlFor="field-occupation" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
            <Briefcase className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            {t.form.occupationLabel} <span className="text-red-500">*</span>
          </label>
          <select
            id="field-occupation"
            value={profile.occupation}
            onChange={(e) => {
              const val = e.target.value as OccupationType;
              onChange({
                ...profile,
                occupation: val,
                isStudent: val === 'student' ? true : profile.isStudent
              });
            }}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
            required
          >
            <option value="farmer">Farmer / Cultivator (किसान)</option>
            <option value="agricultural_labourer">Agricultural Labourer (खेतिहर मजदूर)</option>
            <option value="daily_wage_worker">Daily Wage / Construction Worker (दिहाड़ी मजदूर)</option>
            <option value="street_vendor">Street Vendor / Hawker (रेहड़ी-पटरी विक्रेता)</option>
            <option value="artisan_craftsperson">Artisan / Traditional Craftsperson (शिल्पकार/कारीगर)</option>
            <option value="small_business_owner">Small Shop / Micro Enterprise (छोटा व्यापारी)</option>
            <option value="student">Student / Youth (विद्यार्थी)</option>
            <option value="senior_citizen">Senior Citizen / Retired (वरिष्ठ नागरिक)</option>
            <option value="homemaker">Homemaker (गृहणी)</option>
            <option value="unemployed">Unemployed / Job Seeker (बेरोजगार)</option>
            <option value="salaried_worker">Salaried Employee / Private Service (वेतनभोगी)</option>
            <option value="other">Other Informal Worker (अन्य)</option>
          </select>
        </div>

        {/* 6. Approximate Annual Family Income */}
        <div>
          <label htmlFor="field-income" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
            <IndianRupee className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            {t.form.incomeLabel} <span className="text-red-500">*</span>
          </label>
          <select
            id="field-income"
            value={profile.incomeRange}
            onChange={(e) => onChange({ ...profile, incomeRange: e.target.value as IncomeRange })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
            required
          >
            <option value="below_1_lakh">Below ₹1,00,000 (BPL / Antyodaya bracket)</option>
            <option value="1_to_2_5_lakh">₹1,00,000 - ₹2,50,000 (Low income)</option>
            <option value="2_5_to_5_lakh">₹2,50,000 - ₹5,00,000 (Lower middle income)</option>
            <option value="5_to_8_lakh">₹5,00,000 - ₹8,00,000 (EWS ceiling / Middle income)</option>
            <option value="above_8_lakh">Above ₹8,00,000 (Higher income bracket)</option>
          </select>
        </div>

        {/* 7. Housing Status (Essential for PMAY) */}
        <div>
          <label htmlFor="field-housing" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
            <Home className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            {t.form.housingLabel} <span className="text-red-500">*</span>
          </label>
          <select
            id="field-housing"
            value={profile.housingStatus}
            onChange={(e) => onChange({ ...profile, housingStatus: e.target.value as HousingStatus })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
            required
          >
            <option value="homeless">Homeless / Destitute (बेघर)</option>
            <option value="kutcha">Kutcha House (कच्चा मकान / मिट्टी, घास-फूस या टिन)</option>
            <option value="semi_pucca">Semi-Pucca House (अर्ध-पक्का मकान)</option>
            <option value="rented">Living in Rented Accommodation (किराए का मकान)</option>
            <option value="own_pucca">Already Own a Pucca House (स्वयं का पक्का मकान)</option>
          </select>
        </div>

        {/* 8. Agricultural Landholding */}
        <div>
          <label htmlFor="field-land" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
            {t.form.landLabel}
          </label>
          <select
            id="field-land"
            value={profile.landholding}
            onChange={(e) => onChange({ ...profile, landholding: e.target.value as Landholding })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
          >
            <option value="landless">Landless (भूमिहीन)</option>
            <option value="marginal">Marginal Land (&lt; 1 Hectare / &lt; 2.5 Acres)</option>
            <option value="small">Small Land (1 to 2 Hectares / 2.5 - 5 Acres)</option>
            <option value="medium_large">Medium / Large (&gt; 2 Hectares / &gt; 5 Acres)</option>
          </select>
        </div>

        {/* 9. Ration Card Status */}
        <div>
          <label htmlFor="field-ration" className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
            {t.form.rationCardLabel}
          </label>
          <select
            id="field-ration"
            value={profile.rationCard}
            onChange={(e) => onChange({ ...profile, rationCard: e.target.value as RationCardType })}
            className="w-full rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 px-3 py-2 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
          >
            <option value="antyodaya">Antyodaya Anna Yojana (AAY / Poorest of Poor Card)</option>
            <option value="bpl">BPL Card (Below Poverty Line)</option>
            <option value="priority_phh">Priority Household (PHH / NFSA Card)</option>
            <option value="apl_none">APL Card / No Ration Card</option>
          </select>
        </div>
      </div>

      {/* Special Family Details Checkboxes */}
      <div className="mt-4 pt-4 border-t border-stone-200 dark:border-stone-800 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/50 cursor-pointer hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors">
          <input
            type="checkbox"
            checked={profile.hasDisability}
            onChange={(e) => onChange({ ...profile, hasDisability: e.target.checked })}
            className="w-4 h-4 text-emerald-600 rounded-sm focus:ring-emerald-500"
          />
          <span className="text-xs font-semibold text-stone-800 dark:text-stone-200">
            ♿ {t.form.disabilityLabel}
          </span>
        </label>

        <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/50 cursor-pointer hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors">
          <input
            type="checkbox"
            checked={profile.hasGirlChildUnder10}
            onChange={(e) => onChange({ ...profile, hasGirlChildUnder10: e.target.checked })}
            className="w-4 h-4 text-emerald-600 rounded-sm focus:ring-emerald-500"
          />
          <span className="text-xs font-semibold text-stone-800 dark:text-stone-200">
            👧 {t.form.girlChildLabel}
          </span>
        </label>

        <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/50 cursor-pointer hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors">
          <input
            type="checkbox"
            checked={profile.isStudent}
            onChange={(e) => onChange({ ...profile, isStudent: e.target.checked })}
            className="w-4 h-4 text-emerald-600 rounded-sm focus:ring-emerald-500"
          />
          <span className="text-xs font-semibold text-stone-800 dark:text-stone-200">
            📚 {t.form.studentLabel}
          </span>
        </label>
      </div>

      {/* Buttons */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onReset}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold text-sm hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          {t.form.resetButton}
        </button>

        <button
          type="submit"
          className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md transition-all focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
        >
          <CheckCircle2 className="w-4 h-4" />
          {t.form.findButton}
        </button>
      </div>
    </form>
  );
};
