/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, ShieldCheck } from 'lucide-react';
import { Translations } from '../data/translations';

interface DisclaimerBannerProps {
  t: Translations;
  onReadOutLoud?: (text: string) => void;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ t, onReadOutLoud }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div
      role="region"
      aria-label="Statutory Public Notice"
      className="bg-amber-50 dark:bg-amber-950/40 border-l-4 border-amber-600 dark:border-amber-500 rounded-r-lg p-3.5 mb-6 text-amber-950 dark:text-amber-100 shadow-xs"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <AlertTriangle className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm tracking-wide uppercase text-amber-900 dark:text-amber-200">
                {t.disclaimerTitle}
              </span>
              <span className="text-xs bg-amber-200/80 dark:bg-amber-800/60 text-amber-900 dark:text-amber-100 px-2 py-0.5 rounded-sm font-medium">
                Preliminary Advisory Only
              </span>
            </div>
            <p className="text-xs sm:text-sm text-amber-900/90 dark:text-amber-200/90 mt-1 leading-relaxed">
              {t.disclaimerText}
            </p>

            {isExpanded && (
              <div className="mt-2.5 pt-2.5 border-t border-amber-200 dark:border-amber-800/60 text-xs text-amber-900/85 dark:text-amber-200/85 space-y-1">
                <p className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <strong>Zero Intermediary Policy:</strong> Government schemes never require paying money to agents. Always apply directly at authorized CSC centres, Gram Panchayat offices, or official .gov.in / .nic.in portals.
                </p>
                <p>
                  <strong>Verification Requirement:</strong> Physical inspection of housing structures (e.g., Geo-tagging in PMAY) and revenue record verification are conducted by local administration before release of installment funds.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {onReadOutLoud && (
            <button
              type="button"
              onClick={() => onReadOutLoud(`${t.disclaimerTitle}. ${t.disclaimerText}`)}
              className="text-xs text-amber-800 dark:text-amber-300 hover:text-amber-950 dark:hover:text-amber-100 p-1 rounded-sm focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              title="Read notice out loud"
              aria-label="Read notice out loud"
            >
              🔊
            </button>
          )}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-amber-800 dark:text-amber-300 hover:text-amber-950 dark:hover:text-amber-100 p-1 text-xs font-medium flex items-center gap-0.5 focus:outline-hidden focus:ring-2 focus:ring-amber-500 rounded-sm"
            aria-expanded={isExpanded}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
