/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CheckCircle,
  AlertCircle,
  XCircle,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Volume2,
  Sparkles,
  FileText,
  Info
} from 'lucide-react';
import { EligibilityResult, LanguageCode, Scheme } from '../types/scheme';
import { Translations } from '../data/translations';

interface SchemeCardProps {
  scheme: Scheme;
  result: EligibilityResult;
  isShortlisted: boolean;
  onToggleShortlist: (schemeId: string) => void;
  onOpenDetails: (scheme: Scheme) => void;
  onAskAI: (scheme: Scheme) => void;
  onReadOutLoud: (text: string) => void;
  currentLanguage: LanguageCode;
  t: Translations;
  isTouchToReadActive: boolean;
}

export const SchemeCard: React.FC<SchemeCardProps> = ({
  scheme,
  result,
  isShortlisted,
  onToggleShortlist,
  onOpenDetails,
  onAskAI,
  onReadOutLoud,
  currentLanguage,
  t,
  isTouchToReadActive
}) => {
  const [isRulesExpanded, setIsRulesExpanded] = useState(false);

  // Status badge config
  const statusConfig = {
    ELIGIBLE: {
      label: t.results.badgeEligible,
      icon: CheckCircle,
      badgeClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800',
      borderClass: 'border-emerald-500/50 hover:border-emerald-600',
      scoreBadge: 'bg-emerald-600 text-white'
    },
    MORE_INFO_NEEDED: {
      label: t.results.badgeReview,
      icon: AlertCircle,
      badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-300 dark:border-amber-800',
      borderClass: 'border-amber-500/50 hover:border-amber-600',
      scoreBadge: 'bg-amber-600 text-white'
    },
    NOT_ELIGIBLE: {
      label: t.results.badgeNotEligible,
      icon: XCircle,
      badgeClass: 'bg-stone-200 text-stone-700 dark:bg-stone-800 dark:text-stone-300 border-stone-300 dark:border-stone-700',
      borderClass: 'border-stone-200 dark:border-stone-800 opacity-90',
      scoreBadge: 'bg-stone-500 text-white'
    }
  }[result.status];

  const StatusIcon = statusConfig.icon;

  const displayName = scheme.nameTranslations?.[currentLanguage] || scheme.name;
  const displayTagline = scheme.taglineTranslations?.[currentLanguage] || scheme.tagline;

  const handleCardSpeech = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const textToRead = `${displayName}. Status: ${statusConfig.label}. Available Benefits: ${scheme.availableBenefits.financialAmount || ''}. ${displayTagline}. Summary: ${result.summaryExplanation}`;
    onReadOutLoud(textToRead);
  };

  return (
    <article
      className={`relative bg-white dark:bg-stone-900 rounded-xl border-2 ${statusConfig.borderClass} p-4 sm:p-5 shadow-xs transition-all hover:shadow-md flex flex-col justify-between`}
      onMouseEnter={() => {
        if (isTouchToReadActive) handleCardSpeech();
      }}
      onClick={() => {
        if (isTouchToReadActive) handleCardSpeech();
      }}
      aria-label={`${displayName} - ${statusConfig.label}`}
    >
      <div>
        {/* Top Badges Bar */}
        <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span
              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${statusConfig.badgeClass}`}
            >
              <StatusIcon className="w-3.5 h-3.5 shrink-0" />
              {statusConfig.label}
            </span>

            <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400">
              {scheme.category.replace('_', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-full ${statusConfig.scoreBadge}`}
              title="Calculated eligibility match score"
            >
              {result.matchScore}% Match
            </span>

            {/* Read Out Loud Button */}
            <button
              type="button"
              onClick={handleCardSpeech}
              className="p-1.5 rounded-lg text-stone-500 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              title={t.results.speakCardButton}
              aria-label={`Read ${displayName} out loud`}
            >
              <Volume2 className="w-4 h-4" />
            </button>

            {/* Shortlist Bookmark Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleShortlist(scheme.id);
              }}
              className={`p-1.5 rounded-lg transition-colors ${
                isShortlisted
                  ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60'
                  : 'text-stone-400 hover:text-amber-600 hover:bg-stone-100 dark:hover:bg-stone-800'
              }`}
              title={isShortlisted ? t.results.shortlistedButton : t.results.shortlistButton}
              aria-label={isShortlisted ? t.results.shortlistedButton : t.results.shortlistButton}
            >
              {isShortlisted ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Scheme Name & Ministry */}
        <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 leading-snug">
          {displayName}
        </h3>
        <p className="text-xs text-stone-500 dark:text-stone-400 font-medium mt-0.5">
          {scheme.ministry}
        </p>

        {/* Tagline */}
        <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 mt-2 line-clamp-2 leading-relaxed">
          {displayTagline}
        </p>

        {/* Benefit Highlight Box */}
        <div className="mt-3 p-3 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/60 text-emerald-950 dark:text-emerald-100">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
            <span>{t.results.benefitsTitle}</span>
            {scheme.availableBenefits.frequency && (
              <span className="text-[11px] font-medium lowercase bg-emerald-200/60 dark:bg-emerald-900/50 px-1.5 py-0.5 rounded-sm">
                {scheme.availableBenefits.frequency}
              </span>
            )}
          </div>
          {scheme.availableBenefits.financialAmount && (
            <p className="text-sm font-extrabold text-emerald-900 dark:text-emerald-200 mt-0.5">
              {scheme.availableBenefits.financialAmount}
            </p>
          )}
          <p className="text-xs text-emerald-900/90 dark:text-emerald-200/90 mt-1 line-clamp-2">
            {scheme.availableBenefits.description}
          </p>
        </div>

        {/* Result Summary Note */}
        <div className="mt-2.5 text-xs text-stone-600 dark:text-stone-400 font-medium">
          <p className="line-clamp-2">
            <strong>Evaluation:</strong> {result.summaryExplanation}
          </p>
        </div>

        {/* Document Checklist Preview */}
        <div className="mt-3 flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 flex items-center gap-1">
            <FileText className="w-3 h-3" />
            {t.results.documentsNeeded}:
          </span>
          {scheme.requiredDocuments.slice(0, 3).map((doc) => (
            <span
              key={doc.id}
              className="text-[11px] px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-medium"
            >
              {doc.name.split('(')[0]}
            </span>
          ))}
          {scheme.requiredDocuments.length > 3 && (
            <span className="text-[11px] text-stone-500 font-medium">
              +{scheme.requiredDocuments.length - 3} more
            </span>
          )}
        </div>

        {/* Transparent Rule Breakdown Accordion */}
        <div className="mt-3 pt-2.5 border-t border-stone-200 dark:border-stone-800">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsRulesExpanded(!isRulesExpanded);
            }}
            className="w-full flex items-center justify-between text-xs font-semibold text-stone-700 dark:text-stone-300 hover:text-emerald-700 dark:hover:text-emerald-400 py-1"
            aria-expanded={isRulesExpanded}
          >
            <span className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              {t.results.ruleBreakdownTitle} ({result.ruleBreakdown.length} criteria)
            </span>
            {isRulesExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {isRulesExpanded && (
            <div className="mt-2 space-y-1.5 text-xs bg-stone-50 dark:bg-stone-800/60 p-2.5 rounded-lg border border-stone-200 dark:border-stone-700/60">
              {result.ruleBreakdown.map((rule) => (
                <div key={rule.ruleId} className="flex items-start gap-2 pb-1.5 border-b border-stone-200/50 dark:border-stone-700/50 last:border-0 last:pb-0">
                  {rule.status === 'pass' && (
                    <span className="w-4 h-4 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ✓
                    </span>
                  )}
                  {rule.status === 'warn' && (
                    <span className="w-4 h-4 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ⚠
                    </span>
                  )}
                  {rule.status === 'fail' && (
                    <span className="w-4 h-4 rounded-full bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ✗
                    </span>
                  )}
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-stone-100">
                      {rule.name}:
                    </span>{' '}
                    <span className="text-stone-600 dark:text-stone-300">
                      {rule.detail}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons Bar */}
      <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5">
          {/* Ask AI button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onAskAI(scheme);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-semibold bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 transition-colors"
            title="Ask AI questions about this scheme"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{t.results.aiExplainButton}</span>
          </button>

          {/* Full Details Modal */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetails(scheme);
            }}
            className="px-2.5 py-1.5 rounded-md text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-400 hover:underline transition-colors"
          >
            {t.results.viewDetailsButton}
          </button>
        </div>

        {/* Apply on Official Portal */}
        <a
          href={scheme.applyOnlineUrl || scheme.officialPortalUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors"
        >
          <span>{t.results.applyButton}</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </article>
  );
};
