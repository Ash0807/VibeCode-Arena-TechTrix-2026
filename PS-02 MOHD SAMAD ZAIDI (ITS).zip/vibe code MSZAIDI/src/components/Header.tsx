/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Volume2,
  VolumeX,
  Mic,
  Bookmark,
  Sun,
  Moon,
  Eye,
  Languages,
  Landmark
} from 'lucide-react';
import { LanguageCode } from '../types/scheme';
import { LANGUAGE_LABELS } from '../utils/speechHelper';
import { Translations } from '../data/translations';

interface HeaderProps {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  isTouchToReadActive: boolean;
  onToggleTouchToRead: () => void;
  isHighContrast: boolean;
  onToggleHighContrast: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  fontSizeLevel: number; // 0 = normal, 1 = large, 2 = x-large
  onChangeFontSize: (level: number) => void;
  shortlistedCount: number;
  onOpenShortlist: () => void;
  onOpenVoiceAssistant: () => void;
  t: Translations;
}

export const Header: React.FC<HeaderProps> = ({
  currentLanguage,
  onLanguageChange,
  isTouchToReadActive,
  onToggleTouchToRead,
  isHighContrast,
  onToggleHighContrast,
  isDarkMode,
  onToggleDarkMode,
  fontSizeLevel,
  onChangeFontSize,
  shortlistedCount,
  onOpenShortlist,
  onOpenVoiceAssistant,
  t
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-b border-stone-200 dark:border-stone-800 transition-colors shadow-xs">
      {/* Top Accessibility & Language Bar */}
      <div className="bg-stone-100 dark:bg-stone-950 px-4 py-1.5 text-xs border-b border-stone-200 dark:border-stone-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Official Emblem & Accessibility Notice */}
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-600 dark:bg-emerald-400" />
            <span className="font-semibold text-stone-700 dark:text-stone-300">
              National Government Services Assistance • WCAG 2.1 AA Compliant
            </span>
          </div>

          {/* Accessibility Quick Controls */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            {/* Touch / Hover to Read Toggle */}
            <button
              type="button"
              onClick={onToggleTouchToRead}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-sm font-medium transition-colors ${
                isTouchToReadActive
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300 dark:hover:bg-stone-700'
              }`}
              aria-pressed={isTouchToReadActive}
              title={isTouchToReadActive ? t.accessibility.touchToReadOn : t.accessibility.touchToReadOff}
            >
              {isTouchToReadActive ? (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{t.accessibility.touchToReadOn}</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-3.5 h-3.5" />
                  <span>{t.accessibility.touchToRead}</span>
                </>
              )}
            </button>

            {/* Font Size Adjuster */}
            <div className="flex items-center border border-stone-300 dark:border-stone-700 rounded-sm bg-white dark:bg-stone-900 overflow-hidden">
              <button
                type="button"
                onClick={() => onChangeFontSize(0)}
                className={`px-2 py-0.5 text-xs font-semibold ${fontSizeLevel === 0 ? 'bg-emerald-600 text-white' : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'}`}
                title="Default text size"
                aria-label="Default text size"
              >
                A
              </button>
              <button
                type="button"
                onClick={() => onChangeFontSize(1)}
                className={`px-2 py-0.5 text-xs font-semibold ${fontSizeLevel === 1 ? 'bg-emerald-600 text-white' : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'}`}
                title="Medium large text size"
                aria-label="Medium large text size"
              >
                A+
              </button>
              <button
                type="button"
                onClick={() => onChangeFontSize(2)}
                className={`px-2 py-0.5 text-xs font-semibold ${fontSizeLevel === 2 ? 'bg-emerald-600 text-white' : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'}`}
                title="Extra large text size"
                aria-label="Extra large text size"
              >
                A++
              </button>
            </div>

            {/* High Contrast Mode Toggle */}
            <button
              type="button"
              onClick={onToggleHighContrast}
              className={`p-1.5 rounded-sm transition-colors ${
                isHighContrast
                  ? 'bg-amber-600 text-white'
                  : 'text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800'
              }`}
              title={t.accessibility.highContrast}
              aria-label={t.accessibility.highContrast}
              aria-pressed={isHighContrast}
            >
              <Eye className="w-3.5 h-3.5" />
            </button>

            {/* Dark Mode Toggle */}
            <button
              type="button"
              onClick={onToggleDarkMode}
              className="p-1.5 rounded-sm text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
              title={t.accessibility.darkMode}
              aria-label={t.accessibility.darkMode}
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex items-center justify-between gap-4">
        {/* Brand & Emblem */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-emerald-700 dark:bg-emerald-600 flex items-center justify-center text-white shadow-sm ring-2 ring-emerald-600/30">
            <Landmark className="w-6 h-6" aria-hidden="true" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-stone-900 dark:text-white">
                {t.appName}
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                PMAY & Welfare Finder
              </span>
            </div>
            <p className="text-xs text-stone-600 dark:text-stone-400 font-medium line-clamp-1">
              {t.tagline}
            </p>
          </div>
        </div>

        {/* Action Controls: Language, Voice Assistant, Shortlist */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Selector Dropdown */}
          <div className="relative flex items-center">
            <label htmlFor="language-select" className="sr-only">
              Select Language
            </label>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-semibold text-xs sm:text-sm">
              <Languages className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" aria-hidden="true" />
              <select
                id="language-select"
                value={currentLanguage}
                onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
                className="bg-transparent focus:outline-hidden cursor-pointer font-medium"
              >
                {(Object.keys(LANGUAGE_LABELS) as LanguageCode[]).map((code) => (
                  <option key={code} value={code} className="bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100">
                    {LANGUAGE_LABELS[code].nativeName} ({LANGUAGE_LABELS[code].label})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Voice Assistant Trigger */}
          <button
            type="button"
            onClick={onOpenVoiceAssistant}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-medium text-xs sm:text-sm shadow-xs transition-colors focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            title="Open Voice Assistant in your language"
            aria-label="Open Voice Assistant in your language"
          >
            <Mic className="w-4 h-4 animate-pulse" />
            <span className="hidden sm:inline">{t.accessibility.voiceAssistant}</span>
          </button>

          {/* Shortlisted Schemes Drawer Button */}
          <button
            type="button"
            onClick={onOpenShortlist}
            className="relative flex items-center gap-1 px-3 py-1.5 rounded-lg border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-medium text-xs sm:text-sm transition-colors focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            title="View saved schemes"
            aria-label={`View ${shortlistedCount} saved schemes`}
          >
            <Bookmark className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span className="hidden md:inline">{t.tabs.shortlisted}</span>
            {shortlistedCount > 0 && (
              <span className="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5 rounded-full text-xs font-bold bg-amber-600 text-white">
                {shortlistedCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
