/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Search,
  Globe,
  Radio
} from 'lucide-react';
import { LanguageCode } from '../types/scheme';
import {
  startSpeechRecognition,
  speakText,
  stopSpeaking,
  LANGUAGE_LABELS
} from '../utils/speechHelper';
import { Translations } from '../data/translations';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onApplyVoiceFilter: (categoryOrQuery: string) => void;
  t: Translations;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  onLanguageChange,
  onApplyVoiceFilter,
  t
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [assistantReply, setAssistantReply] = useState('');
  const [isSpeakingReply, setIsSpeakingReply] = useState(false);
  const [speechRecognizer, setSpeechRecognizer] = useState<{ stop: () => void } | null>(null);
  const [autoDetectMode, setAutoDetectMode] = useState(true);
  const [detectedLanguage, setDetectedLanguage] = useState<LanguageCode>(currentLanguage);

  useEffect(() => {
    if (!isOpen) {
      if (speechRecognizer) speechRecognizer.stop();
      stopSpeaking();
      setIsListening(false);
      setIsSpeakingReply(false);
    }
  }, [isOpen, speechRecognizer]);

  if (!isOpen) return null;

  const handleStartListening = () => {
    stopSpeaking();
    setIsSpeakingReply(false);
    setTranscript('');
    setAssistantReply('');

    const targetLang = autoDetectMode ? 'auto' : currentLanguage;

    const recognizer = startSpeechRecognition({
      lang: targetLang,
      onStart: () => setIsListening(true),
      onResult: (text, detectedLang) => {
        setIsListening(false);
        setTranscript(text);
        if (autoDetectMode && detectedLang) {
          setDetectedLanguage(detectedLang);
          onLanguageChange(detectedLang);
        }
        processVoiceCommand(text, detectedLang || currentLanguage);
      },
      onError: (err) => {
        setIsListening(false);
        setAssistantReply(`Could not recognize speech: ${err}. Please click a quick suggested command or type below.`);
      },
      onEnd: () => setIsListening(false)
    });

    setSpeechRecognizer(recognizer);
  };

  const handleStopListening = () => {
    if (speechRecognizer) {
      speechRecognizer.stop();
    }
    setIsListening(false);
  };

  const processVoiceCommand = (userQuery: string, lang: LanguageCode) => {
    const q = userQuery.toLowerCase();
    let reply = '';
    let categoryFilter = '';

    // Housing intent
    if (q.includes('housing') || q.includes('awas') || q.includes('makan') || q.includes('ghar') || q.includes('ঘর') || q.includes('வீடு') || q.includes('pmay')) {
      reply =
        lang === 'hi'
          ? 'मैंने आवास योजनाएं (PMAY ग्रामीण व शहरी) खोल दी हैं। ग्रामीण क्षेत्रों में ₹1.20 लाख और शहरी क्षेत्रों में ₹2.5 लाख तक की सहायता मिलती है।'
          : lang === 'bn'
          ? 'আমি আবাসন প্রকল্পগুলি (PMAY) প্রদর্শন করছি। কাঁচা বা গৃহহীন পরিবার পাকা বাড়ি নির্মাণের জন্য সরাসরি সরকারি অনুদান পাবেন।'
          : lang === 'pa'
          ? 'ਮੈਂ ਆਵਾਸ ਯੋਜਨਾਵਾਂ (PMAY) ਦਿਖਾ ਰਿਹਾ ਹਾਂ। ਪੇਂਡੂ ਖੇਤਰਾਂ ਵਿੱਚ ₹1.20 ਲੱਖ ਅਤੇ ਸ਼ਹਿਰੀ ਖੇਤਰਾਂ ਵਿੱਚ ₹2.5 ਲੱਖ ਤੱਕ ਮਕਾਨ ਸਹਾਇਤਾ ਮਿਲਦੀ ਹੈ।'
          : lang === 'ta'
          ? 'பிரதம மந்திரி ஆவாஸ் யோஜனா (PMAY) வீட்டு வசதி திட்டங்களை காட்டுகிறேன். கிராமப்புற மற்றும் நகர்ப்புற ஏழைகளுக்கு வீடு கட்ட நிதி உதவி வழங்கப்படுகிறது.'
          : 'Showing Housing Assistance (PMAY Rural and Urban). Eligible families without a pucca house can receive ₹1.20 Lakh to ₹2.50 Lakh financial assistance.';
      categoryFilter = 'housing';
    }
    // Farmer / Agriculture intent
    else if (q.includes('kisan') || q.includes('farmer') || q.includes('krishi') || q.includes('khet') || q.includes('কৃষক') || q.includes('விவசாயி') || q.includes('fasal')) {
      reply =
        lang === 'hi'
          ? 'कृषि एवं किसान कल्याण योजनाएं दिखाई जा रही हैं। पीएम किसान के तहत ₹6,000 प्रति वर्ष 3 किस्तों में सीधे बैंक खाते में मिलते हैं।'
          : lang === 'bn'
          ? 'কৃষি ও কৃষক কল্যাণ প্রকল্প প্রদর্শিত হচ্ছে। পিএম কিষাণ প্রকল্পে বছরে ₹৬,০০০ সরাসরি ব্যাংক অ্যাকাউন্টে জমা হয়।'
          : lang === 'pa'
          ? 'ਕਿਸਾਨ ਭਲਾਈ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ। ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਕਿਸਾਨ ਸਨਮਾਨ ਨਿਧੀ ਅਧੀਨ ਸਾਲਾਨਾ ₹6,000 ਸਿੱਧੇ ਬੈਂਕ ਖਾਤੇ ਵਿੱਚ ਜਮ੍ਹਾ ਹੁੰਦੇ ਹਨ।'
          : lang === 'ta'
          ? 'விவசாய நலத்திட்டங்கள் காட்டப்படுகின்றன. PM-KISAN மூலம் ஆண்டுக்கு ₹6,000 நேரடியாக வங்கி கணக்கில் செலுத்தப்படுகிறது.'
          : 'Filtering Agricultural and Farmer Welfare schemes (PM-KISAN ₹6,000/yr, PMFBY crop insurance, and Kisan Credit Card).';
      categoryFilter = 'agriculture';
    }
    // Healthcare / Ayushman intent
    else if (q.includes('health') || q.includes('ayushman') || q.includes('hospital') || q.includes('ilaj') || q.includes('swasthya') || q.includes('দাওয়া') || q.includes('மருத்துவம்')) {
      reply =
        lang === 'hi'
          ? 'आयुष्मान भारत और स्वास्थ्य योजनाएं खोली गई हैं। प्रति परिवार प्रति वर्ष ₹5 लाख का मुफ्त कैशलेस इलाज मिलता है। 70 वर्ष से अधिक आयु के सभी बुजुर्ग भी पात्र हैं।'
          : lang === 'bn'
          ? 'আয়ুষ্মান ভারত ও স্বাস্থ্য প্রকল্প প্রদর্শন করছি। প্রতি বছর ₹৫ লাখ টাকার বিনামূল্যে ক্যাশলেস চিকিৎসা পাওয়া যায়।'
          : lang === 'pa'
          ? 'ਆਯੁਸ਼ਮਾਨ ਭਾਰਤ ਸਿਹਤ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ। ਹਰ ਪਰਿਵਾਰ ਨੂੰ ਸਾਲਾਨਾ ₹5 ਲੱਖ ਦਾ ਮੁਫਤ ਕੈਸ਼ਲੈੱਸ ਹਸਪਤਾਲ ਇਲਾਜ ਮਿਲਦਾ ਹੈ।'
          : lang === 'ta'
          ? 'ஆயுஷ்மான் பாரத் மற்றும் மருத்துவ காப்பீட்டு திட்டங்களை காட்டுகிறேன். குடும்பத்திற்கு ஆண்டுக்கு ₹5 லட்சம் வரை இலவச மருத்துவ சிகிச்சை கிடைக்கும்.'
          : 'Displaying Healthcare schemes. Ayushman Bharat PM-JAY provides ₹5,00,000 free cashless hospital coverage per family per year.';
      categoryFilter = 'healthcare';
    }
    // Street Vendor / PM SVANidhi intent
    else if (q.includes('vendor') || q.includes('rehri') || q.includes('street') || q.includes('svanidhi') || q.includes('हॉकर') || q.includes('வியாபாரி')) {
      reply =
        lang === 'hi'
          ? 'पीएम स्वनिधि रेहड़ी-पटरी विक्रेता योजना। पहली बार ₹10,000, दूसरी बार ₹20,000 और फिर ₹50,000 तक बिना गारंटी कर्ज व 7% ब्याज सब्सिडी।'
          : 'PM SVANidhi for street vendors: Collateral-free loan from ₹10,000 up to ₹50,000 with 7% interest subsidy.';
      categoryFilter = 'employment';
    }
    // Senior citizen / Pension intent
    else if (q.includes('senior') || q.includes('pension') || q.includes('old') || q.includes('bujurg') || q.includes('বৃদ্ধ') || q.includes('முதியோர்')) {
      reply =
        lang === 'hi'
          ? 'वरिष्ठ नागरिक पेंशन एवं अटल पेंशन योजना की जानकारी प्रदर्शित है।'
          : 'Displaying Social Welfare & Pension schemes including IGNOAPS senior citizen pension and Atal Pension Yojana.';
      categoryFilter = 'social_welfare';
    }
    // General fallback
    else {
      reply =
        lang === 'hi'
          ? `मैंने आपकी खोज "${userQuery}" के अनुसार संबंधित सरकारी योजनाओं को सक्रिय कर दिया है।`
          : `Processed your query for "${userQuery}". You can review matching eligibility results below.`;
      categoryFilter = userQuery;
    }

    setAssistantReply(reply);
    onApplyVoiceFilter(categoryFilter);

    // Speak out the reply in the matching language!
    setIsSpeakingReply(true);
    speakText(reply, lang, () => setIsSpeakingReply(false));
  };

  const handleQuickCommand = (command: string) => {
    setTranscript(command);
    processVoiceCommand(command, currentLanguage);
  };

  const sampleCommands: Record<LanguageCode, string[]> = {
    en: ['Housing schemes (PMAY)', 'I am a small farmer', 'Ayushman health card', 'Street vendor loan', 'Senior citizen pension'],
    hi: ['पीएम आवास योजना (मकान)', 'मैं किसान हूँ (पीएम किसान)', 'आयुष्मान भारत कार्ड', 'रेहड़ी-पटरी लोन (स्वनिधि)', 'वृद्धावस्था पेंशन'],
    bn: ['প্রধানমন্ত্রী আবাস যোজনা', 'আমি একজন কৃষক', 'আয়ুষ্মান স্বাস্থ্য কার্ড', 'রাস্তার বিক্রেতা ঋণ', 'বার্ধক্য পেনশন'],
    pa: ['ਪ੍ਰਧਾਨ ਮੰਤਰੀ ਆਵਾਸ ਯੋਜਨਾ', 'ਮੈਂ ਕਿਸਾਨ ਹਾਂ', 'ਆਯੁਸ਼ਮਾਨ ਸਿਹਤ ਕਾਰਡ', 'ਰੇਹੜੀ ਵਾਲਿਆਂ ਲਈ ਕਰਜ਼ਾ', 'ਬੁਢਾਪਾ ਪੈਨਸ਼ਨ'],
    ta: ['வீட்டு வசதி திட்டம் (PMAY)', 'நான் விவசாயி (PM-KISAN)', 'ஆயுஷ்மான் மருத்துவ காப்பீடு', 'தெருவோர வியாபாரி கடன்', 'முதியோர் ஓய்வூதியம்']
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-voice-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs"
    >
      <div className="relative w-full max-w-xl bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl p-5 sm:p-6 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-emerald-700 text-white flex items-center justify-center">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h2 id="modal-voice-title" className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                SchemeSaathi Voice Assistant
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Speak in Hindi, English, Bengali, Punjabi, or Tamil
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Language Mode Toggle */}
        <div className="mt-3.5 p-2.5 rounded-lg bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span className="font-semibold text-stone-700 dark:text-stone-300">Language Mode:</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setAutoDetectMode(true)}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors flex items-center gap-1 ${
                autoDetectMode
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300'
              }`}
            >
              <Radio className="w-3 h-3" /> Auto Detect
            </button>

            <select
              value={currentLanguage}
              onChange={(e) => {
                setAutoDetectMode(false);
                onLanguageChange(e.target.value as LanguageCode);
              }}
              className="bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 text-stone-800 dark:text-stone-200 px-2 py-1 rounded-md font-medium text-xs"
            >
              {(Object.keys(LANGUAGE_LABELS) as LanguageCode[]).map((code) => (
                <option key={code} value={code}>
                  {LANGUAGE_LABELS[code].nativeName}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Center Mic Button & Listening Pulse */}
        <div className="my-6 flex flex-col items-center justify-center text-center">
          <div className="relative">
            {isListening && (
              <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping duration-1000" />
            )}
            <button
              type="button"
              onClick={isListening ? handleStopListening : handleStartListening}
              className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-all focus:outline-hidden ${
                isListening
                  ? 'bg-red-600 text-white ring-4 ring-red-400/50 scale-105'
                  : 'bg-emerald-700 hover:bg-emerald-800 text-white ring-4 ring-emerald-500/30'
              }`}
              aria-label={isListening ? 'Stop listening' : 'Start voice recognition'}
            >
              {isListening ? <MicOff className="w-9 h-9" /> : <Mic className="w-9 h-9" />}
            </button>
          </div>

          <p className="mt-3 text-sm font-bold text-stone-800 dark:text-stone-200">
            {isListening ? t.accessibility.listening : 'Click microphone to speak'}
          </p>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            {isListening
              ? `Listening in ${autoDetectMode ? 'Auto-detection' : LANGUAGE_LABELS[currentLanguage].nativeName}...`
              : t.accessibility.speakNow}
          </p>
        </div>

        {/* Recognized Transcript & Reply */}
        {transcript && (
          <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700 text-xs mb-3">
            <span className="font-semibold text-stone-500 uppercase tracking-wider text-[10px]">
              You said:
            </span>
            <p className="text-stone-900 dark:text-stone-100 font-bold text-sm mt-0.5">
              &quot;{transcript}&quot;
            </p>
          </div>
        )}

        {assistantReply && (
          <div className="p-3.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-950 dark:text-emerald-100 mb-3 flex items-start justify-between gap-2">
            <div>
              <span className="font-bold uppercase tracking-wider text-[10px] text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" /> SchemeSaathi Answer:
              </span>
              <p className="text-sm font-medium mt-1 leading-relaxed">
                {assistantReply}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                if (isSpeakingReply) {
                  stopSpeaking();
                  setIsSpeakingReply(false);
                } else {
                  setIsSpeakingReply(true);
                  speakText(assistantReply, detectedLanguage || currentLanguage, () =>
                    setIsSpeakingReply(false)
                  );
                }
              }}
              className="p-1.5 rounded-md text-emerald-700 hover:bg-emerald-100 dark:hover:bg-emerald-900"
              title={isSpeakingReply ? 'Stop voice' : 'Read answer out loud'}
            >
              {isSpeakingReply ? <VolumeX className="w-4 h-4 text-red-500" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        )}

        {/* Quick Suggested Commands */}
        <div className="mt-2 pt-3 border-t border-stone-200 dark:border-stone-800">
          <span className="text-xs font-semibold text-stone-500 dark:text-stone-400 block mb-2">
            Or click a common request:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {sampleCommands[currentLanguage].map((cmd, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleQuickCommand(cmd)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 hover:bg-stone-100 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-medium transition-colors"
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>

        {/* Manual Search Fallback */}
        <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (transcript.trim()) {
                processVoiceCommand(transcript, currentLanguage);
              }
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Or type your query here..."
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs flex items-center gap-1"
            >
              <Search className="w-3.5 h-3.5" /> Search
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
