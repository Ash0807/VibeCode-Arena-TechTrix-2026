/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Send,
  Loader2,
  Volume2,
  VolumeX,
  ExternalLink,
  BookOpen,
  HelpCircle,
  ShieldAlert
} from 'lucide-react';
import { CitizenProfile, LanguageCode, Scheme } from '../types/scheme';
import { speakText, stopSpeaking } from '../utils/speechHelper';
import { Translations } from '../data/translations';

interface AIGuidanceDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  targetScheme: Scheme | null;
  profile: CitizenProfile;
  currentLanguage: LanguageCode;
  t: Translations;
}

export const AIGuidanceDrawer: React.FC<AIGuidanceDrawerProps> = ({
  isOpen,
  onClose,
  targetScheme,
  profile,
  currentLanguage,
  t
}) => {
  const [query, setQuery] = useState('');
  const [guidanceResponse, setGuidanceResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [aiSource, setAiSource] = useState<'gemini' | 'knowledge_engine'>('gemini');

  useEffect(() => {
    if (!isOpen) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (targetScheme) {
      const defaultQ = `Please explain the eligibility requirements, application steps, and document checklist for ${targetScheme.name} for my profile (${profile.areaType} resident, occupation: ${profile.occupation}, income: ${profile.incomeRange}).`;
      setQuery(defaultQ);
      fetchGuidance(defaultQ);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, targetScheme]);

  if (!isOpen) return null;

  const fetchGuidance = async (question: string) => {
    if (!question.trim()) return;
    setIsLoading(true);
    setGuidanceResponse('');
    stopSpeaking();
    setIsSpeaking(false);

    try {
      const res = await fetch('/api/ai/guidance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: question,
          language: currentLanguage,
          userProfile: profile
        })
      });

      if (!res.ok) throw new Error('Network response was not ok');
      const data = await res.json();
      setGuidanceResponse(data.guidance || 'No guidance generated.');
      setAiSource(data.source || 'gemini');
    } catch {
      setGuidanceResponse(
        `Unable to reach AI service. Please verify your connection or browse official ministry links directly at https://myscheme.gov.in.`
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else if (guidanceResponse) {
      setIsSpeaking(true);
      speakText(guidanceResponse, currentLanguage, () => setIsSpeaking(false));
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-drawer-title"
      className="fixed inset-0 z-50 flex items-center justify-end bg-stone-900/50 backdrop-blur-xs"
    >
      <div className="w-full max-w-xl h-full bg-white dark:bg-stone-900 shadow-2xl flex flex-col justify-between border-l border-stone-200 dark:border-stone-800 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/80 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 id="ai-drawer-title" className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                {t.aiModal.title}
                {aiSource === 'gemini' ? (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    Gemini 3.8
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                    Rule Engine
                  </span>
                )}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {t.aiModal.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {guidanceResponse && (
              <button
                type="button"
                onClick={handleSpeak}
                className="p-2 rounded-lg text-stone-500 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors"
                title={isSpeaking ? 'Stop speaking' : 'Read out response'}
              >
                {isSpeaking ? <VolumeX className="w-4 h-4 text-red-500" /> : <Volume2 className="w-4 h-4" />}
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-700"
              aria-label="Close AI Guidance"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* External Portals & Research Links Card */}
          <div className="p-3.5 rounded-xl bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-stone-300 mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-emerald-600" /> Official Portals & Application Gateways
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a
                href="https://myscheme.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>myScheme.gov.in</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
              <a
                href="https://pmayg.nic.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>PMAY-Gramin</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
              <a
                href="https://pmay-urban.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>PMAY-Urban 2.0</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
              <a
                href="https://beneficiary.nha.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>Ayushman Bharat</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
              <a
                href="https://csc.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>Find Nearest CSC Center</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
              <a
                href="https://pgportal.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 text-stone-800 dark:text-stone-200 font-semibold flex items-center justify-between"
              >
                <span>Central CPGRAMS Portal</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
            </div>
          </div>

          {/* Quick Suggested Queries */}
          <div>
            <span className="text-xs font-semibold text-stone-500 dark:text-stone-400 block mb-2 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5" /> Suggested Inquiries:
            </span>
            <div className="flex flex-col gap-1.5">
              {t.aiModal.suggestedQueries.map((sq, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setQuery(sq);
                    fetchGuidance(sq);
                  }}
                  className="text-left text-xs p-2.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/40 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:border-emerald-300 text-stone-800 dark:text-stone-200 font-medium transition-colors"
                >
                  💬 {sq}
                </button>
              ))}
            </div>
          </div>

          {/* Guidance Response Display */}
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-stone-500">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-600 mb-2" />
              <p className="text-xs font-semibold">Consulting official guidelines & regulatory criteria...</p>
            </div>
          ) : guidanceResponse ? (
            <div className="p-4 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200">
              <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-stone-200 dark:border-stone-700">
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> AI Recommendation & Step-by-Step Instructions:
                </span>
              </div>
              <div className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed space-y-2">
                {guidanceResponse}
              </div>
            </div>
          ) : null}

          {/* Statutory Disclaimer Note */}
          <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-[11px] text-amber-900 dark:text-amber-200 flex items-start gap-2">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <p>{t.aiModal.officialAdviceNote}</p>
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              fetchGuidance(query);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.aiModal.placeholder}
              className="flex-1 px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-900 text-xs sm:text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition-colors"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span className="hidden sm:inline">{t.aiModal.sendButton}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
