/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Sparkles,
  Bookmark,
  FileCheck2,
  Home,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  CitizenProfile,
  EligibilityResult,
  EligibilityStatus,
  LanguageCode,
  Scheme,
  SchemeCategory
} from './types/scheme';
import { SCHEMES_DATABASE } from './data/schemesData';
import { evaluateEligibility } from './utils/eligibilityEngine';
import { TRANSLATIONS } from './data/translations';
import { speakText, stopSpeaking } from './utils/speechHelper';
import { Header } from './components/Header';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { CitizenProfileForm } from './components/CitizenProfileForm';
import { SchemeCard } from './components/SchemeCard';
import { SchemeDetailsModal } from './components/SchemeDetailsModal';
import { DocumentChecklistModal } from './components/DocumentChecklistModal';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { AIGuidanceDrawer } from './components/AIGuidanceDrawer';

const DEFAULT_PROFILE: CitizenProfile = {
  state: 'Uttar Pradesh',
  areaType: 'rural',
  age: 36,
  gender: 'male',
  socialCategory: 'obc',
  occupation: 'farmer',
  incomeRange: 'below_1_lakh',
  housingStatus: 'kutcha',
  landholding: 'marginal',
  hasDisability: false,
  rationCard: 'bpl',
  familyMembersCount: 5,
  hasGirlChildUnder10: true,
  isStudent: false
};

export default function App() {
  // Multilingual state
  const [language, setLanguage] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('schemesaathi_lang');
      if (saved && ['en', 'hi', 'bn', 'pa', 'ta'].includes(saved)) {
        return saved as LanguageCode;
      }
    }
    return 'en';
  });

  const t = useMemo(() => TRANSLATIONS[language] || TRANSLATIONS.en, [language]);

  // Accessibility state
  const [isTouchToReadActive, setIsTouchToReadActive] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('schemesaathi_touch_read') === 'true';
    }
    return false;
  });

  const [isHighContrast, setIsHighContrast] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('schemesaathi_high_contrast') === 'true';
    }
    return false;
  });

  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('schemesaathi_dark_mode') === 'true';
    }
    return false;
  });

  const [fontSizeLevel, setFontSizeLevel] = useState<number>(0);

  // Profile and results state
  const [profile, setProfile] = useState<CitizenProfile>(DEFAULT_PROFILE);
  const [activeTab, setActiveTab] = useState<'finder' | 'housing' | 'directory' | 'saved'>('finder');
  const [statusFilter, setStatusFilter] = useState<'ALL' | EligibilityStatus>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | SchemeCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'match' | 'name'>('match');

  // Shortlisted schemes
  const [shortlistedIds, setShortlistedIds] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('schemesaathi_shortlisted');
        return saved ? JSON.parse(saved) : ['pmay-g', 'pm-kisan'];
      } catch {
        return ['pmay-g', 'pm-kisan'];
      }
    }
    return ['pmay-g', 'pm-kisan'];
  });

  // Modals state
  const [detailsScheme, setDetailsScheme] = useState<Scheme | null>(null);
  const [isChecklistOpen, setIsChecklistOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [aiTargetScheme, setAiTargetScheme] = useState<Scheme | null>(null);

  // Sync settings with DOM & localStorage
  useEffect(() => {
    localStorage.setItem('schemesaathi_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('schemesaathi_touch_read', String(isTouchToReadActive));
  }, [isTouchToReadActive]);

  useEffect(() => {
    localStorage.setItem('schemesaathi_high_contrast', String(isHighContrast));
    if (isHighContrast) {
      document.documentElement.classList.add('contrast-125');
    } else {
      document.documentElement.classList.remove('contrast-125');
    }
  }, [isHighContrast]);

  useEffect(() => {
    localStorage.setItem('schemesaathi_dark_mode', String(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('schemesaathi_shortlisted', JSON.stringify(shortlistedIds));
  }, [shortlistedIds]);

  // Audio helper
  const handleReadOutLoud = useCallback((text: string) => {
    speakText(text, language);
  }, [language]);

  // Shortlist toggle
  const toggleShortlist = (schemeId: string) => {
    setShortlistedIds((prev) =>
      prev.includes(schemeId) ? prev.filter((id) => id !== schemeId) : [...prev, schemeId]
    );
  };

  // Evaluate all schemes with the pure rule engine
  const evaluatedSchemes = useMemo(() => {
    return SCHEMES_DATABASE.map((scheme) => {
      const result = evaluateEligibility(profile, scheme);
      return { scheme, result };
    });
  }, [profile]);

  // Counts for summary bar
  const counts = useMemo(() => {
    let eligible = 0;
    let review = 0;
    let notEligible = 0;

    evaluatedSchemes.forEach(({ result }) => {
      if (result.status === 'ELIGIBLE') eligible++;
      else if (result.status === 'MORE_INFO_NEEDED') review++;
      else notEligible++;
    });

    return { eligible, review, notEligible };
  }, [evaluatedSchemes]);

  // Filtered and sorted schemes
  const filteredSchemes = useMemo(() => {
    return evaluatedSchemes
      .filter(({ scheme, result }) => {
        // Tab-specific constraints
        if (activeTab === 'housing' && scheme.category !== 'housing') {
          return false;
        }
        if (activeTab === 'saved' && !shortlistedIds.includes(scheme.id)) {
          return false;
        }

        // Status filter
        if (statusFilter !== 'ALL' && result.status !== statusFilter) {
          return false;
        }

        // Category filter
        if (categoryFilter !== 'ALL' && scheme.category !== categoryFilter) {
          return false;
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const name = (scheme.nameTranslations?.[language] || scheme.name).toLowerCase();
          const tagline = (scheme.taglineTranslations?.[language] || scheme.tagline).toLowerCase();
          const ministry = scheme.ministry.toLowerCase();
          const category = scheme.category.toLowerCase();
          return (
            name.includes(q) ||
            tagline.includes(q) ||
            ministry.includes(q) ||
            category.includes(q) ||
            scheme.shortCode.toLowerCase().includes(q)
          );
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'match') {
          return b.result.matchScore - a.result.matchScore;
        }
        const nameA = a.scheme.nameTranslations?.[language] || a.scheme.name;
        const nameB = b.scheme.nameTranslations?.[language] || b.scheme.name;
        return nameA.localeCompare(nameB);
      });
  }, [evaluatedSchemes, activeTab, shortlistedIds, statusFilter, categoryFilter, searchQuery, sortBy, language]);

  // Shortlisted scheme objects for Document Checklist
  const shortlistedSchemes = useMemo(() => {
    return SCHEMES_DATABASE.filter((s) => shortlistedIds.includes(s.id));
  }, [shortlistedIds]);

  // Voice assistant intent handler
  const handleApplyVoiceFilter = (categoryOrQuery: string) => {
    if (['housing', 'agriculture', 'healthcare', 'employment', 'education', 'social_welfare'].includes(categoryOrQuery)) {
      setCategoryFilter(categoryOrQuery as SchemeCategory);
      setActiveTab('finder');
    } else {
      setSearchQuery(categoryOrQuery);
      setActiveTab('finder');
    }
  };

  const handleOpenAiDrawer = (scheme?: Scheme) => {
    setAiTargetScheme(scheme || null);
    setIsAiDrawerOpen(true);
  };

  return (
    <div className={`min-h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors ${
      fontSizeLevel === 1 ? 'text-base' : fontSizeLevel === 2 ? 'text-lg' : 'text-sm'
    }`}>
      {/* Header */}
      <Header
        currentLanguage={language}
        onLanguageChange={setLanguage}
        isTouchToReadActive={isTouchToReadActive}
        onToggleTouchToRead={() => {
          const next = !isTouchToReadActive;
          setIsTouchToReadActive(next);
          if (next) handleReadOutLoud('Touch to read mode is now active. Hover or click any element to hear it spoken out loud.');
          else stopSpeaking();
        }}
        isHighContrast={isHighContrast}
        onToggleHighContrast={() => setIsHighContrast(!isHighContrast)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        fontSizeLevel={fontSizeLevel}
        onChangeFontSize={setFontSizeLevel}
        shortlistedCount={shortlistedIds.length}
        onOpenShortlist={() => setActiveTab('saved')}
        onOpenVoiceAssistant={() => setIsVoiceModalOpen(true)}
        t={t}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 py-5 sm:py-6" id="main-content">
        {/* Statutory Preliminary Notice */}
        <DisclaimerBanner t={t} onReadOutLoud={handleReadOutLoud} />

        {/* Navigation Tabs */}
        <nav
          className="flex items-center gap-1 sm:gap-2 border-b border-stone-200 dark:border-stone-800 pb-3 mb-6 overflow-x-auto"
          aria-label="Portal Navigation"
        >
          <button
            type="button"
            onClick={() => setActiveTab('finder')}
            className={`px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
              activeTab === 'finder'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            <Filter className="w-4 h-4" />
            {t.tabs.finder}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('housing')}
            className={`px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
              activeTab === 'housing'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            <Home className="w-4 h-4" />
            {t.tabs.housingFocus}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('directory')}
            className={`px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
              activeTab === 'directory'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            {t.tabs.allSchemes}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
              activeTab === 'saved'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            {t.tabs.shortlisted} ({shortlistedIds.length})
          </button>

          <button
            type="button"
            onClick={() => setIsChecklistOpen(true)}
            className="px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            <FileCheck2 className="w-4 h-4 text-emerald-600" />
            {t.tabs.documentChecklist}
          </button>

          <button
            type="button"
            onClick={() => handleOpenAiDrawer()}
            className="px-3.5 py-2 rounded-lg font-bold text-xs sm:text-sm whitespace-nowrap transition-all flex items-center gap-2 text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 ml-auto"
          >
            <Sparkles className="w-4 h-4 text-amber-500 animate-spin duration-3000" />
            {t.tabs.aiAssistant}
          </button>
        </nav>

        {/* Housing Spotlight Banner for Housing Tab */}
        {activeTab === 'housing' && (
          <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white rounded-2xl p-5 sm:p-6 mb-6 shadow-md">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="max-w-2xl">
                <span className="text-xs uppercase font-extrabold tracking-widest px-2.5 py-1 rounded-full bg-emerald-700/80 text-emerald-100 border border-emerald-500/30">
                  National Housing Mission
                </span>
                <h2 className="text-xl sm:text-2xl font-black mt-2">
                  Pradhan Mantri Awas Yojana (PMAY) Housing Assistance
                </h2>
                <p className="text-xs sm:text-sm text-emerald-100 mt-1 leading-relaxed">
                  Compare rural and urban housing benefits. Homeless families or citizens residing in kutcha, mud, or thatched houses receive direct grants and interest subsidies to construct durable, disaster-resilient pucca homes.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsChecklistOpen(true)}
                  className="px-4 py-2 rounded-xl bg-white text-emerald-950 font-bold text-xs sm:text-sm hover:bg-emerald-50 transition-colors shadow-xs"
                >
                  Housing Document Checklist
                </button>
                <button
                  type="button"
                  onClick={() => handleOpenAiDrawer(SCHEMES_DATABASE[0])}
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm transition-colors border border-emerald-500/40 flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" /> Ask Housing AI
                </button>
              </div>
            </div>

            {/* Quick Housing Comparison Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-4 border-t border-emerald-700/60">
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-700/40 text-xs">
                <strong className="text-sm block text-emerald-200">🌳 PMAY-Gramin (Rural):</strong>
                <p className="text-emerald-100/90 mt-0.5">
                  ₹1,20,000 (Plain) / ₹1,30,000 (Hilly/NE) direct grant + 95 days MGNREGA wages (~₹25,000) + ₹12,000 toilet grant under SBM.
                </p>
              </div>
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-700/40 text-xs">
                <strong className="text-sm block text-emerald-200">🏢 PMAY-Urban 2.0 (Cities/Towns):</strong>
                <p className="text-emerald-100/90 mt-0.5">
                  Up to ₹2,50,000 construction subsidy or 4% interest subvention up to ₹1.80 Lakh for EWS and LIG urban families.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Profile Form (Shown in Finder & Housing tabs) */}
        {(activeTab === 'finder' || activeTab === 'housing') && (
          <div className="mb-8">
            <CitizenProfileForm
              profile={profile}
              onChange={setProfile}
              onSubmit={() => {
                const resultsElement = document.getElementById('scheme-results-section');
                if (resultsElement) resultsElement.scrollIntoView({ behavior: 'smooth' });
              }}
              onReset={() => setProfile(DEFAULT_PROFILE)}
              t={t}
              onReadOutLoud={handleReadOutLoud}
            />
          </div>
        )}

        {/* Results Section */}
        <section id="scheme-results-section" aria-label={t.results.title} className="space-y-4">
          {/* Summary and Controls Header */}
          <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-4 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-stone-200 dark:border-stone-800">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  {t.results.title}
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                    {filteredSchemes.length} Available
                  </span>
                </h2>
                <p className="text-xs text-stone-600 dark:text-stone-400 mt-0.5 font-medium">
                  {t.results.summaryCount(counts.eligible, counts.review, counts.notEligible)}
                </p>
              </div>

              {/* Search Bar */}
              <div className="relative min-w-[240px]">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter by keyword, ministry, benefit..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>
            </div>

            {/* Filter Pills & Sorter */}
            <div className="flex flex-wrap items-center justify-between gap-2.5 pt-3">
              {/* Classification Filter Pills */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => setStatusFilter('ALL')}
                  className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                    statusFilter === 'ALL'
                      ? 'bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                  }`}
                >
                  {t.results.filterAll}
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('ELIGIBLE')}
                  className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                    statusFilter === 'ELIGIBLE'
                      ? 'bg-emerald-700 text-white'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {t.results.filterEligible} ({counts.eligible})
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('MORE_INFO_NEEDED')}
                  className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                    statusFilter === 'MORE_INFO_NEEDED'
                      ? 'bg-amber-600 text-white'
                      : 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-100 border border-amber-200 dark:border-amber-800'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  {t.results.filterReview} ({counts.review})
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('NOT_ELIGIBLE')}
                  className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                    statusFilter === 'NOT_ELIGIBLE'
                      ? 'bg-stone-600 text-white'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200'
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  {t.results.filterNotEligible} ({counts.notEligible})
                </button>
              </div>

              {/* Category & Sort Dropdowns */}
              <div className="flex items-center gap-2">
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value as 'ALL' | SchemeCategory)}
                  className="text-xs px-2.5 py-1 rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-medium cursor-pointer"
                >
                  <option value="ALL">All Categories</option>
                  <option value="housing">Housing Assistance (PMAY)</option>
                  <option value="agriculture">Agriculture & Farmers</option>
                  <option value="employment">Employment & Livelihood</option>
                  <option value="healthcare">Healthcare & Insurance</option>
                  <option value="education">Education & Scholarships</option>
                  <option value="social_welfare">Social Welfare & Pensions</option>
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'match' | 'name')}
                  className="text-xs px-2.5 py-1 rounded-lg border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-medium cursor-pointer"
                >
                  <option value="match">{t.results.sortMatch}</option>
                  <option value="name">{t.results.sortName}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Scheme Cards Grid */}
          {filteredSchemes.length === 0 ? (
            <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-12 text-center">
              <p className="text-stone-500 dark:text-stone-400 font-semibold text-sm">
                {t.results.noSchemesFound}
              </p>
              <button
                type="button"
                onClick={() => {
                  setStatusFilter('ALL');
                  setCategoryFilter('ALL');
                  setSearchQuery('');
                }}
                className="mt-3 px-4 py-2 rounded-lg bg-emerald-700 text-white font-bold text-xs"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
              {filteredSchemes.map(({ scheme, result }) => (
                <SchemeCard
                  key={scheme.id}
                  scheme={scheme}
                  result={result}
                  isShortlisted={shortlistedIds.includes(scheme.id)}
                  onToggleShortlist={toggleShortlist}
                  onOpenDetails={(s) => setDetailsScheme(s)}
                  onAskAI={(s) => handleOpenAiDrawer(s)}
                  onReadOutLoud={handleReadOutLoud}
                  currentLanguage={language}
                  t={t}
                  isTouchToReadActive={isTouchToReadActive}
                />
              ))}
            </div>
          )}
        </section>

        {/* Quick Action Footer Bar */}
        <section className="mt-10 p-5 rounded-2xl bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
              Need Help with Application Documents?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-0.5">
              Generate a printable document checklist with guidance on how to obtain certificates from Tehsildar, CSC, and Food Supply offices.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsChecklistOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs"
            >
              <span>{t.tabs.documentChecklist}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      </main>

      {/* Footer Notice */}
      <footer className="mt-12 border-t border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 py-6 px-4 text-xs text-stone-500 dark:text-stone-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p>
            SchemeSaathi © 2026 • Unified Government Scheme & Housing Assistance Finder • Open Access Citizen Public Tool
          </p>
          <p className="flex items-center gap-2">
            <span>WCAG 2.1 AA Compliant</span>
            <span>•</span>
            <span>Multilingual: EN, हिन्दी, বাংলা, ਪੰਜਾਬੀ, தமிழ்</span>
          </p>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <SchemeDetailsModal
        scheme={detailsScheme}
        onClose={() => setDetailsScheme(null)}
        currentLanguage={language}
        t={t}
        onReadOutLoud={handleReadOutLoud}
      />

      {isChecklistOpen && (
        <DocumentChecklistModal
          schemes={shortlistedSchemes.length > 0 ? shortlistedSchemes : SCHEMES_DATABASE.slice(0, 5)}
          onClose={() => setIsChecklistOpen(false)}
          t={t}
          onReadOutLoud={handleReadOutLoud}
        />
      )}

      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        currentLanguage={language}
        onLanguageChange={setLanguage}
        onApplyVoiceFilter={handleApplyVoiceFilter}
        t={t}
      />

      <AIGuidanceDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        targetScheme={aiTargetScheme}
        profile={profile}
        currentLanguage={language}
        t={t}
      />
    </div>
  );
}
