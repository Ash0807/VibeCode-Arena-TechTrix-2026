import { z } from 'zod';

// ===== Enums and Constants =====
export const SchemeCategory = z.enum([
  'education',
  'healthcare',
  'agriculture',
  'employment',
  'housing',
  'social-welfare',
  'other',
]);
export type SchemeCategory = z.infer<typeof SchemeCategory>;

export const EligibilityStatus = z.enum([
  'Potentially Eligible',
  'More Information Required',
  'Eligibility Criteria Not Met',
]);
export type EligibilityStatus = z.infer<typeof EligibilityStatus>;

export const ResidenceType = z.enum(['rural', 'urban']);
export type ResidenceType = z.infer<typeof ResidenceType>;

export const FeedbackIssueType = z.enum([
  'outdated',
  'broken-link',
  'incorrect-detail',
  'other',
]);
export type FeedbackIssueType = z.infer<typeof FeedbackIssueType>;

// ===== User Profile Schema =====
export const UserProfileSchema = z.object({
  state: z.string().min(1),
  residenceType: ResidenceType,
  ageBand: z.string().min(1),
  occupation: z.string().min(1),
  annualIncomeBand: z.string().min(1),
  householdSize: z.number().int().positive().optional(),
  ownsPuccaHouse: z.enum(['yes', 'no', 'unknown']).optional(),
  isStudent: z.enum(['yes', 'no', 'unknown']).optional(),
  isFarmer: z.enum(['yes', 'no', 'unknown']).optional(),
});
export type UserProfile = z.infer<typeof UserProfileSchema>;

// ===== Eligibility Criterion =====
export const EligibilityCriterionSchema = z.object({
  id: z.string(),
  field: z.string(),
  operator: z.enum(['equals', 'in', 'lte', 'gte', 'between', 'isTrue']),
  value: z.union([
    z.string(),
    z.number(),
    z.boolean(),
    z.array(z.string()),
    z.tuple([z.number(), z.number()]),
  ]),
  description: z.string(),
  required: z.boolean(),
});
export type EligibilityCriterion = z.infer<typeof EligibilityCriterionSchema>;

// ===== Scheme Schema =====
export const SchemeSchema = z.object({
  id: z.string(),
  name: z.string(),
  category: SchemeCategory,
  summary: z.string(),
  purpose: z.string(),
  benefits: z.array(z.string()),
  beneficiaryDescription: z.string(),
  geographicCoverage: z.object({
    states: z.array(z.string()),
    residenceTypes: z.array(ResidenceType).optional(),
  }),
  criteria: z.array(EligibilityCriterionSchema),
  documents: z.array(
    z.object({
      name: z.string(),
      requiredWhen: z.string().optional(),
      notes: z.string().optional(),
    })
  ),
  applicationSteps: z.array(z.string()),
  sourceName: z.string().nullable(),
  sourceUrl: z.string().url().nullable(),
  lastVerifiedAt: z.string().nullable(),
  isDemo: z.boolean(),
  verificationStatus: z.enum(['verified', 'needs-review', 'demo']),
});
export type Scheme = z.infer<typeof SchemeSchema>;

// ===== API Request/Response Schemas =====

// Health
export const HealthResponseSchema = z.object({
  status: z.literal('ok'),
  service: z.string(),
  version: z.string(),
});
export type HealthResponse = z.infer<typeof HealthResponseSchema>;

// List Schemes
export const ListSchemesQuerySchema = z.object({
  category: SchemeCategory.optional(),
  state: z.string().optional(),
  q: z.string().optional(),
  limit: z.coerce.number().int().positive().max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});
export type ListSchemesQuery = z.infer<typeof ListSchemesQuerySchema>;

export const SchemeListItemSchema = z.object({
  id: z.string(),
  name: z.string(),
  category: SchemeCategory,
  summary: z.string(),
  states: z.array(z.string()),
  sourceUrl: z.string().url().nullable(),
  lastVerifiedAt: z.string().nullable(),
  isDemo: z.boolean(),
});
export type SchemeListItem = z.infer<typeof SchemeListItemSchema>;

export const ListSchemesResponseSchema = z.object({
  data: z.array(SchemeListItemSchema),
  pagination: z.object({
    limit: z.number(),
    offset: z.number(),
    total: z.number(),
  }),
});
export type ListSchemesResponse = z.infer<typeof ListSchemesResponseSchema>;

// Scheme Detail
export const SchemeDetailResponseSchema = z.object({
  data: SchemeSchema,
});
export type SchemeDetailResponse = z.infer<typeof SchemeDetailResponseSchema>;

// Eligibility Check
export const EligibilityCheckRequestSchema = z.object({
  profile: UserProfileSchema,
  categories: z.array(SchemeCategory).optional(),
});
export type EligibilityCheckRequest = z.infer<typeof EligibilityCheckRequestSchema>;

export const EligibilityResultSchema = z.object({
  schemeId: z.string(),
  status: EligibilityStatus,
  summary: z.string(),
  matchedCriteria: z.array(z.string()),
  unmetCriteria: z.array(z.string()),
  missingInformation: z.array(z.string()),
  documents: z.array(z.string()),
  confidence: z.string(),
  sourceUrl: z.string().url().nullable(),
  lastVerifiedAt: z.string().nullable(),
  isDemo: z.boolean(),
});
export type EligibilityResult = z.infer<typeof EligibilityResultSchema>;

export const EligibilityCheckResponseSchema = z.object({
  data: z.array(EligibilityResultSchema),
  meta: z.object({
    evaluatedCount: z.number(),
    disclaimer: z.string(),
  }),
});
export type EligibilityCheckResponse = z.infer<typeof EligibilityCheckResponseSchema>;

// Feedback
export const FeedbackRequestSchema = z.object({
  schemeId: z.string(),
  issueType: FeedbackIssueType,
  message: z.string().max(1000).optional(),
});
export type FeedbackRequest = z.infer<typeof FeedbackRequestSchema>;

export const FeedbackResponseSchema = z.object({
  data: z.object({
    received: z.boolean(),
    referenceId: z.string(),
  }),
});
export type FeedbackResponse = z.infer<typeof FeedbackResponseSchema>;

// Error Response
export const ErrorResponseSchema = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    details: z.array(z.any()).optional(),
  }),
  requestId: z.string().optional(),
});
export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;
