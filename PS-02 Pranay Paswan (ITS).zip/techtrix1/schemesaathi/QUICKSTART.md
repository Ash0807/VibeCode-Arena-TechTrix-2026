# 🚀 SchemeSaathi - Quick Start Guide

## Get Running in 2 Minutes!

### Step 1: Open Terminal
Open your terminal/command prompt in the project directory:
```bash
cd d:\techtrix1\schemesaathi
```

### Step 2: Start Development Servers
```bash
npm run dev
```

**That's it!** Both servers will start automatically:
- 🌐 **Frontend:** http://localhost:5173
- 🔌 **API:** http://localhost:3000
- ✅ **Health Check:** http://localhost:3000/api/v1/health

### Step 3: Open in Browser
Open your browser and go to:
```
http://localhost:5173
```

---

## 🎮 Try These Features

### 1. Complete the Questionnaire
1. Click **"Find My Schemes"** on the homepage
2. Fill in your details (3 steps):
   - Personal info (state, age, income)
   - Family details (optional)
   - Review and submit
3. View your personalized recommendations!

### 2. Browse All Schemes
1. Click **"Browse Schemes"** in the navigation
2. Search by keyword or filter by category
3. Click any scheme to see full details

### 3. Shortlist Schemes
1. Click the ❤️ heart icon on any scheme card
2. Access your shortlist from **"My Shortlist"** in navigation
3. Schemes are saved locally (no account needed!)

### 4. Document Checklist
1. Open any scheme detail page
2. Click **"View Document Checklist"**
3. Check off documents as you prepare them
4. Progress is saved automatically

---

## 📱 Test on Mobile

The app is fully responsive! Test it by:
1. Opening DevTools (F12)
2. Click the device toolbar icon (Ctrl+Shift+M)
3. Select a mobile device (e.g., iPhone 12)

---

## 🧪 Verify API is Working

### Test the Health Endpoint:
Open a new terminal and run:
```bash
curl http://localhost:3000/api/v1/health
```

Expected response:
```json
{
  "status": "ok",
  "service": "schemesaathi-api",
  "version": "1.0.0"
}
```

### Test the Schemes Endpoint:
```bash
curl http://localhost:3000/api/v1/schemes
```

You should see 6 demo schemes!

---

## 🛑 Stop the Servers

Press `Ctrl+C` in the terminal where you ran `npm run dev`

---

## 🔧 Troubleshooting

### Port Already in Use?
If ports 3000 or 5173 are busy:

**Change API Port:**
Edit `apps/api/.env`:
```env
PORT=3001
```

**Change Web Port:**
Edit `apps/web/vite.config.ts`:
```typescript
server: {
  port: 5174,
}
```

Then update `apps/web/.env`:
```env
VITE_API_BASE_URL=http://localhost:3001/api/v1
```

### Modules Not Found?
Run:
```bash
npm install
```

### TypeScript Errors?
Run:
```bash
npm run typecheck
```

---

## 📚 Next Steps

- ✅ Read the [README.md](./README.md) for full documentation
- ✅ Check [BUILD_REPORT.md](./BUILD_REPORT.md) for technical details
- ✅ Explore the code in `apps/web/src/pages/`
- ✅ Review API routes in `apps/api/src/routes/`

---

## 💡 Pro Tips

1. **Hot Reload Works!** Edit any file and see changes instantly
2. **Check Browser Console** for helpful error messages
3. **Use DevTools Network Tab** to see API requests
4. **localStorage Inspector** shows your saved profile & shortlist
5. **Test Different Profiles** to see different eligibility results

---

## 🎯 Demo Test Scenarios

### Scenario 1: Student
- **State:** Any state
- **Age:** 18-24
- **Occupation:** Student
- **Income:** 0-150000
- **Is Student:** Yes

**Expected:** Eligible for education schemes

### Scenario 2: Farmer
- **State:** Any state
- **Age:** 35-44
- **Occupation:** Farmer
- **Is Farmer:** Yes

**Expected:** Eligible for agriculture schemes

### Scenario 3: Urban Resident Without House
- **State:** UP
- **Residence:** Urban
- **Owns Pucca House:** No

**Expected:** Eligible for housing schemes

---

**Enjoy exploring SchemeSaathi! 🎉**
