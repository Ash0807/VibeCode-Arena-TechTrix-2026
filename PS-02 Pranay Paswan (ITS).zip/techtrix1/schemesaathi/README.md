# SchemeSaathi

Government scheme discovery platform helping Indian citizens find relevant schemes through transparent, rule-based matching.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm
- Windows/Mac/Linux

### Installation & Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development servers:**
   ```bash
   npm run dev
   ```
   This starts both API and web servers concurrently:
   - **API:** http://localhost:3000
   - **Web:** http://localhost:5173
   - **Health Check:** http://localhost:3000/api/v1/health

3. **Start servers individually (optional):**
   ```bash
   npm run dev:api    # Start backend only
   npm run dev:web    # Start frontend only
   ```

4. **Build for production:**
   ```bash
   npm run build
   ```

5. **Run tests:**
   ```bash
   npm test
   ```

6. **Type checking:**
   ```bash
   npm run typecheck
   ```

## 📁 Project Structure

```
schemesaathi/
├── apps/
│   ├── api/                      # Express backend
│   │   ├── src/
│   │   │   ├── data/             # Scheme data (JSON)
│   │   │   ├── repositories/     # Data access layer
│   │   │   ├── services/         # Business logic
│   │   │   ├── routes/           # API routes
│   │   │   ├── middleware/       # Express middleware
│   │   │   ├── app.ts           # Express app setup
│   │   │   └── server.ts        # Server entry point
│   │   └── package.json
│   │
│   └── web/                      # React frontend
│       ├── src/
│       │   ├── components/       # Shared UI components
│       │   ├── pages/            # Route pages
│       │   ├── lib/              # Utilities (API, storage)
│       │   ├── styles/           # Global styles
│       │   ├── App.tsx           # Main app with routing
│       │   └── main.tsx          # Entry point
│       └── package.json
│
├── packages/
│   └── contracts/                # Shared TypeScript types
│       └── src/index.ts          # Zod schemas & types
│
├── .env.example                  # Environment template
└── package.json                  # Root workspace config
```

## 🔧 Environment Variables

### Backend (`apps/api/.env`)
```env
NODE_ENV=development
PORT=3000
CORS_ORIGINS=http://localhost:5173
```

### Frontend (`apps/web/.env`)
```env
VITE_API_BASE_URL=http://localhost:3000/api/v1
```

## 🛠️ Tech Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool & dev server
- **Tailwind CSS** - Styling
- **React Router** - Navigation
- **Lucide React** - Icons

### Backend
- **Node.js + Express** - Server framework
- **TypeScript** - Type safety
- **Zod** - Schema validation
- **Helmet** - Security headers
- **CORS** - Cross-origin support
- **Rate Limiting** - API protection

### Shared
- **Zod** - Shared validation schemas
- **npm workspaces** - Monorepo management

## 📋 Available Scripts

### Root Level
- `npm run dev` - Start both API and web servers
- `npm run dev:api` - Start backend only
- `npm run dev:web` - Start frontend only
- `npm run build` - Build all packages
- `npm run test` - Run all tests
- `npm run lint` - Lint all packages
- `npm run typecheck` - Type check all packages

### API (from apps/api)
- `npm run dev` - Start dev server with watch mode
- `npm run build` - Compile TypeScript to dist/
- `npm start` - Run production build
- `npm test` - Run tests

### Web (from apps/web)
- `npm run dev` - Start Vite dev server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## 🎯 Key Features

✅ **Personalized Matching** - Rule-based eligibility engine  
✅ **Transparent Explanations** - Clear reasons for each status  
✅ **Document Checklists** - Track application requirements  
✅ **Scheme Shortlisting** - Save schemes for later  
✅ **Privacy-First** - Local storage, no sensitive data collected  
✅ **Responsive Design** - Mobile-first, accessible UI  
✅ **Demo Data** - 6 sample schemes across categories  

## 📊 API Endpoints

### Health Check
```
GET /api/v1/health
```

### List Schemes
```
GET /api/v1/schemes?category=education&state=UP&q=scholarship&limit=20&offset=0
```

### Scheme Details
```
GET /api/v1/schemes/:id
```

### Eligibility Check
```
POST /api/v1/eligibility/check
Body: { profile: {...}, categories: [...] }
```

### Feedback
```
POST /api/v1/feedback
Body: { schemeId: "...", issueType: "...", message: "..." }
```

## 🎨 Design System

### Color Palette
- **Main Background:** `#DDF2FF`
- **Section Background:** `#F3F9FF`
- **Primary Blue:** `#1264D8`
- **Navy Text:** `#12304A`
- **Teal Accent:** `#087F72`
- **Border:** `#C8E4F7`
- **Muted Text:** `#5C7185`

## 🚨 Important Notes

### Eligibility Statuses (Exact Labels)
1. **Potentially Eligible** - Profile matches preliminary criteria
2. **More Information Required** - Missing answers needed
3. **Eligibility Criteria Not Met** - One or more criteria not satisfied

### Data Privacy
- ✅ Collects: State, age band, income band, occupation
- ❌ Never collects: Aadhaar, bank details, OTPs, addresses, documents
- 💾 Storage: localStorage (client-side only)

### Disclaimer
SchemeSaathi is an independent project providing preliminary guidance only. Recommendations are NOT official eligibility decisions. Always verify details on official government portals before applying.

## 🐛 Known Limitations (MVP)

- Demo scheme data needs verification
- No authentication/user accounts
- No database (using JSON seed data)
- Basic feedback collection (no persistence backend)
- Limited error recovery scenarios

## 🔜 Future Enhancements

- PostgreSQL database integration
- User authentication
- Admin dashboard for scheme management
- Advanced search and filters
- Multi-language support
- Email notifications
- Application tracking

## 📝 Development Workflow

1. Make changes to code
2. Servers auto-reload (watch mode)
3. Test in browser: http://localhost:5173
4. Check API: http://localhost:3000/api/v1/health
5. Run type checks: `npm run typecheck`
6. Build for production: `npm run build`

## 🚀 Deployment

### Backend (Render/Railway)
1. Push to Git repository
2. Connect repository to Render/Railway
3. Set environment variables (PORT, CORS_ORIGINS)
4. Deploy from `apps/api` directory
5. Build command: `npm run build`
6. Start command: `npm start`

### Frontend (Vercel/Netlify)
1. Connect repository to Vercel/Netlify
2. Set build directory: `apps/web`
3. Set environment variable: `VITE_API_BASE_URL`
4. Build command: `npm run build`
5. Publish directory: `dist`

## 📄 License

MIT - See LICENSE file for details

## 🤝 Contributing

This is an MVP project. For production use, please:
1. Verify all scheme data with official sources
2. Add comprehensive tests
3. Implement proper database
4. Add security audit
5. Set up monitoring and logging

---

**Built with ❤️ for Indian citizens seeking government scheme information**
