/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'brand-bg': '#DDF2FF',
        'brand-section': '#F3F9FF',
        'brand-primary': '#1264D8',
        'brand-navy': '#12304A',
        'brand-teal': '#087F72',
        'brand-border': '#C8E4F7',
        'brand-muted': '#5C7185',
      },
    },
  },
  plugins: [],
}
