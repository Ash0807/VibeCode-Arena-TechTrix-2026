# How to Add Real Images to SchemeSaathi

## Hero Section Image

### Current Status
- **Location:** `public/hero-family.svg`
- **Type:** SVG illustration (placeholder)
- **Used in:** Home page hero section

### How to Replace with Real Photo

#### Option 1: Use Your Own Image

1. **Prepare your image:**
   - Recommended size: 800x600px or similar 4:3 aspect ratio
   - Format: JPG, PNG, or WebP
   - Optimize for web (keep under 500KB)
   - Image should show: Happy Indian family using mobile/tablet

2. **Add to project:**
   ```bash
   # Copy your image to the public folder
   # Name it: hero-family.jpg (or .png, .webp)
   cp /path/to/your/image.jpg apps/web/public/hero-family.jpg
   ```

3. **Update the code:**
   
   Edit: `apps/web/src/pages/Home.tsx`
   
   Find this line:
   ```tsx
   <img 
     src="/hero-family.svg" 
     alt="Happy Indian Family using Government Schemes"
     className="w-full h-auto"
   />
   ```
   
   Change to:
   ```tsx
   <img 
     src="/hero-family.jpg" 
     alt="Happy Indian Family using Government Schemes"
     className="w-full h-auto object-cover aspect-[4/3]"
   />
   ```

#### Option 2: Use Stock Photos

**Recommended Free Stock Photo Sites:**
- **Unsplash:** https://unsplash.com/s/photos/indian-family
- **Pexels:** https://www.pexels.com/search/indian%20family/
- **Pixabay:** https://pixabay.com/images/search/indian%20family/

**Search Keywords:**
- "Indian family technology"
- "Indian family mobile phone"
- "Happy Indian family"
- "Indian family digital"

**License:** Make sure to use images with appropriate licenses (CC0, free for commercial use)

#### Option 3: Use Illustrations

**Free Illustration Resources:**
- **unDraw:** https://undraw.co/illustrations
- **Freepik:** https://www.freepik.com/ (check license)
- **DrawKit:** https://www.drawkit.com/
- **Humaaans:** https://www.humaaans.com/

## Other Images You Can Add

### 1. Category Icons
- **Location:** Currently using Lucide icons
- **Can be replaced with:** Custom SVG icons or images
- **Edit:** `apps/web/src/pages/Home.tsx` (categories array)

### 2. Favicon
- **Location:** `apps/web/public/`
- **Current:** Using Vite default
- **Add:** 
  ```bash
  # Add your favicon
  cp favicon.ico apps/web/public/favicon.ico
  ```
- **Update:** `apps/web/index.html`
  ```html
  <link rel="icon" type="image/x-icon" href="/favicon.ico" />
  ```

### 3. Open Graph Image (for social sharing)
- **Recommended size:** 1200x630px
- **Add to:** `apps/web/public/og-image.jpg`
- **Update:** `apps/web/index.html`
  ```html
  <meta property="og:image" content="/og-image.jpg" />
  ```

### 4. Scheme Category Images
You can add images for each scheme category:
- Education: `public/categories/education.jpg`
- Healthcare: `public/categories/healthcare.jpg`
- Housing: `public/categories/housing.jpg`
- Agriculture: `public/categories/agriculture.jpg`
- Employment: `public/categories/employment.jpg`
- Social Welfare: `public/categories/social-welfare.jpg`

## Image Optimization Tips

### 1. Compress Images
```bash
# Using online tools:
- TinyPNG: https://tinypng.com/
- Squoosh: https://squoosh.app/
- ImageOptim (Mac): https://imageoptim.com/
```

### 2. Use WebP Format
```bash
# Convert to WebP for better performance
# Using online tools or:
npm install -g webp-converter
webp-converter convert hero-family.jpg -o hero-family.webp
```

### 3. Lazy Loading
For images below the fold, add lazy loading:
```tsx
<img loading="lazy" src="/image.jpg" alt="..." />
```

### 4. Responsive Images
Use srcset for different screen sizes:
```tsx
<img 
  src="/hero-family.jpg"
  srcset="/hero-family-small.jpg 600w,
          /hero-family-medium.jpg 1200w,
          /hero-family-large.jpg 1800w"
  sizes="(max-width: 768px) 100vw, 50vw"
  alt="Happy Indian Family"
/>
```

## Image Attribution

If using stock photos or illustrations, add attribution:

1. **In the footer** (`apps/web/src/components/Layout.tsx`):
```tsx
<p className="text-xs text-brand-muted mt-4">
  Hero image by [Photographer Name] on Unsplash
</p>
```

2. **Or create an attribution page:** `/about#attribution`

## Testing Images

After adding images:

1. **Check file size:**
   ```bash
   ls -lh apps/web/public/*.jpg
   ```

2. **Test in browser:**
   - Open http://localhost:5173
   - Check Network tab in DevTools
   - Ensure image loads quickly

3. **Test responsive:**
   - Resize browser window
   - Check mobile view (DevTools → Device Toolbar)

## Performance Checklist

- [ ] Images are optimized (< 500KB each)
- [ ] Using modern formats (WebP where possible)
- [ ] Alt text is descriptive
- [ ] Images have proper aspect ratios
- [ ] Lazy loading for below-fold images
- [ ] Proper attribution where required

## Quick Reference

| Image Type | Location | Size | Format |
|------------|----------|------|--------|
| Hero | `public/hero-family.*` | 800x600px | JPG/PNG/WebP |
| Favicon | `public/favicon.ico` | 32x32px | ICO |
| OG Image | `public/og-image.jpg` | 1200x630px | JPG |
| Categories | `public/categories/*` | 400x300px | JPG/PNG |

---

**Need Help?** Check the [Vite Static Assets docs](https://vitejs.dev/guide/assets.html)
