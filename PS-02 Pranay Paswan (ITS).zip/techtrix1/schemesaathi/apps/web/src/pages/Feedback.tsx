import { useState } from 'react';
import { MessageSquare, CheckCircle } from 'lucide-react';
import { FeedbackRequest } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';

export function Feedback() {
  const [formData, setFormData] = useState<FeedbackRequest>({
    schemeId: '',
    issueType: 'other',
    message: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    if (!formData.schemeId.trim()) {
      setError('Please enter a scheme ID or name');
      setLoading(false);
      return;
    }

    try {
      await apiClient.submitFeedback(formData);
      setSuccess(true);
      setFormData({ schemeId: '', issueType: 'other', message: '' });
    } catch (err: any) {
      setError(err.message || 'Failed to submit feedback. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card text-center">
            <CheckCircle size={64} className="text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-brand-navy mb-4">
              Thank You for Your Feedback
            </h2>
            <p className="text-brand-muted mb-6">
              Your feedback has been received and will help us improve the platform.
            </p>
            <button
              onClick={() => setSuccess(false)}
              className="btn-primary"
            >
              Submit More Feedback
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-2">Feedback</h1>
          <p className="text-brand-muted">
            Help us improve by reporting issues or sharing suggestions
          </p>
        </div>

        <div className="card">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="label">
                Scheme ID or Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                className="input-field"
                value={formData.schemeId}
                onChange={(e) =>
                  setFormData({ ...formData, schemeId: e.target.value })
                }
                placeholder="e.g., demo-edu-001 or National Scholarship"
                required
              />
              <p className="text-sm text-brand-muted mt-1">
                The scheme ID or name this feedback relates to
              </p>
            </div>

            <div>
              <label className="label">
                Issue Type <span className="text-red-500">*</span>
              </label>
              <select
                className="input-field"
                value={formData.issueType}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    issueType: e.target.value as FeedbackRequest['issueType'],
                  })
                }
                required
              >
                <option value="outdated">Outdated Information</option>
                <option value="broken-link">Broken Link</option>
                <option value="incorrect-detail">Incorrect Details</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="label">Additional Details (Optional)</label>
              <textarea
                className="input-field"
                rows={5}
                maxLength={1000}
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                placeholder="Please provide more details about the issue..."
              />
              <p className="text-sm text-brand-muted mt-1">
                {(formData.message || '').length}/1000 characters
              </p>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center space-x-2"
              disabled={loading}
            >
              <MessageSquare size={20} />
              <span>{loading ? 'Submitting...' : 'Submit Feedback'}</span>
            </button>
          </form>

          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-900">
              <strong>Note:</strong> This feedback helps us maintain accurate scheme information.
              For application support or official queries, please contact the relevant government
              department directly.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
