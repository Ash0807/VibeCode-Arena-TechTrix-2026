import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ExternalLink } from 'lucide-react';
import { Scheme } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function Shortlist() {
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadShortlist();
  }, []);

  const loadShortlist = async () => {
    const shortlistIds = storage.getShortlist();
    
    if (shortlistIds.length === 0) {
      setLoading(false);
      return;
    }

    try {
      const schemePromises = shortlistIds.map(id => apiClient.getSchemeById(id));
      const responses = await Promise.allSettled(schemePromises);
      
      const loadedSchemes = responses
        .filter((result): result is PromiseFulfilledResult<any> => result.status === 'fulfilled')
        .map(result => result.value.data);
      
      setSchemes(loadedSchemes);
    } catch (err) {
      console.error('Failed to load shortlist:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = (schemeId: string) => {
    storage.removeFromShortlist(schemeId);
    setSchemes(schemes.filter(s => s.id !== schemeId));
  };

  if (loading) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
            <p className="text-brand-muted">Loading your shortlist...</p>
          </div>
        </div>
      </div>
    );
  }

  if (schemes.length === 0) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-8">My Shortlist</h1>
          <div className="card text-center max-w-2xl mx-auto">
            <Heart size={48} className="text-brand-muted mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-brand-navy mb-4">
              Your Shortlist is Empty
            </h2>
            <p className="text-brand-muted mb-6">
              Start exploring schemes and save the ones you're interested in for easy access later.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/check" className="btn-primary">
                Find My Schemes
              </Link>
              <Link to="/schemes" className="btn-secondary">
                Explore All Schemes
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-2">My Shortlist</h1>
          <p className="text-brand-muted">
            {schemes.length} saved scheme{schemes.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {schemes.map((scheme) => (
            <div key={scheme.id} className="card hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <span className="text-xs font-medium text-brand-primary uppercase">
                  {scheme.category.replace('-', ' ')}
                </span>
                <button
                  onClick={() => handleRemove(scheme.id)}
                  className="text-red-500 hover:text-red-700 transition-colors"
                  aria-label="Remove from shortlist"
                >
                  <Trash2 size={20} />
                </button>
              </div>

              <Link
                to={`/schemes/${scheme.id}`}
                className="text-lg font-semibold text-brand-navy hover:text-brand-primary mb-2 block"
              >
                {scheme.name}
              </Link>

              {scheme.isDemo && (
                <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded mb-2 inline-block">
                  Demo Data
                </span>
              )}

              <p className="text-brand-muted text-sm mb-4 line-clamp-3">
                {scheme.summary}
              </p>

              <div className="flex items-center justify-between">
                <Link
                  to={`/schemes/${scheme.id}`}
                  className="text-brand-primary hover:text-blue-700 font-medium text-sm flex items-center space-x-1"
                >
                  <span>View Details</span>
                  <ExternalLink size={14} />
                </Link>
                <Link
                  to={`/checklist/${scheme.id}`}
                  className="text-brand-teal hover:text-teal-700 text-sm font-medium"
                >
                  Checklist
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
