import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

export function Help() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'How does SchemeSaathi work?',
      answer:
        'SchemeSaathi uses a rule-based matching system. You answer questions about your circumstances, and we evaluate which schemes you might be eligible for based on their documented criteria.',
    },
    {
      question: 'What do the eligibility statuses mean?',
      answer:
        '"Potentially Eligible" means your profile matches the criteria we have. "More Information Required" means some answers are missing. "Eligibility Criteria Not Met" means based on your answers, you don\'t meet one or more required criteria.',
    },
    {
      question: 'Are these official eligibility decisions?',
      answer:
        'No. These are preliminary recommendations only. The final eligibility decision is made by the official scheme authorities after you apply through their portal.',
    },
    {
      question: 'Do I need to create an account?',
      answer:
        'No. In the MVP version, your answers and shortlist are saved locally on your device. No account is required.',
    },
    {
      question: 'What information do you collect?',
      answer:
        'We only collect information needed for eligibility matching: state, age band, income band, occupation, and similar non-sensitive details. We do NOT collect Aadhaar numbers, bank details, OTPs, or identity documents.',
    },
    {
      question: 'How do I verify scheme details?',
      answer:
        'Always check the official source link provided on each scheme\'s detail page. Verify benefits, criteria, and document requirements before applying.',
    },
    {
      question: 'What if a scheme link is broken?',
      answer:
        'You can report issues using the Feedback form. We regularly verify scheme information, but details can change.',
    },
    {
      question: 'Can I apply through SchemeSaathi?',
      answer:
        'No. SchemeSaathi helps you discover schemes. You must apply through the official government portal for each scheme.',
    },
  ];

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-2">Help & FAQs</h1>
          <p className="text-brand-muted">
            Find answers to common questions about using SchemeSaathi
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="card">
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex justify-between items-center text-left"
              >
                <h3 className="text-lg font-semibold text-brand-navy pr-4">
                  {faq.question}
                </h3>
                {openIndex === index ? (
                  <ChevronUp className="text-brand-primary flex-shrink-0" size={24} />
                ) : (
                  <ChevronDown className="text-brand-primary flex-shrink-0" size={24} />
                )}
              </button>
              {openIndex === index && (
                <p className="text-brand-muted mt-4 leading-relaxed">{faq.answer}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
