import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, AlertCircle, Info, Heart, ExternalLink } from 'lucide-react';
import { EligibilityResult } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function Results() {
  const [results, setResults] = useState<EligibilityResult[]>([]);
  const [filteredResults, setFilteredResults] = useState<EligibilityResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [shortlist, setShortlist] = useState<string[]>([]);

  useEffect(() => {
    loadResults();
    setShortlist(storage.getShortlist());
  }, []);

  useEffect(() => {
    filterResults();
  }, [results, activeFilter]);

  const loadResults = async () => {
    const profile = storage.getProfile();
    if (!profile) {
      setError('No profile found. Please complete the questionnaire first.');
      setLoading(false);
      return;
    }

    try {
      const response = await apiClient.checkEligibility({ profile });
      setResults(response.data);
      setLoading(false);
    } catch (err: any) {
      setError(err.message || 'Failed to load results');
      setLoading(false);
    }
  };

  const filterResults = () => {
    if (activeFilter === 'all') {
      setFilteredResults(results);
    } else {
      setFilteredResults(results.filter((r) => {
        if (activeFilter === 'eligible') return r.status === 'Potentially Eligible';
        if (activeFilter === 'more-info') return r.status === 'More Information Required';
        if (activeFilter === 'not-eligible') return r.status === 'Eligibility Criteria Not Met';
        return true;
      }));
    }
  };

  const toggleShortlist = (schemeId: string) => {
    if (storage.isInShortlist(schemeId)) {
      storage.removeFromShortlist(schemeId);
    } else {
      storage.saveToShortlist(schemeId);
    }
    setShortlist(storage.getShortlist());
  };

  const getStatusColor = (status: string) => {
    if (status === 'Potentially Eligible') return 'text-green-700 bg-green-50 border-green-200';
    if (status === 'More Information Required') return 'text-amber-700 bg-amber-50 border-amber-200';
    return 'text-red-700 bg-red-50 border-red-200';
  };

  const getStatusIcon = (status: string) => {
    if (status === 'Potentially Eligible') return <CheckCircle size={20} className="text-green-600" />;
    if (status === 'More Information Required') return <Info size={20} className="text-amber-600" />;
    return <AlertCircle size={20} className="text-red-600" />;
  };

  if (loading) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
            <p className="text-brand-muted">Analyzing your profile...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card max-w-2xl mx-auto text-center">
            <AlertCircle size={48} className="text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-brand-navy mb-4">Error Loading Results</h2>
            <p className="text-brand-muted mb-6">{error}</p>
            <Link to="/check" className="btn-primary inline-block">
              Try Again
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card max-w-2xl mx-auto text-center">
            <Info size={48} className="text-brand-muted mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-brand-navy mb-4">
              No Matching Schemes Found
            </h2>
            <p className="text-brand-muted mb-6">
              We couldn't find any schemes matching your profile. This doesn't mean you're
              ineligible for all government schemes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/check" className="btn-primary">
                Update My Answers
              </Link>
              <Link to="/schemes" className="btn-secondary">
                Explore All Schemes
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-2">
            Your Recommended Schemes
          </h1>
          <p className="text-brand-muted">
            Found {results.length} scheme{results.length !== 1 ? 's' : ''} based on your profile
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeFilter === 'all'
                ? 'bg-brand-primary text-white'
                : 'bg-white text-brand-navy border border-brand-border hover:bg-brand-section'
            }`}
          >
            All ({results.length})
          </button>
          <button
            onClick={() => setActiveFilter('eligible')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeFilter === 'eligible'
                ? 'bg-green-600 text-white'
                : 'bg-white text-brand-navy border border-brand-border hover:bg-brand-section'
            }`}
          >
            Potentially Eligible ({results.filter(r => r.status === 'Potentially Eligible').length})
          </button>
          <button
            onClick={() => setActiveFilter('more-info')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeFilter === 'more-info'
                ? 'bg-amber-600 text-white'
                : 'bg-white text-brand-navy border border-brand-border hover:bg-brand-section'
            }`}
          >
            More Info Needed ({results.filter(r => r.status === 'More Information Required').length})
          </button>
          <button
            onClick={() => setActiveFilter('not-eligible')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeFilter === 'not-eligible'
                ? 'bg-red-600 text-white'
                : 'bg-white text-brand-navy border border-brand-border hover:bg-brand-section'
            }`}
          >
            Not Eligible ({results.filter(r => r.status === 'Eligibility Criteria Not Met').length})
          </button>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {filteredResults.map((result) => (
            <div key={result.schemeId} className="card">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <Link
                    to={`/schemes/${result.schemeId}`}
                    className="text-xl font-semibold text-brand-navy hover:text-brand-primary"
                  >
                    {result.schemeId.replace('demo-', '').replace(/-/g, ' ')}
                  </Link>
                  {result.isDemo && (
                    <span className="ml-2 text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">
                      Demo Data
                    </span>
                  )}
                </div>
                <button
                  onClick={() => toggleShortlist(result.schemeId)}
                  className="text-brand-muted hover:text-red-500 transition-colors"
                  aria-label={shortlist.includes(result.schemeId) ? 'Remove from shortlist' : 'Add to shortlist'}
                >
                  <Heart
                    size={24}
                    fill={shortlist.includes(result.schemeId) ? 'currentColor' : 'none'}
                  />
                </button>
              </div>

              <div className={`inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg border mb-4 ${getStatusColor(result.status)}`}>
                {getStatusIcon(result.status)}
                <span className="font-medium text-sm">{result.status}</span>
              </div>

              <p className="text-brand-muted mb-4">{result.summary}</p>

              {result.matchedCriteria.length > 0 && (
                <div className="mb-3">
                  <h4 className="text-sm font-semibold text-green-700 mb-2">✓ Matched Criteria:</h4>
                  <ul className="text-sm text-brand-muted space-y-1">
                    {result.matchedCriteria.map((criteria, idx) => (
                      <li key={idx}>• {criteria}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.unmetCriteria.length > 0 && (
                <div className="mb-3">
                  <h4 className="text-sm font-semibold text-red-700 mb-2">✗ Unmet Criteria:</h4>
                  <ul className="text-sm text-brand-muted space-y-1">
                    {result.unmetCriteria.map((criteria, idx) => (
                      <li key={idx}>• {criteria}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.missingInformation.length > 0 && (
                <div className="mb-3">
                  <h4 className="text-sm font-semibold text-amber-700 mb-2">? Missing Information:</h4>
                  <ul className="text-sm text-brand-muted space-y-1">
                    {result.missingInformation.map((field, idx) => (
                      <li key={idx}>• {field.replace(/([A-Z])/g, ' $1').toLowerCase()}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="flex flex-wrap gap-3 mt-4">
                <Link
                  to={`/schemes/${result.schemeId}`}
                  className="text-brand-primary hover:text-blue-700 font-medium text-sm flex items-center space-x-1"
                >
                  <span>View Details</span>
                  <ExternalLink size={16} />
                </Link>
                {result.documents.length > 0 && (
                  <Link
                    to={`/checklist/${result.schemeId}`}
                    className="text-brand-primary hover:text-blue-700 font-medium text-sm"
                  >
                    Document Checklist ({result.documents.length})
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-sm text-amber-900">
            <strong>Important:</strong> These are preliminary matches, not official eligibility
            decisions. Always verify details on official government portals before applying.
          </p>
        </div>
      </div>
    </div>
  );
}
