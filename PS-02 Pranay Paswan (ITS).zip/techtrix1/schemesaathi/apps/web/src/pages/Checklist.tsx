import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, CheckSquare, Square, ExternalLink, Printer } from 'lucide-react';
import { Scheme } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function Checklist() {
  const { id } = useParams<{ id: string }>();
  const [scheme, setScheme] = useState<Scheme | null>(null);
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadSchemeAndChecklist();
    }
  }, [id]);

  const loadSchemeAndChecklist = async () => {
    if (!id) return;

    try {
      const response = await apiClient.getSchemeById(id);
      setScheme(response.data);
      setChecklist(storage.getChecklist(id));
    } catch (err) {
      console.error('Failed to load scheme:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleDocument = (docName: string) => {
    if (!id) return;

    const updated = { ...checklist, [docName]: !checklist[docName] };
    setChecklist(updated);
    storage.updateChecklist(id, updated);
  };

  const resetChecklist = () => {
    if (!id) return;
    
    if (confirm('Are you sure you want to reset this checklist?')) {
      setChecklist({});
      storage.clearChecklist(id);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading || !scheme) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
            <p className="text-brand-muted">Loading checklist...</p>
          </div>
        </div>
      </div>
    );
  }

  const completedCount = Object.values(checklist).filter(Boolean).length;
  const totalCount = scheme.documents.length;
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 print:hidden">
          <Link
            to={`/schemes/${scheme.id}`}
            className="text-brand-primary hover:text-blue-700 flex items-center space-x-2"
          >
            <ArrowLeft size={20} />
            <span>Back to Scheme Details</span>
          </Link>
        </div>

        <div className="card">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-brand-navy mb-2">
              Document Checklist
            </h1>
            <h2 className="text-xl text-brand-muted">{scheme.name}</h2>
          </div>

          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-brand-navy">
                Progress: {completedCount} of {totalCount} prepared
              </span>
              <span className="text-sm font-medium text-brand-navy">
                {progress}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-brand-primary h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Documents */}
          {scheme.documents.length > 0 ? (
            <div className="space-y-3 mb-8">
              {scheme.documents.map((doc, idx) => (
                <div
                  key={idx}
                  className="flex items-start space-x-3 p-4 bg-brand-section rounded-lg hover:bg-blue-100 transition-colors cursor-pointer"
                  onClick={() => toggleDocument(doc.name)}
                >
                  <button
                    className="flex-shrink-0 mt-1"
                    aria-label={checklist[doc.name] ? 'Mark as not prepared' : 'Mark as prepared'}
                  >
                    {checklist[doc.name] ? (
                      <CheckSquare size={24} className="text-brand-primary" />
                    ) : (
                      <Square size={24} className="text-brand-muted" />
                    )}
                  </button>
                  <div className="flex-1">
                    <p
                      className={`font-medium ${
                        checklist[doc.name] ? 'text-brand-navy line-through' : 'text-brand-navy'
                      }`}
                    >
                      {doc.name}
                    </p>
                    {doc.notes && (
                      <p className="text-sm text-brand-muted mt-1">{doc.notes}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-brand-muted">
              <p>No document requirements available for this scheme.</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-wrap gap-4 pt-6 border-t border-brand-border print:hidden">
            <button onClick={resetChecklist} className="btn-secondary">
              Reset Checklist
            </button>
            <button onClick={handlePrint} className="btn-secondary flex items-center space-x-2">
              <Printer size={20} />
              <span>Print Checklist</span>
            </button>
            {scheme.sourceUrl && (
              <a
                href={scheme.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary flex items-center space-x-2"
              >
                <span>Visit Official Portal</span>
                <ExternalLink size={20} />
              </a>
            )}
          </div>

          {/* Notice */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-900">
              <strong>Important:</strong> Document requirements should be confirmed on the official
              portal. Requirements may vary by location and can change without notice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
