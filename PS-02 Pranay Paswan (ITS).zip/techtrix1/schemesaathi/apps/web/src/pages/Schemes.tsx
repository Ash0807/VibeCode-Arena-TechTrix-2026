import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, Heart, ExternalLink } from 'lucide-react';
import { SchemeListItem } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function Schemes() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [schemes, setSchemes] = useState<SchemeListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [shortlist, setShortlist] = useState<string[]>([]);

  const categoryFilter = searchParams.get('category') || '';

  useEffect(() => {
    loadSchemes();
    setShortlist(storage.getShortlist());
  }, [categoryFilter]);

  const loadSchemes = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await apiClient.listSchemes({
        category: categoryFilter as any,
        q: searchQuery || undefined,
      });
      setSchemes(response.data);
    } catch (err: any) {
      setError(err.message || 'Failed to load schemes');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadSchemes();
  };

  const toggleShortlist = (schemeId: string) => {
    if (storage.isInShortlist(schemeId)) {
      storage.removeFromShortlist(schemeId);
    } else {
      storage.saveToShortlist(schemeId);
    }
    setShortlist(storage.getShortlist());
  };

  const categories = [
    { value: '', label: 'All Categories' },
    { value: 'education', label: 'Education' },
    { value: 'healthcare', label: 'Healthcare' },
    { value: 'housing', label: 'Housing' },
    { value: 'agriculture', label: 'Agriculture' },
    { value: 'employment', label: 'Employment' },
    { value: 'social-welfare', label: 'Social Welfare' },
  ];

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-brand-navy mb-2">
            Browse All Schemes
          </h1>
          <p className="text-brand-muted">
            Explore government schemes across different categories
          </p>
        </div>

        {/* Search and Filters */}
        <div className="card mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brand-muted" size={20} />
                  <input
                    type="text"
                    placeholder="Search schemes by name or keyword..."
                    className="input-field pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <button type="submit" className="btn-primary">
                Search
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.value}
                  type="button"
                  onClick={() => {
                    if (cat.value) {
                      setSearchParams({ category: cat.value });
                    } else {
                      setSearchParams({});
                    }
                  }}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    categoryFilter === cat.value
                      ? 'bg-brand-primary text-white'
                      : 'bg-white text-brand-navy border border-brand-border hover:bg-brand-section'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </form>
        </div>

        {/* Results */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
            <p className="text-brand-muted">Loading schemes...</p>
          </div>
        ) : error ? (
          <div className="card text-center">
            <p className="text-red-600 mb-4">{error}</p>
            <button onClick={loadSchemes} className="btn-primary">
              Retry
            </button>
          </div>
        ) : schemes.length === 0 ? (
          <div className="card text-center">
            <p className="text-brand-muted mb-4">No schemes found matching your criteria.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSearchParams({});
              }}
              className="btn-secondary"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div>
            <p className="text-brand-muted mb-4">
              Found {schemes.length} scheme{schemes.length !== 1 ? 's' : ''}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {schemes.map((scheme) => (
                <div key={scheme.id} className="card hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-xs font-medium text-brand-primary uppercase">
                      {scheme.category.replace('-', ' ')}
                    </span>
                    <button
                      onClick={() => toggleShortlist(scheme.id)}
                      className="text-brand-muted hover:text-red-500 transition-colors"
                      aria-label={shortlist.includes(scheme.id) ? 'Remove from shortlist' : 'Add to shortlist'}
                    >
                      <Heart
                        size={20}
                        fill={shortlist.includes(scheme.id) ? 'currentColor' : 'none'}
                      />
                    </button>
                  </div>

                  <Link
                    to={`/schemes/${scheme.id}`}
                    className="text-lg font-semibold text-brand-navy hover:text-brand-primary mb-2 block"
                  >
                    {scheme.name}
                  </Link>

                  {scheme.isDemo && (
                    <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded mb-2 inline-block">
                      Demo Data - Needs Verification
                    </span>
                  )}

                  <p className="text-brand-muted text-sm mb-4 line-clamp-3">
                    {scheme.summary}
                  </p>

                  <div className="flex items-center justify-between">
                    <Link
                      to={`/schemes/${scheme.id}`}
                      className="text-brand-primary hover:text-blue-700 font-medium text-sm flex items-center space-x-1"
                    >
                      <span>View Details</span>
                      <ExternalLink size={14} />
                    </Link>
                    {scheme.sourceUrl && (
                      <a
                        href={scheme.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-brand-teal hover:text-teal-700 text-xs"
                      >
                        Official Link
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
