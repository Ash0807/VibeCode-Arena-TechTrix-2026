export function About() {
  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="card">
          <h1 className="text-3xl font-bold text-brand-navy mb-6">About SchemeSaathi</h1>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">Our Mission</h2>
            <p className="text-brand-muted leading-relaxed">
              SchemeSaathi helps Indian citizens discover relevant government schemes through a
              transparent, rule-based preliminary matching process. We aim to make information about
              public welfare schemes more accessible and easier to understand.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">How It Works</h2>
            <p className="text-brand-muted leading-relaxed mb-4">
              Our platform uses a deterministic rule engine to evaluate your profile against scheme
              eligibility criteria. When you complete the questionnaire, we:
            </p>
            <ol className="list-decimal list-inside space-y-2 text-brand-muted">
              <li>Match your answers against documented scheme criteria</li>
              <li>Show you which criteria you meet or don't meet</li>
              <li>Identify what information is missing</li>
              <li>Provide clear explanations for each recommendation</li>
            </ol>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">
              Understanding Eligibility Statuses
            </h2>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h3 className="font-semibold text-green-800 mb-2">Potentially Eligible</h3>
                <p className="text-sm text-green-700">
                  Your profile matches the preliminary criteria we have for this scheme. This is not
                  a guarantee of approval—you must still apply through official channels.
                </p>
              </div>
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <h3 className="font-semibold text-amber-800 mb-2">More Information Required</h3>
                <p className="text-sm text-amber-700">
                  We're missing some answers needed to evaluate this scheme. You can update your
                  profile to provide more information.
                </p>
              </div>
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <h3 className="font-semibold text-red-800 mb-2">Eligibility Criteria Not Met</h3>
                <p className="text-sm text-red-700">
                  Based on your answers, one or more required criteria are not met. However, scheme
                  rules can be complex—verify on the official portal.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">Source Verification</h2>
            <p className="text-brand-muted leading-relaxed">
              We strive to maintain accurate scheme information from official sources. Each scheme
              record includes source information and last-verified date when available. Demo records
              are clearly labeled and should be verified before use.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">Important Disclaimer</h2>
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-900">
                <strong>SchemeSaathi is an independent project.</strong> We are not affiliated with,
                endorsed by, or officially connected to any government department or ministry.
                Recommendations are preliminary guidance only and do not constitute official
                eligibility decisions. Always verify scheme details, eligibility criteria, and
                document requirements on official government portals before applying.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
