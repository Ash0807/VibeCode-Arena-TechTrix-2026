import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Heart, ExternalLink, FileText, AlertCircle } from 'lucide-react';
import { Scheme } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function SchemeDetail() {
  const { id } = useParams<{ id: string }>();
  const [scheme, setScheme] = useState<Scheme | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (id) {
      loadScheme();
      setIsSaved(storage.isInShortlist(id));
    }
  }, [id]);

  const loadScheme = async () => {
    if (!id) return;
    
    setLoading(true);
    setError('');
    try {
      const response = await apiClient.getSchemeById(id);
      setScheme(response.data);
    } catch (err: any) {
      setError(err.message || 'Failed to load scheme details');
    } finally {
      setLoading(false);
    }
  };

  const toggleSave = () => {
    if (!id) return;
    
    if (isSaved) {
      storage.removeFromShortlist(id);
    } else {
      storage.saveToShortlist(id);
    }
    setIsSaved(!isSaved);
  };

  if (loading) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
            <p className="text-brand-muted">Loading scheme details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !scheme) {
    return (
      <div className="bg-brand-bg min-h-screen py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card text-center">
            <AlertCircle size={48} className="text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-brand-navy mb-4">Scheme Not Found</h2>
            <p className="text-brand-muted mb-6">{error || 'The requested scheme could not be found.'}</p>
            <Link to="/schemes" className="btn-primary inline-block">
              Browse All Schemes
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link to="/schemes" className="text-brand-primary hover:text-blue-700 flex items-center space-x-2">
            <ArrowLeft size={20} />
            <span>Back to All Schemes</span>
          </Link>
        </div>

        <div className="card">
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className="flex-1">
              <span className="text-sm font-medium text-brand-primary uppercase mb-2 block">
                {scheme.category.replace('-', ' ')}
              </span>
              <h1 className="text-3xl font-bold text-brand-navy mb-2">
                {scheme.name}
              </h1>
              {scheme.isDemo && (
                <div className="inline-flex items-center space-x-2 bg-amber-100 text-amber-800 px-3 py-1 rounded text-sm">
                  <AlertCircle size={16} />
                  <span>Demo Data - Needs Verification</span>
                </div>
              )}
            </div>
            <button
              onClick={toggleSave}
              className="text-brand-muted hover:text-red-500 transition-colors p-2"
              aria-label={isSaved ? 'Remove from shortlist' : 'Add to shortlist'}
            >
              <Heart size={28} fill={isSaved ? 'currentColor' : 'none'} />
            </button>
          </div>

          {/* Purpose */}
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">Purpose</h2>
            <p className="text-brand-muted">{scheme.purpose}</p>
          </section>

          {/* Beneficiaries */}
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-brand-navy mb-3">Intended Beneficiaries</h2>
            <p className="text-brand-muted">{scheme.beneficiaryDescription}</p>
            <div className="mt-2 text-sm text-brand-muted">
              <strong>Coverage:</strong> {scheme.geographicCoverage.states.join(', ')}
              {scheme.geographicCoverage.residenceTypes && (
                <> ({scheme.geographicCoverage.residenceTypes.join(', ')})</>
              )}
            </div>
          </section>

          {/* Benefits */}
          {scheme.benefits.length > 0 && (
            <section className="mb-8">
              <h2 className="text-xl font-semibold text-brand-navy mb-3">Benefits</h2>
              <ul className="space-y-2">
                {scheme.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start space-x-2 text-brand-muted">
                    <span className="text-brand-primary mt-1">•</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Eligibility Criteria */}
          {scheme.criteria.length > 0 && (
            <section className="mb-8">
              <h2 className="text-xl font-semibold text-brand-navy mb-3">Eligibility Criteria</h2>
              <ul className="space-y-2">
                {scheme.criteria.map((criterion) => (
                  <li key={criterion.id} className="flex items-start space-x-2 text-brand-muted">
                    <span className="text-brand-primary mt-1">•</span>
                    <span>{criterion.description}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Required Documents */}
          {scheme.documents.length > 0 && (
            <section className="mb-8">
              <h2 className="text-xl font-semibold text-brand-navy mb-3">Required Documents</h2>
              <ul className="space-y-2">
                {scheme.documents.map((doc, idx) => (
                  <li key={idx} className="flex items-start space-x-2 text-brand-muted">
                    <FileText size={18} className="text-brand-primary mt-1 flex-shrink-0" />
                    <div>
                      <span className="font-medium">{doc.name}</span>
                      {doc.notes && <span className="text-sm block">{doc.notes}</span>}
                    </div>
                  </li>
                ))}
              </ul>
              <Link
                to={`/checklist/${scheme.id}`}
                className="btn-secondary mt-4 inline-block"
              >
                View Document Checklist
              </Link>
            </section>
          )}

          {/* Application Steps */}
          {scheme.applicationSteps.length > 0 && (
            <section className="mb-8">
              <h2 className="text-xl font-semibold text-brand-navy mb-3">How to Apply</h2>
              <ol className="space-y-3">
                {scheme.applicationSteps.map((step, idx) => (
                  <li key={idx} className="flex items-start space-x-3 text-brand-muted">
                    <span className="bg-brand-primary text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
                      {idx + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </section>
          )}

          {/* Source Information */}
          <section className="pt-6 border-t border-brand-border">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="text-sm text-brand-muted">
                {scheme.sourceName ? (
                  <>
                    <strong>Source:</strong> {scheme.sourceName}
                  </>
                ) : (
                  <span>Source information not available</span>
                )}
                {scheme.lastVerifiedAt && (
                  <span className="block mt-1">
                    Last verified: {new Date(scheme.lastVerifiedAt).toLocaleDateString()}
                  </span>
                )}
              </div>
              {scheme.sourceUrl && (
                <a
                  href={scheme.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary flex items-center space-x-2 text-center"
                >
                  <span>Visit Official Website</span>
                  <ExternalLink size={18} />
                </a>
              )}
            </div>
          </section>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-900">
              <strong>Disclaimer:</strong> This is preliminary guidance. Verify all details on the
              official source before applying. Document requirements and eligibility criteria may
              change without notice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
