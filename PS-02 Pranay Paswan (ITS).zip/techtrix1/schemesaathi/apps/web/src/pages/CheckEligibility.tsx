import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { UserProfile } from '@schemesaathi/contracts';
import { apiClient } from '../lib/api';
import { storage } from '../lib/storage';

export function CheckEligibility() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const savedProfile = storage.getProfile();
  const [profile, setProfile] = useState<Partial<UserProfile>>(
    savedProfile || {
      state: '',
      residenceType: 'urban',
      ageBand: '',
      occupation: '',
      annualIncomeBand: '',
      householdSize: undefined,
      ownsPuccaHouse: 'unknown',
      isStudent: 'no',
      isFarmer: 'no',
    }
  );

  const updateProfile = (field: string, value: any) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleNext = () => {
    if (step === 1) {
      if (!profile.state || !profile.ageBand || !profile.occupation || !profile.annualIncomeBand) {
        setError('Please fill all required fields');
        return;
      }
    }
    setStep(step + 1);
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = async () => {
    if (!profile.state || !profile.residenceType || !profile.ageBand || !profile.occupation || !profile.annualIncomeBand) {
      setError('Please complete all required fields');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const completeProfile: UserProfile = {
        state: profile.state,
        residenceType: profile.residenceType as 'rural' | 'urban',
        ageBand: profile.ageBand,
        occupation: profile.occupation,
        annualIncomeBand: profile.annualIncomeBand,
        householdSize: profile.householdSize,
        ownsPuccaHouse: profile.ownsPuccaHouse as 'yes' | 'no' | 'unknown',
        isStudent: profile.isStudent as 'yes' | 'no' | 'unknown',
        isFarmer: profile.isFarmer as 'yes' | 'no' | 'unknown',
      };

      storage.saveProfile(completeProfile);
      await apiClient.checkEligibility({ profile: completeProfile });
      navigate('/results');
    } catch (err: any) {
      setError(err.message || 'Failed to check eligibility. Please try again.');
      setLoading(false);
    }
  };

  const states = ['AN', 'AP', 'AR', 'AS', 'BR', 'CH', 'CG', 'DH', 'DD', 'DL', 'GA', 'GJ', 'HR', 'HP', 'JK', 'JH', 'KA', 'KL', 'LD', 'MP', 'MH', 'MN', 'ML', 'MZ', 'NL', 'OD', 'PY', 'PB', 'RJ', 'SK', 'TN', 'TS', 'TR', 'UP', 'UK', 'WB'];
  const ageBands = ['Below 18', '18-24', '25-34', '35-44', '45-59', '60+'];
  const occupations = ['salaried', 'self-employed', 'farmer', 'student', 'unemployed', 'retired', 'other'];
  const incomeBands = ['0-150000', '150000-300000', '300000-500000', '500000-1000000', '1000000+'];

  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4 mb-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    s <= step
                      ? 'bg-brand-primary text-white'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {s < step ? <CheckCircle2 size={20} /> : s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-16 h-1 ${
                      s < step ? 'bg-brand-primary' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <p className="text-sm text-brand-muted">
              Step {step} of 3
            </p>
          </div>
        </div>

        <div className="card max-w-2xl mx-auto">
          {step === 1 && (
            <div>
              <h2 className="text-2xl font-bold text-brand-navy mb-6">
                Personal Details
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="label">
                    State or Union Territory <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="input-field"
                    value={profile.state}
                    onChange={(e) => updateProfile('state', e.target.value)}
                  >
                    <option value="">Select your state</option>
                    {states.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="label">
                    Residence Type <span className="text-red-500">*</span>
                  </label>
                  <div className="flex space-x-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="residenceType"
                        value="urban"
                        checked={profile.residenceType === 'urban'}
                        onChange={(e) => updateProfile('residenceType', e.target.value)}
                        className="mr-2"
                      />
                      Urban
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="residenceType"
                        value="rural"
                        checked={profile.residenceType === 'rural'}
                        onChange={(e) => updateProfile('residenceType', e.target.value)}
                        className="mr-2"
                      />
                      Rural
                    </label>
                  </div>
                </div>

                <div>
                  <label className="label">
                    Age Band <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="input-field"
                    value={profile.ageBand}
                    onChange={(e) => updateProfile('ageBand', e.target.value)}
                  >
                    <option value="">Select your age band</option>
                    {ageBands.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="label">
                    Occupation <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="input-field"
                    value={profile.occupation}
                    onChange={(e) => updateProfile('occupation', e.target.value)}
                  >
                    <option value="">Select your occupation</option>
                    {occupations.map((o) => (
                      <option key={o} value={o}>
                        {o.charAt(0).toUpperCase() + o.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="label">
                    Annual Household Income <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="input-field"
                    value={profile.annualIncomeBand}
                    onChange={(e) => updateProfile('annualIncomeBand', e.target.value)}
                  >
                    <option value="">Select income band</option>
                    {incomeBands.map((i) => (
                      <option key={i} value={i}>
                        ₹{i.replace('-', ' - ').replace('+', ' and above')}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h2 className="text-2xl font-bold text-brand-navy mb-6">
                Family & Household Details
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="label">Household Size (Optional)</label>
                  <input
                    type="number"
                    className="input-field"
                    value={profile.householdSize || ''}
                    onChange={(e) => updateProfile('householdSize', e.target.value ? parseInt(e.target.value) : undefined)}
                    min="1"
                    placeholder="Number of family members"
                  />
                </div>

                <div>
                  <label className="label">Do you own a pucca house?</label>
                  <select
                    className="input-field"
                    value={profile.ownsPuccaHouse}
                    onChange={(e) => updateProfile('ownsPuccaHouse', e.target.value)}
                  >
                    <option value="unknown">Prefer not to say</option>
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>

                <div>
                  <label className="label">Are you currently a student?</label>
                  <select
                    className="input-field"
                    value={profile.isStudent}
                    onChange={(e) => updateProfile('isStudent', e.target.value)}
                  >
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                    <option value="unknown">Prefer not to say</option>
                  </select>
                </div>

                <div>
                  <label className="label">Do you own agricultural land?</label>
                  <select
                    className="input-field"
                    value={profile.isFarmer}
                    onChange={(e) => updateProfile('isFarmer', e.target.value)}
                  >
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                    <option value="unknown">Prefer not to say</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <h2 className="text-2xl font-bold text-brand-navy mb-6">
                Review & Submit
              </h2>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-brand-navy mb-3">Personal Details</h3>
                  <dl className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">State:</dt>
                      <dd className="font-medium">{profile.state}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Residence:</dt>
                      <dd className="font-medium capitalize">{profile.residenceType}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Age Band:</dt>
                      <dd className="font-medium">{profile.ageBand}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Occupation:</dt>
                      <dd className="font-medium capitalize">{profile.occupation}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Income Band:</dt>
                      <dd className="font-medium">₹{profile.annualIncomeBand}</dd>
                    </div>
                  </dl>
                </div>

                <div>
                  <h3 className="font-semibold text-brand-navy mb-3">Family Details</h3>
                  <dl className="space-y-2 text-sm">
                    {profile.householdSize && (
                      <div className="flex justify-between">
                        <dt className="text-brand-muted">Household Size:</dt>
                        <dd className="font-medium">{profile.householdSize}</dd>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Owns Pucca House:</dt>
                      <dd className="font-medium capitalize">{profile.ownsPuccaHouse}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Student:</dt>
                      <dd className="font-medium capitalize">{profile.isStudent}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-brand-muted">Farmer:</dt>
                      <dd className="font-medium capitalize">{profile.isFarmer}</dd>
                    </div>
                  </dl>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          <div className="flex justify-between mt-8">
            {step > 1 && (
              <button
                onClick={handleBack}
                className="btn-secondary flex items-center space-x-2"
                disabled={loading}
              >
                <ArrowLeft size={20} />
                <span>Back</span>
              </button>
            )}
            {step < 3 ? (
              <button
                onClick={handleNext}
                className="btn-primary flex items-center space-x-2 ml-auto"
              >
                <span>Next</span>
                <ArrowRight size={20} />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="btn-primary ml-auto"
                disabled={loading}
              >
                {loading ? 'Finding Schemes...' : 'Find Matching Schemes'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
