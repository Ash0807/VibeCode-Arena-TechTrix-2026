import { Link } from 'react-router-dom';
import {
  GraduationCap,
  Heart as HeartIcon,
  Sprout,
  Briefcase,
  Home as HomeIcon,
  Users,
  CheckCircle,
  FileText,
  Shield,
  AlertCircle,
} from 'lucide-react';

export function Home() {
  const categories = [
    {
      icon: GraduationCap,
      name: 'Education',
      description: 'Scholarships and educational support',
      category: 'education',
    },
    {
      icon: HeartIcon,
      name: 'Healthcare',
      description: 'Health insurance and medical assistance',
      category: 'healthcare',
    },
    {
      icon: HomeIcon,
      name: 'Housing',
      description: 'Affordable housing and shelter schemes',
      category: 'housing',
    },
    {
      icon: Sprout,
      name: 'Agriculture',
      description: 'Support for farmers and rural development',
      category: 'agriculture',
    },
    {
      icon: Briefcase,
      name: 'Employment',
      description: 'Skill development and job opportunities',
      category: 'employment',
    },
    {
      icon: Users,
      name: 'Social Welfare',
      description: 'Pensions and social assistance programs',
      category: 'social-welfare',
    },
  ];

  return (
    <div className="bg-gradient-to-b from-blue-50 via-white to-blue-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-cyan-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-brand-navy leading-tight">
                Find Government Schemes for a Better{' '}
                <span className="text-brand-primary">Tomorrow</span>
              </h1>
              <p className="text-lg text-brand-muted leading-relaxed">
                Discover welfare schemes, explore government schemes and more — tailored to your needs. Just share a few details and find personalized schemes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  to="/check" 
                  className="inline-flex items-center justify-center px-8 py-4 bg-brand-primary text-white font-semibold rounded-xl hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all"
                >
                  Start Finding Schemes →
                </Link>
                <Link 
                  to="/schemes" 
                  className="inline-flex items-center justify-center px-8 py-4 bg-white text-brand-primary font-semibold rounded-xl border-2 border-brand-primary hover:bg-brand-section transition-all"
                >
                  🎥 Watch Video
                </Link>
              </div>
            </div>

            {/* Right Hero Image */}
            <div className="relative hidden md:block">
              <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
                <img 
                  src="https://images.unsplash.com/photo-1609220136736-443140cffec6?w=800&q=85&auto=format&fit=crop"
                  alt="Happy Indian family discovering government schemes together"
                  className="w-full h-auto object-cover"
                  style={{ aspectRatio: '4/3' }}
                  onError={(e) => {
                    // Multiple fallback images for reliability
                    const fallbacks = [
                      'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=800&q=85&auto=format&fit=crop',
                      'https://images.unsplash.com/photo-1475503572774-15a45e5d60b9?w=800&q=85&auto=format&fit=crop',
                      'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&q=85&auto=format&fit=crop'
                    ];
                    const img = e.target as HTMLImageElement;
                    const currentIndex = fallbacks.indexOf(img.src);
                    if (currentIndex < fallbacks.length - 1) {
                      img.src = fallbacks[currentIndex + 1];
                    }
                  }}
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/20 via-transparent to-transparent"></div>
                
                {/* Bottom Info Badge */}
                <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-md rounded-2xl px-5 py-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-brand-muted font-medium mb-0.5">🇮🇳 Digital India Initiative</p>
                      <p className="text-sm font-bold text-brand-navy">Access Your Government Benefits</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="text-green-600" size={18} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating Stat Card 1 */}
              <div className="absolute -bottom-8 -left-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-2xl p-5 z-20 border-4 border-white">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Users className="text-white" size={24} />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white">50+</p>
                    <p className="text-xs text-blue-100">Govt Schemes</p>
                  </div>
                </div>
              </div>
              
              {/* Floating Stat Card 2 */}
              <div className="absolute -top-6 -right-6 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl shadow-2xl p-5 z-20 border-4 border-white">
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto bg-white/20 rounded-xl flex items-center justify-center mb-2">
                    <Shield className="text-white" size={24} />
                  </div>
                  <p className="text-2xl font-bold text-white">100%</p>
                  <p className="text-xs text-cyan-100">Free & Safe</p>
                </div>
              </div>
              
              {/* Decorative blur circles */}
              <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-blue-300 rounded-full opacity-30 blur-3xl"></div>
              <div className="absolute -top-8 -left-8 w-32 h-32 bg-cyan-300 rounded-full opacity-30 blur-3xl"></div>
            </div>
          </div>
        </div>
        
        {/* Wave decoration */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-brand-navy mb-3 text-center">
          Explore Schemes by Category
        </h2>
        <p className="text-brand-muted text-center mb-10">
          Browse through various government welfare programs
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((cat) => (
            <Link
              key={cat.category}
              to={`/schemes?category=${cat.category}`}
              className="group"
            >
              <div className="bg-white rounded-2xl p-6 text-center hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-brand-primary cursor-pointer">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <cat.icon className="text-brand-primary" size={32} />
                </div>
                <h3 className="font-semibold text-brand-navy mb-1">
                  {cat.name}
                </h3>
                <p className="text-xs text-brand-muted">
                  {cat.description.split(' ').slice(0, 2).join(' ')}
                </p>
              </div>
            </Link>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-center gap-4 bg-white rounded-xl p-4 shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Users className="text-brand-primary" size={24} />
            </div>
            <div>
              <p className="font-semibold text-brand-navy">Trusted by 50+ Users</p>
              <p className="text-xs text-brand-muted">Active scheme seekers</p>
            </div>
          </div>
          <div className="flex items-center gap-4 bg-white rounded-xl p-4 shadow-sm">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Shield className="text-brand-teal" size={24} />
            </div>
            <div>
              <p className="font-semibold text-brand-navy">Verified Government Data</p>
              <p className="text-xs text-brand-muted">Official sources only</p>
            </div>
          </div>
          <div className="flex items-center gap-4 bg-white rounded-xl p-4 shadow-sm">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
              <CheckCircle className="text-purple-600" size={24} />
            </div>
            <div>
              <p className="font-semibold text-brand-navy">Safe & Secure</p>
              <p className="text-xs text-brand-muted">Your data stays private</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-gradient-to-b from-brand-section to-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-brand-navy mb-4 text-center">
            How It Works
          </h2>
          <p className="text-brand-muted text-center mb-12">
            Get personalized scheme recommendations in 3 simple steps
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mb-6 shadow-lg">
                  1
                </div>
                <h3 className="text-xl font-semibold text-brand-navy mb-3">
                  Answer Questions
                </h3>
                <p className="text-brand-muted">
                  Complete a short questionnaire about your location, age, income,
                  and household details
                </p>
              </div>
              {/* Connector Line */}
              <div className="hidden md:block absolute top-14 left-full w-8 h-0.5 bg-blue-200"></div>
            </div>
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-cyan-500 to-cyan-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mb-6 shadow-lg">
                  2
                </div>
                <h3 className="text-xl font-semibold text-brand-navy mb-3">
                  Get Recommendations
                </h3>
                <p className="text-brand-muted">
                  See schemes you're potentially eligible for with clear
                  explanations and missing information
                </p>
              </div>
              {/* Connector Line */}
              <div className="hidden md:block absolute top-14 left-full w-8 h-0.5 bg-blue-200"></div>
            </div>
            <div>
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-teal-500 to-teal-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mb-6 shadow-lg">
                  3
                </div>
                <h3 className="text-xl font-semibold text-brand-navy mb-3">
                  Prepare Documents
                </h3>
                <p className="text-brand-muted">
                  View document checklists and official links to verify details
                  and apply
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all">
            <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-teal-100 rounded-2xl flex items-center justify-center mb-6">
              <CheckCircle className="text-brand-teal" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-brand-navy mb-3">
              Personalized Matching
            </h3>
            <p className="text-brand-muted">
              Find schemes tailored to your specific circumstances through
              rule-based eligibility checks
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl flex items-center justify-center mb-6">
              <FileText className="text-brand-primary" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-brand-navy mb-3">
              Clear Explanations
            </h3>
            <p className="text-brand-muted">
              Understand why you match or don't match each scheme with
              transparent eligibility reasoning
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center mb-6">
              <Shield className="text-purple-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-brand-navy mb-3">
              Privacy-First
            </h3>
            <p className="text-brand-muted">
              We don't collect Aadhaar, bank details, or identity documents.
              Your data stays on your device
            </p>
          </div>
        </div>
      </section>

      {/* Disclaimer Banner */}
      <section className="bg-gradient-to-r from-amber-50 to-orange-50 border-y border-amber-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
              <AlertCircle className="text-amber-600" size={20} />
            </div>
            <div>
              <p className="text-amber-900 font-semibold mb-1">
                Important Disclaimer
              </p>
              <p className="text-sm text-amber-800">
                SchemeSaathi provides preliminary guidance only. Recommendations are not official eligibility decisions
                and do not guarantee approval or benefits. Always verify details on official government portals before applying.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
