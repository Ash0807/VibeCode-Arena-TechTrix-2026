import type {
  ListSchemesQuery,
  ListSchemesResponse,
  SchemeDetailResponse,
  EligibilityCheckRequest,
  EligibilityCheckResponse,
  FeedbackRequest,
  FeedbackResponse,
  HealthResponse,
} from '@schemesaathi/contracts';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1';

class ApiClient {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({
        error: { message: 'An error occurred' },
      }));
      throw new Error(error.error?.message || 'Request failed');
    }

    return response.json();
  }

  async health(): Promise<HealthResponse> {
    return this.request<HealthResponse>('/health');
  }

  async listSchemes(query?: Partial<ListSchemesQuery>): Promise<ListSchemesResponse> {
    const params = new URLSearchParams();
    if (query?.category) params.append('category', query.category);
    if (query?.state) params.append('state', query.state);
    if (query?.q) params.append('q', query.q);
    if (query?.limit) params.append('limit', query.limit.toString());
    if (query?.offset) params.append('offset', query.offset.toString());

    const queryString = params.toString();
    return this.request<ListSchemesResponse>(
      `/schemes${queryString ? `?${queryString}` : ''}`
    );
  }

  async getSchemeById(id: string): Promise<SchemeDetailResponse> {
    return this.request<SchemeDetailResponse>(`/schemes/${id}`);
  }

  async checkEligibility(
    request: EligibilityCheckRequest
  ): Promise<EligibilityCheckResponse> {
    return this.request<EligibilityCheckResponse>('/eligibility/check', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async submitFeedback(feedback: FeedbackRequest): Promise<FeedbackResponse> {
    return this.request<FeedbackResponse>('/feedback', {
      method: 'POST',
      body: JSON.stringify(feedback),
    });
  }
}

export const apiClient = new ApiClient();
