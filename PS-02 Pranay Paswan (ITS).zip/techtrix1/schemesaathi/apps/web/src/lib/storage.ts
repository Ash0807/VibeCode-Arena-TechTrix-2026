import type { UserProfile } from '@schemesaathi/contracts';

const STORAGE_KEYS = {
  PROFILE: 'schemesaathi_profile',
  SHORTLIST: 'schemesaathi_shortlist',
  CHECKLIST: 'schemesaathi_checklist_',
};

export const storage = {
  // User Profile
  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (error) {
      console.error('Failed to save profile:', error);
    }
  },

  getProfile(): UserProfile | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Failed to load profile:', error);
      return null;
    }
  },

  clearProfile(): void {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
  },

  // Shortlist
  getShortlist(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SHORTLIST);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to load shortlist:', error);
      return [];
    }
  },

  saveToShortlist(schemeId: string): void {
    try {
      const shortlist = this.getShortlist();
      if (!shortlist.includes(schemeId)) {
        shortlist.push(schemeId);
        localStorage.setItem(STORAGE_KEYS.SHORTLIST, JSON.stringify(shortlist));
      }
    } catch (error) {
      console.error('Failed to save to shortlist:', error);
    }
  },

  removeFromShortlist(schemeId: string): void {
    try {
      const shortlist = this.getShortlist();
      const updated = shortlist.filter((id) => id !== schemeId);
      localStorage.setItem(STORAGE_KEYS.SHORTLIST, JSON.stringify(updated));
    } catch (error) {
      console.error('Failed to remove from shortlist:', error);
    }
  },

  isInShortlist(schemeId: string): boolean {
    return this.getShortlist().includes(schemeId);
  },

  clearShortlist(): void {
    localStorage.removeItem(STORAGE_KEYS.SHORTLIST);
  },

  // Document Checklist
  getChecklist(schemeId: string): Record<string, boolean> {
    try {
      const data = localStorage.getItem(`${STORAGE_KEYS.CHECKLIST}${schemeId}`);
      return data ? JSON.parse(data) : {};
    } catch (error) {
      console.error('Failed to load checklist:', error);
      return {};
    }
  },

  updateChecklist(schemeId: string, checklist: Record<string, boolean>): void {
    try {
      localStorage.setItem(
        `${STORAGE_KEYS.CHECKLIST}${schemeId}`,
        JSON.stringify(checklist)
      );
    } catch (error) {
      console.error('Failed to update checklist:', error);
    }
  },

  clearChecklist(schemeId: string): void {
    localStorage.removeItem(`${STORAGE_KEYS.CHECKLIST}${schemeId}`);
  },

  clearAll(): void {
    this.clearProfile();
    this.clearShortlist();
    // Clear all checklists
    Object.keys(localStorage)
      .filter((key) => key.startsWith(STORAGE_KEYS.CHECKLIST))
      .forEach((key) => localStorage.removeItem(key));
  },
};
