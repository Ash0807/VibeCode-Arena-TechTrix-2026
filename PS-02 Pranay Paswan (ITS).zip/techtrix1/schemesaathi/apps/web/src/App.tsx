import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { CheckEligibility } from './pages/CheckEligibility';
import { Results } from './pages/Results';
import { Schemes } from './pages/Schemes';
import { SchemeDetail } from './pages/SchemeDetail';
import { Shortlist } from './pages/Shortlist';
import { Checklist } from './pages/Checklist';
import { Help } from './pages/Help';
import { About } from './pages/About';
import { Privacy } from './pages/Privacy';
import { Feedback } from './pages/Feedback';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="check" element={<CheckEligibility />} />
          <Route path="results" element={<Results />} />
          <Route path="schemes" element={<Schemes />} />
          <Route path="schemes/:id" element={<SchemeDetail />} />
          <Route path="saved" element={<Shortlist />} />
          <Route path="checklist/:id" element={<Checklist />} />
          <Route path="help" element={<Help />} />
          <Route path="about" element={<About />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="feedback" element={<Feedback />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

function NotFound() {
  return (
    <div className="bg-brand-bg min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="card text-center">
          <h1 className="text-6xl font-bold text-brand-navy mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-brand-navy mb-4">Page Not Found</h2>
          <p className="text-brand-muted mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/" className="btn-primary">
              Go Home
            </a>
            <a href="/schemes" className="btn-secondary">
              Explore Schemes
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
