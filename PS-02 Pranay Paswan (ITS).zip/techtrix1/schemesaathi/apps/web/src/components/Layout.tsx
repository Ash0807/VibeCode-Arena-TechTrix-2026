import { Link, Outlet } from 'react-router-dom';
import { Menu, X, Heart } from 'lucide-react';
import { useState } from 'react';

export function Layout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-white/95 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50 shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-3">
              <img src="/logo.svg" alt="SchemeSaathi Logo" className="w-10 h-10" />
              <span className="text-xl font-bold bg-gradient-to-r from-brand-primary to-cyan-600 bg-clip-text text-transparent">
                SchemeSaathi
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              <Link
                to="/"
                className="px-4 py-2 text-brand-navy hover:text-brand-primary font-medium rounded-lg hover:bg-blue-50 transition-all"
              >
                Home
              </Link>
              <Link
                to="/schemes"
                className="px-4 py-2 text-brand-navy hover:text-brand-primary font-medium rounded-lg hover:bg-blue-50 transition-all"
              >
                Schemes
              </Link>
              <Link
                to="/about"
                className="px-4 py-2 text-brand-navy hover:text-brand-primary font-medium rounded-lg hover:bg-blue-50 transition-all"
              >
                About
              </Link>
              <Link
                to="/help"
                className="px-4 py-2 text-brand-navy hover:text-brand-primary font-medium rounded-lg hover:bg-blue-50 transition-all"
              >
                Help
              </Link>
              <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-gray-200">
                <Link
                  to="/saved"
                  className="relative p-2 text-brand-navy hover:text-brand-primary rounded-lg hover:bg-blue-50 transition-all"
                  title="My Shortlist"
                >
                  <Heart size={22} />
                </Link>
                <Link
                  to="/check"
                  className="px-6 py-2.5 bg-gradient-to-r from-brand-primary to-cyan-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all"
                >
                  Login / Sign Up
                </Link>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-brand-navy"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 space-y-3">
              <Link
                to="/"
                className="block text-brand-navy hover:text-brand-primary font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                to="/check"
                className="block text-brand-navy hover:text-brand-primary font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Find Schemes
              </Link>
              <Link
                to="/schemes"
                className="block text-brand-navy hover:text-brand-primary font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Browse Schemes
              </Link>
              <Link
                to="/saved"
                className="block text-brand-navy hover:text-brand-primary font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                My Shortlist
              </Link>
              <Link
                to="/help"
                className="block text-brand-navy hover:text-brand-primary font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Help
              </Link>
            </div>
          )}
        </nav>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="bg-gradient-to-b from-white to-blue-50 border-t border-blue-100 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img src="/logo.svg" alt="SchemeSaathi Logo" className="w-10 h-10" />
                <span className="text-xl font-bold text-brand-navy">
                  SchemeSaathi
                </span>
              </div>
              <p className="text-brand-muted text-sm mb-4 max-w-md">
                Helping Indian citizens discover relevant government schemes
                through transparent, rule-based matching. Making welfare schemes accessible to everyone.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-brand-muted hover:text-brand-primary transition-colors">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </a>
                <a href="#" className="text-brand-muted hover:text-brand-primary transition-colors">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-brand-navy mb-4">
                Quick Links
              </h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link
                    to="/about"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/schemes"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    Browse Schemes
                  </Link>
                </li>
                <li>
                  <Link
                    to="/help"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    Help & FAQs
                  </Link>
                </li>
                <li>
                  <Link
                    to="/feedback"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    Feedback
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-brand-navy mb-4">
                Legal
              </h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link
                    to="/privacy"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link
                    to="/about"
                    className="text-brand-muted hover:text-brand-primary transition-colors"
                  >
                    Terms of Service
                  </Link>
                </li>
              </ul>
              <div className="mt-6">
                <p className="text-xs text-brand-muted">
                  <strong>Disclaimer:</strong> Independent project. Not affiliated with government.
                </p>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-blue-100 text-center text-sm text-brand-muted">
            <p>© {new Date().getFullYear()} SchemeSaathi. All rights reserved. Made with ❤️ for India</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
