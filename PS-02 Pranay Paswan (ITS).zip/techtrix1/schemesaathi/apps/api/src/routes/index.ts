import { Router } from 'express';
import {
  ListSchemesQuerySchema,
  EligibilityCheckRequestSchema,
  FeedbackRequestSchema,
  SchemeListItem,
} from '@schemesaathi/contracts';
import { SchemeRepository } from '../repositories/schemeRepository.js';
import { EligibilityEngine } from '../services/eligibilityEngine.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();
const schemeRepo = new SchemeRepository();
const eligibilityEngine = new EligibilityEngine();

// Health check
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'schemesaathi-api',
    version: '1.0.0',
  });
});

// List/search schemes
router.get('/schemes', (req, res, next) => {
  try {
    const query = ListSchemesQuerySchema.parse(req.query);
    const { schemes, total } = schemeRepo.search(query);

    const schemeList: SchemeListItem[] = schemes.map((s) => ({
      id: s.id,
      name: s.name,
      category: s.category,
      summary: s.summary,
      states: s.geographicCoverage.states,
      sourceUrl: s.sourceUrl,
      lastVerifiedAt: s.lastVerifiedAt,
      isDemo: s.isDemo,
    }));

    res.json({
      data: schemeList,
      pagination: {
        limit: query.limit,
        offset: query.offset,
        total,
      },
    });
  } catch (error) {
    next(error);
  }
});

// Get scheme details
router.get('/schemes/:id', (req, res, next) => {
  try {
    const scheme = schemeRepo.findById(req.params.id);

    if (!scheme) {
      throw new AppError(404, 'NOT_FOUND', 'The requested scheme was not found.');
    }

    res.json({ data: scheme });
  } catch (error) {
    next(error);
  }
});

// Eligibility check
router.post('/eligibility/check', (req, res, next) => {
  try {
    const request = EligibilityCheckRequestSchema.parse(req.body);
    const allSchemes = schemeRepo.findAll();

    const results = eligibilityEngine.evaluateMultiple(
      allSchemes,
      request.profile,
      request.categories
    );

    res.json({
      data: results,
      meta: {
        evaluatedCount: results.length,
        disclaimer:
          'These are preliminary matches, not an official eligibility decision.',
      },
    });
  } catch (error) {
    next(error);
  }
});

// Feedback
router.post('/feedback', (req, res, next) => {
  try {
    const feedback = FeedbackRequestSchema.parse(req.body);

    // In MVP, we just acknowledge receipt
    // In production, this would persist to a database
    const referenceId = `fb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    res.status(201).json({
      data: {
        received: true,
        referenceId,
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
