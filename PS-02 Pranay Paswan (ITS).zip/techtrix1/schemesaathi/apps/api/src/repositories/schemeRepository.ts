import { Scheme } from '@schemesaathi/contracts';
import schemesData from '../data/schemes.json' assert { type: 'json' };

export class SchemeRepository {
  private schemes: Scheme[];

  constructor() {
    this.schemes = schemesData as Scheme[];
  }

  findAll(): Scheme[] {
    return this.schemes;
  }

  findById(id: string): Scheme | undefined {
    return this.schemes.find((s) => s.id === id);
  }

  search(params: {
    category?: string;
    state?: string;
    q?: string;
    limit?: number;
    offset?: number;
  }): { schemes: Scheme[]; total: number } {
    let filtered = [...this.schemes];

    // Filter by category
    if (params.category) {
      filtered = filtered.filter((s) => s.category === params.category);
    }

    // Filter by state
    if (params.state) {
      filtered = filtered.filter(
        (s) =>
          s.geographicCoverage.states.includes('ALL') ||
          s.geographicCoverage.states.includes(params.state!)
      );
    }

    // Search by name or summary
    if (params.q) {
      const query = params.q.toLowerCase();
      filtered = filtered.filter(
        (s) =>
          s.name.toLowerCase().includes(query) ||
          s.summary.toLowerCase().includes(query) ||
          s.purpose.toLowerCase().includes(query)
      );
    }

    const total = filtered.length;
    const limit = params.limit || 20;
    const offset = params.offset || 0;

    const paginated = filtered.slice(offset, offset + limit);

    return { schemes: paginated, total };
  }
}
