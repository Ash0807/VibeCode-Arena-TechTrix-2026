import {
  Scheme,
  UserProfile,
  EligibilityResult,
  EligibilityCriterion,
} from '@schemesaathi/contracts';

export class EligibilityEngine {
  evaluate(scheme: Scheme, profile: UserProfile): EligibilityResult {
    const matchedCriteria: string[] = [];
    const unmetCriteria: string[] = [];
    const missingInformation: string[] = [];

    for (const criterion of scheme.criteria) {
      const result = this.evaluateCriterion(criterion, profile);

      if (result === 'match') {
        matchedCriteria.push(criterion.description);
      } else if (result === 'mismatch') {
        unmetCriteria.push(criterion.description);
      } else if (result === 'missing') {
        missingInformation.push(criterion.field);
      }
    }

    // Determine status
    let status: 'Potentially Eligible' | 'More Information Required' | 'Eligibility Criteria Not Met';
    let summary: string;

    if (missingInformation.length > 0) {
      status = 'More Information Required';
      summary = 'One or more required answers are missing.';
    } else if (unmetCriteria.length > 0) {
      status = 'Eligibility Criteria Not Met';
      summary = 'Some eligibility criteria are not met based on your profile.';
    } else {
      status = 'Potentially Eligible';
      summary = 'Your profile matches the preliminary eligibility criteria.';
    }

    return {
      schemeId: scheme.id,
      status,
      summary,
      matchedCriteria,
      unmetCriteria,
      missingInformation,
      documents: scheme.documents.map((d) => d.name),
      confidence: scheme.isDemo ? 'demo' : 'preliminary',
      sourceUrl: scheme.sourceUrl,
      lastVerifiedAt: scheme.lastVerifiedAt,
      isDemo: scheme.isDemo,
    };
  }

  private evaluateCriterion(
    criterion: EligibilityCriterion,
    profile: UserProfile
  ): 'match' | 'mismatch' | 'missing' {
    const fieldValue = (profile as any)[criterion.field];

    // Handle missing information
    if (
      fieldValue === undefined ||
      fieldValue === null ||
      fieldValue === 'unknown'
    ) {
      return criterion.required ? 'missing' : 'match';
    }

    // Evaluate based on operator
    switch (criterion.operator) {
      case 'equals':
        return fieldValue === criterion.value ? 'match' : 'mismatch';

      case 'in':
        return Array.isArray(criterion.value) &&
          (criterion.value as string[]).includes(String(fieldValue))
          ? 'match'
          : 'mismatch';

      case 'lte':
        return typeof fieldValue === 'number' &&
          typeof criterion.value === 'number' &&
          fieldValue <= criterion.value
          ? 'match'
          : 'mismatch';

      case 'gte':
        return typeof fieldValue === 'number' &&
          typeof criterion.value === 'number' &&
          fieldValue >= criterion.value
          ? 'match'
          : 'mismatch';

      case 'isTrue':
        return fieldValue === true || fieldValue === 'yes'
          ? 'match'
          : 'mismatch';

      case 'between':
        if (
          typeof fieldValue === 'number' &&
          Array.isArray(criterion.value) &&
          criterion.value.length === 2 &&
          typeof criterion.value[0] === 'number' &&
          typeof criterion.value[1] === 'number'
        ) {
          return fieldValue >= criterion.value[0] &&
            fieldValue <= criterion.value[1]
            ? 'match'
            : 'mismatch';
        }
        return 'mismatch';

      default:
        return 'mismatch';
    }
  }

  evaluateMultiple(
    schemes: Scheme[],
    profile: UserProfile,
    categories?: string[]
  ): EligibilityResult[] {
    let filteredSchemes = schemes;

    // Filter by categories if provided
    if (categories && categories.length > 0) {
      filteredSchemes = schemes.filter((s) => categories.includes(s.category));
    }

    // Filter by geographic coverage
    filteredSchemes = filteredSchemes.filter((s) => {
      const matchesState =
        s.geographicCoverage.states.includes('ALL') ||
        s.geographicCoverage.states.includes(profile.state);

      const matchesResidence =
        !s.geographicCoverage.residenceTypes ||
        s.geographicCoverage.residenceTypes.includes(profile.residenceType);

      return matchesState && matchesResidence;
    });

    return filteredSchemes.map((scheme) => this.evaluate(scheme, profile));
  }
}
