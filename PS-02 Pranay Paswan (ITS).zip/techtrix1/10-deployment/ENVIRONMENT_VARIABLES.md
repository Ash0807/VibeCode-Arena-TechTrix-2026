# Environment Variables

Never commit real secrets. `.env.example` should contain placeholders only.

## API
```env
NODE_ENV=development
PORT=4000
CORS_ORIGINS=http://localhost:5173
LOG_LEVEL=info
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=60
```

If a database or feedback store is added, document its URL and credentials separately and keep them only in the hosting provider's secret manager. Do not add unused variables merely for appearance.

## Frontend
```env
VITE_API_BASE_URL=http://localhost:4000
```

For production, replace with the deployed backend origin. Vite exposes variables prefixed with `VITE_` to browser code, so never place secrets in them.

## Startup validation
- Fail fast when required production configuration is missing.
- Normalize and validate CORS origins.
- Do not default production CORS to `*`.
- Document the exact environment variables used by the implemented code.
