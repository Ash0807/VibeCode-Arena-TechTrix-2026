# Deployment Guide

## Deployment shape
- Frontend: Vercel or Netlify
- Backend: Render or Railway
- MVP scheme data: bundled with backend
- No database required unless feedback persistence or admin editing is implemented

## Before deployment
1. Run `npm ci`.
2. Run lint, typecheck, tests, and build.
3. Confirm `.env` is ignored by Git.
4. Verify every external scheme URL in the seed data.
5. Confirm all unverified records are labelled demo.
6. Set production environment variables.
7. Confirm backend health endpoint works locally.

## Backend on Render (example)
- Create a Web Service from repository.
- Root directory: repository root if monorepo scripts support it, otherwise `apps/api`.
- Build command: `npm ci && npm run build --workspace=apps/api` (adapt to actual workspace scripts).
- Start command: `npm run start --workspace=apps/api`.
- Set `NODE_ENV=production`, `CORS_ORIGINS`, and other variables from `ENVIRONMENT_VARIABLES.md`.
- Configure health check path `/api/v1/health`.

If the chosen host does not support workspace commands in this form, use its documented root-directory settings and adjust commands. Do not leave guessed commands in the final README; verify the actual build.

## Frontend on Vercel/Netlify
- Build command: `npm run build --workspace=apps/web` (adapt to actual scripts).
- Output directory: `apps/web/dist`.
- Environment variable: `VITE_API_BASE_URL=https://<deployed-api-domain>`.
- Add SPA rewrite/fallback for React Router if required by host.
- Redeploy after changing environment variables.

## Post-deployment verification
- Open `/api/v1/health` in a browser.
- Open frontend URL in a private window.
- Complete a questionnaire and verify network request goes to deployed API.
- Confirm CORS allows only the intended frontend origin(s).
- Test at least one verified official link and one demo record.
- Test mobile width and browser refresh on nested routes.

## Rollback
- Redeploy the last known-good deployment.
- If data is inaccurate, remove or disable the affected record rather than leaving a known incorrect rule live.
- Document the incident and correction.
