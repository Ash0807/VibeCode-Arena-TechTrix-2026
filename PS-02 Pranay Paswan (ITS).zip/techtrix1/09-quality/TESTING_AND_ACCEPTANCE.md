# Testing and Acceptance Checklist

## Automated checks
Root scripts should provide:
- `npm run lint`
- `npm run typecheck`
- `npm run test`
- `npm run build`

## Backend tests
- Health endpoint returns 200 and expected service name.
- List schemes supports filters and pagination.
- Unknown scheme ID returns 404.
- Invalid category/query returns 400.
- Invalid eligibility payload returns 400.
- Each of the three eligibility statuses has unit tests.
- Unknown answers produce `unknown`, never false by default.
- Feedback success is returned only if data is persisted.
- CORS blocks unapproved production origins.
- Rate limits activate on configured endpoints.

## Frontend tests
- Questionnaire inputs have labels.
- Required fields show accessible validation messages.
- Back navigation preserves answers.
- API errors show retry and preserve profile.
- Result card shows exact status and explanation.
- Missing source URL does not render a broken/fake link.
- Shortlist add/remove persists across refresh.
- Empty and no-results states are useful.
- Layout is usable at 360px width and desktop width.

## End-to-end smoke test
1. Open landing page.
2. Start questionnaire.
3. Enter valid demo profile.
4. Submit and wait for API response.
5. Verify statuses and explanations.
6. Open scheme details.
7. Save and remove a scheme.
8. Open official link for a verified scheme only.
9. Report stale information only if backend persistence exists.
10. Refresh and check saved state.
11. Repeat with API stopped and verify graceful error.

## Acceptance criteria
- No TypeScript errors, lint failures, or failing tests.
- Production build succeeds from a clean install.
- No console errors in core journey.
- No hardcoded localhost URL in production code.
- No secrets committed.
- Disclaimer visible before or alongside results.
- All demo data visibly labelled.
- No invented government links or claims of guaranteed eligibility.
- Deployment health check and API integration work on production URLs.
