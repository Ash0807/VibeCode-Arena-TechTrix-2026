# SchemeSaathi — Implementation Documentation Pack

This pack is the project blueprint for building, testing, and deploying SchemeSaathi as a working full-stack web application.

## Product goal
Help people discover relevant Indian government schemes through a transparent, rule-based preliminary matching flow. The app collects only the information needed for matching, explains why a scheme may fit or not fit, shows document checklists and official links, and lets users shortlist schemes.

## Recommended MVP stack
- **Frontend:** React + Vite + TypeScript + Tailwind CSS
- **Backend:** Node.js + Express + TypeScript
- **Validation:** Zod (shared API contracts where practical)
- **Tests:** Vitest + React Testing Library for frontend; Vitest/Supertest for backend
- **MVP data:** versioned local JSON/TypeScript seed data, with a clean repository layer so a database can be added later
- **Deployment:** Vercel or Netlify for frontend; Render or Railway for backend
- **Persistence:** localStorage for shortlist and non-sensitive preferences in MVP. Do not store identity documents or Aadhaar numbers.

## Read in this order
1. `01-product/PRODUCT_REQUIREMENTS.md`
2. `01-product/USER_FLOWS.md`
3. `02-architecture/SYSTEM_ARCHITECTURE.md`
4. `02-architecture/REPOSITORY_STRUCTURE.md`
5. `03-implementation/IMPLEMENTATION_PHASES.md`
6. `04-frontend/FRONTEND_SPEC.md`
7. `05-backend/BACKEND_SPEC.md`
8. `06-apis/API_CONTRACT.md`
9. `07-data/DATA_MODEL_AND_SCHEMES.md`
10. `08-rules/ELIGIBILITY_RULE_ENGINE.md`
11. `09-quality/TESTING_AND_ACCEPTANCE.md`
12. `10-deployment/DEPLOYMENT_GUIDE.md`
13. `10-deployment/ENVIRONMENT_VARIABLES.md`
14. `11-security/SECURITY_PRIVACY.md`
15. `12-agent-prompts/MASTER_BUILD_PROMPT.md`, then the phase prompts in that folder.

## Important product safety rules
- Results are **preliminary guidance**, not official eligibility decisions.
- Use the exact status labels: `Potentially Eligible`, `More Information Required`, `Eligibility Criteria Not Met`.
- Every result must show reasons and missing information.
- Never invent official scheme URLs. Keep source URL and last-verified date in the dataset.
- If a scheme's rules are uncertain or outdated, label it for manual verification instead of confidently declaring eligibility.
- Do not collect Aadhaar number, bank account details, OTPs, or uploads of identity documents in the MVP.
- Do not imply government affiliation. Show a clear independent-project disclaimer.

## Definition of done
A fresh clone can install dependencies, run frontend and backend locally, pass automated checks, build for production, and deploy using documented environment variables. See `09-quality/TESTING_AND_ACCEPTANCE.md`.
