# Phase-by-Phase Agent Prompts

Run one prompt at a time if the agent performs better with smaller tasks. Keep `MASTER_BUILD_PROMPT.md` as the overall instruction.

## Prompt 1 — Repository audit and scaffold
Read the master prompt and repository structure document. Inspect the repository, then create the smallest complete TypeScript monorepo scaffold. Add workspace scripts, `.env.example`, `.gitignore`, lint/typecheck/build commands, and health endpoint. Run installation and verify both apps start. Do not implement extra features yet.

## Prompt 2 — Data and API
Read the data model and API contract. Implement validated demo scheme records, repository functions, all required Express routes, shared response types, validation, standard errors, health endpoint, CORS, rate limiting, and security headers. Ensure missing source URLs remain null and never invent URLs. Add API tests.

## Prompt 3 — Eligibility engine
Read `ELIGIBILITY_RULE_ENGINE.md`. Implement a pure, deterministic, unit-tested evaluator. Use pass/fail/unknown. Return the exact required statuses and detailed reasons. Cover missing answers, mandatory failures, demo data, and invalid profiles. Do not add AI to decide eligibility.

## Prompt 4 — Frontend design
Read `FRONTEND_SPEC.md`. Implement the responsive landing page, accessible questionnaire wizard, results view, scheme detail view, saved schemes page, document checklist, disclaimer, and all loading/error/empty states. Use a consistent design system. Keep eligibility decisions on the backend. Avoid generic template-looking UI and excessive animation.

## Prompt 5 — Integration
Connect every relevant screen to the real API using `VITE_API_BASE_URL`. Remove mock production flows. Preserve answers on failure, handle invalid payloads and server errors, and implement shortlist persistence. Add frontend tests and verify the complete journey.

## Prompt 6 — QA and security
Read testing and security docs. Run lint, typecheck, tests, and production build. Fix all issues. Check mobile responsiveness, keyboard navigation, CORS, request validation, safe links, missing source links, and absence of secrets. Report only checks actually run.

## Prompt 7 — Deployment and handoff
Read deployment and environment docs. Prepare host configuration, health checks, SPA fallback if needed, and final README. Deploy only if authorized credentials and access are available. Verify live health and frontend-to-backend requests before reporting URLs. Otherwise give exact manual deployment steps and required environment values.
