# Master Build Prompt — SchemeSaathi

You are a senior full-stack engineer, product designer, QA engineer, and deployment engineer. Build a complete, polished, runnable, deployable SchemeSaathi MVP from the current repository.

## First: inspect, don't overwrite blindly
1. Inspect all existing files and scripts.
2. Identify what already works.
3. Preserve useful code and avoid duplicating configuration.
4. Create or update files in place.
5. Do not claim tests/build/deployment passed unless you actually ran and verified them.

## Required docs
Follow these documents as the source of truth:
- `01-product/PRODUCT_REQUIREMENTS.md`
- `01-product/USER_FLOWS.md`
- `02-architecture/SYSTEM_ARCHITECTURE.md`
- `02-architecture/REPOSITORY_STRUCTURE.md`
- `03-implementation/IMPLEMENTATION_PHASES.md`
- `04-frontend/FRONTEND_SPEC.md`
- `05-backend/BACKEND_SPEC.md`
- `06-apis/API_CONTRACT.md`
- `07-data/DATA_MODEL_AND_SCHEMES.md`
- `08-rules/ELIGIBILITY_RULE_ENGINE.md`
- `09-quality/TESTING_AND_ACCEPTANCE.md`
- `10-deployment/DEPLOYMENT_GUIDE.md`
- `10-deployment/ENVIRONMENT_VARIABLES.md`
- `11-security/SECURITY_PRIVACY.md`

## Non-negotiable requirements
- React + Vite + TypeScript + Tailwind frontend.
- Express + TypeScript backend.
- API endpoints match the API contract.
- Rule-based eligibility evaluation with explainable reasons and three-valued logic.
- Exact status strings: `Potentially Eligible`, `More Information Required`, `Eligibility Criteria Not Met`.
- No fabricated official scheme URLs or unsupported eligibility claims.
- Demo data is visibly labelled.
- Responsive, accessible, polished interface.
- Working loading, empty, validation, and error states.
- `.env.example`, useful README, tests, and deployment instructions.
- Do not add authentication, payments, document uploads, or a database unless the core MVP is complete and stable.

## Build behavior
- Work in small phases.
- Run relevant tests after each major phase.
- Fix errors rather than only listing them.
- If a tool or deployment credential is unavailable, complete all local preparation and state exactly what manual action remains.
- Do not expose secrets in output or commit history.
- Do not stop at mock UI: connect frontend to the actual backend.
- Do not use fake API success data in production paths.

## Final response format
At completion, report:
1. What was built.
2. Exact local run commands.
3. Tests, lint, typecheck, and build results (only those actually run).
4. Required environment variables.
5. Deployment status and live URLs only if verified.
6. Known limitations and next steps.
