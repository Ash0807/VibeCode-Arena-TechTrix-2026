# Data Model and Scheme Records

## Scheme record
```ts
type SchemeCategory =
  | "education" | "healthcare" | "agriculture" | "employment"
  | "housing" | "social-welfare" | "other";

type Scheme = {
  id: string;
  name: string;
  category: SchemeCategory;
  summary: string;
  purpose: string;
  benefits: string[];
  beneficiaryDescription: string;
  geographicCoverage: {
    states: string[]; // ["ALL"] means nationwide, only if verified
    residenceTypes?: ("rural" | "urban")[];
  };
  criteria: EligibilityCriterion[];
  documents: { name: string; requiredWhen?: string; notes?: string }[];
  applicationSteps: string[];
  sourceName: string | null;
  sourceUrl: string | null;
  lastVerifiedAt: string | null;
  isDemo: boolean;
  verificationStatus: "verified" | "needs-review" | "demo";
};
```

## Criterion model
Use a finite, auditable set of operators. Example:
```ts
type EligibilityCriterion = {
  id: string;
  field: string;
  operator: "equals" | "in" | "lte" | "gte" | "between" | "isTrue";
  value: string | number | boolean | string[] | [number, number];
  description: string;
  required: boolean;
};
```

## Data quality rules
- Stable, unique IDs.
- Scheme name and category are mandatory.
- `sourceUrl` must be a valid HTTPS URL when present.
- No invented URLs. If no official source has been verified, use `null`.
- `lastVerifiedAt` is null until a human has checked the record.
- `isDemo: true` records must be visibly marked as demo in the UI.
- Never present placeholder records as official schemes.
- Store a short source note and a verification owner/work item for future maintenance.
- Add automated schema validation to CI.

## Initial dataset
Seed 8–12 records to demonstrate all categories, but mark unverified records as demo. Prefer a small number of genuinely verified official schemes over a large inaccurate catalogue. When adding a real scheme, confirm details and links from its official ministry/state portal and record the verification date.
