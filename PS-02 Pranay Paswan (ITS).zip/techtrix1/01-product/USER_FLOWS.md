# User Flows

## Flow A — Discover schemes
1. User opens landing page.
2. User selects “Check schemes”.
3. User completes a short step-by-step profile questionnaire.
4. Frontend validates each step and allows back navigation.
5. Frontend submits profile to `POST /api/v1/eligibility/check`.
6. Backend evaluates curated scheme rules.
7. Results page groups schemes by status and shows explanations.
8. User opens a scheme detail page or expands a result card.

## Flow B — Review a scheme
1. User opens a scheme card.
2. App displays purpose, benefits, eligibility criteria, required documents, source link, and last-verified date.
3. User can copy/save the document checklist.
4. User opens the official application/source link in a new tab with safe link attributes.

## Flow C — Shortlist
1. User clicks “Save scheme”.
2. Scheme ID is stored in localStorage.
3. Saved schemes page lists saved IDs that still exist in the scheme dataset.
4. User can remove a saved scheme. If localStorage is unavailable, show a helpful message and allow use without saving.

## Flow D — Report stale data
1. User selects “Report incorrect/outdated information”.
2. App asks for scheme ID and a short issue category, with optional text.
3. Submit to `POST /api/v1/feedback`.
4. Show success only if backend confirms receipt. Never claim that government agencies received the report.

## Error cases
- Backend unavailable: show retry button and preserve questionnaire answers.
- Invalid profile: show field-level errors.
- No matching schemes: suggest adjusting optional answers and show all categories to explore.
- Scheme source missing: do not display a fake link; show “Official link not available — verify with the relevant department.”
