# Product Requirements — SchemeSaathi

## 1. Problem
Government benefits and assistance are spread across many official portals. People may struggle to discover relevant schemes, understand eligibility conditions, prepare documents, and find the correct official application route.

## 2. Target users
- Students and families looking for education support
- Rural and urban households exploring housing or welfare support
- Workers, farmers, caregivers, and people exploring employment, healthcare, agriculture, or social welfare schemes
- Community volunteers helping users navigate scheme information

## 3. MVP scope
1. Responsive landing page explaining the service.
2. Guided eligibility questionnaire.
3. Rule-based matching against curated sample schemes.
4. Results with one of three exact statuses:
   - `Potentially Eligible`
   - `More Information Required`
   - `Eligibility Criteria Not Met`
5. Explain each status with matched criteria, unmet criteria, and missing answers.
6. Scheme detail view: purpose, target beneficiaries, benefits, eligibility, documents, source, last verified date, and official application link.
7. Shortlist/save schemes locally.
8. Generate a practical document checklist.
9. Search and filter by category, state, and status.
10. Accessible disclaimer and feedback/report-stale-information action (MVP can record feedback locally or to a simple endpoint).

## 4. Out of scope for first release
- Official application submission on behalf of a user
- Login, identity verification, Aadhaar integration, or document upload
- Claims of guaranteed eligibility or guaranteed benefits
- Scraping government sites at runtime
- AI deciding eligibility without auditable rules
- Payment processing
- Admin CMS unless time remains after the MVP works

## 5. Main questionnaire fields
Ask only what is required by the selected scheme rules. Initial shared fields may include:
- State/UT
- Rural or urban residence
- Age band (prefer age range over exact birth date)
- Occupation group
- Approximate annual household income band
- Household size / relevant family situation
- Student status or education level when relevant
- Farmer status when relevant
- Housing ownership / current housing condition when relevant
- Category/disability/widow status only where required by a scheme and with a clear explanation of why it is asked; avoid collecting sensitive details unless necessary.

Use `unknown` / `prefer not to say` where possible. A missing answer must not be treated as a negative answer.

## 6. Result requirements
Each result includes:
- Scheme name and category
- Exact status
- Plain-language reason
- Criteria matched
- Criteria not met (if any)
- Missing answers / additional details needed
- Benefits summary
- Document checklist
- Official source/application link
- Last verified date and data confidence note

## 7. UX requirements
- Mobile-first and keyboard accessible
- Clear progress indicator and back navigation
- Preserve answers while navigating back
- Avoid overwhelming forms; use short steps and conditional questions
- Strong empty, loading, error, and no-results states
- No deceptive urgency, fake testimonials, fake government logos, or fabricated statistics

## 8. Success criteria
- A user can complete the questionnaire and see results without creating an account.
- Every result explains the reason for its status.
- No unsupported scheme claims or invented URLs.
- Core user journey works on mobile and desktop.
- All acceptance tests in the testing document pass.
