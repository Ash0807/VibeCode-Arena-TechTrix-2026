# Security and Privacy

## Data minimization
- Do not request Aadhaar numbers, PAN, bank details, OTPs, exact home address, or identity-document uploads in the MVP.
- Prefer broad age and income bands.
- Explain why any optional/sensitive field is needed.
- Permit unknown/prefer-not-to-say where possible.
- Do not send analytics events containing questionnaire answers.

## Application security
- Validate every API request.
- Use secure HTTP headers (for example, Helmet).
- Configure CORS to approved origins.
- Apply rate limits to public endpoints.
- Limit body sizes and message lengths.
- Use safe external links: `target="_blank"` with `rel="noopener noreferrer"` when applicable.
- Avoid rendering user text as raw HTML.
- Keep dependencies updated and review audit output.
- Never log secrets, full profiles, or sensitive answers.

## Honest UX
- State that SchemeSaathi is an independent discovery tool and not a government website.
- Eligibility is preliminary and does not guarantee approval, benefits, or acceptance of an application.
- Explain source verification date and data limitations.
- Do not imply feedback is submitted to a ministry unless that integration truly exists.
- Provide a way to correct stale data or clearly say the feature is not active.

## Deployment security
- HTTPS only in production.
- Store secrets in the hosting platform's environment settings.
- Restrict CORS to the deployed frontend origin.
- Avoid exposing stack traces and internal paths.
- Have a plan to disable inaccurate scheme records quickly.
