# Release Checklist

## Before merge
- [ ] Product requirements met
- [ ] API contract and frontend types match
- [ ] All scheme records pass schema validation
- [ ] Every real scheme has verified official source and last-verified date
- [ ] Demo records are clearly labelled
- [ ] Rule engine has tests for all statuses
- [ ] No sensitive information is logged
- [ ] No secrets or `.env` files committed
- [ ] Lint, typecheck, tests, and production build pass

## Before deployment
- [ ] Backend environment variables set
- [ ] Frontend API base URL set
- [ ] CORS includes production frontend origin only
- [ ] Health check configured
- [ ] SPA fallback configured if needed
- [ ] HTTPS confirmed
- [ ] Core user journey smoke-tested

## After deployment
- [ ] Frontend loads on mobile and desktop
- [ ] API health endpoint responds
- [ ] Questionnaire reaches deployed backend
- [ ] Results display reason explanations
- [ ] Shortlist works
- [ ] Broken/missing links are handled safely
- [ ] Disclaimer is visible
- [ ] README contains real verified URLs only
