# API Contract — `/api/v1`

All responses are JSON. Use the same response shapes in frontend types and backend schemas. Dates use ISO 8601 (`YYYY-MM-DD`) unless a full timestamp is needed.

## 1. Health
`GET /api/v1/health`

Success `200`:
```json
{
  "status": "ok",
  "service": "schemesaathi-api",
  "version": "1.0.0"
}
```

## 2. List/search schemes
`GET /api/v1/schemes?category=housing&state=UP&q=home&limit=20&offset=0`

Success `200`:
```json
{
  "data": [
    {
      "id": "demo-housing-001",
      "name": "Example Housing Support Scheme",
      "category": "housing",
      "summary": "Demo record: replace with verified scheme information.",
      "states": ["ALL"],
      "sourceUrl": null,
      "lastVerifiedAt": null,
      "isDemo": true
    }
  ],
  "pagination": { "limit": 20, "offset": 0, "total": 1 }
}
```

Allowed categories: `education`, `healthcare`, `agriculture`, `employment`, `housing`, `social-welfare`, `other`. Unknown category should produce `400`.

## 3. Scheme details
`GET /api/v1/schemes/:id`

Success `200`:
```json
{
  "data": {
    "id": "demo-housing-001",
    "name": "Example Housing Support Scheme",
    "category": "housing",
    "purpose": "Demo content pending verification.",
    "benefits": [],
    "eligibility": [],
    "documents": [],
    "applicationSteps": [],
    "sourceName": null,
    "sourceUrl": null,
    "lastVerifiedAt": null,
    "isDemo": true,
    "disclaimer": "Verify details on the official source before applying."
  }
}
```
Unknown ID: `404`.

## 4. Eligibility check
`POST /api/v1/eligibility/check`

Request:
```json
{
  "profile": {
    "state": "UP",
    "residenceType": "urban",
    "ageBand": "25-34",
    "occupation": "salaried",
    "annualIncomeBand": "150000-300000",
    "householdSize": 4,
    "ownsPuccaHouse": "unknown",
    "isStudent": "no",
    "isFarmer": "no"
  },
  "categories": ["housing", "social-welfare"]
}
```

Success `200`:
```json
{
  "data": [
    {
      "schemeId": "demo-housing-001",
      "status": "More Information Required",
      "summary": "One or more required answers are missing.",
      "matchedCriteria": [],
      "unmetCriteria": [],
      "missingInformation": ["ownsPuccaHouse"],
      "documents": [],
      "confidence": "demo",
      "sourceUrl": null,
      "lastVerifiedAt": null,
      "isDemo": true
    }
  ],
  "meta": {
    "evaluatedCount": 1,
    "disclaimer": "These are preliminary matches, not an official eligibility decision."
  }
}
```

Valid statuses are exactly:
- `Potentially Eligible`
- `More Information Required`
- `Eligibility Criteria Not Met`

## 5. Feedback
`POST /api/v1/feedback`

Request:
```json
{
  "schemeId": "demo-housing-001",
  "issueType": "outdated",
  "message": "Optional note, maximum 1000 characters."
}
```

Allowed `issueType`: `outdated`, `broken-link`, `incorrect-detail`, `other`.

Success `201` only when feedback has actually been persisted:
```json
{
  "data": {
    "received": true,
    "referenceId": "generated-server-reference"
  }
}
```
If no persistence is configured, return a documented `501`/`503` or disable the form; do not fake receipt.

## Standard error response
```json
{
  "error": {
    "code": "NOT_FOUND",
    "message": "The requested scheme was not found.",
    "details": []
  },
  "requestId": "req_example"
}
```

## Contract rules
- Validate query parameters and request bodies.
- Never trust a status submitted by the frontend.
- Limit list results and feedback message length.
- Do not return private server details.
- Keep frontend TypeScript types aligned with this contract.
