# Eligibility Rule Engine

## Purpose
Produce transparent preliminary matching, not an official eligibility decision.

## Status precedence
1. If one or more required criteria are unknown because the user did not answer them, and no known criterion already definitively fails the scheme, return `More Information Required`.
2. If any mandatory criterion definitively fails, return `Eligibility Criteria Not Met`.
3. If all mandatory criteria pass and no required answer is missing, return `Potentially Eligible`.
4. If a scheme has unverified/demo rules, do not represent the outcome as verified eligibility. Include `confidence: "demo"` and show a visible demo-data warning.

If a definitive mandatory failure exists, it is reasonable to return `Eligibility Criteria Not Met` even if other optional fields are unknown; list both the unmet criterion and other missing information when helpful. Keep this behavior consistent and covered by tests.

## Three-valued logic
Each criterion evaluation returns:
- `pass`
- `fail`
- `unknown`

Unknown means the answer or rule is not available. It is not equivalent to `false`.

## Engine pseudocode
```ts
function evaluateScheme(profile, scheme) {
  const evaluations = scheme.criteria.map(criterion =>
    evaluateCriterion(profile, criterion)
  );

  const unmet = evaluations.filter(x => x.result === "fail");
  const missing = evaluations.filter(x => x.result === "unknown");

  if (unmet.some(x => x.required)) {
    return result("Eligibility Criteria Not Met", unmet, missing);
  }

  if (missing.some(x => x.required)) {
    return result("More Information Required", unmet, missing);
  }

  return result("Potentially Eligible", unmet, missing);
}
```

## Required reason codes
- `CRITERION_PASSED`
- `CRITERION_FAILED`
- `ANSWER_REQUIRED`
- `RULE_UNVERIFIED`
- `SOURCE_MISSING`
- `SOURCE_OUTDATED`

## Requirements
- Every result includes human-readable reasons.
- Reasons must map to criterion descriptions, not generic “not eligible” text.
- Age and income band comparisons must be explicit and tested.
- Do not assume that an absent value means no, zero, or false.
- Do not infer a legal category, caste, disability, or other sensitive status.
- Do not combine schemes or promise that multiple benefits can be received unless official rules confirm compatibility.
- A result is a discovery aid. Official scheme authorities make final decisions.

## Test cases
1. All required criteria pass → `Potentially Eligible`.
2. One required answer missing, no mandatory failure → `More Information Required`.
3. One mandatory criterion fails → `Eligibility Criteria Not Met`.
4. Missing answer plus mandatory failure → `Eligibility Criteria Not Met`, with both reasons represented.
5. Rule is demo/unverified → demo warning remains visible.
6. Missing source URL → no external link is rendered.
7. Invalid profile input → API returns `400`, engine is not called.
