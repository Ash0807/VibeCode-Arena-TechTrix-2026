# Frontend Specification

## Stack
React, Vite, TypeScript, Tailwind CSS, React Router, and a lightweight form/schema solution such as React Hook Form + Zod. Avoid unnecessary libraries.

## Pages
- `/` — landing page with value proposition, “Check schemes” CTA, how it works, categories, disclaimer.
- `/check` — step-by-step questionnaire.
- `/results` — eligibility results and filters.
- `/schemes/:id` — scheme details.
- `/saved` — shortlisted schemes.
- `*` — accessible not-found page.

## Visual direction
- Trustworthy, modern public-service utility; not a government impersonation.
- Warm off-white background, deep navy/teal text, one bright accent, clear spacing, restrained shadows.
- Strong typography hierarchy and readable line length.
- Cards with clear status labels, category icons, benefits summary, and action buttons.
- Subtle transitions only; respect reduced-motion settings.
- Mobile-first layout, touch targets ideally 44×44 px or larger.

## Components
- `AppShell`, `Header`, `Footer`, `DisclaimerBanner`
- `StepProgress`, `QuestionField`, `QuestionnaireNavigation`
- `SchemeCard`, `EligibilityStatusBadge`, `ReasonList`
- `DocumentChecklist`, `SchemeFilters`, `EmptyState`, `ErrorState`
- `Toast` or inline accessible status message
- `LoadingSkeleton`

## State and API rules
- Keep questionnaire answers in app state and preserve them if API requests fail.
- API response status is authoritative for the displayed result.
- Do not compute eligibility independently in the frontend.
- Handle `AbortController` or request cancellation when leaving a page.
- Use `VITE_API_BASE_URL`; do not hardcode production endpoints.
- localStorage may store shortlist IDs and questionnaire draft only if clearly useful. Avoid storing sensitive attributes.

## Accessibility
- Semantic headings and landmarks.
- Every input has a visible label.
- Errors are associated with fields and announced to screen readers.
- Keyboard-visible focus styles.
- Color is never the only way status is communicated.
- Modal/dialog focus management if dialogs are used.
- Ensure contrast and responsive text sizing.

## Required states
- Initial, loading, success, empty, invalid form, network error, server error, saved, unsaved, source missing/outdated.
- Do not use fake loading delays or pretend API responses.
