# Recommended Repository Structure

Use a monorepo so the frontend, backend, shared contracts, data, and documentation stay synchronized.

```text
schemesaathi/
├── README.md
├── package.json
├── package-lock.json
├── .gitignore
├── .editorconfig
├── .env.example
├── docs/
│   └── (copy this documentation pack here)
├── apps/
│   ├── web/
│   │   ├── package.json
│   │   ├── vite.config.ts
│   │   ├── index.html
│   │   └── src/
│   │       ├── app/
│   │       ├── components/
│   │       ├── features/
│   │       │   ├── questionnaire/
│   │       │   ├── results/
│   │       │   ├── schemes/
│   │       │   └── shortlist/
│   │       ├── lib/api.ts
│   │       ├── lib/storage.ts
│   │       ├── styles/
│   │       └── main.tsx
│   └── api/
│       ├── package.json
│       └── src/
│           ├── app.ts
│           ├── server.ts
│           ├── routes/
│           ├── controllers/
│           ├── services/
│           ├── schemas/
│           ├── data/schemes.json
│           ├── repositories/
│           ├── rules/
│           ├── middleware/
│           └── tests/
├── packages/
│   └── contracts/
│       ├── package.json
│       └── src/
└── tests/
    └── e2e/
```

## Build guidance
- Use npm workspaces or another single, documented workspace approach.
- Root scripts should expose `dev`, `build`, `test`, `lint`, and `typecheck`.
- Do not create duplicate package managers or multiple lockfiles.
- Do not commit `.env` or secrets.
- Keep scheme records in one source of truth.
