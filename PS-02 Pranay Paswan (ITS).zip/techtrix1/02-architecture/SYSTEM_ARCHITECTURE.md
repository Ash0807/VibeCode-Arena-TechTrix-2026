# System Architecture

## Overview
React client → Express REST API → scheme repository → deterministic eligibility rule engine.

The MVP uses curated data checked into the repository. Keep the repository layer isolated so JSON seed data can later be replaced with PostgreSQL without rewriting routes or the rule engine.

## Responsibilities
### Frontend
- Questionnaire state and client-side validation
- Accessible responsive UI
- API calls and error handling
- Result explanation rendering
- Local shortlist persistence
- No authoritative eligibility logic duplicated in UI

### Backend
- Request validation
- API versioning under `/api/v1`
- Rule evaluation and status assignment
- Scheme search/detail responses
- Feedback validation
- CORS, rate limiting, security headers, request logging

### Data
Each scheme has a stable ID, category, geographic coverage, criteria, benefits, required documents, source URL, and `lastVerifiedAt`.

## Data flow
1. Client posts profile answers.
2. Server validates request with a schema.
3. Engine evaluates each applicable scheme.
4. Engine returns status plus reason codes and user-facing explanations.
5. Client renders results without inferring its own eligibility status.

## Architecture rules
- Use TypeScript on both sides.
- Keep route handlers thin; business logic belongs in services.
- Keep eligibility rules data-driven and testable.
- Never trust client-provided scheme data or status.
- Do not log full user profiles or sensitive answers.
- Set explicit API timeouts and useful error messages.
- Use a health endpoint for deployment checks.
