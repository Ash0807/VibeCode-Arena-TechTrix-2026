# SchemeSaathi — Complete Frontend Build Prompt

> **Purpose:** Use this single Markdown file with a coding agent to build and polish every SchemeSaathi frontend page. Read the existing repository and project documentation first. Implement the complete frontend in the existing application; do not create a disconnected demo.

---

## 1. Role and project context

You are a senior UI/UX designer and frontend engineer. Improve the existing SchemeSaathi project into a polished, production-quality, responsive government-scheme discovery platform.

SchemeSaathi helps users discover Indian government schemes through a transparent, rule-based preliminary matching process. Users can complete a questionnaire, view scheme recommendations and explanations, inspect scheme details, prepare a document checklist, and shortlist schemes.

### Before editing
1. Inspect the current repository, scripts, routes, components, API client, and styles.
2. Read the existing `README.md` and relevant project docs, especially frontend, API contract, data model, eligibility rule engine, security/privacy, testing, and deployment documentation.
3. Preserve working code and follow the existing architecture.
4. Reuse installed dependencies and existing shared components where appropriate.
5. Do not create a separate demo app or replace real API calls with mock responses.

## 2. Technology and implementation rules

Use the existing React + Vite + TypeScript + Tailwind CSS setup. Reuse the project's router and UI libraries if already installed. Avoid unnecessary dependencies.

- Use reusable components and typed API service functions.
- Use `VITE_API_BASE_URL` for the API base URL.
- Never hardcode production API endpoints.
- Follow the documented API contract and keep frontend types aligned with backend responses.
- Keep eligibility decisions on the backend; do not reimplement the eligibility engine in the UI.
- Use localStorage for shortlist IDs and safe, non-sensitive questionnaire drafts where appropriate.
- Never place questionnaire details or sensitive attributes in URL query parameters.
- Do not collect Aadhaar numbers, PAN, bank details, OTPs, exact home addresses, or identity-document uploads in the MVP.
- Do not invent official scheme URLs, scheme facts, user testimonials, government endorsements, statistics, or successful submissions.
- Label demo/unverified records visibly.
- A preliminary recommendation is not an official eligibility decision and does not guarantee approval or benefits.

## 3. Global design system

The website must not look like a plain all-white template. Use a light-blue visual identity across all routes.

### Palette
- Main background: `#DDF2FF`
- Section background: `#F3F9FF`
- Cards and form surfaces: `#FFFFFF`
- Primary blue: `#1264D8`
- Deep navy text: `#12304A`
- Teal accent: `#087F72`
- Borders: `#C8E4F7`
- Muted text: `#5C7185`

### Visual style
- Soft blue gradients and subtle decorative shapes
- White cards over light-blue page backgrounds
- Rounded cards (14–20px), gentle shadows, clean typography
- Strong visual hierarchy and balanced spacing
- Friendly, high-quality illustrations relevant to Indian citizens and public services
- Consistent Lucide-style icons
- Subtle hover/focus/transition effects; respect reduced-motion preferences
- Avoid excessive animations, clutter, overly large empty areas, and generic template styling

### Shared shell
Create or refine reusable:
- Header and footer
- Desktop navigation and mobile menu
- Page container and section heading
- Buttons, links, inputs, selects, checkboxes, radio/segmented controls
- Scheme cards, category chips, status badges
- Step progress indicator
- Loading skeletons, empty states, error states
- Accessible toast/inline notifications
- Disclaimer banner
- Document checklist item

### Accessibility and responsive design
- Mobile-first layout; test at 360px, tablet, and desktop widths.
- Use semantic HTML, landmarks, and a logical heading hierarchy.
- Every input must have a visible label.
- Show clear keyboard focus states.
- Associate validation errors with fields and announce relevant status changes.
- Never rely on colour alone for eligibility statuses.
- Ensure buttons/touch targets are comfortably tappable.
- Maintain readable contrast and responsive typography.
- If dialogs are used, manage focus correctly.

## 4. Routes and pages to implement

Implement all pages below within the existing router. If a route already exists, improve it rather than creating a duplicate. Navigation must work and every visible CTA must perform its advertised action.

### A. Landing page — `/`

Build a high-quality, welcoming landing page.

Include:
- Hero headline: **“Find Government Schemes Made Simpler”**
- Short explanation: discover potentially relevant education, healthcare, agriculture, employment, housing, and social welfare schemes.
- Primary CTA: **“Find My Schemes”** → `/check`
- Secondary CTA: **“Explore Schemes”** → `/schemes`
- Relevant, high-quality illustration of an Indian family or citizen using a digital service.
- Six category cards with icons, short descriptions, and links to filtered scheme listings.
- Three-step “How it works” section.
- Feature section for personalized matching, transparent eligibility explanations, and document checklists.
- Trust section explaining rule-based matching and official-source references without invented statistics or government affiliation.
- Visible preliminary-guidance disclaimer.
- Footer links for About, Help, Privacy, and Feedback.

Use a light-blue gradient hero, visual depth, subtle decoration, responsive layouts, and meaningful hover states. Do not invent testimonials or government endorsements.

### B. Scheme finder — personal details — `/check`

Build the first step of a guided questionnaire.

Collect only necessary information:
- State or Union Territory
- Rural or urban residence
- Age band
- Occupation
- Approximate annual household income band

Design:
- Light-blue page background
- Centered white form card
- Step progress indicator
- Desktop explanatory side panel where useful; mobile progress indicator above the form
- Clearly labelled dropdowns, segmented controls, or radio cards
- Short helper text explaining why answers are requested
- Required markers, validation messages, Back and Next buttons
- Privacy reassurance

Preserve answers when navigating backward. Validate using the existing shared schema/state approach. Do not collect identity numbers, bank details, or document uploads.

### C. Scheme finder — family details

Implement the next questionnaire step using the same design system.

Ask only fields needed by supported scheme rules, potentially:
- Household size
- Student status
- Farmer status
- House ownership/current housing condition
- Other scheme-specific circumstances when genuinely necessary

Use conditional fields so irrelevant questions do not appear. Provide “Unknown” or “Prefer not to say” where appropriate. Explain why any sensitive or personal question is needed. Missing answers must not be treated as “No.”

Include Back and Next actions and preserve the user's answers.

### D. Scheme finder — review and submit

Show a review summary grouped into Personal Details and Family Details.

Include:
- Edit action for each section, returning to the appropriate step without losing answers
- Back action
- Primary CTA: **“Find Matching Schemes”**

Validate the complete profile, submit it to the documented eligibility API, prevent duplicate submissions, and show a loading state. On failure, preserve answers and provide a retry action. On success, use the actual API response or existing shared state to navigate to `/results`.

Do not calculate eligibility in the frontend and do not put profile answers in URL query parameters.

### E. Recommended schemes / results — `/results`

Build a polished results dashboard.

At the top show:
- “Your Recommended Schemes”
- Short explanation of how recommendations were generated
- Number of returned schemes, calculated from actual data
- Filters for All, Education, Healthcare, Housing, Agriculture, Employment, and Social Welfare, based on actual returned categories

Each scheme card must include:
- Scheme name and category
- Short purpose/benefit summary
- Exact status returned by the backend
- Concise reason for the status
- Missing information or unmet criteria, when applicable
- “View Details” action
- “Save Scheme” action

Use exactly these status labels:
- `Potentially Eligible`
- `More Information Required`
- `Eligibility Criteria Not Met`

Use green, amber, and red as supporting status colours respectively, but also show text and icons. Do not change or upgrade backend statuses.

Include useful loading skeletons, API errors with Retry, no-results and empty-category states. Preserve questionnaire answers. Do not generate fake scheme results.

### F. Browse all schemes — `/schemes`

Build a scheme directory that works even when users have not completed the questionnaire.

Include:
- Search by scheme name or keyword
- Category filters
- State/Union Territory filter if supported by the API
- Responsive scheme card grid/list
- Pagination or “Load more” if supported
- Clear/reset-filter action
- Empty, loading, and error states

Each card displays scheme name, category, short description, source verification state, and “View Details.” Clearly label demo records. Connect to the actual scheme-list endpoint. Do not fabricate scheme records or links.

### G. Scheme details — `/schemes/:id`

Fetch the selected scheme from the backend by ID; do not hardcode details into the page.

Include:
- Breadcrumb navigation
- Scheme name, category, and verification label
- Purpose and intended beneficiaries
- Benefits summary
- Eligibility criteria
- Required documents
- Application process, only where available and verified
- Source name and last-verified date
- Save/unsave action
- “Visit Official Website” action only when a verified URL exists
- Document checklist action
- Preliminary-guidance disclaimer

Use tabs or anchor navigation where helpful, while keeping mobile content accessible. Clearly label demo records. If an official URL is missing, do not render a fake link. Handle loading, not-found, and API errors gracefully.

### H. Document checklist

Build a checklist page or panel for a selected scheme.

Include:
- Selected scheme name
- Checklist of documents returned by the backend
- Checkboxes to mark prepared documents
- Progress such as “3 of 6 prepared,” calculated from actual checklist state
- Reset checklist action
- Back to Scheme action
- Official website action only when a verified source URL exists
- Print-friendly checklist
- Notice that document requirements should be confirmed on the official portal

Save checklist progress locally using the scheme ID if appropriate. Do not upload documents or collect identity-document images.

Only show Required/Optional labels when supported by data. If document information is absent, display “Document requirements have not been verified” rather than inventing requirements.

### I. My shortlist — `/saved`

Build the saved schemes page.

- Read saved scheme IDs from the existing localStorage utility.
- Resolve details using the existing API/data layer.
- Show “My Shortlisted Schemes” and the actual saved count.
- Display scheme cards with category and actual eligibility status if a matching result exists.
- Include “View Details” and “Remove” actions.
- Provide confirmation or an undo option for removal.
- Show an empty state with an “Explore Schemes” CTA.
- Handle deleted or unavailable scheme IDs gracefully.

Saving/removing should update immediately and remain consistent across results, details, and saved pages. Do not require login for the MVP. Saving a scheme must never be described as applying for it.

### J. Dashboard — `/dashboard`

Build a useful overview without pretending the user has an account if authentication does not exist.

Include:
- Welcome heading
- Total schemes returned in the current results, if available
- Counts for the three eligibility statuses, computed from actual data
- Shortlisted schemes
- Quick actions: Check Schemes, Explore Schemes, My Shortlist, Document Checklist
- Profile summary from existing questionnaire state, if available

Use a modern two-column desktop layout and stacked mobile cards. Use charts only when real data exists and the chart adds value.

Do not fabricate a name, scheme counts, application history, or approval status. If data is unavailable, show an empty state with a CTA to start checking schemes.

### K. Profile and update answers — `/profile`

For the MVP, use existing local questionnaire state/localStorage utilities. Do not invent authentication.

Include:
- Previously entered answers when available
- Edit answers action
- Validation and rerun eligibility check through the real API
- Notice that changing answers may change recommendations
- Privacy note about not asking for Aadhaar, bank details, OTPs, or document uploads
- Clear locally stored questionnaire answers and shortlist data action, with confirmation

If no profile exists, show an empty state and a “Start Scheme Finder” CTA. Do not display private data in URLs or logs.

### L. No matching schemes state — used in `/results`

Create a polished empty state with a friendly illustration and message:
**“We couldn't find a matching scheme with the details provided.”**

Explain that this does not prove the user is ineligible for every government scheme.

Provide:
- “Update My Answers” — return to questionnaire with answers preserved
- “Explore All Schemes” — `/schemes`
- Clear/change category filters where applicable

If the API returns schemes with `Eligibility Criteria Not Met`, display those results under the correct status instead of claiming no schemes were returned. Never loosen rules or invent matches. Include the preliminary-guidance disclaimer.

### M. Loading, error, and not-found states

Create reusable states and use them across all pages.

**Loading**
- Skeleton cards and progress indicators matching the light-blue design system
- No fake long delays

**API/network error**
- Friendly error message
- Retry action
- Navigation to a useful prior screen
- Preserve questionnaire answers and safe user input

**API unavailable**
- Explain that results could not be loaded
- Never show fake success data

**404**
- Custom not-found page with a friendly illustration
- Working Home and Explore Schemes buttons

**Error handling**
- Prevent duplicate submissions
- Handle unexpected response shapes safely
- Do not expose stack traces/server internals
- Use accessible notifications
- Make errors recoverable where possible

### N. About — `/about`

Explain:
- Why SchemeSaathi exists
- How rule-based matching works
- What the three eligibility statuses mean
- Why preliminary recommendations are not official decisions
- How source verification works

Do not claim government affiliation, partnership, or endorsement.

### O. Help — `/help`

Create a clear FAQ covering:
- How to complete the questionnaire
- Meaning of each eligibility status
- How to use document checklists
- How to verify and open official links
- How to report outdated information

Use accessible accordions if helpful. Ensure keyboard navigation works.

### P. Privacy — `/privacy`

Describe the actual data handling implemented in the code. Explain localStorage use and data minimization accurately. Do not promise information is never stored unless the implementation confirms it. Do not claim legal certifications or compliance that have not been established.

### Q. Feedback — `/feedback`

Build a short, accessible feedback form with:
- Issue category
- Optional message
- Validation and character limit
- Clear submit/loading/error states

Connect to the documented feedback API only if it is implemented. Show success only after the backend confirms that feedback was persisted. If persistence is unavailable, disable the form or explain the limitation; never fake successful submission.

Do not invent contact details or imply that feedback has been sent to a government department.

## 5. Shared navigation and interactions

Ensure navigation is consistent:
- Home
- Find Schemes
- Browse Schemes
- My Shortlist
- Profile (if implemented)
- Help

On desktop, use a clean top navigation or the existing layout if one already exists. On mobile, use a compact menu or bottom navigation only if it improves usability.

Every visible button/link must have a real action. All pages must handle missing data and loading/error states. Keep shared UI components reusable and avoid duplicating API logic.

## 6. API and data integration

- Use the API endpoints and response types documented in the project docs.
- Use a shared typed API client.
- Respect `VITE_API_BASE_URL`.
- Do not embed mock data in production user flows.
- Do not trust client-supplied eligibility statuses.
- Do not show a source link when the URL is missing or invalid.
- Use safe external links (`target="_blank"` with `rel="noopener noreferrer"` when opening a new tab).
- Use actual response data for all counts and summaries.
- If the backend is unavailable, show a recoverable error instead of pretending the request succeeded.

## 7. Security, privacy, and trust

- Minimize personal data collection.
- Do not log full questionnaire profiles or sensitive answers.
- Do not use raw HTML rendering for user-supplied text.
- Never store secrets in frontend code or `VITE_` variables.
- Keep the independent-project disclaimer visible.
- Explain that recommendations are preliminary and do not guarantee eligibility, approval, or receipt of benefits.
- Clearly mark demo/unverified data and show last-verified dates when available.
- Do not invent official links, eligibility criteria, or document requirements.

## 8. Final integration and design audit

After all pages are implemented, inspect the complete frontend and improve it holistically.

### Design audit
- Replace plain all-white page backgrounds with the light-blue design system.
- Standardize spacing, typography, cards, borders, shadows, buttons, and status badges.
- Ensure header, footer, navigation, and mobile menu are consistent.
- Improve hierarchy and remove excessive empty space.
- Ensure the site looks polished on mobile, tablet, and desktop.
- Use consistent icons and appropriate illustrations.
- Check contrast, focus states, keyboard navigation, and reduced-motion behavior.

### Functional audit
- Test every navigation link and CTA.
- Test the complete questionnaire-to-results flow.
- Verify real API integration and error handling.
- Check details, checklist, shortlist persistence, and filters.
- Ensure the three statuses are displayed exactly as returned.
- Remove fake data from production flows.
- Ensure missing official links are handled safely.
- Verify the disclaimer is visible.

### Engineering audit
- Remove duplicate components and dead code.
- Fix React warnings, TypeScript errors, broken routes, and console errors.
- Keep API calls in reusable service functions.
- Verify environment variable usage.
- Run the project's lint, typecheck, tests, and production build scripts.
- Verify nested routes are supported by deployment configuration.

Do not rewrite working features unnecessarily. Fix actual issues and report only checks that were genuinely run.

## 9. Definition of done

The frontend is complete when:
- Every route above is implemented or clearly marked as intentionally out of scope.
- The design is consistent, light-blue, responsive, accessible, and polished.
- The questionnaire connects to the actual backend.
- Results and eligibility statuses come from the backend.
- Scheme details and directory use real API/data sources.
- Shortlist and checklist work as specified.
- Loading, empty, error, and not-found states work.
- No invented scheme facts, official URLs, testimonials, or fake success messages appear.
- No secrets or sensitive personal data are exposed.
- Lint, typecheck, tests, and production build pass, or any remaining failures are documented honestly.

## 10. Final report

When done, provide:
1. Pages and shared components implemented.
2. Main files changed.
3. Local run commands.
4. Tests, lint, typecheck, and build results — only those actually run.
5. Required environment variables.
6. Known limitations and next steps.
7. Deployment status and live URLs only if deployment was performed and verified.
