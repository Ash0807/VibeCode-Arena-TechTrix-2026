# Scheme Data Maintenance

## Why this exists
Government schemes and rules change. A correct interface with stale data can still mislead users.

## Verification checklist for each real scheme
- Confirm scheme name and current status on an official ministry/state portal.
- Confirm who administers the scheme and who can apply.
- Verify geographic coverage and rural/urban scope.
- Verify income, age, household, occupation, and other criteria.
- Verify benefit description and whether benefits are conditional.
- Verify required documents and application process.
- Verify official source/application URLs and HTTPS.
- Record `lastVerifiedAt` and `sourceName`.
- Add tests for each eligibility rule.
- Have a second reviewer check high-impact criteria where possible.

## Change workflow
1. Open a change request for the scheme record.
2. Attach official source notes (not personal data).
3. Update criteria and source metadata.
4. Run schema validation and rule tests.
5. Review user-facing explanations.
6. Merge and deploy.
7. If a source is broken or uncertain, mark `needs-review` and suppress definitive matching until reviewed.

## User-facing freshness
Show the last-verified date when available. If missing or older than the team's chosen review interval, display a visible “Please verify on the official portal” warning. Do not label a record verified merely because its URL opens.
