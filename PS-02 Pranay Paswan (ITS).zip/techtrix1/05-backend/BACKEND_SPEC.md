# Backend Specification

## Stack
Node.js, Express, TypeScript, Zod, and Vitest/Supertest.

## Layers
- Routes: URL/method definitions only
- Controllers: request/response mapping
- Services: scheme search and eligibility use cases
- Rules: deterministic criteria evaluation
- Repositories: scheme data access
- Schemas: request validation
- Middleware: errors, request IDs, rate limits, security, CORS

## Required endpoints
See `../06-apis/API_CONTRACT.md`.

## Error format
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Please correct the highlighted fields.",
    "details": []
  },
  "requestId": "req_example"
}
```

Never expose stack traces, environment variables, secrets, or raw internal errors in production.

## Runtime requirements
- `GET /api/v1/health` returns service status and version.
- Bind to `process.env.PORT` or a safe local default.
- Use graceful shutdown for SIGTERM/SIGINT.
- Validate environment variables on startup.
- Limit JSON request body size.
- Apply rate limiting to eligibility and feedback endpoints.
- Restrict CORS to configured frontend origins in production.
- Add request IDs and structured logs; do not log complete questionnaire payloads.
- Use consistent HTTP status codes.

## MVP persistence
- Schemes: checked-in seed JSON.
- Feedback: either store in a simple configured database or clearly document that it is not persisted. If not persisted, do not show a success confirmation implying it was stored.
- Shortlist: localStorage on client; no server account required.
- Keep a repository interface so a database can be introduced later.

## Reliability
- Validate every incoming payload.
- Return `400` for invalid input, `404` for unknown scheme, `429` for rate-limited requests, and `500` only for unexpected server failures.
- Never silently convert unknown answers to false.
