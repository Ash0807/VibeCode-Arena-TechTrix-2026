# Implementation Phases — 90-Minute MVP

This is a time-boxed plan. Working software is more important than adding many incomplete features.

## Phase 0 — Repository and environment (0–8 min)
- Inspect the existing repository before editing.
- Create monorepo structure and scripts.
- Add TypeScript, linting, formatting, and `.env.example`.
- Verify both apps can start.

**Exit gate:** `npm install` and local dev commands work.

## Phase 1 — Data and contracts (8–18 min)
- Define shared types and API response schemas.
- Add 8–12 clearly labelled demo scheme records across categories.
- Each record must contain source URL or explicit missing-source state, source name, and last-verified date.
- Do not invent legal criteria or official links. Clearly mark demo records as demo data requiring verification.

**Exit gate:** schema validation passes for every record.

## Phase 2 — Backend and rule engine (18–35 min)
- Implement health, list/search, detail, eligibility check, and feedback endpoints.
- Build deterministic rule engine with explicit missing-answer handling.
- Add unit tests for all three status outcomes.
- Add validation, CORS, rate limiting, security headers, and error middleware.

**Exit gate:** API tests pass and `GET /api/v1/health` returns healthy.

## Phase 3 — Frontend experience (35–58 min)
- Build landing page, questionnaire wizard, result cards, scheme details, shortlist, and checklist.
- Use a consistent design system and responsive layout.
- Add skeleton/loading, empty, validation, network-error, and success states.
- Use accessible labels and keyboard navigation.

**Exit gate:** user can complete the entire flow against the local API.

## Phase 4 — Integration and quality (58–72 min)
- Connect all screens to real API endpoints.
- Test invalid input, no matches, API down, stale scheme source, and shortlist persistence.
- Fix TypeScript, lint, and build errors.
- Confirm no fake success messages or unsupported eligibility guarantees.

**Exit gate:** automated checks and core manual flow pass.

## Phase 5 — Deployment (72–84 min)
- Deploy API to Render/Railway.
- Set production `CORS_ORIGINS` and environment variables.
- Deploy web app to Vercel/Netlify.
- Set `VITE_API_BASE_URL` to the deployed API URL.
- Confirm health endpoint and browser network requests.

**Exit gate:** production URL loads and eligibility check succeeds.

## Phase 6 — Smoke test and handoff (84–90 min)
- Test on mobile viewport and desktop.
- Verify official links open safely.
- Update README with commands, URLs, env vars, known limitations, and rollback steps.
- Commit cleanly; do not report deployment as complete until verified.

**Exit gate:** acceptance checklist passes.

## If time runs out
Prioritize: health endpoint → rule engine → questionnaire → results → verified scheme data → deployment. Defer animation, authentication, admin dashboard, database migration, and advanced analytics.
