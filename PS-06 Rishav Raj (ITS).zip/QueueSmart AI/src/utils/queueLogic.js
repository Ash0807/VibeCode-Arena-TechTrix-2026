import { TOKEN_STATUS, PRIORITY_CONFIG } from '../data/mockData.js';

// Priority weight lookup
export function getPriorityWeight(priority) {
  const key = (priority || 'standard').toLowerCase();
  return PRIORITY_CONFIG[key]?.weight || 1;
}

// State transition validation rule
export function canTransition(fromStatus, toStatus) {
  const from = (fromStatus || '').toUpperCase();
  const to = (toStatus || '').toUpperCase();

  const VALID_TRANSITIONS = {
    [TOKEN_STATUS.WAITING]: [TOKEN_STATUS.SERVING, TOKEN_STATUS.SKIPPED],
    [TOKEN_STATUS.SERVING]: [TOKEN_STATUS.COMPLETED, TOKEN_STATUS.SKIPPED],
    [TOKEN_STATUS.COMPLETED]: [], // terminal
    [TOKEN_STATUS.SKIPPED]: [],   // terminal
  };

  return (VALID_TRANSITIONS[from] || []).includes(to);
}

// FIFO ordering within configurable priority levels
export function compareTokens(a, b) {
  const weightA = getPriorityWeight(a.priority);
  const weightB = getPriorityWeight(b.priority);

  // 1. Higher priority level first
  if (weightA !== weightB) {
    return weightB - weightA;
  }

  // 2. Strict FIFO (First-In, First-Out by arrival timestamp)
  return new Date(a.joinedAt).getTime() - new Date(b.joinedAt).getTime();
}

// Calculate dynamic estimated waiting time for a token
// Formula: (Eligible People Ahead * Avg Service Duration) / Eligible Active (Open) Counters
export function calculateTokenWaitEstimate(token, allTokens, allCounters, servicesList) {
  const service = servicesList.find((s) => s.id === token.serviceId) || servicesList[0];
  const avgDuration = service.avgTimeMin || 6;

  // Active (Open) counters eligible to serve this service
  const eligibleActiveCounters = allCounters.filter(
    (c) => c.isOpen && c.services.includes(token.serviceId)
  );
  const activeCountersCount = eligibleActiveCounters.length;

  // Eligible people ahead in WAITING status for this service
  const eligiblePeopleAhead = allTokens.filter((t) => {
    if (t.status !== TOKEN_STATUS.WAITING || t.id === token.id) return false;
    if (t.serviceId !== token.serviceId) return false;
    return compareTokens(t, token) < 0;
  }).length;

  // If no open counters available, indicate delay
  if (activeCountersCount === 0) {
    return {
      minutes: Math.max(10, (eligiblePeopleAhead + 1) * avgDuration),
      peopleAhead: eligiblePeopleAhead,
      activeCountersCount: 0,
      note: 'All assigned desk counters are currently closed. Service will resume once a counter opens.',
    };
  }

  // If first in line (0 people ahead)
  if (eligiblePeopleAhead === 0) {
    const isCounterIdle = eligibleActiveCounters.some((c) => !c.currentToken);
    const est = isCounterIdle ? 1 : Math.max(1, Math.round(avgDuration / 2));
    return {
      minutes: est,
      peopleAhead: 0,
      activeCountersCount,
      note: isCounterIdle ? 'Next to be called. An eligible counter is currently available.' : 'Next in line. Awaiting current counter session completion.',
    };
  }

  // Standard multi-counter queuing formula
  const calculated = Math.max(
    1,
    Math.round((eligiblePeopleAhead * avgDuration) / activeCountersCount)
  );

  return {
    minutes: calculated,
    peopleAhead: eligiblePeopleAhead,
    activeCountersCount,
    note: `Dynamic estimate: ${eligiblePeopleAhead} people ahead across ${activeCountersCount} active open counter(s).`,
  };
}

// Recalculate estimates for all waiting tokens
export function recalculateWaitingEstimates(tokensList, countersList, servicesList) {
  return tokensList.map((token) => {
    if (token.status === TOKEN_STATUS.WAITING) {
      const { minutes, peopleAhead, note } = calculateTokenWaitEstimate(
        token,
        tokensList,
        countersList,
        servicesList
      );
      return {
        ...token,
        estimatedWaitMin: minutes,
        peopleAhead,
        aiNote: note,
      };
    }
    return token;
  });
}
