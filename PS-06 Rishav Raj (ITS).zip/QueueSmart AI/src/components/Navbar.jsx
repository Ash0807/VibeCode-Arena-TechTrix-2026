import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { useAuth } from '../context/AuthContext';
import { getMissingFirebaseConfig, isFirebaseConfigured } from '../firebase/config';
import {
  Sparkles,
  Ticket,
  Tv,
  LayoutDashboard,
  UserPlus,
  Volume2,
  VolumeX,
  Play,
  Square,
  RotateCcw,
  Menu,
  X,
  Layers,
  Database,
  LogOut,
  User,
  HelpCircle,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export function Navbar({ currentRoute, setCurrentRoute }) {
  const {
    waitingTokens,
    soundEnabled,
    setSoundEnabled,
    isSimulating,
    toggleSimulation,
    resetDemoData,
    myToken,
  } = useQueue();

  const { user, isAuthenticated, logout } = useAuth();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);

  const missingKeys = getMissingFirebaseConfig();

  const navItems = [
    { id: 'landing', label: 'Overview', icon: Layers },
    { id: 'register', label: 'Get Token', icon: UserPlus },
    {
      id: 'my-token',
      label: 'My Token',
      icon: Ticket,
      badge: myToken ? myToken.tokenNumber : null,
    },
    {
      id: 'admin',
      label: 'Admin Desk',
      icon: LayoutDashboard,
      badge: waitingTokens.length > 0 ? `${waitingTokens.length} waiting` : null,
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-200',
    },
    {
      id: 'display',
      label: 'Public TV Display',
      icon: Tv,
      highlight: true,
    },
  ];

  const handleNavClick = (id) => {
    setCurrentRoute(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('landing')}
            className="flex items-center gap-2.5 text-left focus:outline-none group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-teal-500/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-teal-100" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg tracking-tight text-white">QueueSmart</span>
                <span className="bg-teal-500/20 text-teal-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-teal-500/30">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Predictive Queue Engine</p>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/40 p-1 rounded-xl border border-slate-800">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentRoute === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all relative cursor-pointer ${
                    isActive
                      ? 'bg-teal-500 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                        isActive
                          ? 'bg-teal-900/60 text-white'
                          : item.badgeColor || 'bg-slate-800 text-teal-300 border border-teal-500/30'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {item.highlight && !isActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Desktop Right Tools */}
          <div className="hidden lg:flex items-center gap-2.5">
            {/* Firebase Sync Pill */}
            <button
              onClick={() => setShowConfigModal(true)}
              title="Click to check Firebase Cloud connection & configuration"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                isFirebaseConfigured
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/40'
                  : 'bg-amber-950/50 border-amber-500/40 text-amber-300 hover:bg-amber-900/40'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>{isFirebaseConfigured ? 'Cloud Sync' : 'Demo Mode'}</span>
            </button>

            {/* Live Simulation button */}
            <button
              onClick={toggleSimulation}
              title={isSimulating ? 'Stop auto-simulating live traffic' : 'Simulate live queue progression'}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                isSimulating
                  ? 'bg-teal-500/20 border-teal-400 text-teal-300 animate-pulse'
                  : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {isSimulating ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-teal-400 text-teal-400" />
                  <span>AI Sim Active</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-slate-300" />
                  <span>Simulate Traffic</span>
                </>
              )}
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'Mute audio announcement chime' : 'Enable audio chime'}
              className={`p-2 rounded-lg border transition cursor-pointer ${
                soundEnabled
                  ? 'bg-slate-800/80 text-teal-400 border-slate-700 hover:border-teal-500/50'
                  : 'bg-slate-800/40 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Reset Data */}
            <button
              onClick={resetDemoData}
              title="Reset queue to baseline data"
              className="p-2 rounded-lg bg-slate-800/60 text-slate-400 hover:text-slate-200 border border-slate-700 hover:bg-slate-800 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Authenticated Staff Chip or CTA */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
                <div className="text-right">
                  <div className="text-xs font-bold text-white leading-tight">
                    {user?.displayName || 'Operator'}
                  </div>
                  <div className="text-[10px] text-teal-400 font-mono">
                    {user?.isLiveFirebase ? 'Firebase Admin' : 'Staff Demo'}
                  </div>
                </div>
                <button
                  onClick={logout}
                  title="Sign out of Admin Portal"
                  className="p-2 rounded-lg bg-slate-800/80 text-rose-400 hover:bg-rose-500/20 border border-slate-700 hover:border-rose-500/30 transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleNavClick('register')}
                className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs px-3.5 py-2 rounded-lg shadow-sm hover:shadow-teal-500/20 transition flex items-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Join Queue</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 rounded-lg bg-slate-800 text-slate-300"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-teal-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentRoute === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium ${
                  isActive
                    ? 'bg-teal-500 text-white'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-teal-300 border border-teal-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Mobile Quick Action Bar (Simulation, Reset & Config) */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={toggleSimulation}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  isSimulating
                    ? 'bg-teal-500/20 border-teal-400 text-teal-300 animate-pulse'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300'
                }`}
              >
                {isSimulating ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-teal-400 text-teal-400" />
                    <span>Stop Sim</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-slate-300" />
                    <span>Simulate</span>
                  </>
                )}
              </button>

              <button
                onClick={resetDemoData}
                className="py-2 px-3 text-xs font-semibold rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700 hover:bg-slate-800 flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Data</span>
              </button>
            </div>

            <div className="flex items-center justify-between gap-2">
              <button
                onClick={() => setShowConfigModal(true)}
                className="flex-1 py-2 text-xs font-semibold rounded-lg bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Database className="w-3.5 h-3.5 text-teal-400" />
                <span>{isFirebaseConfigured ? 'Firebase: Cloud' : 'Firebase: Demo'}</span>
              </button>

              {isAuthenticated && (
                <button
                  onClick={logout}
                  className="px-3 py-2 text-xs font-semibold rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Exit</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Firebase Cloud Info Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-teal-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Firebase Cloud Backend Status
                </h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isFirebaseConfigured ? (
              <div className="space-y-3 text-xs text-slate-600">
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-bold block text-emerald-950">
                      Cloud Firestore & Authentication Active!
                    </span>
                    Real-time listeners are synchronizing tokens, queue statuses, and counter sessions across all connected screens.
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-xs text-slate-600">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block mb-0.5 text-amber-950">
                      Functional Mock Demo Engine Active
                    </span>
                    The working queue engine is running with in-memory & localStorage state. To connect to a live Firebase project, configure your environment variables in <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">.env.local</code>.
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 mb-2">Remaining Environment Variables:</h4>
                  <div className="space-y-1.5 font-mono text-[11px] bg-slate-900 text-slate-200 p-3 rounded-xl overflow-x-auto">
                    {missingKeys.map((key) => (
                      <div key={key} className="flex items-center justify-between gap-2 text-rose-300">
                        <span>{key}</span>
                        <span className="text-[10px] text-amber-400 font-sans">Pending</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 mb-1">Configuration Steps:</h4>
                  <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px] leading-relaxed">
                    <li>Create project in <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-teal-600 underline inline-flex items-center gap-0.5">Firebase Console <ExternalLink className="w-2.5 h-2.5" /></a></li>
                    <li>Enable <strong>Firestore Database</strong> and <strong>Email/Password Authentication</strong>.</li>
                    <li>Copy config into <code className="bg-slate-100 px-1 rounded font-mono">.env.local</code> (template provided in <code className="bg-slate-100 px-1 rounded font-mono">.env.example</code>).</li>
                    <li>Deploy <code className="bg-slate-100 px-1 rounded font-mono">firestore.rules</code> to enforce security.</li>
                  </ol>
                </div>
              </div>
            )}

            <div className="mt-6 pt-4 border-t border-slate-100 text-right">
              <button
                onClick={() => setShowConfigModal(false)}
                className="bg-slate-900 text-white font-semibold px-4 py-2 rounded-xl text-xs hover:bg-slate-800 transition cursor-pointer"
              >
                Close Status
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
