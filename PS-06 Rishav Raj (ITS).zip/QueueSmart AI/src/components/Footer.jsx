import React from 'react';
import { Sparkles, ShieldCheck, Cpu, Clock, Terminal } from 'lucide-react';

export function Footer({ setCurrentRoute }) {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="font-bold text-base text-white">QueueSmart AI</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-xs">
              Next-generation intelligent queue virtualization. Optimizing wait times with dynamic machine learning and real-time counter orchestration.
            </p>
            <div className="flex items-center gap-2 text-teal-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
              <span>AI Dispatch Engine v2.4 Active</span>
            </div>
          </div>

          {/* Quick Access */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-sm">System Portals</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentRoute('landing')}
                  className="hover:text-teal-400 transition"
                >
                  Product Overview
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentRoute('register')}
                  className="hover:text-teal-400 transition"
                >
                  Visitor Self Check-in
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentRoute('my-token')}
                  className="hover:text-teal-400 transition"
                >
                  My Live Token Status
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentRoute('admin')}
                  className="hover:text-teal-400 transition"
                >
                  Operator Admin Console
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentRoute('display')}
                  className="hover:text-teal-400 transition"
                >
                  Kiosk & Lobby TV Display
                </button>
              </li>
            </ul>
          </div>

          {/* Architecture Highlights */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-sm">AI Engine Features</h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-teal-400" />
                <span>Dynamic Wait Time Estimation</span>
              </li>
              <li className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                <span>Automated Senior & Medical Triage</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-teal-400" />
                <span>Traffic Surge & Bottleneck Alerting</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-teal-400" />
                <span>Zero-Latency Web Audio Chime Alerts</span>
              </li>
            </ul>
          </div>

          {/* Operational Metrics */}
          <div>
            <h4 className="text-white font-semibold mb-3 text-sm">System Telemetry</h4>
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Mean Wait Accuracy</span>
                <span className="text-teal-400 font-mono font-semibold">98.4%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Throughput Target</span>
                <span className="text-white font-mono font-semibold">48 visits/hr</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Avg Queue Velocity</span>
                <span className="text-teal-400 font-mono font-semibold">5.8 min/ticket</span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-500">
          <div>
            © 2026 QueueSmart AI Systems Inc. Built with React.js, Vite & Tailwind CSS.
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Navy • White • Teal Theme</span>
            <span>•</span>
            <span>Realistic Simulation Engine</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
