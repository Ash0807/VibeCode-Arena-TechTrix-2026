import React from 'react';
import { useQueue } from '../context/QueueContext';
import { CheckCircle2, AlertTriangle, Info, Bell, X } from 'lucide-react';

export function Toast() {
  const { toastMessage, showToast } = useQueue();

  if (!toastMessage) return null;

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-teal-500 shrink-0" />,
    warning: <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />,
    announcement: <Bell className="w-5 h-5 text-teal-400 shrink-0 animate-bounce" />,
    info: <Info className="w-5 h-5 text-blue-500 shrink-0" />,
  };

  const bgStyles = {
    announcement: 'bg-slate-900 text-white border-teal-500/40 shadow-xl shadow-teal-950/20',
    success: 'bg-white text-slate-900 border-teal-200 shadow-lg shadow-teal-900/5',
    warning: 'bg-white text-slate-900 border-amber-200 shadow-lg shadow-amber-900/5',
    info: 'bg-white text-slate-900 border-slate-200 shadow-lg',
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-in fade-in slide-in-from-bottom-5 duration-300">
      <div
        className={`flex items-start gap-3 p-4 rounded-xl border ${
          bgStyles[toastMessage.type] || bgStyles.info
        } transition-all`}
      >
        {icons[toastMessage.type] || icons.info}
        <div className="flex-1 text-sm font-medium leading-relaxed">
          {toastMessage.message}
        </div>
        <button
          onClick={() => showToast(null)}
          className="text-slate-400 hover:text-slate-600 transition p-0.5 rounded-lg"
          aria-label="Close toast"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
