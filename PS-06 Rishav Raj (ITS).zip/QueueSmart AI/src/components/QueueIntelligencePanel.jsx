import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import {
  Brain,
  Sparkles,
  AlertTriangle,
  Clock,
  ArrowRight,
  TrendingDown,
  CheckCircle2,
  Sliders,
  HelpCircle,
  X,
  Layers,
  Power,
  Users,
  Info,
  ShieldAlert,
  Zap,
} from 'lucide-react';

export function QueueIntelligencePanel() {
  const {
    counters,
    tokens,
    services,
    queueIntelligence,
    simulateWhatIfCounterOpen,
    openCounterDirectly,
  } = useQueue();

  const {
    congestionScore,
    congestionLevel,
    bottlenecks,
    longWaitCount,
    criticalWaitCount,
    recommendation,
    closedCounters,
    disclaimer,
  } = queueIntelligence;

  // Selected counter for What-If simulator
  const [selectedSimCounterId, setSelectedSimCounterId] = useState(() => {
    return recommendation?.counterId || (closedCounters[0]?.id || counters[0]?.id);
  });

  // Modal for confirming "Apply Suggestion"
  const [confirmModalData, setConfirmModalData] = useState(null);

  // Compute what-if simulation for selected counter
  const simulationResult = simulateWhatIfCounterOpen(selectedSimCounterId);

  const handleApplyClick = (rec) => {
    setConfirmModalData(rec);
  };

  const handleConfirmAction = () => {
    if (!confirmModalData) return;
    openCounterDirectly(confirmModalData.counterId);
    setConfirmModalData(null);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold">
              <Brain className="w-3.5 h-3.5 text-indigo-600" />
              <span>Explainable Queue Intelligence</span>
            </div>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
              Rule-Based Prototype Intelligence
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Congestion Diagnosis & What-If Dispatcher
          </h2>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{disclaimer}</span>
          </p>
        </div>

        {/* Congestion Level Pill */}
        <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-2xl border border-slate-200 self-start lg:self-auto">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
              Congestion Index
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black font-mono text-slate-900">
                {congestionScore}%
              </span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  congestionLevel.color === 'emerald'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : congestionLevel.color === 'blue'
                    ? 'bg-blue-100 text-blue-800 border border-blue-300'
                    : congestionLevel.color === 'amber'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-rose-100 text-rose-800 border border-rose-300'
                }`}
              >
                {congestionLevel.label}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Diagnostics & Flags */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Long wait flag */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Long Wait Flag (&ge;10m)
            </div>
            <div className="text-2xl font-black font-mono text-slate-900 mt-0.5">
              {longWaitCount}{' '}
              <span className="text-xs font-normal text-slate-500">
                ({criticalWaitCount} critical &gt;15m)
              </span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {longWaitCount > 0
                ? 'Visitors flagged for prolonged waiting delay'
                : 'All waiting times currently within target thresholds'}
            </div>
          </div>
        </div>

        {/* Bottleneck services */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Identified Bottlenecks
            </div>
            <div className="text-2xl font-black font-mono text-slate-900 mt-0.5">
              {bottlenecks.length}{' '}
              <span className="text-xs font-normal text-slate-500">Service Desk(s)</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5 truncate max-w-[200px]">
              {bottlenecks.length > 0
                ? bottlenecks.map((b) => b.service.name.split(' ')[0]).join(', ')
                : 'Balanced flow across all service desks'}
            </div>
          </div>
        </div>

        {/* Closed Eligible Desks */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
            <Power className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Standby Closed Desks
            </div>
            <div className="text-2xl font-black font-mono text-slate-900 mt-0.5">
              {closedCounters.length}{' '}
              <span className="text-xs font-normal text-slate-500">Available to Open</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {closedCounters.length > 0
                ? 'Can be activated instantly to relieve queue pressure'
                : 'All facility counters are currently open'}
            </div>
          </div>
        </div>
      </div>

      {/* RECOMMENDATION CARD WITH EXPLAINABLE REASONING */}
      {recommendation ? (
        <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 text-white shadow-xl relative overflow-hidden border border-indigo-800/50">
          <div className="relative z-10 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-teal-400 text-slate-950 flex items-center justify-center font-bold">
                  <Zap className="w-4 h-4" />
                </span>
                <div>
                  <span className="text-xs font-bold text-teal-300 uppercase tracking-wider">
                    Recommended Dispatch Action
                  </span>
                  <h3 className="text-lg sm:text-xl font-extrabold text-white">
                    Open {recommendation.counterName} (Operator: {recommendation.operator})
                  </h3>
                </div>
              </div>

              {/* Apply Suggestion Button */}
              <button
                onClick={() => handleApplyClick(recommendation)}
                className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-black px-5 py-2.5 rounded-xl text-xs shadow-lg shadow-teal-500/20 transition flex items-center gap-2 shrink-0 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Apply Suggestion</span>
              </button>
            </div>

            {/* Explainable Reasoning Breakdown */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-indigo-900/60 space-y-2">
              <div className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Brain className="w-3.5 h-3.5" />
                <span>Explainable Diagnostic Rationale:</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300 leading-relaxed list-disc list-inside">
                {recommendation.reason.map((r, i) => (
                  <li key={i} className="pl-1">
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>Rule: {recommendation.heuristicRule}</span>
                <span className="text-teal-400 font-bold">
                  Expected Reduction: ~{recommendation.waitReductionPct}%
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="text-xs font-bold uppercase tracking-wider block text-emerald-950">
                Queue Operating Optimally
              </span>
              <p className="text-xs text-emerald-800 mt-0.5">
                All queues are balanced within acceptable thresholds. No counter modifications needed at this moment.
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold bg-white text-emerald-800 px-3 py-1 rounded-xl border border-emerald-300">
            Flow Balanced
          </span>
        </div>
      )}

      {/* WHAT-IF SIMULATOR */}
      <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-teal-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                What-If Queue Capacity Simulator
              </h3>
              <p className="text-xs text-slate-500">
                Test the impact of opening an additional counter before taking operational action.
              </p>
            </div>
          </div>

          {/* Select Counter to Simulate */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-medium">Test Opening:</span>
            <select
              value={selectedSimCounterId}
              onChange={(e) => setSelectedSimCounterId(e.target.value)}
              className="bg-white border border-slate-200 font-bold text-slate-800 rounded-xl px-3 py-1.5 focus:outline-none focus:border-teal-500 shadow-sm"
            >
              {counters.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.operator}) - {c.isOpen ? 'Already Open' : 'CLOSED (Standby)'}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Simulation Output Comparison Cards */}
        {simulationResult && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {/* Avg Wait Before vs After */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Average Waiting Time
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black font-mono text-slate-400 line-through">
                    {simulationResult.before.avgWaitMin}m
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                  <span className="text-2xl font-black font-mono text-teal-600">
                    {simulationResult.after.avgWaitMin}m
                  </span>
                </div>
                <div className="text-[11px] text-teal-700 font-semibold mt-1 flex items-center gap-1">
                  <TrendingDown className="w-3.5 h-3.5" />
                  <span>-{simulationResult.waitReductionPct}% wait reduction</span>
                </div>
              </div>

              {/* Max Waiting Time */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Max Queue Delay
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black font-mono text-slate-400 line-through">
                    {simulationResult.before.maxWaitMin}m
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                  <span className="text-2xl font-black font-mono text-indigo-600">
                    {simulationResult.after.maxWaitMin}m
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Peak wait time trimmed
                </div>
              </div>

              {/* Total Time Saved */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Total Visitor Time Saved
                </span>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {simulationResult.timeSavedTotalMinutes} min
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Aggregate queue dwell reduction
                </div>
              </div>

              {/* Visitors Benefiting */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Immediate Beneficiaries
                </span>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {simulationResult.benefitedCount} Visitors
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Wait times accelerated
                </div>
              </div>
            </div>

            {/* Visualizer Bar & Action */}
            <div className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1.5 flex-1">
                <div className="flex justify-between text-xs font-semibold text-slate-600">
                  <span>Capacity Projection: {simulationResult.counter.name}</span>
                  <span className="text-teal-600 font-mono font-bold">
                    {simulationResult.waitReductionPct}% Improvement
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                  <div
                    className="bg-slate-400 h-full transition-all"
                    style={{ width: `${Math.max(10, 100 - simulationResult.waitReductionPct)}%` }}
                  />
                  <div
                    className="bg-teal-500 h-full transition-all"
                    style={{ width: `${simulationResult.waitReductionPct}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-400">
                  Gray: Projected waiting time remaining • Teal: Time saved by activating {simulationResult.counter.name}
                </div>
              </div>

              {!simulationResult.counter.isOpen && (
                <button
                  onClick={() =>
                    handleApplyClick({
                      counterId: simulationResult.counter.id,
                      counterName: simulationResult.counter.name,
                      operator: simulationResult.counter.operator,
                      waitReductionPct: simulationResult.waitReductionPct,
                      projectedAvgWait: simulationResult.after.avgWaitMin,
                      currentAvgWait: simulationResult.before.avgWaitMin,
                      reason: [
                        `Simulation confirmed opening ${simulationResult.counter.name} reduces average wait from ${simulationResult.before.avgWaitMin}m to ${simulationResult.after.avgWaitMin}m (-${simulationResult.waitReductionPct}%).`,
                        `${simulationResult.benefitedCount} waiting visitor(s) will have their queues expedited immediately.`,
                      ],
                    })
                  }
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm"
                >
                  <Power className="w-3.5 h-3.5 text-teal-400" />
                  <span>Open {simulationResult.counter.name} Now</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* CONFIRMATION MODAL FOR APPLY SUGGESTION */}
      {confirmModalData && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-teal-600" />
                <h3 className="font-bold text-lg text-slate-900">
                  Confirm Dispatch Recommendation
                </h3>
              </div>
              <button
                onClick={() => setConfirmModalData(null)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-600">
              <p className="text-sm text-slate-700">
                Are you sure you want to open{' '}
                <strong className="text-slate-950">{confirmModalData.counterName}</strong> assigned to{' '}
                <strong className="text-slate-950">{confirmModalData.operator}</strong>?
              </p>

              <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 space-y-2">
                <div className="font-bold text-xs uppercase tracking-wider text-indigo-950">
                  Expected Queue Impact:
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-indigo-600 block">Avg Wait Change:</span>
                    <strong className="text-slate-900 text-sm font-mono">
                      {confirmModalData.currentAvgWait}m &rarr; {confirmModalData.projectedAvgWait}m
                    </strong>
                  </div>
                  <div>
                    <span className="text-indigo-600 block">Queue Delay Trim:</span>
                    <strong className="text-teal-700 text-sm font-mono">
                      -{confirmModalData.waitReductionPct}%
                    </strong>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-100 text-slate-600 text-[11px]">
                Upon confirmation, the desk will transition to <strong>OPEN & AVAILABLE</strong> and waiting estimates for all visitors will be recalculated in real time.
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                onClick={() => setConfirmModalData(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAction}
                className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-5 py-2.5 text-xs rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <Power className="w-3.5 h-3.5" />
                <span>Confirm & Open Counter</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
