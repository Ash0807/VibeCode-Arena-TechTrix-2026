import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { QrCode, Check, Download, ExternalLink } from 'lucide-react';

export function QRCodeDisplay({ tokenNumber, tokenId, size = 160, className = '' }) {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  // Construct a realistic, scannable verification link
  const verificationUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}#my-token?token=${encodeURIComponent(tokenNumber || 'QS-101')}`
    : `https://queuesmart-ai.web.app/#my-token?token=${encodeURIComponent(tokenNumber || 'QS-101')}`;

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    QRCode.toDataURL(verificationUrl, {
      width: size * 2, // High resolution for crisp retina display & scanning
      margin: 1.5,
      color: {
        dark: '#0B132B', // Deep navy QR modules
        light: '#FFFFFF', // Pure white background
      },
      errorCorrectionLevel: 'M', // 15% error recovery
    })
      .then((url) => {
        if (isMounted) {
          setQrDataUrl(url);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error('QR code generation error:', err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [verificationUrl, size]);

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.download = `QueueSmart-${tokenNumber || 'Token'}-QR.png`;
    link.href = qrDataUrl;
    link.click();
  };

  return (
    <div className={`bg-white p-3.5 sm:p-4 rounded-2xl text-slate-900 mx-auto flex flex-col items-center shadow-lg border border-slate-200/80 ${className}`}>
      <div className="relative flex items-center justify-center bg-white rounded-xl overflow-hidden p-1">
        {loading || !qrDataUrl ? (
          <div
            style={{ width: size, height: size }}
            className="flex flex-col items-center justify-center bg-slate-50 text-slate-400 rounded-lg animate-pulse"
          >
            <QrCode className="w-8 h-8 text-teal-600 animate-spin" />
            <span className="text-[10px] font-mono mt-2 text-slate-500">Generating QR...</span>
          </div>
        ) : (
          <img
            src={qrDataUrl}
            alt={`Scannable QR Code for Token ${tokenNumber}`}
            style={{ width: size, height: size }}
            className="block rounded-lg object-contain transition-transform hover:scale-105 duration-200 cursor-pointer"
            title="Scan with phone camera to track this token"
            onClick={handleDownloadQR}
          />
        )}
      </div>

      {/* Token validation label underneath */}
      <div className="mt-2.5 text-center w-full">
        <div className="inline-flex items-center gap-1 font-mono text-[10px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>{tokenNumber || 'QS-101'} • SCANNABLE</span>
        </div>
        <p className="text-[10px] text-slate-400 mt-1 font-medium">
          Scan with phone camera to verify pass
        </p>
      </div>
    </div>
  );
}
