import React from 'react';
import { Clock, Volume2, UserCheck, CheckCircle2, XCircle, AlertCircle, Sparkles, Ban } from 'lucide-react';
import { PRIORITY_CONFIG } from '../data/mockData';

export function StatusBadge({ status, size = 'md' }) {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3.5 py-1.5 font-semibold',
  };

  const normalized = (status || '').toUpperCase();

  switch (normalized) {
    case 'SERVING':
    case 'CALLING':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-semibold rounded-full bg-teal-500/10 text-teal-800 border border-teal-500/30 ${sizeClasses[size]}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
          <UserCheck className="w-3.5 h-3.5 text-teal-600" />
          SERVING
        </span>
      );

    case 'WAITING':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-amber-50 text-amber-800 border border-amber-200 ${sizeClasses[size]}`}
        >
          <Clock className="w-3.5 h-3.5 text-amber-600" />
          WAITING
        </span>
      );

    case 'COMPLETED':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses[size]}`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-slate-500" />
          COMPLETED
        </span>
      );

    case 'SKIPPED':
    case 'NO-SHOW':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-rose-50 text-rose-700 border border-rose-200 ${sizeClasses[size]}`}
        >
          <Ban className="w-3.5 h-3.5 text-rose-600" />
          SKIPPED
        </span>
      );

    default:
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-slate-100 text-slate-700 ${sizeClasses[size]}`}
        >
          {status}
        </span>
      );
  }
}

export function PriorityBadge({ priority, size = 'sm' }) {
  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
  };

  const key = (priority || 'standard').toLowerCase();
  const config = PRIORITY_CONFIG[key] || PRIORITY_CONFIG.standard;

  if (key === 'standard') {
    return (
      <span className={`inline-flex items-center font-medium rounded-md bg-slate-100 text-slate-600 border border-slate-200 ${sizeClasses[size]}`}>
        Standard
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 font-semibold rounded-md border ${config.badgeBg} ${sizeClasses[size]}`}>
      <Sparkles className="w-3 h-3" />
      {config.label}
    </span>
  );
}
