import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getMissingFirebaseConfig, isFirebaseConfigured } from '../firebase/config';
import {
  Lock,
  Mail,
  KeyRound,
  Sparkles,
  ArrowRight,
  AlertCircle,
  Database,
  CheckCircle2,
  HelpCircle,
  UserCheck,
  ShieldCheck,
  X,
  ExternalLink,
} from 'lucide-react';

export function AdminLogin({ onLoginSuccess }) {
  const { loginWithEmail, loginWithDemo, authError, setAuthError, isFirebase } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);

  const missingKeys = getMissingFirebaseConfig();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setAuthError('Please fill in both operator email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      await loginWithEmail(email, password);
      if (onLoginSuccess) onLoginSuccess();
    } catch (err) {
      // Error handled in AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDemoLogin = () => {
    loginWithDemo();
    if (onLoginSuccess) onLoginSuccess();
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-8 sm:p-10 max-w-md w-full relative overflow-hidden">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 text-teal-400 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-slate-900/10">
            <Lock className="w-6 h-6" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
            <span>Staff & Admin Gateway</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            Operator Console Login
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Authenticate to manage counter sessions, call queue tokens, and configure triage.
          </p>
        </div>

        {/* Firebase Status Badge */}
        <div className="mb-6">
          <button
            type="button"
            onClick={() => setShowConfigModal(true)}
            className={`w-full p-3 rounded-xl border text-xs flex items-center justify-between transition ${
              isFirebase
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900 hover:bg-emerald-100/70'
                : 'bg-amber-50/70 border-amber-200 text-amber-900 hover:bg-amber-100/70'
            }`}
          >
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-slate-600 shrink-0" />
              <span className="font-semibold">
                {isFirebase ? 'Firebase Cloud Active' : 'Local Mock Engine Active'}
              </span>
            </div>
            <span className="text-[11px] underline underline-offset-2 flex items-center gap-1">
              <span>{isFirebase ? 'Details' : 'Setup Remaining'}</span>
              <HelpCircle className="w-3.5 h-3.5" />
            </span>
          </button>
        </div>

        {/* Error Alert */}
        {authError && (
          <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{authError}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Operator Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                placeholder="operator@queuesmart.ai"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-teal-500 transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Password
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-teal-500 transition"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-xl text-xs shadow-md transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Sign In as Operator</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200" />
          </div>
          <span className="relative bg-white px-3 text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
            Or Test Immediately
          </span>
        </div>

        {/* Instant Demo Sign-In */}
        <button
          onClick={handleDemoLogin}
          type="button"
          className="w-full bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold py-3 px-4 rounded-xl text-xs shadow-md shadow-teal-500/20 transition flex items-center justify-center gap-2"
        >
          <UserCheck className="w-4 h-4" />
          <span>One-Click Demo Staff Login (Sarah Chen)</span>
        </button>

        <p className="text-[11px] text-slate-400 text-center mt-4">
          Demo login bypasses credentials to let you test counter orchestration instantly.
        </p>
      </div>

      {/* Configuration Remaining Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-teal-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Firebase Cloud Integration Status
                </h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isFirebase ? (
              <div className="space-y-3 text-xs text-slate-600">
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-bold block">Firebase Connected & Synced!</span>
                    Live Cloud Firestore and Firebase Auth are active. Tokens and counter statuses are synchronizing in real time.
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-xs text-slate-600">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block mb-0.5">
                      Working Mock Demo Engine Active
                    </span>
                    The app is fully functioning with in-memory & localStorage state. To connect to a live Google Cloud Firestore project, provide your environment variables in <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">.env.local</code>.
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 mb-2">Remaining Environment Variables:</h4>
                  <div className="space-y-1.5 font-mono text-[11px] bg-slate-900 text-slate-200 p-3 rounded-xl overflow-x-auto">
                    {missingKeys.map((key) => (
                      <div key={key} className="flex items-center justify-between gap-2 text-rose-300">
                        <span>{key}</span>
                        <span className="text-[10px] text-amber-400 font-sans">Pending</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 mb-1">How to Connect:</h4>
                  <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px] leading-relaxed">
                    <li>Create a project in the <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-teal-600 underline inline-flex items-center gap-0.5">Firebase Console <ExternalLink className="w-2.5 h-2.5" /></a></li>
                    <li>Enable <strong>Firestore Database</strong> and <strong>Email/Password Auth</strong>.</li>
                    <li>Copy project configuration into <code className="bg-slate-100 px-1 rounded font-mono">.env.local</code> (see <code className="bg-slate-100 px-1 rounded font-mono">.env.example</code>).</li>
                    <li>Deploy <code className="bg-slate-100 px-1 rounded font-mono">firestore.rules</code> to enforce route protection.</li>
                  </ol>
                </div>
              </div>
            )}

            <div className="mt-6 pt-4 border-t border-slate-100 text-right">
              <button
                onClick={() => setShowConfigModal(false)}
                className="bg-slate-900 text-white font-semibold px-4 py-2 rounded-xl text-xs hover:bg-slate-800 transition"
              >
                Close Status
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
