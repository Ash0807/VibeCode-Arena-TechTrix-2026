import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const env = import.meta.env;

// Required Firebase keys
const REQUIRED_KEYS = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_APP_ID',
];

export function getMissingFirebaseConfig() {
  const missing = [];
  for (const key of REQUIRED_KEYS) {
    const val = env[key];
    if (!val || val.includes('your-') || val.includes('example.com') || val.trim() === '') {
      missing.push(key);
    }
  }
  return missing;
}

export function checkIsFirebaseConfigured() {
  if (env.VITE_USE_MOCK_DEMO === 'true') {
    return false;
  }
  const missing = getMissingFirebaseConfig();
  return missing.length === 0;
}

export const isFirebaseConfigured = checkIsFirebaseConfigured();

export const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || '',
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: env.VITE_FIREBASE_APP_ID || '',
};

let app = null;
let auth = null;
let db = null;

if (isFirebaseConfigured) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);
    console.info('🔥 Firebase initialized successfully in Cloud mode.');
  } catch (err) {
    console.warn('⚠️ Firebase initialization failed. Falling back to local mock engine:', err);
    app = null;
    auth = null;
    db = null;
  }
} else {
  console.info(
    'ℹ️ Firebase environment variables are not configured. QueueSmart AI is running in Local Mock Demo Mode.'
  );
}

export { app, auth, db };
