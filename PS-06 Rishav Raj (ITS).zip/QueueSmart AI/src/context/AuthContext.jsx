import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, isFirebaseConfigured } from '../firebase/config';
import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from 'firebase/auth';

const AuthContext = createContext(null);

const SESSION_KEY_DEMO_USER = 'queuesmart_admin_user';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = sessionStorage.getItem(SESSION_KEY_DEMO_USER);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [loading, setLoading] = useState(isFirebaseConfigured);
  const [authError, setAuthError] = useState(null);

  // Listen to Firebase auth changes when live Firebase is active
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(
      auth,
      (firebaseUser) => {
        if (firebaseUser) {
          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName || firebaseUser.email.split('@')[0],
            role: 'admin',
            isLiveFirebase: true,
          });
        } else {
          // Check if session storage has demo login
          const saved = sessionStorage.getItem(SESSION_KEY_DEMO_USER);
          setUser(saved ? JSON.parse(saved) : null);
        }
        setLoading(false);
      },
      (error) => {
        console.error('Firebase Auth state error:', error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Login with email and password
  const loginWithEmail = async (email, password) => {
    setAuthError(null);
    setLoading(true);

    try {
      if (isFirebaseConfigured && auth) {
        const cred = await signInWithEmailAndPassword(auth, email, password);
        const adminUser = {
          uid: cred.user.uid,
          email: cred.user.email,
          displayName: cred.user.displayName || email.split('@')[0],
          role: 'admin',
          isLiveFirebase: true,
        };
        setUser(adminUser);
        setLoading(false);
        return adminUser;
      } else {
        // Demo Mock Authentication
        await new Promise((r) => setTimeout(r, 400)); // simulate latency
        if (!email.includes('@')) {
          throw new Error('Please enter a valid operator email address.');
        }
        if (password.length < 4) {
          throw new Error('Password must be at least 4 characters.');
        }

        const demoUser = {
          uid: 'admin-demo-1',
          email: email.trim(),
          displayName: email.split('@')[0].toUpperCase(),
          role: 'admin',
          isLiveFirebase: false,
        };

        setUser(demoUser);
        sessionStorage.setItem(SESSION_KEY_DEMO_USER, JSON.stringify(demoUser));
        setLoading(false);
        return demoUser;
      }
    } catch (err) {
      setLoading(false);
      const friendlyMsg =
        err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password'
          ? 'Invalid operator credentials. Check your email and password.'
          : err.code === 'auth/user-not-found'
          ? 'No admin account found with this email.'
          : err.message || 'Authentication failed.';
      setAuthError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  // Instant demo admin login
  const loginWithDemo = () => {
    const demoAdmin = {
      uid: 'operator-chen-demo',
      email: 'sarah.chen@queuesmart.ai',
      displayName: 'Sarah Chen (Lead Desk Operator)',
      role: 'admin',
      isLiveFirebase: false,
    };
    setUser(demoAdmin);
    sessionStorage.setItem(SESSION_KEY_DEMO_USER, JSON.stringify(demoAdmin));
    return demoAdmin;
  };

  // Sign out
  const logout = async () => {
    if (isFirebaseConfigured && auth) {
      try {
        await firebaseSignOut(auth);
      } catch (err) {
        console.warn('Firebase signout warning:', err);
      }
    }
    setUser(null);
    sessionStorage.removeItem(SESSION_KEY_DEMO_USER);
  };

  const value = {
    user,
    isAuthenticated: Boolean(user),
    isAdmin: Boolean(user && user.role === 'admin'),
    isFirebase: isFirebaseConfigured,
    loading,
    authError,
    setAuthError,
    loginWithEmail,
    loginWithDemo,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
