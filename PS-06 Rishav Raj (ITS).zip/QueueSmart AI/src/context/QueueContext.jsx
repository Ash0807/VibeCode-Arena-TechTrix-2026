import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  SERVICES,
  INITIAL_COUNTERS,
  INITIAL_TOKENS,
  AI_ANALYTICS,
  TOKEN_STATUS,
  PRIORITY_CONFIG,
} from '../data/mockData';
import { playQueueChime, playNotificationSound } from '../utils/audio';
import { db, isFirebaseConfigured } from '../firebase/config';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  getDocs,
} from 'firebase/firestore';

const QueueContext = createContext(null);

const STORAGE_KEY_TOKENS = 'queuesmart_tokens';
const STORAGE_KEY_COUNTERS = 'queuesmart_counters';
const STORAGE_KEY_MY_TOKEN = 'queuesmart_my_token_id';

import {
  getPriorityWeight,
  canTransition,
  compareTokens,
  calculateTokenWaitEstimate,
  recalculateWaitingEstimates,
} from '../utils/queueLogic';

import {
  analyzeQueueIntelligence,
  simulateWhatIfCounterOpen,
  INTELLIGENCE_DISCLAIMER,
} from '../utils/queueIntelligence';

export {
  getPriorityWeight,
  canTransition,
  compareTokens,
  calculateTokenWaitEstimate,
  recalculateWaitingEstimates,
  analyzeQueueIntelligence,
  simulateWhatIfCounterOpen,
  INTELLIGENCE_DISCLAIMER,
};

export function QueueProvider({ children }) {
  const [services] = useState(SERVICES);

  const [counters, setCounters] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_COUNTERS);
      return saved ? JSON.parse(saved) : INITIAL_COUNTERS;
    } catch {
      return INITIAL_COUNTERS;
    }
  });

  const [tokens, setTokens] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TOKENS);
      const initial = saved ? JSON.parse(saved) : INITIAL_TOKENS;
      return recalculateWaitingEstimates(initial, INITIAL_COUNTERS, SERVICES);
    } catch {
      return recalculateWaitingEstimates(INITIAL_TOKENS, INITIAL_COUNTERS, SERVICES);
    }
  });

  // Current visitor token ID
  const [myTokenId, setMyTokenId] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MY_TOKEN);
      return saved || 'tok-a105';
    } catch {
      return 'tok-a105';
    }
  });

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastAnnouncement, setLastAnnouncement] = useState({
    tokenNumber: 'C-107',
    counterNumber: 3,
    counterName: 'Counter 03',
    time: 'Just now',
  });
  const [toastMessage, setToastMessage] = useState(null);

  // Sync state to localStorage for local persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TOKENS, JSON.stringify(tokens));
    } catch (e) {
      console.error(e);
    }
  }, [tokens]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_COUNTERS, JSON.stringify(counters));
    } catch (e) {
      console.error(e);
    }
  }, [counters]);

  useEffect(() => {
    if (myTokenId) {
      localStorage.setItem(STORAGE_KEY_MY_TOKEN, myTokenId);
    }
  }, [myTokenId]);

  // Real-time Firestore synchronization when Firebase is configured
  useEffect(() => {
    if (!isFirebaseConfigured || !db) return;

    let unsubTokens = null;
    let unsubCounters = null;

    try {
      const tokensRef = collection(db, 'tokens');
      const countersRef = collection(db, 'counters');

      // Check if Firestore collections need initial seed
      getDocs(tokensRef)
        .then((snap) => {
          if (snap.empty) {
            console.info('🔥 Seeding initial tokens into Cloud Firestore...');
            INITIAL_TOKENS.forEach((tok) => {
              setDoc(doc(db, 'tokens', tok.id), tok).catch(console.error);
            });
          }
        })
        .catch((err) => console.warn('Firestore token check warning:', err));

      getDocs(countersRef)
        .then((snap) => {
          if (snap.empty) {
            console.info('🔥 Seeding initial counters into Cloud Firestore...');
            INITIAL_COUNTERS.forEach((cntr) => {
              setDoc(doc(db, 'counters', cntr.id), cntr).catch(console.error);
            });
          }
        })
        .catch((err) => console.warn('Firestore counter check warning:', err));

      // Listen to real-time tokens in Firestore
      unsubTokens = onSnapshot(
        tokensRef,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteTokens = snapshot.docs.map((d) => d.data());
            remoteTokens.sort(
              (a, b) => new Date(b.joinedAt).getTime() - new Date(a.joinedAt).getTime()
            );
            setTokens(recalculateWaitingEstimates(remoteTokens, counters, services));
          }
        },
        (err) => console.warn('Firestore tokens subscription warning:', err)
      );

      // Listen to real-time counters in Firestore
      unsubCounters = onSnapshot(
        countersRef,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteCounters = snapshot.docs.map((d) => d.data());
            remoteCounters.sort((a, b) => a.number - b.number);
            setCounters(remoteCounters);
          }
        },
        (err) => console.warn('Firestore counters subscription warning:', err)
      );
    } catch (err) {
      console.warn('Firestore listener setup error:', err);
    }

    return () => {
      if (unsubTokens) unsubTokens();
      if (unsubCounters) unsubCounters();
    };
  }, [counters, services]);

  const showToast = useCallback((message, type = 'info') => {
    setToastMessage({ message, type, id: Date.now() });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  }, []);

  const broadcastCall = useCallback(
    (tokenNum, counterNum, counterName) => {
      if (soundEnabled) {
        playQueueChime();
      }
      setLastAnnouncement({
        tokenNumber: tokenNum,
        counterNumber: counterNum,
        counterName: counterName || `Counter ${counterNum}`,
        time: 'Just now',
      });
      showToast(`🔔 Token ${tokenNum} called to Counter 0${counterNum}!`, 'announcement');
    },
    [soundEnabled, showToast]
  );

  // Register New Visitor Token (Persists to Firestore if live)
  const registerToken = useCallback(
    ({ name, phone = '', email = '', serviceId, priority = 'standard', notes = '', notificationPref = 'sms' }) => {
      const service = services.find((s) => s.id === serviceId) || services[0];

      // Find highest existing QS- number
      const qsNumbers = tokens
        .map((t) => {
          const match = t.tokenNumber.match(/^QS-(\d+)$/i);
          return match ? parseInt(match[1], 10) : null;
        })
        .filter((n) => n !== null);

      const nextNum = qsNumbers.length > 0 ? Math.max(...qsNumbers) + 1 : 101;
      const tokenNumber = `QS-${nextNum}`;

      const initialToken = {
        id: `tok-${Date.now()}`,
        tokenNumber,
        name: name.trim(),
        phone: phone ? phone.trim() : 'Walk-In (No phone)',
        email: email ? email.trim() : '',
        serviceId,
        priority: priority.toLowerCase(),
        status: TOKEN_STATUS.WAITING,
        counterId: null,
        counterNumber: null,
        joinedAt: new Date().toISOString(),
        calledAt: null,
        completedAt: null,
        estimatedWaitMin: 5,
        peopleAhead: 0,
        aiConfidence: `${Math.floor(93 + Math.random() * 6)}%`,
        notes: notes ? notes.trim() : '',
        notificationPref,
      };

      // Persist to Cloud Firestore if connected
      if (isFirebaseConfigured && db) {
        setDoc(doc(db, 'tokens', initialToken.id), initialToken).catch((err) =>
          console.warn('Firestore token write failed:', err)
        );
      }

      const updatedTokensList = [initialToken, ...tokens];
      const recalculated = recalculateWaitingEstimates(updatedTokensList, counters, services);

      setTokens(recalculated);
      setMyTokenId(initialToken.id);
      showToast(`Token ${tokenNumber} registered! Viewing your live pass.`, 'success');
      return initialToken;
    },
    [tokens, counters, services, showToast]
  );

  // Counter Action: Call Next (Priority + FIFO)
  const callNext = useCallback(
    (counterId) => {
      const counter = counters.find((c) => c.id === counterId);
      if (!counter) return null;

      if (!counter.isOpen) {
        showToast(`Counter 0${counter.number} is closed. Open the counter first.`, 'warning');
        return null;
      }

      if (counter.currentToken) {
        showToast(
          `Counter 0${counter.number} is already serving ${counter.currentToken}. Complete or skip it before calling next.`,
          'warning'
        );
        return null;
      }

      const eligibleWaiting = tokens.filter(
        (t) => t.status === TOKEN_STATUS.WAITING && counter.services.includes(t.serviceId)
      );

      if (eligibleWaiting.length === 0) {
        showToast(`No visitors waiting for Counter 0${counter.number} services.`, 'info');
        return null;
      }

      eligibleWaiting.sort(compareTokens);
      const nextToken = eligibleWaiting[0];

      if (!canTransition(nextToken.status, TOKEN_STATUS.SERVING)) {
        showToast(`Invalid state transition: Cannot transition from ${nextToken.status} to SERVING.`, 'warning');
        return null;
      }

      // Persist updates to Firestore if live
      if (isFirebaseConfigured && db) {
        updateDoc(doc(db, 'tokens', nextToken.id), {
          status: TOKEN_STATUS.SERVING,
          counterId: counter.id,
          counterNumber: counter.number,
          calledAt: new Date().toISOString(),
          estimatedWaitMin: 0,
          peopleAhead: 0,
        }).catch((err) => console.warn('Firestore callNext token update failed:', err));

        updateDoc(doc(db, 'counters', counter.id), {
          status: 'busy',
          currentToken: nextToken.tokenNumber,
        }).catch((err) => console.warn('Firestore callNext counter update failed:', err));
      }

      const updatedTokens = tokens.map((t) => {
        if (t.id === nextToken.id) {
          return {
            ...t,
            status: TOKEN_STATUS.SERVING,
            counterId: counter.id,
            counterNumber: counter.number,
            calledAt: new Date().toISOString(),
            estimatedWaitMin: 0,
            peopleAhead: 0,
            aiNote: `Currently being served at Counter 0${counter.number} (${counter.operator}).`,
          };
        }
        return t;
      });

      const updatedCounters = counters.map((c) => {
        if (c.id === counterId) {
          return {
            ...c,
            status: 'busy',
            currentToken: nextToken.tokenNumber,
          };
        }
        return c;
      });

      const finalTokens = recalculateWaitingEstimates(updatedTokens, updatedCounters, services);

      setTokens(finalTokens);
      setCounters(updatedCounters);

      broadcastCall(nextToken.tokenNumber, counter.number, counter.name);
      return nextToken;
    },
    [counters, tokens, services, showToast, broadcastCall]
  );

  // Counter Action: Complete Service (SERVING -> COMPLETED)
  const completeService = useCallback(
    (counterId) => {
      const counter = counters.find((c) => c.id === counterId);
      if (!counter) return;

      const tokenNumber = counter.currentToken;
      const servingToken = tokens.find(
        (t) => t.tokenNumber === tokenNumber && t.status === TOKEN_STATUS.SERVING
      );

      if (servingToken && !canTransition(servingToken.status, TOKEN_STATUS.COMPLETED)) {
        showToast(`Invalid state transition: Token is in ${servingToken.status} status.`, 'warning');
        return;
      }

      // Persist to Cloud Firestore if connected
      if (isFirebaseConfigured && db) {
        if (servingToken) {
          updateDoc(doc(db, 'tokens', servingToken.id), {
            status: TOKEN_STATUS.COMPLETED,
            completedAt: new Date().toISOString(),
          }).catch((err) => console.warn('Firestore completeService token update failed:', err));
        }

        updateDoc(doc(db, 'counters', counter.id), {
          status: counter.isOpen ? 'available' : 'closed',
          currentToken: null,
          servedToday: (counter.servedToday || 0) + 1,
        }).catch((err) => console.warn('Firestore completeService counter update failed:', err));
      }

      const updatedTokens = tokens.map((t) => {
        if (t.tokenNumber === tokenNumber && t.status === TOKEN_STATUS.SERVING) {
          return {
            ...t,
            status: TOKEN_STATUS.COMPLETED,
            completedAt: new Date().toISOString(),
            aiNote: `Session successfully completed at Counter 0${counter.number}.`,
          };
        }
        return t;
      });

      const updatedCounters = counters.map((c) => {
        if (c.id === counterId) {
          return {
            ...c,
            status: c.isOpen ? 'available' : 'closed',
            currentToken: null,
            servedToday: c.servedToday + 1,
          };
        }
        return c;
      });

      const finalTokens = recalculateWaitingEstimates(updatedTokens, updatedCounters, services);

      setTokens(finalTokens);
      setCounters(updatedCounters);

      showToast(`Token ${tokenNumber || 'current'} marked COMPLETED. Counter 0${counter.number} is now Available.`, 'success');
    },
    [counters, tokens, services, showToast]
  );

  // Counter Action: Skip Token (SERVING or WAITING -> SKIPPED)
  const skipToken = useCallback(
    (tokenIdOrCounterId, reason = 'Visitor No-Show') => {
      let tokenToSkip = tokens.find((t) => t.id === tokenIdOrCounterId);
      let counterToFree = null;

      if (!tokenToSkip) {
        const counter = counters.find((c) => c.id === tokenIdOrCounterId);
        if (counter && counter.currentToken) {
          tokenToSkip = tokens.find((t) => t.tokenNumber === counter.currentToken);
          counterToFree = counter;
        }
      } else if (tokenToSkip.counterId) {
        counterToFree = counters.find((c) => c.id === tokenToSkip.counterId);
      }

      if (!tokenToSkip) {
        showToast('No active token found to skip.', 'warning');
        return;
      }

      if (!canTransition(tokenToSkip.status, TOKEN_STATUS.SKIPPED)) {
        showToast(
          `Invalid state transition: Cannot skip token currently in ${tokenToSkip.status} status.`,
          'warning'
        );
        return;
      }

      // Persist to Cloud Firestore if connected
      if (isFirebaseConfigured && db) {
        updateDoc(doc(db, 'tokens', tokenToSkip.id), {
          status: TOKEN_STATUS.SKIPPED,
          completedAt: new Date().toISOString(),
          aiNote: `Marked SKIPPED (${reason}).`,
        }).catch((err) => console.warn('Firestore skipToken token update failed:', err));

        if (counterToFree) {
          updateDoc(doc(db, 'counters', counterToFree.id), {
            status: counterToFree.isOpen ? 'available' : 'closed',
            currentToken: null,
            skippedToday: (counterToFree.skippedToday || 0) + 1,
          }).catch((err) => console.warn('Firestore skipToken counter update failed:', err));
        }
      }

      const updatedTokens = tokens.map((t) => {
        if (t.id === tokenToSkip.id) {
          return {
            ...t,
            status: TOKEN_STATUS.SKIPPED,
            completedAt: new Date().toISOString(),
            aiNote: `Marked SKIPPED (${reason}).`,
          };
        }
        return t;
      });

      let updatedCounters = counters;
      if (counterToFree) {
        updatedCounters = counters.map((c) => {
          if (c.id === counterToFree.id) {
            return {
              ...c,
              status: c.isOpen ? 'available' : 'closed',
              currentToken: null,
              skippedToday: (c.skippedToday || 0) + 1,
            };
          }
          return c;
        });
      }

      const finalTokens = recalculateWaitingEstimates(updatedTokens, updatedCounters, services);

      setTokens(finalTokens);
      setCounters(updatedCounters);

      showToast(`Token ${tokenToSkip.tokenNumber} marked SKIPPED.`, 'warning');
    },
    [tokens, counters, services, showToast]
  );

  // Counter Action: Toggle Open / Close Counter
  const toggleCounterStatus = useCallback(
    (counterId) => {
      const target = counters.find((c) => c.id === counterId);
      if (!target) return;

      const willBeOpen = !target.isOpen;

      // Persist to Cloud Firestore if connected
      if (isFirebaseConfigured && db) {
        updateDoc(doc(db, 'counters', counterId), {
          isOpen: willBeOpen,
          status: willBeOpen ? (target.currentToken ? 'busy' : 'available') : 'closed',
        }).catch((err) => console.warn('Firestore toggleCounterStatus failed:', err));
      }

      const updatedCounters = counters.map((c) => {
        if (c.id === counterId) {
          return {
            ...c,
            isOpen: willBeOpen,
            status: willBeOpen ? (c.currentToken ? 'busy' : 'available') : 'closed',
          };
        }
        return c;
      });

      const finalTokens = recalculateWaitingEstimates(tokens, updatedCounters, services);

      setCounters(updatedCounters);
      setTokens(finalTokens);

      showToast(
        `Counter 0${target.number} is now ${willBeOpen ? 'OPEN' : 'CLOSED'}. Queue wait times updated.`,
        willBeOpen ? 'success' : 'info'
      );
    },
    [counters, tokens, services, showToast]
  );

  // Transfer Token
  const transferToken = useCallback(
    (tokenId, newServiceId, note = 'Transferred by operator') => {
      const targetService = services.find((s) => s.id === newServiceId);
      if (!targetService) return;

      const targetToken = tokens.find((t) => t.id === tokenId);
      if (!targetToken) return;

      // Persist to Cloud Firestore if connected
      if (isFirebaseConfigured && db) {
        updateDoc(doc(db, 'tokens', tokenId), {
          serviceId: newServiceId,
          status: TOKEN_STATUS.WAITING,
          counterId: null,
          counterNumber: null,
          calledAt: null,
        }).catch((err) => console.warn('Firestore transferToken failed:', err));
      }

      const updatedTokens = tokens.map((t) => {
        if (t.id === tokenId) {
          return {
            ...t,
            serviceId: newServiceId,
            status: TOKEN_STATUS.WAITING,
            counterId: null,
            counterNumber: null,
            calledAt: null,
            notes: t.notes ? `${t.notes} | ${note}` : note,
          };
        }
        return t;
      });

      const updatedCounters = counters.map((c) => {
        if (c.currentToken === targetToken.tokenNumber) {
          return { ...c, status: c.isOpen ? 'available' : 'closed', currentToken: null };
        }
        return c;
      });

      const finalTokens = recalculateWaitingEstimates(updatedTokens, updatedCounters, services);

      setTokens(finalTokens);
      setCounters(updatedCounters);
      showToast(`Transferred to ${targetService.name}`, 'info');
    },
    [tokens, counters, services, showToast]
  );

  // Delay turn (visitor self-service: +5 mins buffer)
  const delayTurn = useCallback(
    (tokenId) => {
      const updatedTokens = tokens.map((t) => {
        if (t.id === tokenId && t.status === TOKEN_STATUS.WAITING) {
          const newJoinedAt = new Date(new Date(t.joinedAt).getTime() + 5 * 60000).toISOString();
          if (isFirebaseConfigured && db) {
            updateDoc(doc(db, 'tokens', tokenId), { joinedAt: newJoinedAt }).catch(console.error);
          }
          return {
            ...t,
            joinedAt: newJoinedAt,
            aiNote: 'Turn delayed by 5 minutes. Next waiting visitors prioritized.',
          };
        }
        return t;
      });

      const finalTokens = recalculateWaitingEstimates(updatedTokens, counters, services);
      setTokens(finalTokens);
      showToast('Turn delayed by 5 minutes. Feel free to grab a coffee!', 'info');
    },
    [tokens, counters, services, showToast]
  );

  // Cancel token (WAITING -> SKIPPED)
  const cancelToken = useCallback(
    (tokenId) => {
      skipToken(tokenId, 'Cancelled by Visitor');
    },
    [skipToken]
  );

  // Bump priority
  const bumpPriority = useCallback(
    (tokenId, newPriority) => {
      if (isFirebaseConfigured && db) {
        updateDoc(doc(db, 'tokens', tokenId), { priority: newPriority.toLowerCase() }).catch(console.error);
      }

      const updatedTokens = tokens.map((t) => {
        if (t.id === tokenId) {
          return {
            ...t,
            priority: newPriority.toLowerCase(),
            aiNote: `Priority escalated to ${newPriority.toUpperCase()} by triage staff.`,
          };
        }
        return t;
      });

      const finalTokens = recalculateWaitingEstimates(updatedTokens, counters, services);
      setTokens(finalTokens);
      showToast(`Priority updated to ${newPriority}`, 'success');
    },
    [tokens, counters, services, showToast]
  );

  // Reset demo data
  const resetDemoData = useCallback(() => {
    const freshTokens = recalculateWaitingEstimates(INITIAL_TOKENS, INITIAL_COUNTERS, SERVICES);
    setTokens(freshTokens);
    setCounters(INITIAL_COUNTERS);
    setMyTokenId('tok-a105');
    localStorage.removeItem(STORAGE_KEY_TOKENS);
    localStorage.removeItem(STORAGE_KEY_COUNTERS);
    localStorage.removeItem(STORAGE_KEY_MY_TOKEN);
    showToast('Demo data reset to pristine state.', 'info');
  }, [showToast]);

  // Live simulation
  const toggleSimulation = useCallback(() => {
    setIsSimulating((prev) => !prev);
  }, []);

  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      const availableCounters = counters.filter((c) => c.isOpen && !c.currentToken);
      if (availableCounters.length > 0) {
        const randCounter = availableCounters[Math.floor(Math.random() * availableCounters.length)];
        callNext(randCounter.id);
      } else {
        const busyCounters = counters.filter((c) => c.isOpen && c.currentToken);
        if (busyCounters.length > 0) {
          const randBusy = busyCounters[Math.floor(Math.random() * busyCounters.length)];
          completeService(randBusy.id);
        }
      }
    }, 12000);

    return () => clearInterval(interval);
  }, [isSimulating, counters, callNext, completeService]);

  // Derived metrics
  const waitingTokens = tokens.filter((t) => t.status === TOKEN_STATUS.WAITING);
  const servingTokens = tokens.filter((t) => t.status === TOKEN_STATUS.SERVING);
  const completedTokens = tokens.filter((t) => t.status === TOKEN_STATUS.COMPLETED);
  const skippedTokens = tokens.filter((t) => t.status === TOKEN_STATUS.SKIPPED);

  const openCounters = counters.filter((c) => c.isOpen);
  const closedCounters = counters.filter((c) => !c.isOpen);

  // Dynamic average wait time across waiting queue
  const dynamicAvgWaitMin =
    waitingTokens.length > 0
      ? (
          waitingTokens.reduce((acc, t) => acc + (t.estimatedWaitMin || 4), 0) /
          waitingTokens.length
        ).toFixed(1)
      : '0.0';

  // Currently selected visitor token
  const myToken =
    tokens.find((t) => t.id === myTokenId) ||
    tokens.find((t) => t.tokenNumber === myTokenId) ||
    tokens[0];

  // In-App Notifications for visitor (tracked per myToken)
  const [visitorNotifications, setVisitorNotifications] = useState(() => {
    try {
      const saved = sessionStorage.getItem('queuesmart_visitor_notifications');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const lastNotifiedStateRef = useRef({
    tokenId: null,
    calledStatus: false,
    approachingAhead: null,
    lastWaitMin: null,
  });

  useEffect(() => {
    try {
      sessionStorage.setItem(
        'queuesmart_visitor_notifications',
        JSON.stringify(visitorNotifications)
      );
    } catch (e) {
      console.error(e);
    }
  }, [visitorNotifications]);

  // Evaluate visitor notification triggers (no duplicates, no random fake activity)
  useEffect(() => {
    if (!myToken) return;

    // Reset tracking if user switched tokens
    if (lastNotifiedStateRef.current.tokenId !== myToken.id) {
      lastNotifiedStateRef.current = {
        tokenId: myToken.id,
        calledStatus: myToken.status === TOKEN_STATUS.SERVING || myToken.status === 'CALLING',
        approachingAhead: null,
        lastWaitMin: myToken.estimatedWaitMin || null,
      };
      return;
    }

    const newAlerts = [];
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // 1. TOKEN IS CALLED
    const isCalledNow = myToken.status === TOKEN_STATUS.SERVING || myToken.status === 'CALLING';
    if (isCalledNow && !lastNotifiedStateRef.current.calledStatus) {
      lastNotifiedStateRef.current.calledStatus = true;
      newAlerts.push({
        id: `notif-called-${Date.now()}`,
        type: 'called',
        title: '🔔 Your Token Has Been Called!',
        message: `Token ${myToken.tokenNumber} is now being served at Counter 0${myToken.counterNumber || 1}. Please proceed to the desk immediately.`,
        timestamp: timeStr,
        read: false,
        priority: 'high',
      });
      if (soundEnabled) {
        playNotificationSound();
      }
    }

    // 2. APPROACHING TURN (1 or 2 people ahead, in WAITING status)
    if (
      myToken.status === TOKEN_STATUS.WAITING &&
      myToken.peopleAhead !== undefined &&
      myToken.peopleAhead > 0 &&
      myToken.peopleAhead <= 2 &&
      lastNotifiedStateRef.current.approachingAhead !== myToken.peopleAhead
    ) {
      lastNotifiedStateRef.current.approachingAhead = myToken.peopleAhead;
      newAlerts.push({
        id: `notif-approach-${Date.now()}`,
        type: 'approaching',
        title: myToken.peopleAhead === 1 ? '⚡ You Are Next in Line!' : '📍 Approaching Your Turn',
        message:
          myToken.peopleAhead === 1
            ? `Only 1 person ahead of ${myToken.tokenNumber}. Please be ready near the service desks.`
            : `2 people ahead of ${myToken.tokenNumber}. Your turn will be called soon.`,
        timestamp: timeStr,
        read: false,
        priority: 'medium',
      });
      if (soundEnabled) {
        playNotificationSound();
      }
    }

    // 3. SIGNIFICANT WAIT TIME CHANGE (>= 3 minutes)
    if (
      myToken.status === TOKEN_STATUS.WAITING &&
      myToken.estimatedWaitMin !== undefined &&
      lastNotifiedStateRef.current.lastWaitMin !== null
    ) {
      const waitDiff = myToken.estimatedWaitMin - lastNotifiedStateRef.current.lastWaitMin;
      if (Math.abs(waitDiff) >= 3) {
        lastNotifiedStateRef.current.lastWaitMin = myToken.estimatedWaitMin;
        const isFaster = waitDiff < 0;
        newAlerts.push({
          id: `notif-wait-${Date.now()}`,
          type: 'wait_change',
          title: isFaster ? '⏱️ Wait Time Significantly Reduced' : '⏱️ Wait Time Adjusted',
          message: isFaster
            ? `Good news! Your estimated wait decreased by ${Math.abs(waitDiff)} min (now ~${myToken.estimatedWaitMin}m) due to counter throughput.`
            : `Estimated wait adjusted to ~${myToken.estimatedWaitMin}m (+${waitDiff}m) based on current desk throughput.`,
          timestamp: timeStr,
          read: false,
          priority: 'low',
        });
        if (soundEnabled) {
          playNotificationSound();
        }
      }
    } else if (lastNotifiedStateRef.current.lastWaitMin === null && myToken.estimatedWaitMin) {
      lastNotifiedStateRef.current.lastWaitMin = myToken.estimatedWaitMin;
    }

    if (newAlerts.length > 0) {
      setVisitorNotifications((prev) => [...newAlerts, ...prev].slice(0, 15));
    }
  }, [myToken, soundEnabled]);

  const dismissVisitorNotification = useCallback((id) => {
    setVisitorNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const markVisitorNotificationRead = useCallback((id) => {
    setVisitorNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const clearAllVisitorNotifications = useCallback(() => {
    setVisitorNotifications([]);
  }, []);

  // Explainable Queue Intelligence Analysis
  const queueIntelligence = analyzeQueueIntelligence(tokens, counters, services);

  const openCounterDirectly = useCallback(
    (counterId) => {
      const c = counters.find((item) => item.id === counterId);
      if (!c) return;
      if (!c.isOpen) {
        toggleCounterStatus(counterId);
      }
      showToast(`Counter 0${c.number} (${c.name}) successfully OPENED. Waiting times recalculated.`, 'success');
    },
    [counters, toggleCounterStatus, showToast]
  );

  const value = {
    services,
    counters,
    tokens,
    waitingTokens,
    servingTokens,
    completedTokens,
    skippedTokens,
    openCounters,
    closedCounters,
    myToken,
    myTokenId,
    setMyTokenId,
    soundEnabled,
    setSoundEnabled,
    isSimulating,
    toggleSimulation,
    lastAnnouncement,
    broadcastCall,
    registerToken,
    callNext,
    completeService,
    skipToken,
    toggleCounterStatus,
    openCounterDirectly,
    transferToken,
    delayTurn,
    cancelToken,
    bumpPriority,
    resetDemoData,
    toastMessage,
    showToast,
    dynamicAvgWaitMin,
    isFirebase: isFirebaseConfigured,
    queueIntelligence,
    simulateWhatIfCounterOpen: (counterId) =>
      simulateWhatIfCounterOpen(counterId, tokens, counters, services),
    visitorNotifications,
    unreadVisitorNotificationCount: visitorNotifications.filter((n) => !n.read).length,
    dismissVisitorNotification,
    markVisitorNotificationRead,
    clearAllVisitorNotifications,
    analytics: {
      ...AI_ANALYTICS,
      avgWaitTimeMin: dynamicAvgWaitMin,
    },
  };

  return <QueueContext.Provider value={value}>{children}</QueueContext.Provider>;
}

export function useQueue() {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
}
