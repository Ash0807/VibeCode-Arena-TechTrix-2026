import React from 'react';
import { useQueue } from '../context/QueueContext';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import {
  Sparkles,
  ArrowRight,
  Clock,
  Users,
  Cpu,
  Tv,
  CheckCircle2,
  TrendingDown,
  ShieldCheck,
  Zap,
  Building2,
  Activity,
  Layers,
  HelpCircle,
  CreditCard,
  FileCheck,
} from 'lucide-react';

export function LandingPage({ setCurrentRoute }) {
  const { waitingTokens, servingTokens, openCounters, counters, services, myToken, dynamicAvgWaitMin } = useQueue();

  const activeWaitingCount = waitingTokens.length;
  const currentlyServingCount = servingTokens.length;
  const openCountersCount = openCounters.length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800 text-white pt-16 pb-24 px-4 sm:px-6 lg:px-8">
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(#14b8a6_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-semibold">
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span>Next-Generation Predictive Queue Intelligence</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-white">
                Zero Physical Lines. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-teal-200">
                  Smarter Service.
                </span>
              </h1>

              <p className="text-lg text-slate-300 leading-relaxed max-w-2xl font-normal">
                QueueSmart AI eliminates waiting room frustration with real-time machine learning queue prediction, automated priority triage for seniors & medical cases, and synchronized public kiosk displays.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setCurrentRoute('register')}
                  className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-6 py-3.5 rounded-xl shadow-lg shadow-teal-500/25 transition-all flex items-center gap-2 group"
                >
                  <span>Join Queue / Get Token</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => setCurrentRoute('display')}
                  className="bg-slate-800/90 hover:bg-slate-700 text-white font-semibold px-6 py-3.5 rounded-xl border border-slate-700 transition flex items-center gap-2"
                >
                  <Tv className="w-4 h-4 text-teal-400" />
                  <span>Open TV Display Board</span>
                </button>

                <button
                  onClick={() => setCurrentRoute('admin')}
                  className="text-slate-300 hover:text-white font-medium px-4 py-3 text-sm flex items-center gap-1.5 transition underline-offset-4 hover:underline"
                >
                  <span>Staff / Operator Desk &rarr;</span>
                </button>
              </div>

              {/* Live Metric Badges */}
              <div className="pt-6 border-t border-slate-800/80 grid grid-cols-3 gap-4">
                <div>
                  <div className="text-2xl font-extrabold text-teal-400 font-mono">
                    {activeWaitingCount}
                  </div>
                  <div className="text-xs text-slate-400 font-medium">In Live Queue</div>
                </div>
                <div>
                  <div className="text-2xl font-extrabold text-white font-mono">
                    {openCountersCount} / {counters.length}
                  </div>
                  <div className="text-xs text-slate-400 font-medium">Open Counters</div>
                </div>
                <div>
                  <div className="text-2xl font-extrabold text-teal-300 font-mono">
                    ~{dynamicAvgWaitMin}m
                  </div>
                  <div className="text-xs text-slate-400 font-medium">Avg Dynamic Wait</div>
                </div>
              </div>
            </div>

            {/* Right Live Card Widget */}
            <div className="lg:col-span-5">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 shadow-2xl backdrop-blur-md relative overflow-hidden">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" />
                    <span className="text-sm font-semibold text-white">Live Queue Monitor</span>
                  </div>
                  <span className="text-xs font-mono bg-teal-950 text-teal-400 px-2 py-0.5 rounded border border-teal-800">
                    AI Predictor: 98.4% Acc
                  </span>
                </div>

                {/* Now Serving Highlight */}
                <div className="mb-4 bg-slate-900 p-4 rounded-xl border border-teal-500/20">
                  <div className="text-xs uppercase font-bold text-teal-400 tracking-wider mb-2 flex items-center justify-between">
                    <span>Currently Serving</span>
                    <span className="text-[10px] text-slate-400 font-normal">Real-Time Sync</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {servingTokens.slice(0, 2).map((token) => (
                      <div
                        key={token.id}
                        className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="text-xl font-bold font-mono text-teal-300">
                            {token.tokenNumber}
                          </div>
                          <div className="text-xs text-slate-400 truncate max-w-[100px]">
                            {token.name}
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-200">
                            C-0{token.counterNumber}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Up Next List */}
                <div>
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Up Next in Queue ({waitingTokens.length} waiting)
                  </div>
                  <div className="space-y-2">
                    {waitingTokens.slice(0, 3).map((token, idx) => (
                      <div
                        key={token.id}
                        className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 text-xs font-mono flex items-center justify-center font-bold">
                            {idx + 1}
                          </span>
                          <div>
                            <span className="font-mono font-bold text-white text-sm">
                              {token.tokenNumber}
                            </span>
                            <span className="text-slate-400 text-xs ml-2">
                              {token.name}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <PriorityBadge priority={token.priority} size="sm" />
                          <span className="text-xs font-mono text-teal-400">
                            ~{token.estimatedWaitMin}m
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Link to My Token */}
                {myToken && (
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    <div className="text-xs text-slate-400">
                      Active Ticket on this device: <strong className="text-teal-300">{myToken.tokenNumber}</strong>
                    </div>
                    <button
                      onClick={() => setCurrentRoute('my-token')}
                      className="text-xs text-teal-400 hover:text-teal-300 font-semibold"
                    >
                      Track Now &rarr;
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Value Pillars Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight sm:text-4xl">
            Engineered for Modern Enterprise Operations
          </h2>
          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            Replace chaotic waiting areas, static printed tickets, and manual reception bottlenecks with an automated, AI-balanced workflow.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative group">
            <div className="w-12 h-12 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-teal-600 mb-5 group-hover:scale-105 transition-transform">
              <Cpu className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Predictive AI Wait Times</h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              Machine learning calculates precise wait times in real time based on active counter pacing, time-of-day traffic surges, and historical service durations.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-teal-700 font-medium">
              <CheckCircle2 className="w-4 h-4 text-teal-600" />
              <span>98.4% estimation accuracy rate</span>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative group">
            <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 mb-5 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Intelligent Priority Triage</h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              Automatic fast-lane prioritization for senior citizens, patients requiring medical assistance, pregnant mothers, and pre-scheduled appointments.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-amber-800 font-medium">
              <CheckCircle2 className="w-4 h-4 text-amber-600" />
              <span>64% faster assistance for vulnerable visitors</span>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative group">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mb-5 group-hover:scale-105 transition-transform">
              <Tv className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Synchronized Kiosk & TV Audio</h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              Broadcast high-contrast lobby screen updates with two-tone chime announcements. Seamlessly responsive for wall TVs, mobile phones, or iPad kiosks.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium">
              <CheckCircle2 className="w-4 h-4 text-indigo-600" />
              <span>Zero-latency Web Audio chime alerts</span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works 3-Step Walkthrough */}
      <section className="bg-slate-100/70 border-y border-slate-200/80 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Frictionless Visitor Journey
            </h2>
            <p className="mt-3 text-slate-600 text-sm">
              From the moment a visitor arrives until their consultation is completed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Step 1 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-extrabold text-teal-600 font-mono">01</span>
                  <span className="px-2.5 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-semibold">
                    Visitor Self-Check In
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2">
                  Select Service & Instant AI Pass
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Visitors scan a lobby QR code or use a tablet kiosk to select their desired service. The system generates a digital token with QR verification.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentRoute('register')}
                  className="text-xs text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1"
                >
                  <span>Test Visitor Registration</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-extrabold text-teal-600 font-mono">02</span>
                  <span className="px-2.5 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-semibold">
                    Live Mobile Tracking
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2">
                  Wait Anywhere Without Anxiety
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Visitors relax at a cafeteria or outside. Their live web pass shows exact queue position, dynamic countdown, and options to delay turn if delayed.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentRoute('my-token')}
                  className="text-xs text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1"
                >
                  <span>View Live Ticket Demo</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-extrabold text-teal-600 font-mono">03</span>
                  <span className="px-2.5 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-semibold">
                    Counter Call & Chime
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2">
                  Instant Chime & Direct Counter Assignment
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  When the counter operator clicks "Call Next", the lobby screen rings an audible chime, highlights the token, and directs the visitor to Counter X.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentRoute('admin')}
                  className="text-xs text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1"
                >
                  <span>Open Operator Desk</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Supported Service Desks
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Multi-department routing with designated counters and estimated service rates.
            </p>
          </div>
          <button
            onClick={() => setCurrentRoute('register')}
            className="mt-4 md:mt-0 text-sm font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1"
          >
            <span>Register for a desk</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((svc) => (
            <div
              key={svc.id}
              className="bg-white border border-slate-200 rounded-xl p-5 hover:border-teal-400 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-slate-100 text-slate-700">
                    Series {svc.code}-XXX
                  </span>
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-teal-600" />
                    <span>~{svc.avgTimeMin}m avg service</span>
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-base mb-1.5">{svc.name}</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {svc.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">
                  {svc.activeCounters.join(' • ')}
                </span>
                <button
                  onClick={() => setCurrentRoute('register')}
                  className="font-semibold text-teal-600 hover:text-teal-800"
                >
                  Get Token &rarr;
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Target Industries */}
      <section className="bg-slate-900 text-white py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-2 block">
              Enterprise Adaptability
            </span>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              Deployed in High-Volume Facilities
            </h2>
            <p className="mt-3 text-slate-300 text-sm">
              Custom-tailored algorithms optimized for diverse customer servicing dynamics.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-5 rounded-xl bg-slate-800/80 border border-slate-700">
              <Building2 className="w-7 h-7 text-teal-400 mb-3" />
              <h4 className="font-bold text-white text-base mb-1">Hospitals & Clinics</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Triage patients by acuity, reduce infection exposure in crowded waiting halls, and alert pharmacy queues.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-800/80 border border-slate-700">
              <CreditCard className="w-7 h-7 text-teal-400 mb-3" />
              <h4 className="font-bold text-white text-base mb-1">Banks & Credit Unions</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Separate high-speed teller transactions from in-depth mortgage and wealth consultations.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-800/80 border border-slate-700">
              <FileCheck className="w-7 h-7 text-teal-400 mb-3" />
              <h4 className="font-bold text-white text-base mb-1">Government & DMV</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Transform notorious civil licensing queues into civilized, scheduled digital appointments.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-800/80 border border-slate-700">
              <Users className="w-7 h-7 text-teal-400 mb-3" />
              <h4 className="font-bold text-white text-base mb-1">Telecom & Retail Desks</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Allow customers to browse showroom devices while maintaining their spot for technical support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final Action CTA Banner */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-teal-600 via-teal-700 to-slate-900 rounded-3xl p-8 sm:p-12 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl">
            <h2 className="text-3xl font-extrabold tracking-tight">
              Ready to experience modern queue management?
            </h2>
            <p className="text-teal-100 text-sm leading-relaxed">
              Issue a sample ticket, watch the live TV screen update, and step into the operator admin shoes with full interactive simulation.
            </p>
          </div>

          <div className="flex flex-wrap gap-4 shrink-0">
            <button
              onClick={() => setCurrentRoute('register')}
              className="bg-white text-slate-900 hover:bg-slate-100 font-bold px-6 py-3.5 rounded-xl shadow-md transition"
            >
              Get a Token
            </button>
            <button
              onClick={() => setCurrentRoute('admin')}
              className="bg-slate-950/40 hover:bg-slate-950/60 text-white font-semibold px-6 py-3.5 rounded-xl border border-white/20 transition"
            >
              Explore Admin Portal
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
