import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import {
  User,
  Phone,
  Mail,
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  CreditCard,
  FileCheck,
  Users,
  Building,
  Loader2,
} from 'lucide-react';

export function VisitorRegistration({ setCurrentRoute }) {
  const { services, registerToken, waitingTokens, counters } = useQueue();

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    serviceId: 'general',
    priority: 'standard',
    notes: '',
    notificationPref: 'sms',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState('');

  const selectedService = services.find((s) => s.id === formData.serviceId) || services[0];

  // Dynamic wait time estimate formula: (People Ahead * Avg Duration) / Active Open Counters
  const eligibleOpenCounters = counters.filter(
    (c) => c.isOpen && c.services.includes(formData.serviceId)
  );
  const activeCountersCount = Math.max(1, eligibleOpenCounters.length);

  const prioWeight = (p) => ({ vip: 4, medical: 3, senior: 2, appointment: 2, standard: 1 }[p] || 1);
  const currentWeight = prioWeight(formData.priority);
  const isPriority = formData.priority !== 'standard';
  const eligiblePeopleAhead = waitingTokens.filter(
    (t) => t.serviceId === formData.serviceId && prioWeight(t.priority) >= currentWeight
  ).length;

  const avgDuration = selectedService.avgTimeMin || 6;
  const calculatedWait =
    eligiblePeopleAhead === 0
      ? eligibleOpenCounters.some((c) => !c.currentToken)
        ? 1
        : Math.max(1, Math.round(avgDuration / 2))
      : Math.max(1, Math.round((eligiblePeopleAhead * avgDuration) / activeCountersCount));

  const validate = () => {
    const errs = {};
    setSubmitError('');

    // Customer Name is mandatory
    if (!formData.name.trim()) {
      errs.name = 'Customer name is required';
    } else if (formData.name.trim().length < 2) {
      errs.name = 'Customer name must be at least 2 characters';
    }

    // Contact details are optional, but if provided, validate formats
    if (formData.phone.trim()) {
      // Validate phone has at least 7 digits/characters
      const phoneDigits = formData.phone.replace(/\D/g, '');
      if (phoneDigits.length < 7) {
        errs.phone = 'Please enter a valid phone number (at least 7 digits)';
      }
    }

    if (formData.email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        errs.email = 'Please enter a valid email address';
      }
    }

    if (!formData.serviceId) {
      errs.serviceId = 'Please select a service desk';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      setSubmitError('Please fix the errors in the form before submitting.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      // Simulate realistic async processing delay
      await new Promise((resolve) => setTimeout(resolve, 500));

      const newToken = registerToken({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim(),
        serviceId: formData.serviceId,
        priority: formData.priority,
        notes: formData.notes.trim(),
        notificationPref: formData.notificationPref,
      });

      if (newToken) {
        // Automatically navigate to My Token page as requested
        setCurrentRoute('my-token');
      } else {
        setSubmitError('Failed to generate token. Please try again.');
        setIsSubmitting(false);
      }
    } catch (err) {
      console.error(err);
      setSubmitError('An unexpected error occurred while generating your token.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold mb-2">
          <Sparkles className="w-3.5 h-3.5 text-teal-600" />
          <span>Self-Service Visitor Check-in</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Visitor Queue Registration
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Select your service desk, enter your details, and receive an instant smart queue ticket.
        </p>
      </div>

      {/* Global Error Banner */}
      {submitError && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{submitError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8" noValidate>
        {/* Left Column: Form Fields */}
        <div className="lg:col-span-8 space-y-8">
          {/* 1. Service Selection */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-500 text-white text-xs flex items-center justify-center font-bold">
                  1
                </span>
                <span>Select Service Desk</span>
                <span className="text-rose-500">*</span>
              </h2>
              <span className="text-xs text-slate-500">Live Desk Status Active</span>
            </div>

            {errors.serviceId && (
              <p className="text-rose-600 text-xs mb-3 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errors.serviceId}</span>
              </p>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {services.map((svc) => {
                const isSelected = formData.serviceId === svc.id;
                const waiters = waitingTokens.filter((t) => t.serviceId === svc.id).length;
                return (
                  <div
                    key={svc.id}
                    onClick={() => setFormData({ ...formData, serviceId: svc.id })}
                    className={`cursor-pointer rounded-xl p-4 border text-left transition-all relative ${
                      isSelected
                        ? 'border-teal-500 bg-teal-50/40 ring-2 ring-teal-500/20 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        Desk {svc.code}
                      </span>
                      <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-teal-600" />
                        <span>~{svc.avgTimeMin}m</span>
                      </span>
                    </div>

                    <div className="font-bold text-slate-900 text-sm mb-1">{svc.name}</div>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {svc.description}
                    </p>

                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">{waiters} people waiting</span>
                      {isSelected && (
                        <span className="text-teal-600 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Selected</span>
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Customer Name & Optional Contact Details */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-teal-500 text-white text-xs flex items-center justify-center font-bold">
                2
              </span>
              <span>Customer Information</span>
            </h2>

            {/* Customer Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Customer Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="e.g. Rachel Adams"
                  value={formData.name}
                  disabled={isSubmitting}
                  onChange={(e) => {
                    setFormData({ ...formData, name: e.target.value });
                    if (errors.name) setErrors({ ...errors, name: null });
                  }}
                  className={`w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 transition ${
                    errors.name ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200 focus:border-teal-500'
                  }`}
                />
              </div>
              {errors.name && (
                <p className="text-rose-600 text-xs mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.name}</span>
                </p>
              )}
            </div>

            {/* Optional Contact Details (Phone & Email) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700">
                    Mobile Phone
                  </label>
                  <span className="text-[11px] text-slate-400 font-normal">Optional</span>
                </div>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={formData.phone}
                    disabled={isSubmitting}
                    onChange={(e) => {
                      setFormData({ ...formData, phone: e.target.value });
                      if (errors.phone) setErrors({ ...errors, phone: null });
                    }}
                    className={`w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 transition ${
                      errors.phone ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200 focus:border-teal-500'
                    }`}
                  />
                </div>
                {errors.phone ? (
                  <p className="text-rose-600 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.phone}</span>
                  </p>
                ) : (
                  <p className="text-[11px] text-slate-400 mt-1">Receive SMS token status updates</p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700">
                    Email Address
                  </label>
                  <span className="text-[11px] text-slate-400 font-normal">Optional</span>
                </div>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    placeholder="rachel@example.com"
                    value={formData.email}
                    disabled={isSubmitting}
                    onChange={(e) => {
                      setFormData({ ...formData, email: e.target.value });
                      if (errors.email) setErrors({ ...errors, email: null });
                    }}
                    className={`w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 transition ${
                      errors.email ? 'border-rose-400 bg-rose-50/20' : 'border-slate-200 focus:border-teal-500'
                    }`}
                  />
                </div>
                {errors.email ? (
                  <p className="text-rose-600 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.email}</span>
                  </p>
                ) : (
                  <p className="text-[11px] text-slate-400 mt-1">For digital receipt and e-ticket</p>
                )}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700">
                  Purpose / Notes for Desk Operator
                </label>
                <span className="text-[11px] text-slate-400 font-normal">Optional</span>
              </div>
              <textarea
                rows={2}
                placeholder="Brief reason for your visit (helps counter operator prepare files ahead)..."
                value={formData.notes}
                disabled={isSubmitting}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-500/30 transition"
              />
            </div>
          </div>

          {/* 3. Priority Category */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-4">
              <span className="w-6 h-6 rounded-full bg-teal-500 text-white text-xs flex items-center justify-center font-bold">
                3
              </span>
              <span>Priority Category</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                {
                  id: 'standard',
                  title: 'Standard Visitor',
                  desc: 'Regular queuing in standard arrival sequence.',
                },
                {
                  id: 'senior',
                  title: 'Senior Citizen (60+)',
                  desc: 'Priority queue placement with seating priority.',
                },
                {
                  id: 'medical',
                  title: 'Medical / Accessibility',
                  desc: 'Accessibility priority desk routing.',
                },
                {
                  id: 'appointment',
                  title: 'Pre-Booked Appointment',
                  desc: 'Fast-pass for scheduled calendar appointment.',
                },
                {
                  id: 'vip',
                  title: 'VIP / Executive',
                  desc: 'Executive triage desk consultation.',
                },
              ].map((p) => {
                const isChecked = formData.priority === p.id;
                return (
                  <label
                    key={p.id}
                    className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition ${
                      isChecked
                        ? 'border-teal-500 bg-teal-50/40 ring-1 ring-teal-500 shadow-sm'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="priority"
                      value={p.id}
                      checked={isChecked}
                      disabled={isSubmitting}
                      onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                      className="mt-0.5 text-teal-600 focus:ring-teal-500"
                    />
                    <div>
                      <div className="text-xs font-bold text-slate-900">{p.title}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{p.desc}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: AI Live Estimation & Registration Button */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-xl sticky top-24">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span className="font-bold text-sm text-white">AI Dynamic Forecast</span>
              </div>
              <span className="text-[10px] font-mono bg-teal-950 text-teal-400 px-2 py-0.5 rounded border border-teal-800">
                Live Model
              </span>
            </div>

            {/* Big Wait Forecast */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-4 text-center">
              <span className="text-xs text-slate-400 block mb-1">Expected Wait Time</span>
              <div className="text-4xl font-black font-mono text-teal-300">
                ~{calculatedWait} min
              </div>
              <p className="text-[11px] text-teal-400/90 mt-1 font-medium">
                {isPriority
                  ? '⚡ Priority triage expedited placement'
                  : 'Based on current counter velocity & traffic surge'}
              </p>
            </div>

            {/* Breakdown Summary */}
            <div className="space-y-3 text-xs text-slate-300 mb-6">
              <div className="flex justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Target Desk</span>
                <span className="font-semibold text-white">{selectedService.name}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Assigned Counters</span>
                <span className="font-semibold text-white">
                  {selectedService.activeCounters.join(', ')}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Ahead in Line</span>
                <span className="font-mono text-teal-300 font-bold">
                  {eligiblePeopleAhead === 0 ? "You'll be next!" : `${eligiblePeopleAhead} visitors ahead`}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Open Counters</span>
                <span className="font-mono text-white font-semibold">
                  {eligibleOpenCounters.length} active
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Token Format</span>
                <span className="font-mono text-teal-300 font-bold">QS-101 sequence</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Calculation Model</span>
                <span className="font-mono text-white font-semibold">Dynamic FIFO</span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold py-3.5 px-4 rounded-xl shadow-lg shadow-teal-500/25 transition-all flex items-center justify-center gap-2 group disabled:opacity-60 cursor-pointer disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Generating Smart Token...</span>
                </>
              ) : (
                <>
                  <span>Generate Token & View Pass</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>

            <p className="text-[11px] text-slate-400 text-center mt-3">
              Wait times are mathematical estimates based on active open counters and people ahead — not guaranteed appointment commitments.
            </p>
          </div>
        </div>
      </form>
    </div>
  );
}
