import React, { useState, useEffect } from 'react';
import { useQueue, compareTokens } from '../context/QueueContext';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import { TOKEN_STATUS } from '../data/mockData';
import {
  Tv,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Clock,
  Sparkles,
  ArrowRight,
  Sun,
  Moon,
  PowerOff,
  Users,
  Info,
} from 'lucide-react';

export function PublicQueueDisplay({ setCurrentRoute }) {
  const {
    counters,
    tokens,
    waitingTokens,
    servingTokens,
    openCounters,
    services,
    soundEnabled,
    setSoundEnabled,
    broadcastCall,
    lastAnnouncement,
  } = useQueue();

  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Digital clock update every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.warn(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  // Sort waiting tokens by Priority + FIFO
  const sortedWaitingTokens = [...waitingTokens].sort(compareTokens);

  return (
    <div
      className={`min-h-screen transition-colors duration-300 flex flex-col justify-between ${
        isDarkMode ? 'bg-[#070D19] text-white' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Top TV Screen Bar */}
      <div
        className={`px-6 py-4 border-b flex flex-col md:flex-row md:items-center justify-between gap-4 ${
          isDarkMode
            ? 'bg-slate-950/80 border-slate-800'
            : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        {/* Left: Facility Title & Live Indicator */}
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-teal-500 text-white flex items-center justify-center font-bold shadow-md shadow-teal-500/20">
            <Tv className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight">QueueSmart AI</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30 font-semibold">
                LOBBY TV DISPLAY
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>
                {openCounters.length} Open Counters Active • Real-Time Dynamic Synchronization
              </span>
            </div>
          </div>
        </div>

        {/* Center / Right: Live Digital Clock & Kiosk Controls */}
        <div className="flex items-center gap-4 ml-auto">
          {/* Digital Clock */}
          <div
            className={`px-4 py-2 rounded-xl border font-mono text-center ${
              isDarkMode
                ? 'bg-slate-900 border-slate-800 text-teal-300'
                : 'bg-slate-50 border-slate-200 text-slate-900'
            }`}
          >
            <div className="text-xl sm:text-2xl font-black tracking-wider">
              {currentTime.toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              })}
            </div>
            <div className="text-[10px] uppercase tracking-widest text-slate-400 font-sans">
              {currentTime.toLocaleDateString([], {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
              })}
            </div>
          </div>

          {/* Audio Chime Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'Audio chime enabled' : 'Audio chime muted'}
            className={`p-2.5 rounded-xl border transition flex items-center gap-1.5 text-xs font-semibold ${
              soundEnabled
                ? 'bg-teal-500 text-slate-950 border-teal-400 shadow-md shadow-teal-500/20'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4" />
                <span className="hidden sm:inline">Chime ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4" />
                <span className="hidden sm:inline">Chime OFF</span>
              </>
            )}
          </button>

          {/* Light / Dark Mode Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            title="Toggle High-Contrast / Light Screen Theme"
            className={`p-2.5 rounded-xl border transition ${
              isDarkMode
                ? 'bg-slate-900 text-slate-300 border-slate-800 hover:text-white'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:text-slate-900'
            }`}
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            title="Toggle Kiosk Fullscreen Mode"
            className={`p-2.5 rounded-xl border transition ${
              isDarkMode
                ? 'bg-slate-900 text-slate-300 border-slate-800 hover:text-white'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:text-slate-900'
            }`}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Return to Admin */}
          <button
            onClick={() => setCurrentRoute('admin')}
            className="text-xs text-slate-400 hover:text-white px-2 py-1 font-medium transition"
          >
            Operator Desk &rarr;
          </button>
        </div>
      </div>

      {/* Main Screen Body: Counters Grid + Up Next Panel */}
      <div className="flex-1 p-6 max-w-[1700px] w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: 6 Service Counters (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-teal-400 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" />
              <span>Service Counters • Live Status</span>
            </h2>
            <span className="text-xs text-slate-400">
              {openCounters.length} Open ({counters.filter((c) => c.currentToken).length} Serving)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {counters.map((c) => {
              const activeTok = tokens.find(
                (t) => t.tokenNumber === c.currentToken && t.status === TOKEN_STATUS.SERVING
              );
              const isServing = Boolean(activeTok);
              const isOpen = c.isOpen;
              const primaryService = services.find((s) => c.services.includes(s.id));

              return (
                <div
                  key={c.id}
                  className={`rounded-2xl p-5 border transition-all relative overflow-hidden flex flex-col justify-between min-h-[220px] ${
                    !isOpen
                      ? 'bg-slate-950/40 border-slate-900 opacity-60'
                      : isServing
                      ? isDarkMode
                        ? 'bg-slate-900/95 border-teal-500/40 ring-2 ring-teal-500/20 shadow-xl'
                        : 'bg-white border-teal-300 shadow-md ring-2 ring-teal-400/20'
                      : isDarkMode
                      ? 'bg-slate-950/70 border-slate-800/80'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  {/* Top Counter Header */}
                  <div className={`flex items-center justify-between pb-3 border-b mb-3 ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
                    <span className={`font-mono text-base font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                      COUNTER 0{c.number}
                    </span>

                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider font-mono ${
                        !isOpen
                          ? isDarkMode ? 'bg-slate-800 text-slate-400 border border-slate-700' : 'bg-slate-200 text-slate-600 border border-slate-300'
                          : isServing
                          ? 'bg-teal-500 text-slate-950 font-extrabold animate-pulse'
                          : isDarkMode ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}
                    >
                      {!isOpen ? 'CLOSED' : isServing ? 'SERVING' : 'AVAILABLE'}
                    </span>
                  </div>

                  {/* Token Number Display */}
                  <div className="py-2 text-center my-auto">
                    {!isOpen ? (
                      <div className="py-4">
                        <PowerOff className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                        <div className={`text-sm font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>COUNTER CLOSED</div>
                        <div className="text-[11px] text-slate-400">Desk not currently active</div>
                      </div>
                    ) : activeTok ? (
                      <>
                        <div className="text-xs uppercase text-teal-500 font-bold mb-1 tracking-wider">
                          Ticket Serving
                        </div>
                        <div
                          className={`text-5xl sm:text-6xl font-black font-mono tracking-tight leading-none ${
                            isDarkMode ? 'text-white' : 'text-slate-900'
                          }`}
                        >
                          {activeTok.tokenNumber}
                        </div>
                        <div className={`text-xs font-mono font-medium mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          Privacy Protected • {activeTok.name.split(' ')[0][0]}. {activeTok.name.split(' ').slice(-1)[0][0]}***
                        </div>
                      </>
                    ) : (
                      <div className="py-5">
                        <div className="text-2xl font-black text-emerald-500 tracking-wide font-mono">
                          READY
                        </div>
                        <div className={`text-xs mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Available for next visitor</div>
                      </div>
                    )}
                  </div>

                  {/* Footer: Operator & Service */}
                  <div className={`pt-3 border-t text-xs flex items-center justify-between ${isDarkMode ? 'border-slate-800/60 text-slate-400' : 'border-slate-200 text-slate-600'}`}>
                    <span className="truncate max-w-[130px] font-medium">
                      {isOpen ? c.operator : 'Offline'}
                    </span>
                    <span className={`text-[11px] font-mono truncate max-w-[110px] font-semibold ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`}>
                      {primaryService?.name.split(' ')[0]}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: Up Next in Queue Ticker (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-400" />
              <span>Next in Line (FIFO Priority)</span>
            </h2>
            <span className="text-xs font-mono text-teal-400">
              {waitingTokens.length} Waiting
            </span>
          </div>

          <div
            className={`rounded-2xl border p-4 shadow-xl ${
              isDarkMode
                ? 'bg-slate-900/80 border-slate-800'
                : 'bg-white border-slate-200'
            }`}
          >
            {sortedWaitingTokens.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                Queue is clear. No waiting visitors at this moment.
              </div>
            ) : (
              <div className="space-y-2.5">
                {sortedWaitingTokens.slice(0, 7).map((token, idx) => {
                  const svc = services.find((s) => s.id === token.serviceId);
                  return (
                    <div
                      key={token.id}
                      className={`flex items-center justify-between p-3 rounded-xl border transition ${
                        isDarkMode
                          ? 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center ${isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-200 text-slate-700'}`}>
                          {idx + 1}
                        </span>
                        <div>
                          <div className={`font-mono text-lg font-black leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                            {token.tokenNumber}
                          </div>
                          <div className={`text-[11px] truncate max-w-[130px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                            {svc?.name.split(' ')[0]}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <PriorityBadge priority={token.priority} size="sm" />
                        <div className="text-xs font-mono text-teal-400 font-bold mt-1">
                          ~{token.estimatedWaitMin || 4}m{' '}
                          <span className="text-[10px] text-slate-500 font-normal">est</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {sortedWaitingTokens.length > 7 && (
              <div className="text-center pt-3 text-xs text-slate-400 font-medium">
                + {sortedWaitingTokens.length - 7} more visitors waiting in queue
              </div>
            )}

            <div className="mt-3 pt-3 border-t border-slate-800/80 text-[10px] text-slate-400 flex items-center gap-1.5">
              <Info className="w-3 h-3 text-teal-400 shrink-0" />
              <span>Estimates dynamically adapt as counters open or close. Not guaranteed times.</span>
            </div>
          </div>

          {/* Sound Announcement Test */}
          <div
            className={`p-4 rounded-xl border text-xs flex items-center justify-between ${
              isDarkMode
                ? 'bg-slate-950 border-slate-800 text-slate-300'
                : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <div>
              <span className="font-semibold block text-white">Audio Announcement Alert</span>
              <span className="text-[11px] text-slate-400">
                Last alert: {lastAnnouncement.tokenNumber} &rarr; Counter {lastAnnouncement.counterNumber}
              </span>
            </div>
            <button
              onClick={() => broadcastCall('TEST', 1, 'Counter 01')}
              className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 transition"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Test Chime</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Ticker Notice Banner */}
      <div
        className={`px-6 py-3 border-t text-xs flex items-center justify-between gap-4 overflow-hidden ${
          isDarkMode
            ? 'bg-slate-950 border-slate-800 text-slate-300'
            : 'bg-white border-slate-200 text-slate-700'
        }`}
      >
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-ping" />
          <span className="font-bold uppercase tracking-wider text-teal-400">
            Lobby Notices:
          </span>
        </div>

        <div className="overflow-hidden whitespace-nowrap flex-1 text-slate-300">
          <div className="inline-block animate-marquee font-medium">
            Please have your ID card, SMS confirmation, or booking reference ready when your ticket number is called. • High-speed Guest Wi-Fi: <strong>QueueSmart-Guest</strong> • Priority Assistance available at Counter 01 & Counter 06 • Delay your turn anytime via your mobile ticket pass.
          </div>
        </div>

        <div className="shrink-0 text-slate-400 font-mono text-[11px] hidden sm:block">
          AI ENGINE v2.4 • ONLINE
        </div>
      </div>
    </div>
  );
}
