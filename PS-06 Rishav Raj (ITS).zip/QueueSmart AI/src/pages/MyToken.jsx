import React, { useState, useEffect } from 'react';
import { useQueue } from '../context/QueueContext';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import { QRCodeDisplay } from '../components/QRCodeDisplay';
import {
  Ticket,
  Clock,
  Volume2,
  AlertTriangle,
  QrCode,
  ArrowRight,
  Sparkles,
  Printer,
  XCircle,
  HelpCircle,
  CheckCircle2,
  Users,
  Coffee,
  BellRing,
  UserCheck,
  Building,
  Bell,
  Zap,
  X,
  Copy,
  Check,
} from 'lucide-react';

export function MyToken({ setCurrentRoute }) {
  const {
    tokens,
    myToken,
    setMyTokenId,
    services,
    counters,
    delayTurn,
    cancelToken,
    broadcastCall,
    visitorNotifications,
    unreadVisitorNotificationCount,
    dismissVisitorNotification,
    markVisitorNotificationRead,
    clearAllVisitorNotifications,
  } = useQueue();

  const [showNotificationDrawer, setShowNotificationDrawer] = useState(false);
  const [copied, setCopied] = useState(false);

  // Simulated countdown seconds for immersion
  const [secondsRemaining, setSecondsRemaining] = useState(180);

  const handleCopyToken = () => {
    if (!myToken?.tokenNumber) return;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(myToken.tokenNumber);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    if (!myToken || myToken.status !== 'waiting') return;
    const initialSeconds = (myToken.estimatedWaitMin || 4) * 60;
    setSecondsRemaining(initialSeconds);

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => (prev > 1 ? prev - 1 : 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [myToken?.id, myToken?.estimatedWaitMin, myToken?.status]);

  if (!myToken) {
    return (
      <div className="min-h-[75vh] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mb-4">
          <Ticket className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-800 mb-2">No Active Token Found</h2>
        <p className="text-sm text-slate-500 max-w-sm mb-6">
          You don't have an active queue ticket yet. Join the queue to get an instant smart pass.
        </p>
        <button
          onClick={() => setCurrentRoute('register')}
          className="bg-teal-500 text-white font-bold px-6 py-3 rounded-xl hover:bg-teal-400 transition"
        >
          Get a New Token
        </button>
      </div>
    );
  }

  const tokenService = services.find((s) => s.id === myToken.serviceId) || services[0];
  const assignedCounter = counters.find((c) => c.id === myToken.counterId || c.number === myToken.counterNumber);

  // Minutes & seconds formatted
  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeFormatted = `${mins}:${secs < 10 ? '0' : ''}${secs}`;

  const statusUpper = (myToken.status || '').toUpperCase();
  const isCalling = statusUpper === 'CALLING';
  const isServing = statusUpper === 'SERVING' || isCalling;
  const isWaiting = statusUpper === 'WAITING';
  const isDone = statusUpper === 'COMPLETED';
  const isSkipped = statusUpper === 'SKIPPED';

  // People ahead is calculated dynamically in QueueContext using Priority + FIFO
  const peopleAhead = isWaiting ? (myToken.peopleAhead ?? 0) : 0;

  // Identify currently serving token for this service desk (or fallback to any active counter)
  const sameServiceServing = tokens.filter(
    (t) => (t.status || '').toUpperCase() === 'SERVING' && t.serviceId === myToken.serviceId
  );
  const anyServing = tokens.filter((t) => (t.status || '').toUpperCase() === 'SERVING');
  const activeServingToken = sameServiceServing[0] || anyServing[0];
  const servingCounter = activeServingToken
    ? counters.find((c) => c.id === activeServingToken.counterId || c.number === activeServingToken.counterNumber)
    : null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-6">
      {/* Top Bar with Demo Token Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            <span>Live Digital Boarding Pass</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Queue Token
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* In-App Notification Bell Button */}
          <button
            onClick={() => setShowNotificationDrawer(!showNotificationDrawer)}
            className="relative px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-50 shadow-sm transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
            title="View simulated in-app visitor notifications"
          >
            <Bell className="w-4 h-4 text-teal-600" />
            <span>Alerts</span>
            {unreadVisitorNotificationCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-mono font-bold flex items-center justify-center animate-pulse">
                {unreadVisitorNotificationCount}
              </span>
            )}
          </button>

          {/* Demo Token Switcher */}
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm text-xs">
            <span className="text-slate-500 font-medium">Switch:</span>
            <select
              value={myToken.id}
              onChange={(e) => setMyTokenId(e.target.value)}
              className="font-mono font-bold text-slate-800 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:border-teal-500"
            >
              {tokens.slice(0, 12).map((t) => (
                <option key={t.id} value={t.id}>
                  {t.tokenNumber} - {t.name} ({t.status})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* REAL-TIME IN-APP NOTIFICATION BANNER (Triggered on Approaching Turn, Called, or Wait Time Changes) */}
      {visitorNotifications.length > 0 && visitorNotifications[0] && !visitorNotifications[0].read && (
        <div
          className={`p-4 rounded-2xl border shadow-md flex items-start justify-between gap-3 transition-all ${
            visitorNotifications[0].type === 'called'
              ? 'bg-teal-600 text-white border-teal-400 shadow-teal-500/20'
              : visitorNotifications[0].type === 'approaching'
              ? 'bg-amber-500 text-white border-amber-400 shadow-amber-500/20'
              : 'bg-indigo-600 text-white border-indigo-500 shadow-indigo-600/20'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shrink-0 mt-0.5">
              {visitorNotifications[0].type === 'called' ? (
                <BellRing className="w-5 h-5 animate-bounce" />
              ) : visitorNotifications[0].type === 'approaching' ? (
                <Zap className="w-5 h-5 animate-pulse" />
              ) : (
                <Clock className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-white/90">
                {visitorNotifications[0].title}
              </div>
              <p className="text-sm font-semibold text-white mt-0.5">
                {visitorNotifications[0].message}
              </p>
              <span className="text-[10px] text-white/70 font-mono mt-1 block">
                {visitorNotifications[0].timestamp} • Simulated In-App Visitor Notification
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => markVisitorNotificationRead(visitorNotifications[0].id)}
              className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white transition text-xs font-bold px-2.5 cursor-pointer"
            >
              Acknowledge
            </button>
            <button
              onClick={() => dismissVisitorNotification(visitorNotifications[0].id)}
              className="p-1 rounded-lg text-white/80 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* EXPANDABLE IN-APP NOTIFICATION DRAWER / CENTER */}
      {showNotificationDrawer && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-sm text-slate-900">
                Visitor Notifications & Milestone Alerts ({visitorNotifications.length})
              </h3>
            </div>
            <div className="flex items-center gap-2">
              {visitorNotifications.length > 0 && (
                <>
                  <button
                    onClick={() => visitorNotifications.forEach((n) => markVisitorNotificationRead(n.id))}
                    className="text-xs text-slate-500 hover:text-teal-600 font-medium cursor-pointer"
                  >
                    Mark All Read
                  </button>
                  <span className="text-slate-300">•</span>
                  <button
                    onClick={clearAllVisitorNotifications}
                    className="text-xs text-rose-500 hover:text-rose-700 font-medium cursor-pointer"
                  >
                    Clear All
                  </button>
                </>
              )}
              <button
                onClick={() => setShowNotificationDrawer(false)}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {visitorNotifications.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No notifications yet. You will be alerted when you approach your turn, when called, or if your wait time changes significantly.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {visitorNotifications.map((n) => (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl border flex items-start justify-between gap-3 transition ${
                    !n.read
                      ? 'bg-teal-50/70 border-teal-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <span
                      className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                        !n.read ? 'bg-teal-500 ring-4 ring-teal-200' : 'bg-slate-300'
                      }`}
                    />
                    <div>
                      <div className="text-xs font-bold text-slate-900">{n.title}</div>
                      <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                      <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                        {n.timestamp}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => dismissVisitorNotification(n.id)}
                    className="p-1 text-slate-400 hover:text-slate-600 shrink-0 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* CALLING NOW ALERT BANNER */}
      {isCalling && (
        <div className="p-5 rounded-2xl bg-teal-500 text-white shadow-xl shadow-teal-500/20 border-2 border-teal-300 animate-pulse flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-white text-teal-600 flex items-center justify-center shrink-0">
              <BellRing className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-teal-100">
                You Are Being Called!
              </div>
              <div className="text-xl sm:text-2xl font-black">
                Please proceed to Counter 0{myToken.counterNumber || 3} immediately
              </div>
            </div>
          </div>
          <button
            onClick={() =>
              broadcastCall(
                myToken.tokenNumber,
                myToken.counterNumber || 3,
                `Counter ${myToken.counterNumber || 3}`
              )
            }
            className="bg-slate-950 text-white hover:bg-slate-900 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shrink-0"
          >
            <Volume2 className="w-4 h-4 text-teal-400" />
            <span>Replay Audio Chime</span>
          </button>
        </div>
      )}

      {/* 4 CORE METRICS DISPLAY (Status, People Ahead, Wait Time, Currently Serving) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* 1. Token Status */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Token Status
          </span>
          <div className="my-2">
            <StatusBadge status={myToken.status} size="md" />
          </div>
          <span className="text-[11px] text-slate-500">
            {isWaiting && 'Registered in queue'}
            {isCalling && 'Proceed to counter'}
            {isServing && 'In session with agent'}
            {isDone && 'Service finished'}
          </span>
        </div>

        {/* 2. People Ahead */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            People Ahead
          </span>
          <div className="my-1">
            <div className="text-3xl font-black font-mono text-slate-900">
              {isWaiting ? peopleAhead : 0}
            </div>
          </div>
          <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-teal-600" />
            {isWaiting
              ? peopleAhead === 0
                ? "You're next in line!"
                : `${peopleAhead} ahead in line`
              : 'Direct counter turn'}
          </span>
        </div>

        {/* 3. Estimated Waiting Time */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Est. Waiting Time
          </span>
          <div className="my-1">
            <div className="text-3xl font-black font-mono text-teal-600">
              {isWaiting ? `~${myToken.estimatedWaitMin || 4}m` : '0m'}
            </div>
          </div>
          <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-teal-600" />
            {isWaiting ? `Countdown: ${timeFormatted}` : 'Now active'}
          </span>
        </div>

        {/* 4. Currently Serving Token */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Currently Serving
          </span>
          <div className="my-1">
            {activeServingToken ? (
              <div className="text-2xl font-black font-mono text-slate-900 flex items-center gap-1.5">
                <span>{activeServingToken.tokenNumber}</span>
                <span className="text-xs font-mono font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                  C-0{activeServingToken.counterNumber || 2}
                </span>
              </div>
            ) : (
              <div className="text-xl font-bold text-slate-400 font-mono">None (Idle)</div>
            )}
          </div>
          <span className="text-[11px] text-slate-500 truncate">
            {servingCounter ? `${servingCounter.operator}` : 'Across all counters'}
          </span>
        </div>
      </div>

      {/* Estimate Disclaimer Banner */}
      <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
        <HelpCircle className="w-4 h-4 text-slate-400 shrink-0" />
        <span>
          <strong>Estimate Notice:</strong> Waiting times are dynamic mathematical calculations based on eligible people ahead, average duration, and active open counters — estimates are not guaranteed appointment times.
        </span>
      </div>

      {/* MAIN DIGITAL TICKET PASS */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden relative">
        {/* Ticket Header */}
        <div className="bg-slate-900 text-white p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 rounded-lg bg-teal-500 flex items-center justify-center text-white">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-white text-base">QueueSmart AI</span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                PASS #{myToken.id.slice(-6)}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Smart Virtual Boarding Pass • Issued:{' '}
              {new Date(myToken.joinedAt).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-teal-300 text-[11px] font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
              <span>Neural Telemetry Synced</span>
            </div>
            <PriorityBadge priority={myToken.priority} size="md" />
            <StatusBadge status={myToken.status} size="lg" />
          </div>
        </div>

        {/* Ticket Core Content */}
        <div className="p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Big Token Number & Visitor Details */}
            <div className="md:col-span-7 space-y-6">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                    Your Virtual Token Number
                  </span>
                  <button
                    onClick={handleCopyToken}
                    className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                    title="Copy Token Number to Clipboard"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-teal-600" />
                        <span className="text-teal-700 font-bold">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Copy #</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="text-5xl sm:text-7xl font-black font-mono tracking-tight text-slate-900">
                  {myToken.tokenNumber}
                </div>
                <div className="text-lg font-bold text-slate-800 mt-1">
                  {myToken.name}
                </div>
                <div className="text-xs text-slate-500">
                  {myToken.phone} {myToken.email && `• ${myToken.email}`}
                </div>
              </div>

              {/* Service & Desk info */}
              <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-400 block font-medium">Service Desk</span>
                  <span className="font-bold text-slate-800 text-sm">{tokenService.name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Assigned Location</span>
                  <span className="font-bold text-slate-800 text-sm">
                    {assignedCounter
                      ? `${assignedCounter.name} (${assignedCounter.operator})`
                      : `Counters ${tokenService.activeCounters.join(' / ')}`}
                  </span>
                </div>
              </div>

              {/* AI Status Insight Box */}
              <div className="p-4 rounded-xl bg-teal-50/70 border border-teal-200 text-xs text-teal-900 flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-teal-950">AI Dynamic Queue Forecast:</span>
                  <p className="text-teal-800/90 leading-relaxed mt-0.5">
                    {myToken.aiNote}
                  </p>
                </div>
              </div>
            </div>

            {/* Right Side: QR Code & Large Countdown */}
            <div className="md:col-span-5 bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 text-center flex flex-col justify-between space-y-6">
              {isWaiting && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">
                    Live Countdown Clock
                  </div>
                  <div className="text-4xl font-extrabold font-mono text-teal-300">
                    ~{timeFormatted}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Position in line: <strong className="text-white text-sm font-mono">#{peopleAhead + 1}</strong>
                  </div>
                </div>
              )}

              {(isCalling || isServing) && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-teal-400 font-semibold mb-1">
                    Currently Assigned To
                  </div>
                  <div className="text-3xl font-extrabold text-white">
                    Counter 0{myToken.counterNumber || 3}
                  </div>
                  <div className="text-xs text-slate-300 mt-1">
                    Operator: {assignedCounter?.operator || 'Desk Officer'}
                  </div>
                </div>
              )}

              {isDone && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-emerald-400 font-semibold mb-1">
                    Service Finished
                  </div>
                  <div className="text-2xl font-bold text-white">Visit Completed</div>
                  <div className="text-xs text-slate-400 mt-1">
                    Thank you for using QueueSmart AI!
                  </div>
                </div>
              )}

              {isSkipped && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-rose-400 font-semibold mb-1">
                    Pass Status
                  </div>
                  <div className="text-2xl font-bold text-white">Ticket Skipped</div>
                  <div className="text-xs text-slate-400 mt-1">
                    Marked No-Show or cancelled. Please check in again if needed.
                  </div>
                </div>
              )}

              {/* Real Scannable Dynamic QR Code */}
              <QRCodeDisplay
                tokenNumber={myToken.tokenNumber}
                tokenId={myToken.id}
                size={135}
              />
            </div>
          </div>

          {/* Stepper Progress Bar */}
          <div className="mt-8 pt-8 border-t border-slate-200">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
              Queue Milestone Progress
            </div>

            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="space-y-1.5">
                <div className="h-2 rounded-full bg-teal-500" />
                <span className="font-bold text-slate-800 block text-[11px]">1. Registered</span>
                <span className="text-[10px] text-slate-400">Pass Issued</span>
              </div>

              <div className="space-y-1.5">
                <div
                  className={`h-2 rounded-full ${
                    isCalling || isServing || isDone
                      ? 'bg-teal-500'
                      : isWaiting
                      ? 'bg-amber-400 animate-pulse'
                      : 'bg-slate-200'
                  }`}
                />
                <span className="font-bold text-slate-800 block text-[11px]">2. In Line</span>
                <span className="text-[10px] text-slate-400">
                  {isWaiting ? `${peopleAhead} ahead` : 'Cleared'}
                </span>
              </div>

              <div className="space-y-1.5">
                <div
                  className={`h-2 rounded-full ${
                    isDone
                      ? 'bg-teal-500'
                      : isCalling || isServing
                      ? 'bg-teal-500 animate-pulse'
                      : 'bg-slate-200'
                  }`}
                />
                <span className="font-bold text-slate-800 block text-[11px]">3. At Counter</span>
                <span className="text-[10px] text-slate-400">
                  {myToken.counterNumber ? `Counter ${myToken.counterNumber}` : 'Pending'}
                </span>
              </div>

              <div className="space-y-1.5">
                <div
                  className={`h-2 rounded-full ${isDone ? 'bg-teal-500' : 'bg-slate-200'}`}
                />
                <span className="font-bold text-slate-800 block text-[11px]">4. Completed</span>
                <span className="text-[10px] text-slate-400">
                  {isDone ? 'Done' : 'Final Step'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="bg-slate-50 border-t border-slate-200 p-4 sm:p-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {isWaiting && (
              <button
                onClick={() => delayTurn(myToken.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition shadow-sm cursor-pointer"
              >
                <Coffee className="w-3.5 h-3.5 text-amber-600" />
                <span>Need 5 Mins (Delay Turn)</span>
              </button>
            )}

            <button
              onClick={handleCopyToken}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition shadow-sm cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-teal-600" />
                  <span className="text-teal-700 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>Copy Token</span>
                </>
              )}
            </button>

            <button
              onClick={() => broadcastCall(myToken.tokenNumber, myToken.counterNumber || 1, 'Counter')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition shadow-sm cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-teal-600" />
              <span>Test Audio Ring</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition shadow-sm cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print Pass</span>
            </button>
          </div>

          <div>
            {isWaiting && (
              <button
                onClick={() => {
                  if (confirm('Are you sure you want to cancel your queue ticket?')) {
                    cancelToken(myToken.id);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-rose-600 hover:bg-rose-50 transition"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Cancel My Ticket</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
