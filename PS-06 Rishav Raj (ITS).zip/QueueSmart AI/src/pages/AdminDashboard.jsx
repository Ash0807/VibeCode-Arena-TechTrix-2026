import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import { QueueIntelligencePanel } from '../components/QueueIntelligencePanel';
import { TOKEN_STATUS } from '../data/mockData';
import {
  Users,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Volume2,
  ArrowRight,
  Plus,
  Search,
  Filter,
  UserCheck,
  XCircle,
  ArrowRightLeft,
  Tv,
  Power,
  PowerOff,
  Cpu,
  Layers,
  Ban,
  Building,
  Info,
} from 'lucide-react';

export function AdminDashboard({ setCurrentRoute }) {
  const {
    counters,
    tokens,
    waitingTokens,
    servingTokens,
    completedTokens,
    skippedTokens,
    openCounters,
    closedCounters,
    services,
    callNext,
    completeService,
    skipToken,
    toggleCounterStatus,
    transferToken,
    bumpPriority,
    cancelToken,
    registerToken,
    broadcastCall,
    dynamicAvgWaitMin,
    analytics,
    showToast,
  } = useQueue();

  // Active selected counter for operator workstation
  const [selectedCounterId, setSelectedCounterId] = useState('c1');

  // Queue table filters: 'all' | 'WAITING' | 'SERVING' | 'COMPLETED' | 'SKIPPED'
  const [statusFilter, setStatusFilter] = useState('all');
  const [serviceFilter, setServiceFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [transferringToken, setTransferringToken] = useState(null);
  const [targetTransferService, setTargetTransferService] = useState('general');

  // Quick add form state
  const [quickAdd, setQuickAdd] = useState({
    name: '',
    phone: '',
    serviceId: 'general',
    priority: 'standard',
  });

  const activeCounter = counters.find((c) => c.id === selectedCounterId) || counters[0];
  const activeCounterToken = tokens.find(
    (t) => t.tokenNumber === activeCounter.currentToken && t.status === TOKEN_STATUS.SERVING
  );

  // Filtered queue tokens
  const filteredTokens = tokens.filter((t) => {
    // Status filter
    if (statusFilter !== 'all') {
      if (t.status !== statusFilter) return false;
    }

    // Service filter
    if (serviceFilter !== 'all' && t.serviceId !== serviceFilter) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNum = t.tokenNumber.toLowerCase().includes(q);
      const matchName = t.name.toLowerCase().includes(q);
      const matchPhone = t.phone.toLowerCase().includes(q);
      if (!matchNum && !matchName && !matchPhone) return false;
    }

    return true;
  });

  const handleQuickAddSubmit = (e) => {
    e.preventDefault();
    if (!quickAdd.name.trim()) return;
    registerToken({
      name: quickAdd.name,
      phone: quickAdd.phone || '',
      serviceId: quickAdd.serviceId,
      priority: quickAdd.priority,
    });
    setQuickAdd({ name: '', phone: '', serviceId: 'general', priority: 'standard' });
    setShowAddModal(false);
  };

  const handleTransferSubmit = () => {
    if (!transferringToken) return;
    transferToken(transferringToken.id, targetTransferService, 'Operator desk reassignment');
    setTransferringToken(null);
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      {/* Page Title & Top Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-teal-400 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Queue Dispatch Center</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Operator & Admin Console
          </h1>
          <p className="text-slate-600 text-sm mt-0.5">
            Real-time counter orchestration, FIFO priority dispatching, and queue velocity analytics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-sm transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Walk-In Visitor</span>
          </button>

          <button
            onClick={() => setCurrentRoute('display')}
            className="bg-slate-900 hover:bg-slate-800 text-white font-semibold px-4 py-2.5 rounded-xl text-xs border border-slate-700 transition flex items-center gap-1.5"
          >
            <Tv className="w-4 h-4 text-teal-400" />
            <span>Open Public Display</span>
          </button>
        </div>
      </div>

      {/* KPI Stat Cards (Dynamic Sync) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Waiting */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Waiting in Queue
            </span>
            <div className="text-3xl font-extrabold text-slate-900 mt-1 font-mono">
              {waitingTokens.length}
            </div>
            <div className="text-xs text-amber-700 font-medium mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-600" />
              <span>FIFO Priority Roster</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Serving */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Currently Serving
            </span>
            <div className="text-3xl font-extrabold text-teal-600 mt-1 font-mono">
              {servingTokens.length}
            </div>
            <div className="text-xs text-slate-500 font-medium mt-1">
              Active sessions at desks
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <UserCheck className="w-6 h-6" />
          </div>
        </div>

        {/* Dynamic Avg Wait */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Mean Dynamic Wait
            </span>
            <div className="text-3xl font-extrabold text-slate-900 mt-1 font-mono">
              ~{dynamicAvgWaitMin}m
            </div>
            <div className="text-xs text-slate-500 font-medium mt-1">
              Estimate based on active counters
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Open Counters */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Open Counters
            </span>
            <div className="text-3xl font-extrabold text-slate-900 mt-1 font-mono">
              {openCounters.length} / {counters.length}
            </div>
            <div className="text-xs text-slate-500 font-medium mt-1">
              {closedCounters.length > 0 ? `${closedCounters.length} closed` : 'All counters open'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Power className="w-6 h-6" />
          </div>
        </div>

        {/* Completed Today */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Completed / Skipped
            </span>
            <div className="text-2xl font-extrabold text-slate-900 mt-1 font-mono">
              {completedTokens.length} <span className="text-xs text-slate-400 font-normal">/ {skippedTokens.length}</span>
            </div>
            <div className="text-xs text-slate-500 font-medium mt-1">
              Throughput today
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* EXPLAINABLE QUEUE INTELLIGENCE & WHAT-IF SIMULATOR */}
      <QueueIntelligencePanel />

      {/* OPERATOR WORKSTATION (Counter Control Console) */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span>Counter Operator Station</span>
              <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full font-mono font-semibold">
                Station Active
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Control desk operations: call next waiting visitor, complete session, skip, or toggle counter open/closed.
            </p>
          </div>

          {/* Counter Switcher Tabs */}
          <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1.5 rounded-2xl">
            {counters.map((c) => {
              const isSelected = c.id === selectedCounterId;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCounterId(c.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${c.isOpen ? (c.currentToken ? 'bg-teal-500' : 'bg-emerald-400') : 'bg-slate-400'}`} />
                  <span>C-0{c.number}</span>
                  {!c.isOpen && <span className="text-[10px] text-slate-400 font-normal">(Off)</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Counter Control Box */}
        <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Counter details & Open/Close Toggle */}
            <div className="lg:col-span-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono text-2xl font-black text-slate-900 block">
                    {activeCounter.name}
                  </span>
                  <span className="text-xs text-slate-500">
                    Operator: <strong className="text-slate-900">{activeCounter.operator}</strong>
                  </span>
                </div>

                {/* Counter Open / Close Toggle Button */}
                <button
                  onClick={() => toggleCounterStatus(activeCounter.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm ${
                    activeCounter.isOpen
                      ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border border-emerald-300'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-700 border border-slate-300'
                  }`}
                  title={activeCounter.isOpen ? 'Click to close counter' : 'Click to open counter'}
                >
                  {activeCounter.isOpen ? (
                    <>
                      <Power className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Counter OPEN</span>
                    </>
                  ) : (
                    <>
                      <PowerOff className="w-3.5 h-3.5 text-slate-500" />
                      <span>Counter CLOSED</span>
                    </>
                  )}
                </button>
              </div>

              <div className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-200">
                <div>
                  Assigned Services:{' '}
                  <span className="font-semibold text-slate-900">
                    {activeCounter.services
                      .map((sid) => services.find((s) => s.id === sid)?.name)
                      .join(', ')}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-slate-500 font-mono text-[11px]">
                  <span>Served: <strong className="text-slate-900">{activeCounter.servedToday}</strong></span>
                  <span>Skipped: <strong className="text-slate-900">{activeCounter.skippedToday || 0}</strong></span>
                  <span>Avg Velocity: {activeCounter.avgServiceTime}</span>
                </div>
              </div>

              {!activeCounter.isOpen && (
                <div className="p-3 rounded-xl bg-slate-200/80 border border-slate-300 text-xs text-slate-700 flex items-center gap-2">
                  <PowerOff className="w-4 h-4 text-slate-500 shrink-0" />
                  <span>This counter is closed and excluded from queue wait-time calculations.</span>
                </div>
              )}
            </div>

            {/* Current Active Token Workstation */}
            <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Currently Serving at Desk
                </span>
                {activeCounterToken && <StatusBadge status={activeCounterToken.status} size="sm" />}
              </div>

              {activeCounterToken ? (
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-4xl sm:text-5xl font-black font-mono text-slate-900 tracking-tight">
                        {activeCounterToken.tokenNumber}
                      </div>
                      <div className="text-base font-bold text-slate-800 mt-1">
                        {activeCounterToken.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        {activeCounterToken.phone}
                      </div>
                    </div>
                    <PriorityBadge priority={activeCounterToken.priority} size="md" />
                  </div>

                  {activeCounterToken.notes && (
                    <div className="p-2.5 rounded-lg bg-slate-50 text-xs text-slate-600 border border-slate-100">
                      <strong>Visitor Request:</strong> {activeCounterToken.notes}
                    </div>
                  )}

                  {/* Actions for current serving token */}
                  <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => broadcastCall(activeCounterToken.tokenNumber, activeCounter.number, activeCounter.name)}
                      className="min-h-[44px] bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 border border-teal-200 transition cursor-pointer active:scale-95"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-teal-600" />
                      <span>Re-Chime Alert</span>
                    </button>

                    <button
                      onClick={() => completeService(activeCounter.id)}
                      className="min-h-[44px] bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                      <span>Complete Service</span>
                    </button>

                    <button
                      onClick={() => setTransferringToken(activeCounterToken)}
                      className="min-h-[44px] bg-white hover:bg-slate-50 text-slate-700 font-semibold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 border border-slate-200 transition cursor-pointer active:scale-95"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                      <span>Transfer Desk</span>
                    </button>

                    <button
                      onClick={() => skipToken(activeCounter.id, 'Visitor No-Show')}
                      className="min-h-[44px] text-rose-600 hover:bg-rose-50 font-semibold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition ml-auto cursor-pointer active:scale-95"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Skip Token</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="py-6 text-center space-y-4">
                  <p className="text-sm text-slate-500">
                    {activeCounter.isOpen
                      ? `Counter 0${activeCounter.number} is OPEN and Available for the next visitor.`
                      : `Counter 0${activeCounter.number} is currently CLOSED.`}
                  </p>

                  <button
                    onClick={() => callNext(activeCounter.id)}
                    disabled={!activeCounter.isOpen}
                    className="min-h-[48px] bg-teal-500 hover:bg-teal-400 text-slate-950 font-black px-6 py-3.5 rounded-xl text-sm shadow-md transition flex items-center gap-2 mx-auto disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>Call Next (FIFO Priority)</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* REAL-TIME QUEUE MANAGEMENT TABLE */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Live Queue Roster ({filteredTokens.length})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict FIFO ordering within priority levels. Estimates dynamically adapt as counters open/close.
            </p>
          </div>

          {/* Filters & Search */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search token, name, phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:border-teal-500 w-48 sm:w-56"
              />
            </div>

            {/* Status Filter Tabs */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:border-teal-500 font-semibold text-slate-700"
            >
              <option value="all">All Statuses</option>
              <option value={TOKEN_STATUS.WAITING}>WAITING ({waitingTokens.length})</option>
              <option value={TOKEN_STATUS.SERVING}>SERVING ({servingTokens.length})</option>
              <option value={TOKEN_STATUS.COMPLETED}>COMPLETED ({completedTokens.length})</option>
              <option value={TOKEN_STATUS.SKIPPED}>SKIPPED ({skippedTokens.length})</option>
            </select>

            {/* Service Desk Filter */}
            <select
              value={serviceFilter}
              onChange={(e) => setServiceFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:border-teal-500 font-medium"
            >
              <option value="all">All Service Desks</option>
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Disclaimer Note */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
          <Info className="w-4 h-4 text-slate-400 shrink-0" />
          <span>
            Wait times are mathematical estimates based on eligible people ahead, average duration, and active open counters — not guaranteed appointment commitments.
          </span>
        </div>

        {/* Responsive Mobile Queue Cards (Viewports < md) */}
        <div className="block md:hidden space-y-3">
          {filteredTokens.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No tokens found matching the selected filters.
            </div>
          ) : (
            filteredTokens.map((t) => {
              const svc = services.find((s) => s.id === t.serviceId) || services[0];
              return (
                <div key={t.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="font-mono font-bold text-lg text-slate-900 tracking-tight">
                      {t.tokenNumber}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <PriorityBadge priority={t.priority} size="sm" />
                      <StatusBadge status={t.status} size="sm" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Visitor</span>
                      <div className="font-semibold text-slate-800 truncate">{t.name}</div>
                      <div className="text-[11px] text-slate-400">{t.phone || 'Walk-in'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Service</span>
                      <div className="font-medium text-slate-700 truncate">{svc.name}</div>
                      <div className="text-[11px] font-mono text-teal-700 font-semibold mt-0.5">
                        {t.status === TOKEN_STATUS.WAITING ? (
                          `~${t.estimatedWaitMin || 4}m (${t.peopleAhead || 0} ahead)`
                        ) : t.counterNumber ? (
                          `Counter 0${t.counterNumber}`
                        ) : (
                          '—'
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center gap-2">
                    {t.status === TOKEN_STATUS.WAITING && (
                      <>
                        <button
                          onClick={() => {
                            if (!activeCounter.isOpen) {
                              showToast('Selected counter is closed. Please open it first.', 'warning');
                              return;
                            }
                            callNext(activeCounter.id);
                          }}
                          className="flex-1 min-h-[44px] px-3 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1 shadow-sm active:scale-95 transition cursor-pointer"
                        >
                          Call Now
                        </button>
                        <button
                          onClick={() => skipToken(t.id, 'Skipped by Operator')}
                          className="min-h-[44px] px-3 py-2 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold text-xs active:scale-95 transition border border-rose-200 cursor-pointer"
                        >
                          Skip
                        </button>
                        <button
                          onClick={() => bumpPriority(t.id, t.priority === 'senior' ? 'vip' : 'senior')}
                          className="min-h-[44px] px-3 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs active:scale-95 transition cursor-pointer"
                        >
                          Bump
                        </button>
                      </>
                    )}

                    {t.status === TOKEN_STATUS.SERVING && (
                      <>
                        <button
                          onClick={() => completeService(t.counterId || activeCounter.id)}
                          className="flex-1 min-h-[44px] px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-sm active:scale-95 transition cursor-pointer"
                        >
                          Complete Service
                        </button>
                        <button
                          onClick={() => skipToken(t.id, 'Marked No-Show')}
                          className="min-h-[44px] px-3 py-2 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold text-xs active:scale-95 transition border border-rose-200 cursor-pointer"
                        >
                          Skip
                        </button>
                      </>
                    )}

                    <button
                      onClick={() => setTransferringToken(t)}
                      className="min-h-[44px] px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs border border-slate-200 active:scale-95 transition cursor-pointer"
                    >
                      Transfer
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Desktop / Tablet Queue Table (hidden on mobile < md) */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-y border-slate-200 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4">Token #</th>
                <th className="py-3 px-4">Visitor</th>
                <th className="py-3 px-4">Desk Service</th>
                <th className="py-3 px-4">Priority (FIFO)</th>
                <th className="py-3 px-4">Est. Wait (Mins)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTokens.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No tokens found matching the selected filters.
                  </td>
                </tr>
              ) : (
                filteredTokens.map((t) => {
                  const svc = services.find((s) => s.id === t.serviceId) || services[0];
                  return (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-sm text-slate-900">
                        {t.tokenNumber}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-800">{t.name}</div>
                        <div className="text-[11px] text-slate-400">{t.phone}</div>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        {svc.name}
                      </td>

                      <td className="py-3.5 px-4">
                        <PriorityBadge priority={t.priority} size="sm" />
                      </td>

                      <td className="py-3.5 px-4 font-mono text-slate-700">
                        {t.status === TOKEN_STATUS.WAITING ? (
                          <span className="text-teal-700 font-semibold">
                            ~{t.estimatedWaitMin || 4}m{' '}
                            <span className="text-[10px] text-slate-400 font-normal">
                              ({t.peopleAhead || 0} ahead)
                            </span>
                          </span>
                        ) : t.counterNumber ? (
                          `Counter 0${t.counterNumber}`
                        ) : (
                          '—'
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <StatusBadge status={t.status} size="sm" />
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                        {t.status === TOKEN_STATUS.WAITING && (
                          <>
                            <button
                              onClick={() => {
                                if (!activeCounter.isOpen) {
                                  showToast('Selected counter is closed. Please open it first.', 'warning');
                                  return;
                                }
                                callNext(activeCounter.id);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold border border-teal-200 transition cursor-pointer"
                            >
                              Call Now
                            </button>

                            <button
                              onClick={() => skipToken(t.id, 'Skipped by Operator')}
                              className="px-2 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 font-medium transition cursor-pointer"
                            >
                              Skip
                            </button>

                            <button
                              onClick={() =>
                                bumpPriority(
                                  t.id,
                                  t.priority === 'senior' ? 'vip' : 'senior'
                                )
                              }
                              title="Escalate priority tier"
                              className="px-2 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition cursor-pointer"
                            >
                              Bump
                            </button>
                          </>
                        )}

                        {t.status === TOKEN_STATUS.SERVING && (
                          <>
                            <button
                              onClick={() => completeService(t.counterId || activeCounter.id)}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold transition cursor-pointer"
                            >
                              Complete
                            </button>

                            <button
                              onClick={() => skipToken(t.id, 'Marked No-Show')}
                              className="px-2 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 font-medium transition cursor-pointer"
                            >
                              Skip
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => setTransferringToken(t)}
                          className="px-2 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition cursor-pointer"
                        >
                          Transfer
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* QUICK ADD VISITOR MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <h3 className="text-xl font-bold text-slate-900 mb-1">
              Add Walk-In Visitor
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Reception check-in. Generates sequential QS token and inserts via priority + FIFO.
            </p>

            <form onSubmit={handleQuickAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Visitor Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jonathan Reed"
                  value={quickAdd.name}
                  onChange={(e) => setQuickAdd({ ...quickAdd, name: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mobile Phone (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={quickAdd.phone}
                  onChange={(e) => setQuickAdd({ ...quickAdd, phone: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Service Desk
                  </label>
                  <select
                    value={quickAdd.serviceId}
                    onChange={(e) => setQuickAdd({ ...quickAdd, serviceId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 font-medium"
                  >
                    {services.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Priority Tier
                  </label>
                  <select
                    value={quickAdd.priority}
                    onChange={(e) => setQuickAdd({ ...quickAdd, priority: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 font-medium"
                  >
                    <option value="standard">Standard (Tier 1)</option>
                    <option value="senior">Senior Citizen (Tier 2)</option>
                    <option value="medical">Medical Assistance (Tier 3)</option>
                    <option value="vip">VIP Executive (Tier 4)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-5 py-2 text-xs rounded-xl shadow transition"
                >
                  Issue Token
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TRANSFER MODAL */}
      {transferringToken && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <h3 className="text-xl font-bold text-slate-900 mb-1">
              Transfer Token {transferringToken.tokenNumber}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Reassign visitor <strong>{transferringToken.name}</strong> to a different service department.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Destination Service Desk
                </label>
                <select
                  value={targetTransferService}
                  onChange={(e) => setTargetTransferService(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} (~{s.avgTimeMin}m avg)
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 rounded-xl bg-amber-50 text-amber-900 text-xs border border-amber-200">
                The visitor will be inserted into the destination line according to FIFO priority and estimated wait time will automatically recalculate.
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setTransferringToken(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleTransferSubmit}
                  className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-5 py-2 text-xs rounded-xl shadow transition"
                >
                  Confirm Transfer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
