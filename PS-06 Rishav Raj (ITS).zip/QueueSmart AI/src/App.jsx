import React, { useState, useEffect } from 'react';
import { QueueProvider } from './context/QueueContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { AdminLogin } from './components/AdminLogin';

// Pages
import { LandingPage } from './pages/LandingPage';
import { VisitorRegistration } from './pages/VisitorRegistration';
import { MyToken } from './pages/MyToken';
import { AdminDashboard } from './pages/AdminDashboard';
import { PublicQueueDisplay } from './pages/PublicQueueDisplay';

function AppContent() {
  const { isAuthenticated } = useAuth();

  // Sync route with URL hash for easy bookmarking and browser navigation
  const [currentRoute, setCurrentRoute] = useState(() => {
    const hash = window.location.hash.replace('#/', '').replace('#', '');
    if (['register', 'my-token', 'admin', 'display'].includes(hash)) {
      return hash;
    }
    return 'landing';
  });

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      if (['landing', 'register', 'my-token', 'admin', 'display'].includes(hash)) {
        setCurrentRoute(hash);
      } else if (!hash) {
        setCurrentRoute('landing');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (route) => {
    setCurrentRoute(route);
    window.location.hash = `#/${route === 'landing' ? '' : route}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // If in public kiosk / TV display mode, we render the immersive TV screen
  if (currentRoute === 'display') {
    return (
      <div className="min-h-screen bg-[#070D19] text-white">
        <PublicQueueDisplay setCurrentRoute={navigateTo} />
        <Toast />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      <Navbar currentRoute={currentRoute} setCurrentRoute={navigateTo} />

      <main className="flex-1">
        {currentRoute === 'landing' && <LandingPage setCurrentRoute={navigateTo} />}
        {currentRoute === 'register' && <VisitorRegistration setCurrentRoute={navigateTo} />}
        {currentRoute === 'my-token' && <MyToken setCurrentRoute={navigateTo} />}
        {currentRoute === 'admin' && (
          isAuthenticated ? (
            <AdminDashboard setCurrentRoute={navigateTo} />
          ) : (
            <AdminLogin onLoginSuccess={() => navigateTo('admin')} />
          )
        )}
      </main>

      <Footer setCurrentRoute={navigateTo} />
      <Toast />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <QueueProvider>
        <AppContent />
      </QueueProvider>
    </AuthProvider>
  );
}
