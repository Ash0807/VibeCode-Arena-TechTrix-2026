# QueueSmart AI - Predictive Queue Management System

A modern, AI-powered smart queue management web application built with **React 19**, **Vite**, **Tailwind CSS**, and **Firebase** (Cloud Firestore & Firebase Authentication).

---

## 🚀 Key Features

1. **AI Predictive Wait Times**: Real-time calculation based on eligible people ahead, service duration, and active open counters (`(People Ahead × Avg Duration) / Active Open Counters`).
2. **Explainable Queue Intelligence (No External AI API)**:
   - **Deterministic Heuristics**: Formulated from queuing theory (Little's Law and Erlang-C multi-server delay models). Transparently labeled as *rule-based prototype intelligence, not trained machine learning*.
   - **Congestion Detection**: Continuous monitoring of overall facility load, load ratios per counter, and service bottleneck identification.
   - **Long Waiting Time Flags**: Automatic flagging of visitors waiting $\ge 10$ minutes (critical if $\ge 15$ minutes).
   - **Counter Recommendations**: Identifies qualified closed standby counters and recommends opening them with step-by-step explainable reasoning.
   - **Apply Suggestion with Confirmation**: Operators can review the diagnostic rationale and open recommended desks directly with a confirmation dialog.
3. **Interactive What-If Capacity Simulator**:
   - Compares queue performance **before** and **after** opening another counter.
   - Computes average wait time reduction, peak queue delay reduction, total visitor minutes saved, and number of immediate beneficiaries.
4. **Visitor In-App Milestone Notifications**:
   - **Approaching Turn**: Alerts when $\le 2$ people are ahead so visitors are prepared.
   - **Token Called**: Immediate alert with chime when called to a specific desk counter.
   - **Significant Wait Time Changes**: Alerts visitors when wait time shifts by $\ge 3$ minutes (e.g. reduced after a counter opens).
   - **Deduplication Protection**: State tracking prevents duplicate alerts and eliminates random fake activity.
   - **Visitor Notification Drawer**: Interactive notification feed allowing visitors to view, acknowledge, or dismiss past alerts.
5. **Real-Time Synchronization**: Multi-screen sync (Visitor Token Pass, Admin Operator Desk, Public TV Display) using Firestore real-time snapshot listeners (`onSnapshot`).
6. **Dual Operation Engine**:
   - **Cloud Mode**: Seamless persistence with Google Cloud Firestore and Firebase Authentication.
   - **Demo Mode**: 100% functional in-memory and `localStorage` mock engine if credentials are not configured or while testing offline.
7. **Role & Route Protection**:
   - Admin routes (`#/admin`) protected with an Operator Authentication gateway.
   - One-click demo login for rapid testing.
   - Granular Firebase Security Rules (`firestore.rules`).
8. **Customer Privacy Protection**:
   - Public display screens mask customer names (e.g., `P. S***a`).
   - Personal contact details (phone numbers, email addresses) are strictly excluded from public display and visitor views.
9. **Multi-Service & Priority Triage**:
   - Support for General Inquiries, Express Checkout, VIP/Priority, and Document Verification.
   - Configurable priority weights with strict FIFO (First-In, First-Out) ordering within priority levels.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS, Lucide React
- **Cloud Backend**: Google Cloud Firestore & Firebase Auth
- **Audio Synthesis**: Web Audio API synthesizers for queue chimes and visitor notification alerts

---

## ⚙️ Firebase Setup & Configuration

### 1. Configure Environment Variables
Copy `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

Fill in your Firebase project credentials in `.env.local`:
```env
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_firebase_app_id
```

### 2. Enable Firebase Services in Firebase Console
1. Go to [Firebase Console](https://console.firebase.google.com/).
2. Create or select your project.
3. **Authentication**: Enable **Email/Password** sign-in provider.
4. **Firestore Database**: Create a database in **Production mode**.

### 3. Deploy Firestore Security Rules
Deploy `firestore.rules` using the Firebase CLI:
```bash
npm install -g firebase-tools
firebase login
firebase init firestore
firebase deploy --only firestore:rules
```

---

## 💻 Running Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

---

## 🔒 Security & Privacy Architecture

- **Public Access**: Visitors can register waiting tokens and view public display screens.
- **Admin Access**: Only authenticated operators can call next, complete service, skip tokens, or modify counter configurations.
- **Security Rules**: All write permissions on counters and status updates on tokens are protected by `request.auth != null`.
- **Public Displays**: Customer personal data (phone numbers, emails) is never exposed on kiosk screens or public dashboards.
