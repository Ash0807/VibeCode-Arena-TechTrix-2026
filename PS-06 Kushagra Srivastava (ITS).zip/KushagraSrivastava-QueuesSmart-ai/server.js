"use strict";
// Zero-dependency server (Node 18+). Run: node server.js  ->  http://localhost:3000
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Q = require("./queue");

const PORT = process.env.PORT || 3000;
const ADMIN_PIN = process.env.ADMIN_PIN || "1234"; // demo PIN for staff login
const FRONTEND = path.join(__dirname, "..", "frontend");
const sessions = new Set(); // tokens of logged-in staff
let timer = null;

Q.init();

const send = (res, code, obj) => {
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(JSON.stringify(obj));
};
const readBody = (req) =>
  new Promise((resolve) => {
    let b = "";
    req.on("data", (c) => { b += c; if (b.length > 1e5) req.destroy(); });
    req.on("end", () => { try { resolve(JSON.parse(b || "{}")); } catch { resolve({}); } });
  });

function setSim(on) {
  Q.setAuto(on);
  clearInterval(timer);
  if (on) timer = setInterval(Q.tick, 1500); // 1.5 s real time = 1 simulated minute
}

// Public routes: anyone can join, book, check in, view the board, track a token
const publicRoutes = {
  "POST /api/join": (b) => Q.join(b),
  "POST /api/appointments": (b) => Q.book(b),
  "POST /api/checkin": (b) => Q.checkIn(b),
  "POST /api/track": (b) => { if (b.tok) { Q.track(String(b.tok)); Q.checkTracks(); } return { ok: true }; },
  "POST /api/sim": (b) => { setSim(b.auto); return { ok: true }; },
  "POST /api/admin/login": (b) => {
    if (b.pin !== ADMIN_PIN) return { error: "Wrong PIN" };
    const t = crypto.randomBytes(16).toString("hex");
    sessions.add(t);
    return { token: t };
  },
};

// Staff-only routes: need the x-admin-token header from login
const adminRoutes = {
  "POST /api/admin/call": (b) => ({ ok: Q.callNext(Q.S.C.find((c) => c.id === +b.counter)) }),
  "POST /api/admin/complete": (b) => ({ ok: Q.finish(Q.S.C.find((c) => c.id === +b.counter)) }),
  "POST /api/admin/toggle": (b) => { const c = Q.S.C.find((x) => x.id === +b.counter); if (c) c.open = !c.open; return { ok: !!c }; },
  "POST /api/admin/counter": () => { Q.addCounter(); return { ok: true }; },
  "POST /api/admin/config": (b) => { Q.setConfig(b); return { ok: true }; },
  "POST /api/admin/reset": () => { setSim(false); Q.init(); return { ok: true }; },
};

const MIME = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript" };

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  const key = req.method + " " + url.pathname;
  try {
    if (key === "GET /api/state") {
      const admin = sessions.has(req.headers["x-admin-token"]);
      return send(res, 200, Q.snapshot(url.searchParams.get("track") || "", admin));
    }
    if (publicRoutes[key]) {
      const r = publicRoutes[key](await readBody(req));
      return send(res, r.error ? 400 : 200, r);
    }
    if (adminRoutes[key]) {
      if (!sessions.has(req.headers["x-admin-token"])) return send(res, 401, { error: "Staff login required" });
      Q.checkTracks();
      const r = adminRoutes[key](await readBody(req));
      Q.checkTracks();
      return send(res, 200, r);
    }
    if (url.pathname.startsWith("/api/")) return send(res, 404, { error: "Not found" });

    // static frontend
    const file = path.normalize(path.join(FRONTEND, url.pathname === "/" ? "index.html" : url.pathname));
    if (!file.startsWith(FRONTEND) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
    fs.createReadStream(file).pipe(res);
  } catch (err) {
    console.error(err);
    send(res, 500, { error: "Server error" });
  }
}).listen(PORT, () => console.log(`QueueSmart AI running on http://localhost:${PORT} (staff PIN: ${ADMIN_PIN})`));
