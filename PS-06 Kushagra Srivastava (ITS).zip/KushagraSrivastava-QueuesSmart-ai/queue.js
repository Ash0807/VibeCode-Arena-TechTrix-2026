"use strict";
// Core queue logic: tokens, priority order, ETA, counters, simulation, notifications.
// All data is in memory (sample/simulated data), so a server restart resets everything.

const SV = {
  GEN: { n: "General Enquiry", avg: 5 },
  BIL: { n: "Billing & Payments", avg: 7 },
  DOC: { n: "Documents", avg: 10 },
  CON: { n: "Consultation", avg: 12 },
};
const SLOTS = ["10:00", "10:30", "11:00", "11:30", "12:00"].map((t) => ({ t, m: +t.slice(0, 2) * 60 + +t.slice(3) }));
const NAMES = ["Aarav", "Priya", "Rohan", "Sneha", "Vikram", "Anita", "Karan", "Meera", "Rahul", "Divya", "Imran", "Pooja", "Arjun", "Neha", "Sanjay"];
const SVC_KEYS = Object.keys(SV);
const fmt = (m) => String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");

let S;

function init() {
  S = {
    clock: 570, // 09:30, simulated minutes since midnight
    seq: { GEN: 100, BIL: 100, DOC: 100, CON: 100 },
    sid: 0, Q: [], C: [], apts: [], streak: 0, auto: false, tracks: {},
    hist: { GEN: [], BIL: [], DOC: [], CON: [] },
    FAIR: 3, CAP: 12,
    PRI: [
      { id: "reg", n: "Regular", r: 1 },
      { id: "apt", n: "Appointment (on time)", r: 2 },
      { id: "sen", n: "Senior citizen", r: 3 },
      { id: "dis", n: "Differently abled / pregnant", r: 3 },
      { id: "eme", n: "Emergency", r: 4 },
    ],
  };
  S.C = [
    { id: 1, open: true, cur: null, left: 0 },
    { id: 2, open: true, cur: null, left: 0 },
    { id: 3, open: false, cur: null, left: 0 },
  ];
  for (let i = 0; i < 5; i++) { // already completed customers, so stats are not empty
    const e = randomCustomer();
    e.t0 = S.clock - 25 - i; e.start = S.clock - 20 + i; e.end = S.clock - 14 + i; e.status = "done";
    S.hist[e.svc].push(e.end - e.start);
  }
  for (let i = 0; i < 9; i++) randomCustomer().t0 = S.clock - i;
  callNext(S.C[0]); callNext(S.C[1]);
  S.apts = [{ id: 1, name: "Ritu Sharma", phone: "9810000001", svc: "CON", slot: SLOTS[0], done: false }];
}

const rank = (e) => (S.PRI.find((p) => p.id === e.pri) || { r: 1 }).r;
const pname = (id) => (S.PRI.find((p) => p.id === id) || { n: id }).n;
const avg = (s) => { const h = S.hist[s]; return (SV[s].avg * 3 + h.reduce((a, b) => a + b, 0)) / (3 + h.length); };
const openC = () => S.C.filter((c) => c.open);

function add(name, phone, svc, pri, slot) {
  S.seq[svc]++;
  const e = { id: ++S.sid, tok: svc[0] + "-" + S.seq[svc], name, phone, svc, pri, t0: S.clock, status: "waiting", slot: slot || null };
  S.Q.push(e);
  return e;
}
function randomCustomer() {
  const r = Math.random();
  return add(NAMES[(Math.random() * NAMES.length) | 0], "98" + Math.random().toString().slice(2, 10),
    SVC_KEYS[(Math.random() * 4) | 0], r < 0.12 ? "sen" : r < 0.17 ? "dis" : r < 0.19 ? "eme" : "reg");
}

// Order of service. Higher priority level first, then arrival time.
// Fairness rule: after FAIR priority calls in a row, the next Regular token goes.
function ordered() {
  const w = S.Q.filter((x) => x.status === "waiting");
  const reg = w.filter((x) => rank(x) === 1).sort((a, b) => a.t0 - b.t0 || a.id - b.id);
  const hi = w.filter((x) => rank(x) > 1).sort((a, b) => rank(b) - rank(a) || a.t0 - b.t0 || a.id - b.id);
  const out = []; let s = S.streak;
  while (reg.length || hi.length) {
    let p;
    if (hi.length && (s < S.FAIR || !reg.length)) { p = hi.shift(); s++; } else { p = reg.shift(); s = 0; }
    out.push(p);
  }
  return out;
}

// Wait estimate = people ahead x average service time / open counters. Always an estimate.
function eta(e, o) {
  o = o || ordered();
  const i = o.indexOf(e);
  if (i < 0) return null;
  const n = openC().length;
  if (!n) return { pos: i + 1, min: null };
  const free = openC().filter((c) => !c.cur).length;
  const ahead = o.slice(0, i);
  const mean = ahead.length ? ahead.reduce((a, x) => a + avg(x.svc), 0) / ahead.length : avg(e.svc);
  const min = i < free ? 0 : Math.round((ahead.length / n) * mean + (free ? 0 : Math.min(...openC().map((c) => c.left)) * 0.5));
  return { pos: i + 1, min, lo: Math.round(min * 0.8), hi: Math.ceil(min * 1.25) + 1 };
}

function callNext(c) {
  if (!c || !c.open || c.cur) return false;
  const o = ordered();
  if (!o.length) return false;
  const e = o[0];
  e.status = "serving"; e.counter = c.id; e.start = S.clock;
  S.streak = rank(e) > 1 ? S.streak + 1 : 0;
  c.cur = e;
  c.left = Math.max(1, Math.round(avg(e.svc) * (0.6 + Math.random() * 0.8)));
  return true;
}
function finish(c) {
  const e = c && c.cur;
  if (!e) return false;
  e.status = "done"; e.end = S.clock;
  S.hist[e.svc].push(Math.max(1, e.end - e.start));
  c.cur = null;
  return true;
}

// Simulated notifications for tokens that a user is tracking
function track(tok) {
  if (!S.tracks[tok]) S.tracks[tok] = { near: false, last: null, srv: false, notes: [] };
  return S.tracks[tok];
}
function note(t, m) { t.notes.unshift({ t: fmt(S.clock), m }); t.notes.length = Math.min(t.notes.length, 20); }
function checkTracks() {
  for (const tok of Object.keys(S.tracks)) {
    const e = S.Q.find((x) => x.tok === tok), t = S.tracks[tok];
    if (!e) continue;
    if (e.status === "waiting") {
      const x = eta(e);
      if (!x || x.min == null) continue;
      if (x.pos <= 3 && !t.near) { t.near = true; note(t, `Your turn is approaching: ${x.pos - 1} ahead of ${tok}.`); }
      if (t.last == null) t.last = x.min;
      else if (Math.abs(x.min - t.last) >= 3) { note(t, `Estimated wait for ${tok} changed: ~${t.last} → ~${x.min} min.`); t.last = x.min; }
    } else if (e.status === "serving" && !t.srv) {
      t.srv = true; note(t, `${tok}, please proceed to Counter ${e.counter}.`);
    }
  }
}

function tick() {
  S.clock++;
  S.C.forEach((c) => { if (c.cur && --c.left <= 0) finish(c); });
  if (S.auto) { S.C.forEach(callNext); if (Math.random() < 0.55) randomCustomer(); }
  checkTracks();
}

function stats(w) {
  const d = S.Q.filter((x) => x.status === "done");
  return {
    served: d.length,
    avgWait: d.length ? Math.round(d.reduce((a, x) => a + (x.start - x.t0), 0) / d.length) : 0,
    avgService: d.length ? +(d.reduce((a, x) => a + (x.end - x.start), 0) / d.length).toFixed(1) : 0,
    maxEta: Math.max(0, ...w.map((x) => eta(x, w).min || 0)),
  };
}

// Basic optimisation: overcrowding alerts and counter allocation suggestions
function insights(w, st) {
  const n = openC().length, out = [];
  if (!n) return [["bad", "No counters are open. Open at least one."]];
  const ratio = w.length / n;
  if (w.length > S.CAP || st.maxEta > 25) out.push(["bad", `Overcrowding risk: ${w.length} waiting, longest estimate ~${st.maxEta} min.`]);
  const closed = S.C.find((c) => !c.open);
  if (closed && (ratio > 5 || st.maxEta > 20))
    out.push(["", `Suggestion: open Counter ${closed.id}. Expected longest wait drops from ~${st.maxEta} to ~${Math.round((st.maxEta * n) / (n + 1))} min.`]);
  else if (!closed && ratio > 5) out.push(["", `Suggestion: add a new counter (${ratio.toFixed(1)} tokens per counter).`]);
  if (n > 1 && ratio < 1 && openC().filter((c) => !c.cur).length > 1) out.push(["", `Suggestion: close one idle counter; only ${w.length} waiting.`]);
  const mix = {};
  w.forEach((x) => (mix[x.svc] = (mix[x.svc] || 0) + 1));
  const top = Object.entries(mix).sort((a, b) => b[1] - a[1])[0];
  if (top && top[1] >= 4) out.push(["", `Pattern: ${SV[top[0]].n} is driving the queue (${top[1]} waiting). Dedicate a counter to it.`]);
  if (!out.length) out.push(["ok", "Queue is healthy. No action needed."]);
  return out;
}

const mask = (n) => n.split(" ").map((p) => p[0] + "***").join(" ");

function snapshot(trackTok, admin) {
  const w = ordered(), st = stats(w);
  const t = trackTok ? S.tracks[trackTok] : null;
  const te = trackTok ? S.Q.find((x) => x.tok === trackTok) : null;
  return {
    clock: S.clock, clockText: fmt(S.clock), auto: S.auto, fair: S.FAIR, cap: S.CAP,
    services: SV, slots: SLOTS.map((s) => s.t), priorities: S.PRI,
    counters: S.C.map((c) => ({ id: c.id, open: c.open, tok: c.cur ? c.cur.tok : null, svc: c.cur ? c.cur.svc : null, left: c.left })),
    waitingCount: w.length, completed: st.served,
    waiting: w.slice(0, 15).map((e) => ({
      tok: e.tok, svc: e.svc, priName: pname(e.pri), rank: rank(e), waited: S.clock - e.t0, eta: eta(e, w),
      ...(admin ? { name: e.name } : {}),
    })),
    stats: st,
    insights: insights(w, st),
    apts: S.apts.map((a) => ({ id: a.id, name: mask(a.name), slot: a.slot.t, svc: a.svc, done: a.done })),
    aptCounts: Object.fromEntries(SLOTS.map((s) => [s.t, S.apts.filter((a) => a.slot.t === s.t && !a.done).length])),
    track: te ? { tok: te.tok, status: te.status, counter: te.counter || null, eta: te.status === "waiting" ? eta(te, w) : null } : null,
    notes: t ? t.notes : [],
  };
}

// ---- actions used by the API ----
function join({ name, phone, svc, pri }) {
  if (!name || String(phone || "").replace(/\D/g, "").length < 10) return { error: "Enter a name and a valid 10-digit phone number." };
  if (!SV[svc]) return { error: "Unknown service." };
  const p = S.PRI.find((x) => x.id === pri);
  if (!p || p.id === "apt") return { error: "Unknown priority category." };
  const e = add(String(name).slice(0, 60), String(phone), svc, pri);
  track(e.tok); checkTracks();
  return { tok: e.tok };
}
function book({ name, phone, svc, slot }) {
  const s = SLOTS.find((x) => x.t === slot);
  if (!name || String(phone || "").replace(/\D/g, "").length < 10) return { error: "Enter a name and a valid 10-digit phone number." };
  if (!SV[svc] || !s) return { error: "Invalid service or slot." };
  if (S.apts.filter((a) => a.slot.t === slot && !a.done).length >= 2) return { error: "That slot is full." };
  S.apts.push({ id: Date.now(), name: String(name).slice(0, 60), phone: String(phone), svc, slot: s, done: false });
  return { ok: true };
}
function checkIn({ id }) {
  const a = S.apts.find((x) => x.id === +id);
  if (!a || a.done) return { error: "Appointment not found." };
  const ok = S.clock >= a.slot.m - 15 && S.clock <= a.slot.m + 15; // on-time window
  a.done = true;
  const e = add(a.name, a.phone, a.svc, ok ? "apt" : "reg", a.slot.t);
  track(e.tok); checkTracks();
  return { tok: e.tok, onTime: ok };
}
function setConfig({ ranks, fair, cap }) {
  if (ranks) for (const [id, r] of Object.entries(ranks)) { const p = S.PRI.find((x) => x.id === id); if (p && id !== "reg") p.r = Math.min(9, Math.max(2, +r || 2)); }
  if (fair) S.FAIR = Math.min(10, Math.max(1, +fair || 3));
  if (cap) S.CAP = Math.max(3, +cap || 12);
}

module.exports = {
  init, tick, snapshot, join, book, checkIn, setConfig, track, checkTracks,
  get S() { return S; }, callNext, finish, SV,
  setAuto: (v) => { S.auto = !!v; },
  addCounter: () => S.C.push({ id: S.C.length + 1, open: true, cur: null, left: 0 }),
};
