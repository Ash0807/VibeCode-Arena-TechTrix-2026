"use strict";
// Frontend: shows what the backend sends and posts user actions. No queue logic lives here.
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

let D = null; // latest state from /api/state
let view = "join", mode = "now", track = "", adminToken = "", lastNote = "", joinMsg = "";

async function api(path, body) {
  const opt = { headers: { "x-admin-token": adminToken } };
  if (body !== undefined) { opt.method = "POST"; opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401) adminToken = ""; throw new Error(j.error || "Request failed"); }
  return j;
}
async function refresh() {
  try { D = await api("/api/state?track=" + encodeURIComponent(track)); } catch (e) { return; }
  const n = D.notes[0];
  if (n && n.t + n.m !== lastNote) { lastNote = n.t + n.m; toast(n.m); }
  $("#auto").textContent = D.auto ? "⏸ Pause simulation" : "▶ Auto-simulate";
  render();
}
function toast(m) {
  const t = $("#toast"); t.textContent = "🔔 " + m; t.style.display = "block";
  clearTimeout(toast.h); toast.h = setTimeout(() => (t.style.display = "none"), 3500);
}
const etaTxt = (t) => !t ? "–" : t.min == null ? "No counters open" : t.min === 0 ? "Next up" : `~${t.min} min (${t.lo}–${t.hi})`;
const alerts = (l) => l.map(([c, m]) => `<div class="alert ${c}">${esc(m)}</div>`).join("");

function render(force) {
  if (!D) return;
  $("#nav").innerHTML = [["join", "Join / Book"], ["live", "Live Board"], ["admin", "Staff Dashboard"]]
    .map(([k, l]) => `<button class="${view === k ? "on" : ""}" onclick="view='${k}';render(true)">${l}</button>`).join("");
  if (view === "join") { if (force || !$("#joinForm")) renderJoin(); else aptList(); }
  else if (view === "live") renderLive();
  else renderAdmin();
}

// ---------- Join / Book ----------
function rules() {
  const g = {};
  D.priorities.forEach((p) => (g[p.r] = g[p.r] || []).push(p.n));
  return `<ol class="mut">${Object.keys(g).sort((a, b) => b - a).map((r) => `<li>Level ${r}: ${g[r].map(esc).join(", ")}</li>`).join("")}</ol>
  <p class="mut">Same level: first come, first served. Fairness rule: after ${D.fair} priority calls in a row, the next Regular token is served. Priority is verified by staff (ID) at the counter.</p>`;
}
function renderJoin() {
  const sv = Object.entries(D.services);
  $("#app").innerHTML = `<div class="grid"><div class="card"><h2>Get a token</h2>
  <div class="row"><button class="${mode === "now" ? "on" : ""}" onclick="mode='now';renderJoin()">Join queue now</button><button class="${mode === "apt" ? "on" : ""}" onclick="mode='apt';renderJoin()">Book appointment</button></div>
  <div id="joinForm"><label>Name</label><input id="fn" placeholder="Full name">
  <label>Phone (simulated notifications only)</label><input id="fp" inputmode="tel" placeholder="10-digit number">
  <label>Service category</label><select id="fs">${sv.map(([k, v]) => `<option value="${k}">${esc(v.n)}, about ${v.avg} min</option>`).join("")}</select>
  ${mode === "now"
    ? `<label>Priority category</label><select id="fq">${D.priorities.filter((p) => p.id !== "apt").map((p) => `<option value="${p.id}">${esc(p.n)}</option>`).join("")}</select>`
    : `<label>Appointment slot</label><select id="fl">${D.slots.map((s) => { const left = 2 - D.aptCounts[s]; return `<option value="${s}" ${left <= 0 ? "disabled" : ""}>${s} (${Math.max(left, 0)} left)</option>`; }).join("")}</select>`}
  <p><button class="p" onclick="submitJoin()">${mode === "now" ? "Generate token" : "Book slot"}</button></p><div id="joinRes">${joinMsg}</div></div></div>
  <div class="card"><h2>Priority rules</h2>${rules()}</div>
  <div class="card"><h2>Appointments today</h2><div id="aptList"></div></div></div>`;
  aptList();
}
function aptList() {
  const el = $("#aptList"); if (!el) return;
  el.innerHTML = D.apts.length
    ? D.apts.map((a) => `<div class="row" style="justify-content:space-between;margin-bottom:6px"><span>${esc(a.name)} · ${a.slot} · ${esc(D.services[a.svc].n)}</span>${a.done ? '<span class="pill">checked in</span>' : `<button onclick="checkIn(${a.id})">Check in</button>`}</div>`).join("")
      + `<p class="mut">On-time check-in (15 min before to 15 min after the slot) gets appointment priority; otherwise you join as Regular. Current time: ${D.clockText}.</p>`
    : "<p class='mut'>No appointments.</p>";
}
async function submitJoin() {
  const body = { name: $("#fn").value.trim(), phone: $("#fp").value.trim(), svc: $("#fs").value };
  try {
    if (mode === "apt") {
      await api("/api/appointments", { ...body, slot: $("#fl").value });
      joinMsg = `<div class="alert ok">Booked ${esc($("#fl").value)}. Use “Check in” when you arrive.</div>`;
    } else {
      const r = await api("/api/join", { ...body, pri: $("#fq").value });
      track = r.tok; await refresh(); showTok();
      return;
    }
  } catch (e) { joinMsg = `<div class="alert bad">${esc(e.message)}</div>`; }
  await refresh(); renderJoin();
}
function showTok(extra) {
  const t = D.track;
  joinMsg = `${extra || ""}<div class="alert ok"><div>Your token</div><div class="tok">${esc(track)}</div><div>${t && t.eta ? `Position ${t.eta.pos} · ${etaTxt(t.eta)}` : "Waiting"}</div><div class="mut">Estimate only, not a guarantee. Tracking started; you’ll get simulated alerts.</div></div>`;
  renderJoin();
}
async function checkIn(id) {
  try {
    const r = await api("/api/checkin", { id });
    track = r.tok; await refresh();
    showTok(r.onTime ? "" : `<div class="alert">Outside the on-time window, so you joined as Regular.</div>`);
  } catch (e) { toast(e.message); }
}

// ---------- Live board ----------
function trackBox() {
  if (!track) return "";
  const t = D.track;
  if (!t) return '<p class="mut">Token not found.</p>';
  return `<p><b>${esc(t.tok)}</b>: ${t.status === "waiting" ? `position ${t.eta.pos}, ${etaTxt(t.eta)}` : t.status === "serving" ? `now serving at Counter ${t.counter}` : "completed"}</p>`;
}
function renderLive() {
  $("#app").innerHTML = `<div class="stats"><div class="stat"><small>Clock (simulated)</small><b>${D.clockText}</b></div><div class="stat"><small>Waiting</small><b>${D.waitingCount}</b></div><div class="stat"><small>Completed</small><b>${D.completed}</b></div><div class="stat"><small>Open counters</small><b>${D.counters.filter((c) => c.open).length}/${D.counters.length}</b></div></div>
  ${alerts(D.insights.filter((a) => a[0] === "bad"))}
  <div class="grid">${D.counters.map((c) => `<div class="card"><h2>Counter ${c.id} ${c.open ? "" : '<span class="pill">closed</span>'}</h2><div class="tok">${c.tok || "–"}</div><div class="mut">${c.tok ? esc(D.services[c.svc].n) : c.open ? "Idle" : "Not serving"}</div></div>`).join("")}</div>
  <div class="grid" style="margin-top:12px"><div class="card"><h2>Track my token</h2><div class="row"><input id="tk" value="${esc(track)}" placeholder="e.g. G-105" style="flex:1"><button class="p" onclick="setTrack()">Track</button></div>${trackBox()}
  <h2 style="margin-top:14px">Simulated notifications</h2>${D.notes.length ? D.notes.map((n) => `<div class="mut">${n.t} · ${esc(n.m)}</div>`).join("") : '<div class="mut">None yet. Track a token to receive alerts.</div>'}</div>
  <div class="card"><h2>Waiting tokens (service order)</h2><div class="wrap"><table class="tbl"><tr><th>#</th><th>Token</th><th>Service</th><th>Priority</th><th>Est. wait</th></tr>${D.waiting.map((e, i) => `<tr><td>${i + 1}</td><td><b>${e.tok}</b></td><td>${esc(D.services[e.svc].n)}</td><td>${e.rank > 1 ? `<span class="pill h">${esc(e.priName)}</span>` : "Regular"}</td><td>${etaTxt(e.eta)}</td></tr>`).join("") || "<tr><td colspan=5>Queue is empty</td></tr>"}</table></div><p class="mut">Estimates use people ahead, average service time and open counters. They are not guarantees.</p></div></div>`;
}
async function setTrack() {
  track = $("#tk").value.trim().toUpperCase();
  if (track) await api("/api/track", { tok: track });
  refresh();
}

// ---------- Staff dashboard ----------
const act = async (path, body) => { try { await api(path, body || {}); } catch (e) { toast(e.message); } refresh(); };
async function login() {
  try { adminToken = (await api("/api/admin/login", { pin: $("#pin").value })).token; refresh(); } catch (e) { toast(e.message); }
}
function renderAdmin() {
  if (!adminToken) {
    $("#app").innerHTML = `<div class="card" style="max-width:340px"><h2>Staff login</h2><label>PIN (demo: 1234)</label><input id="pin" type="password"><p><button class="p" onclick="login()">Sign in</button></p></div>`;
    return;
  }
  if (document.activeElement && document.activeElement.closest && document.activeElement.closest("#cfg")) return; // do not disturb typing
  const s = D.stats;
  $("#app").innerHTML = `<div class="stats"><div class="stat"><small>Waiting</small><b>${D.waitingCount}</b></div><div class="stat"><small>Served</small><b>${s.served}</b></div><div class="stat"><small>Avg actual wait</small><b>${s.avgWait} min</b></div><div class="stat"><small>Avg service time</small><b>${s.avgService} min</b></div><div class="stat"><small>Longest estimate</small><b>${s.maxEta} min</b></div></div>
  ${alerts(D.insights)}
  <div class="grid"><div class="card"><h2>Counters</h2>${D.counters.map((c) => `<div style="padding:8px 0;border-bottom:1px solid var(--bd)"><b>Counter ${c.id}</b> ${c.open ? "" : '<span class="pill">closed</span>'} · ${c.tok ? `serving <b>${c.tok}</b> (${c.left} min left)` : "idle"}<div class="row" style="margin-top:6px"><button class="g" ${c.tok || !c.open || !D.waitingCount ? "disabled" : ""} onclick="act('/api/admin/call',{counter:${c.id}})">Call next</button><button ${c.tok ? "" : "disabled"} onclick="act('/api/admin/complete',{counter:${c.id}})">Complete</button><button class="${c.open ? "r" : ""}" onclick="act('/api/admin/toggle',{counter:${c.id}})">${c.open ? "Close" : "Open"}</button></div></div>`).join("")}
  <p><button onclick="act('/api/admin/counter')">+ Add counter</button> <button class="r" onclick="if(confirm('Reset demo data?'))act('/api/admin/reset')">Reset sample data</button></p></div>
  <div class="card"><h2>Next in line</h2><div class="wrap"><table class="tbl"><tr><th>Token</th><th>Name</th><th>Service</th><th>Priority</th><th>Waiting</th></tr>${D.waiting.slice(0, 10).map((e) => `<tr><td><b>${e.tok}</b></td><td>${esc(e.name || "")}</td><td>${esc(D.services[e.svc].n)}</td><td>${esc(e.priName)}</td><td>${e.waited} min</td></tr>`).join("") || "<tr><td colspan=5>Empty</td></tr>"}</table></div></div>
  <div class="card" id="cfg"><h2>Priority rules (configurable)</h2>${D.priorities.filter((p) => p.id !== "reg").map((p) => `<div class="row" style="margin-bottom:6px"><span style="flex:1">${esc(p.n)}</span><input type="number" min="2" max="9" value="${p.r}" style="width:64px" onchange="act('/api/admin/config',{ranks:{'${p.id}':this.value}})"></div>`).join("")}
  <div class="row" style="margin-bottom:6px"><span style="flex:1">Fairness: Regular after N priority calls</span><input type="number" min="1" max="10" value="${D.fair}" style="width:64px" onchange="act('/api/admin/config',{fair:this.value})"></div>
  <div class="row"><span style="flex:1">Overcrowding threshold (waiting)</span><input type="number" min="3" value="${D.cap}" style="width:64px" onchange="act('/api/admin/config',{cap:this.value})"></div>
  <p class="mut">Higher level is served first. Rules are shown to users on the Join page.</p></div></div>`;
}

$("#auto").onclick = async () => { await api("/api/sim", { auto: !D.auto }); refresh(); };
refresh();
setInterval(refresh, 1500);
