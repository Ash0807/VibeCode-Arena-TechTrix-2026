import React, { useState, useEffect } from 'react';
import { QueueProvider, useQueue } from './context/QueueContext';
import { Header } from './components/Header';
import { CustomerPortal } from './components/CustomerPortal';
import { LiveQueueDisplay } from './components/LiveQueueDisplay';
import { AdminDashboard } from './components/AdminDashboard';
import { AnalyticsView } from './components/AnalyticsView';
import { NotificationModal } from './components/NotificationModal';
import {
  Bell,
  X,
  Sparkles,
  ExternalLink,
  Code2,
  Database,
  Cpu
} from 'lucide-react';

const MainAppContent: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<'user' | 'display' | 'admin' | 'analytics'>('user');
  const [isNotifModalOpen, setIsNotifModalOpen] = useState(false);
  const [toastAlert, setToastAlert] = useState<{ title: string; message: string; type: string } | null>(null);

  const { notifications } = useQueue();

  // Watch for latest high-priority notification to display quick toast
  useEffect(() => {
    if (notifications.length > 0) {
      const latest = notifications[0];
      const isRecent = Date.now() - latest.timestamp < 3000;
      if (isRecent) {
        setToastAlert({
          title: latest.title,
          message: latest.message,
          type: latest.type
        });
        const timer = setTimeout(() => {
          setToastAlert(null);
        }, 5000);
        return () => clearTimeout(timer);
      }
    }
  }, [notifications]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans">
      
      {/* Global Header & Simulation Controller */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        unreadCount={notifications.length}
        onOpenNotifications={() => setIsNotifModalOpen(true)}
      />

      {/* Main Tab View */}
      <main className="flex-1">
        {currentTab === 'user' && <CustomerPortal />}
        {currentTab === 'display' && <LiveQueueDisplay />}
        {currentTab === 'admin' && <AdminDashboard />}
        {currentTab === 'analytics' && <AnalyticsView />}
      </main>

      {/* Live Floating Toast Alert for Turns & Delays */}
      {toastAlert && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-slate-900 border border-cyan-500/50 shadow-2xl rounded-2xl p-4 animate-fade-in flex items-start gap-3 backdrop-blur-md">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex-1">
            <h4 className="text-xs font-bold text-white">{toastAlert.title}</h4>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
              {toastAlert.message}
            </p>
          </div>
          <button
            onClick={() => setToastAlert(null)}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Notification Center Modal */}
      <NotificationModal
        isOpen={isNotifModalOpen}
        onClose={() => setIsNotifModalOpen(false)}
      />

      {/* Prototype Footer with System Specs */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 py-6 px-4 sm:px-6 lg:px-8 mt-12 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 font-bold text-white">
              <span>QueueSmart AI</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                PROTOTYPE
              </span>
            </div>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" /> Dynamic Waiting Time Engine
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-slate-400">
              <Database className="w-3.5 h-3.5" /> In-Memory State & Simulation Bus
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-slate-400">
              <Code2 className="w-3.5 h-3.5" /> Modular React + TypeScript
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
};

export const App: React.FC = () => {
  return (
    <QueueProvider>
      <MainAppContent />
    </QueueProvider>
  );
};

export default App;

