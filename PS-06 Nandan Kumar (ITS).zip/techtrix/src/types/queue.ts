export type ServiceCategoryId = 'GENERAL' | 'TELLER' | 'MEDICAL' | 'DOCUMENT';

export interface ServiceCategory {
  id: ServiceCategoryId;
  name: string;
  code: string;
  iconName: string;
  description: string;
  defaultDurationMinutes: number; // Avg service duration in minutes
  colorTheme: {
    bg: string;
    text: string;
    border: string;
    accent: string;
  };
}

export type PriorityLevelId = 'EMERGENCY' | 'PWD' | 'SENIOR_PREGNANT' | 'STANDARD';

export interface PriorityLevel {
  id: PriorityLevelId;
  name: string;
  code: string;
  weight: number; // Higher weight = higher priority in queue
  badgeColor: string;
  description: string;
  ruleExplanation: string;
  requiresVerification: boolean;
}

export type TokenStatus = 'WAITING' | 'SERVING' | 'COMPLETED' | 'NO_SHOW' | 'CANCELLED';

export interface Token {
  id: string; // e.g., "GEN-101", "MED-204"
  sequenceNumber: number; // e.g., 101
  customerName: string;
  phoneNumber: string;
  serviceCategoryId: ServiceCategoryId;
  priorityLevelId: PriorityLevelId;
  status: TokenStatus;
  counterId: string | null; // e.g. "COUNTER-1" when being served or completed
  createdAt: number; // timestamp ms
  calledAt: number | null;
  completedAt: number | null;
  estimatedWaitMinutes: number;
  delayOffsetMinutes: number; // manual or auto simulated delay (e.g. +5 mins)
  notes?: string;
  cancellationReason?: string;
}

export type CounterStatus = 'OPEN' | 'PAUSED' | 'CLOSED';

export interface Counter {
  id: string; // e.g. "COUNTER-1"
  counterNumber: number;
  name: string;
  staffName: string;
  assignedServiceId: ServiceCategoryId | 'ALL';
  status: CounterStatus;
  currentServedTokenId: string | null;
  servedCountToday: number;
  averageServeTimeMinutes: number;
}

export type AlertType = 'TURN_APPROACHING' | 'WAIT_TIME_UPDATED' | 'CALLED' | 'GENERAL';

export interface NotificationAlert {
  id: string;
  tokenId: string;
  customerName: string;
  type: AlertType;
  title: string;
  message: string;
  timestamp: number;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface IntelligentSuggestion {
  id: string;
  type: 'BOTTLENECK' | 'IDLE_COUNTER' | 'SPIKE_PREDICTION' | 'REALLOCATION';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  metric: string;
  suggestedAction: {
    type: 'REALLOCATE_COUNTER' | 'OPEN_COUNTER' | 'EXPEDITE_PRIORITY';
    counterId?: string;
    targetServiceId?: ServiceCategoryId;
    recommendedStaff?: string;
  };
  createdAt: number;
  dismissed: boolean;
}

export interface QueueAnalytics {
  totalRegistered: number;
  totalServed: number;
  totalWaiting: number;
  totalNoShow: number;
  totalCancelled: number;
  averageWaitTimeOverall: number;
  averageWaitTimeByService: Record<ServiceCategoryId, number>;
  activeCountersCount: number;
  serviceEfficiencyScore: number;
  peakHourTrends: {
    hour: string;
    demand: number;
    served: number;
  }[];
}

export interface CreateTokenDto {
  customerName: string;
  phoneNumber: string;
  serviceCategoryId: ServiceCategoryId;
  priorityLevelId: PriorityLevelId;
  notes?: string;
}

