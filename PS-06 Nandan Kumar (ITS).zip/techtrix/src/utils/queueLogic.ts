import { Token, Counter, ServiceCategory, PriorityLevel, ServiceCategoryId, IntelligentSuggestion } from '../types/queue';

/**
 * Priority definitions and comparative weights
 */
export const PRIORITY_DEFINITIONS: Record<string, { weight: number; label: string; badge: string; reason: string }> = {
  EMERGENCY: {
    weight: 400,
    label: 'Emergency / Critical',
    badge: 'bg-red-500/20 text-red-300 border-red-500/40',
    reason: 'Critical medical/urgent triage priority takes precedence over all other queues.'
  },
  PWD: {
    weight: 300,
    label: 'Persons with Disabilities (PWD)',
    badge: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    reason: 'Accessibility affirmative action slots ahead of standard queue.'
  },
  SENIOR_PREGNANT: {
    weight: 200,
    label: 'Senior Citizen & Expectant Mother',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    reason: 'Express care lane reserved for vulnerable demographics.'
  },
  STANDARD: {
    weight: 100,
    label: 'Standard Queue',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    reason: 'Serviced in chronological order of arrival (FIFO).'
  }
};

/**
 * Compares two tokens for queue position:
 * 1. Higher Priority Weight first
 * 2. If equal priority, FIFO (earlier createdAt timestamp first)
 */
export function compareTokens(a: Token, b: Token, priorityLevels: PriorityLevel[]): number {
  const priorityWeightMap = new Map<string, number>(
    priorityLevels.map(p => [p.id, p.weight])
  );

  const weightA = priorityWeightMap.get(a.priorityLevelId) ?? 100;
  const weightB = priorityWeightMap.get(b.priorityLevelId) ?? 100;

  if (weightA !== weightB) {
    return weightB - weightA; // Higher weight comes first
  }

  // FIFO fallback
  return a.createdAt - b.createdAt;
}

/**
 * Sorts all waiting tokens according to priority rules and arrival time.
 */
export function sortQueueTokens(tokens: Token[], priorityLevels: PriorityLevel[]): Token[] {
  return [...tokens].sort((a, b) => compareTokens(a, b, priorityLevels));
}

/**
 * Calculates waiting position and rule transparency breakdown for a given token.
 */
export function getQueuePositionDetails(
  targetToken: Token,
  allTokens: Token[],
  priorityLevels: PriorityLevel[]
) {
  // Filter only WAITING tokens for the same service category
  const waitingForService = allTokens.filter(
    t => t.status === 'WAITING' && t.serviceCategoryId === targetToken.serviceCategoryId
  );

  const sorted = sortQueueTokens(waitingForService, priorityLevels);
  const positionIndex = sorted.findIndex(t => t.id === targetToken.id);

  if (positionIndex === -1) {
    return {
      position: null,
      tokensAhead: 0,
      totalWaitingInService: waitingForService.length,
      higherPriorityAhead: 0,
      samePriorityAhead: 0,
      transparencyNote: 'Token is currently not in the active waiting queue.'
    };
  }

  const tokensAhead = positionIndex;
  const targetPriorityWeight = priorityLevels.find(p => p.id === targetToken.priorityLevelId)?.weight ?? 100;

  let higherPriorityAhead = 0;
  let samePriorityAhead = 0;

  for (let i = 0; i < positionIndex; i++) {
    const aheadToken = sorted[i];
    const aheadWeight = priorityLevels.find(p => p.id === aheadToken.priorityLevelId)?.weight ?? 100;
    if (aheadWeight > targetPriorityWeight) {
      higherPriorityAhead++;
    } else {
      samePriorityAhead++;
    }
  }

  let transparencyNote = '';
  if (higherPriorityAhead > 0) {
    transparencyNote = `${higherPriorityAhead} priority token(s) (Emergency/PWD/Senior) are slotted ahead per regulatory accessibility compliance.`;
  } else if (targetPriorityWeight > 100) {
    transparencyNote = `Your priority status has expedited your position ahead of standard queue arrivals.`;
  } else {
    transparencyNote = `Position is determined strictly by arrival timestamp (FIFO).`;
  }

  return {
    position: positionIndex + 1,
    tokensAhead,
    totalWaitingInService: waitingForService.length,
    higherPriorityAhead,
    samePriorityAhead,
    transparencyNote
  };
}

/**
 * Calculates dynamic waiting time using the specified algorithm:
 * Estimated Wait Time = (Tokens Ahead * Avg Service Duration) / Active Counters
 * With adjustments for priority offsets and manual/simulated delay offsets.
 */
export function calculateDynamicWaitTime(
  token: Token,
  allTokens: Token[],
  counters: Counter[],
  services: ServiceCategory[],
  priorityLevels: PriorityLevel[]
): {
  estimatedMinutes: number;
  tokensAhead: number;
  activeCounters: number;
  avgDurationMinutes: number;
  priorityAdjustmentMinutes: number;
  delayOffsetMinutes: number;
  disclaimer: string;
} {
  const service = services.find(s => s.id === token.serviceCategoryId);
  const avgDurationMinutes = service ? service.defaultDurationMinutes : 10;

  // Active service counters for this service category (or flexible counters serving ALL)
  const activeCountersList = counters.filter(
    c => c.status === 'OPEN' && (c.assignedServiceId === token.serviceCategoryId || c.assignedServiceId === 'ALL')
  );
  const activeCounters = Math.max(activeCountersList.length, 1); // Avoid division by zero

  const { tokensAhead, higherPriorityAhead } = getQueuePositionDetails(token, allTokens, priorityLevels);

  // Priority adjustment: each higher priority token ahead can add ~15% variance
  const priorityAdjustmentMinutes = Math.round(higherPriorityAhead * avgDurationMinutes * 0.15);

  // Base formula
  const baseWaitTimeMinutes = (tokensAhead * avgDurationMinutes) / activeCounters;

  // Total dynamic estimate
  const delayOffsetMinutes = token.delayOffsetMinutes || 0;
  const rawTotal = Math.round(baseWaitTimeMinutes + priorityAdjustmentMinutes + delayOffsetMinutes);

  // If tokensAhead is 0 and counter is currently serving someone, it's ~3-5 mins remaining
  const estimatedMinutes = tokensAhead === 0 ? Math.max(2, Math.round(avgDurationMinutes * 0.4)) : Math.max(1, rawTotal);

  return {
    estimatedMinutes,
    tokensAhead,
    activeCounters: activeCountersList.length,
    avgDurationMinutes,
    priorityAdjustmentMinutes,
    delayOffsetMinutes,
    disclaimer: 'Dynamic algorithmic prediction based on real-time counter velocity. Subject to change.'
  };
}

/**
 * Detects bottlenecks and generates intelligent administrative suggestions.
 */
export function analyzeQueueAndGenerateSuggestions(
  tokens: Token[],
  counters: Counter[],
  services: ServiceCategory[],
  priorityLevels: PriorityLevel[]
): IntelligentSuggestion[] {
  const suggestions: IntelligentSuggestion[] = [];
  const waitingTokens = tokens.filter(t => t.status === 'WAITING');

  // 1. Check for overcrowding per service category
  for (const service of services) {
    const serviceWaiting = waitingTokens.filter(t => t.serviceCategoryId === service.id);
    const activeCounters = counters.filter(
      c => c.status === 'OPEN' && (c.assignedServiceId === service.id || c.assignedServiceId === 'ALL')
    );

    const ratio = activeCounters.length > 0 ? serviceWaiting.length / activeCounters.length : serviceWaiting.length;

    if (activeCounters.length === 0 && serviceWaiting.length > 0) {
      suggestions.push({
        id: `crit-no-counter-${service.id}`,
        type: 'BOTTLENECK',
        severity: 'critical',
        title: `Zero Active Counters for ${service.name}`,
        message: `${serviceWaiting.length} customer(s) are waiting with no active counters assigned. Immediate counter assignment required!`,
        metric: `${serviceWaiting.length} unserviced`,
        suggestedAction: {
          type: 'OPEN_COUNTER',
          targetServiceId: service.id
        },
        createdAt: Date.now(),
        dismissed: false
      });
    } else if (ratio >= 6) {
      // Overcrowding threshold triggered
      // Find if there is an idle counter assigned to a low-demand service
      const idleCounter = counters.find(c => {
        if (c.status !== 'OPEN' || c.assignedServiceId === service.id) return false;
        const otherWaiting = waitingTokens.filter(t => t.serviceCategoryId === c.assignedServiceId).length;
        return otherWaiting <= 1 && c.currentServedTokenId === null;
      });

      if (idleCounter) {
        suggestions.push({
          id: `realloc-${idleCounter.id}-${service.id}`,
          type: 'REALLOCATION',
          severity: 'warning',
          title: `Counter Reallocation Recommended`,
          message: `${idleCounter.name} is currently idle. Recommend reallocating to '${service.name}' due to queue spike (${serviceWaiting.length} waiting).`,
          metric: `${ratio.toFixed(1)} tokens/counter`,
          suggestedAction: {
            type: 'REALLOCATE_COUNTER',
            counterId: idleCounter.id,
            targetServiceId: service.id,
            recommendedStaff: idleCounter.staffName
          },
          createdAt: Date.now(),
          dismissed: false
        });
      } else {
        suggestions.push({
          id: `bottleneck-${service.id}`,
          type: 'BOTTLENECK',
          severity: 'warning',
          title: `High Queue Density in ${service.name}`,
          message: `Current queue depth is ${serviceWaiting.length} tokens across ${activeCounters.length} active counter(s). Average wait is exceeding nominal targets.`,
          metric: `${ratio.toFixed(1)} load factor`,
          suggestedAction: {
            type: 'OPEN_COUNTER',
            targetServiceId: service.id
          },
          createdAt: Date.now(),
          dismissed: false
        });
      }
    }
  }

  // 2. Check for overdue priority tokens
  const emergencyTokens = waitingTokens.filter(t => t.priorityLevelId === 'EMERGENCY');
  if (emergencyTokens.length > 0) {
    const oldestEmergency = emergencyTokens[0];
    const waitingMins = Math.round((Date.now() - oldestEmergency.createdAt) / 60000);
    if (waitingMins >= 5) {
      suggestions.push({
        id: `emergency-alert-${oldestEmergency.id}`,
        type: 'SPIKE_PREDICTION',
        severity: 'critical',
        title: `Urgent: Emergency Token Waiting`,
        message: `Token ${oldestEmergency.id} (${oldestEmergency.customerName}) has been waiting for ${waitingMins} minutes. Intercept next available counter!`,
        metric: `${waitingMins}m wait`,
        suggestedAction: {
          type: 'EXPEDITE_PRIORITY',
          targetServiceId: oldestEmergency.serviceCategoryId
        },
        createdAt: Date.now(),
        dismissed: false
      });
    }
  }

  return suggestions;
}

