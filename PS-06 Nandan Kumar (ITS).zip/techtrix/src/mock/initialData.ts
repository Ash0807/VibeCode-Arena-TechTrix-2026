import { ServiceCategory, PriorityLevel, Counter, Token, IntelligentSuggestion } from '../types/queue';

export const INITIAL_SERVICES: ServiceCategory[] = [
  {
    id: 'GENERAL',
    name: 'General Inquiry & Support',
    code: 'GEN',
    iconName: 'HelpCircle',
    description: 'General questions, registration guidance, ticket status inquiries.',
    defaultDurationMinutes: 8,
    colorTheme: {
      bg: 'bg-blue-500/10',
      text: 'text-blue-400',
      border: 'border-blue-500/30',
      accent: '#3b82f6'
    }
  },
  {
    id: 'TELLER',
    name: 'Teller & Cash Transactions',
    code: 'TEL',
    iconName: 'CreditCard',
    description: 'Cash deposits, withdrawals, fee payments, foreign currency exchange.',
    defaultDurationMinutes: 6,
    colorTheme: {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-400',
      border: 'border-emerald-500/30',
      accent: '#10b981'
    }
  },
  {
    id: 'MEDICAL',
    name: 'Medical Consultation & Triage',
    code: 'MED',
    iconName: 'Activity',
    description: 'Doctor appointments, preliminary vitals screening, urgent medical assessment.',
    defaultDurationMinutes: 15,
    colorTheme: {
      bg: 'bg-rose-500/10',
      text: 'text-rose-400',
      border: 'border-rose-500/30',
      accent: '#f43f5e'
    }
  },
  {
    id: 'DOCUMENT',
    name: 'Document Verification & Issuance',
    code: 'DOC',
    iconName: 'FileCheck',
    description: 'ID verification, certificate issuance, notary stamps, licensing checks.',
    defaultDurationMinutes: 12,
    colorTheme: {
      bg: 'bg-amber-500/10',
      text: 'text-amber-400',
      border: 'border-amber-500/30',
      accent: '#f59e0b'
    }
  }
];

export const INITIAL_PRIORITIES: PriorityLevel[] = [
  {
    id: 'EMERGENCY',
    name: 'Emergency / Urgent Care',
    code: 'EMG',
    weight: 400,
    badgeColor: 'bg-red-500/20 text-red-300 border-red-500/50',
    description: 'Acute pain, emergency medical symptoms, critical deadline filings.',
    ruleExplanation: 'Priority Tier 1: Immediate dispatch ahead of all regular and express lanes.',
    requiresVerification: true
  },
  {
    id: 'PWD',
    name: 'Persons with Disabilities (PWD)',
    code: 'PWD',
    weight: 300,
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/50',
    description: 'Physical or cognitive accessibility requirements, wheelchair assistance.',
    ruleExplanation: 'Priority Tier 2: Affirmative accessibility quota, slots directly behind emergency tokens.',
    requiresVerification: true
  },
  {
    id: 'SENIOR_PREGNANT',
    name: 'Senior Citizen & Expectant Mother',
    code: 'SNR',
    weight: 200,
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/50',
    description: 'Ages 60+ or expectant mothers requiring reduced physical wait periods.',
    ruleExplanation: 'Priority Tier 3: Express privilege slots ahead of standard queue arrivals.',
    requiresVerification: false
  },
  {
    id: 'STANDARD',
    name: 'Standard Queue',
    code: 'STD',
    weight: 100,
    badgeColor: 'bg-slate-700/60 text-slate-300 border-slate-600',
    description: 'General public regular appointments and standard intake.',
    ruleExplanation: 'Priority Tier 4: Serviced strictly chronologically (First-In, First-Out).',
    requiresVerification: false
  }
];

const NOW = Date.now();

export const INITIAL_COUNTERS: Counter[] = [
  {
    id: 'COUNTER-1',
    counterNumber: 1,
    name: 'Counter 1 - Express Teller',
    staffName: 'Sarah Jenkins',
    assignedServiceId: 'TELLER',
    status: 'OPEN',
    currentServedTokenId: 'TEL-101',
    servedCountToday: 14,
    averageServeTimeMinutes: 5.5
  },
  {
    id: 'COUNTER-2',
    counterNumber: 2,
    name: 'Counter 2 - Document Verification',
    staffName: 'Michael Chang',
    assignedServiceId: 'DOCUMENT',
    status: 'OPEN',
    currentServedTokenId: 'DOC-102',
    servedCountToday: 9,
    averageServeTimeMinutes: 11.2
  },
  {
    id: 'COUNTER-3',
    counterNumber: 3,
    name: 'Counter 3 - Medical Triage',
    staffName: 'Dr. Amanda Vance',
    assignedServiceId: 'MEDICAL',
    status: 'OPEN',
    currentServedTokenId: 'MED-103',
    servedCountToday: 7,
    averageServeTimeMinutes: 14.8
  },
  {
    id: 'COUNTER-4',
    counterNumber: 4,
    name: 'Counter 4 - Flex & Support Desk',
    staffName: 'Robert Patel',
    assignedServiceId: 'ALL',
    status: 'OPEN',
    currentServedTokenId: null, // Idle! Good for reallocation trigger
    servedCountToday: 12,
    averageServeTimeMinutes: 7.9
  }
];

export const INITIAL_TOKENS: Token[] = [
  // Currently being served
  {
    id: 'TEL-101',
    sequenceNumber: 101,
    customerName: 'Marcus Bennett',
    phoneNumber: '+1 (555) 234-8901',
    serviceCategoryId: 'TELLER',
    priorityLevelId: 'STANDARD',
    status: 'SERVING',
    counterId: 'COUNTER-1',
    createdAt: NOW - 25 * 60000,
    calledAt: NOW - 3 * 60000,
    completedAt: null,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0
  },
  {
    id: 'DOC-102',
    sequenceNumber: 102,
    customerName: 'Elena Rostova',
    phoneNumber: '+1 (555) 432-1098',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'STANDARD',
    status: 'SERVING',
    counterId: 'COUNTER-2',
    createdAt: NOW - 30 * 60000,
    calledAt: NOW - 6 * 60000,
    completedAt: null,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0
  },
  {
    id: 'MED-103',
    sequenceNumber: 103,
    customerName: 'Devon Hayes',
    phoneNumber: '+1 (555) 890-7654',
    serviceCategoryId: 'MEDICAL',
    priorityLevelId: 'EMERGENCY',
    status: 'SERVING',
    counterId: 'COUNTER-3',
    createdAt: NOW - 18 * 60000,
    calledAt: NOW - 8 * 60000,
    completedAt: null,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0
  },

  // Waiting in queue (Showing priority slotting!)
  // In DOCUMENT service:
  {
    id: 'DOC-104',
    sequenceNumber: 104,
    customerName: 'Margaret O\'Connor',
    phoneNumber: '+1 (555) 345-6789',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'SENIOR_PREGNANT', // Senior should slot ahead of standard!
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 12 * 60000, // Arrived later than 105, but higher priority!
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 12,
    delayOffsetMinutes: 0,
    notes: 'Senior ID verified at gate'
  },
  {
    id: 'DOC-105',
    sequenceNumber: 105,
    customerName: 'Alexander Wu',
    phoneNumber: '+1 (555) 987-6543',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'STANDARD',
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 15 * 60000, // Arrived earlier, but standard priority
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 24,
    delayOffsetMinutes: 0
  },
  {
    id: 'DOC-106',
    sequenceNumber: 106,
    customerName: 'Sophia Martinez',
    phoneNumber: '+1 (555) 678-1234',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'PWD', // PWD slots ahead of Standard
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 8 * 60000,
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 18,
    delayOffsetMinutes: 0
  },
  {
    id: 'DOC-107',
    sequenceNumber: 107,
    customerName: 'Liam Chen',
    phoneNumber: '+1 (555) 456-7890',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'STANDARD',
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 6 * 60000,
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 30,
    delayOffsetMinutes: 0
  },

  // In TELLER service:
  {
    id: 'TEL-108',
    sequenceNumber: 108,
    customerName: 'Aria Thompson',
    phoneNumber: '+1 (555) 112-9988',
    serviceCategoryId: 'TELLER',
    priorityLevelId: 'STANDARD',
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 9 * 60000,
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 6,
    delayOffsetMinutes: 0
  },

  // In MEDICAL service:
  {
    id: 'MED-109',
    sequenceNumber: 109,
    customerName: 'Clara Oswald',
    phoneNumber: '+1 (555) 778-3344',
    serviceCategoryId: 'MEDICAL',
    priorityLevelId: 'STANDARD',
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 10 * 60000,
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 15,
    delayOffsetMinutes: 0
  },

  // In GENERAL service:
  {
    id: 'GEN-110',
    sequenceNumber: 110,
    customerName: 'David K. Miller',
    phoneNumber: '+1 (555) 889-1122',
    serviceCategoryId: 'GENERAL',
    priorityLevelId: 'STANDARD',
    status: 'WAITING',
    counterId: null,
    createdAt: NOW - 5 * 60000,
    calledAt: null,
    completedAt: null,
    estimatedWaitMinutes: 8,
    delayOffsetMinutes: 0
  },

  // History tokens (Completed & No-Show)
  {
    id: 'GEN-098',
    sequenceNumber: 98,
    customerName: 'Beatrice Vance',
    phoneNumber: '+1 (555) 321-7654',
    serviceCategoryId: 'GENERAL',
    priorityLevelId: 'STANDARD',
    status: 'COMPLETED',
    counterId: 'COUNTER-4',
    createdAt: NOW - 70 * 60000,
    calledAt: NOW - 55 * 60000,
    completedAt: NOW - 48 * 60000,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0
  },
  {
    id: 'TEL-099',
    sequenceNumber: 99,
    customerName: 'Lucas Thorne',
    phoneNumber: '+1 (555) 654-9870',
    serviceCategoryId: 'TELLER',
    priorityLevelId: 'STANDARD',
    status: 'COMPLETED',
    counterId: 'COUNTER-1',
    createdAt: NOW - 60 * 60000,
    calledAt: NOW - 45 * 60000,
    completedAt: NOW - 38 * 60000,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0
  },
  {
    id: 'DOC-100',
    sequenceNumber: 100,
    customerName: 'Priya Sharma',
    phoneNumber: '+1 (555) 998-1245',
    serviceCategoryId: 'DOCUMENT',
    priorityLevelId: 'STANDARD',
    status: 'NO_SHOW',
    counterId: 'COUNTER-2',
    createdAt: NOW - 50 * 60000,
    calledAt: NOW - 32 * 60000,
    completedAt: null,
    estimatedWaitMinutes: 0,
    delayOffsetMinutes: 0,
    notes: 'Customer failed to report after 3 audible calls'
  }
];

export const INITIAL_SUGGESTIONS: IntelligentSuggestion[] = [
  {
    id: 'realloc-counter-4-doc',
    type: 'REALLOCATION',
    severity: 'warning',
    title: 'Counter 4 Idle — Spiking Document Queue',
    message: 'Counter 4 (Robert Patel) is currently idle while Document Verification has 4 customers in queue. Recommend reallocating to Document Verification.',
    metric: '4 in queue / 1 counter',
    suggestedAction: {
      type: 'REALLOCATE_COUNTER',
      counterId: 'COUNTER-4',
      targetServiceId: 'DOCUMENT',
      recommendedStaff: 'Robert Patel'
    },
    createdAt: NOW - 2 * 60000,
    dismissed: false
  }
];

