import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Token,
  Counter,
  ServiceCategory,
  PriorityLevel,
  NotificationAlert,
  IntelligentSuggestion,
  QueueAnalytics,
  CreateTokenDto,
  ServiceCategoryId,
  CounterStatus
} from '../types/queue';
import {
  INITIAL_SERVICES,
  INITIAL_PRIORITIES,
  INITIAL_COUNTERS,
  INITIAL_TOKENS,
  INITIAL_SUGGESTIONS
} from '../mock/initialData';
import {
  sortQueueTokens,
  calculateDynamicWaitTime,
  analyzeQueueAndGenerateSuggestions,
  getQueuePositionDetails
} from '../utils/queueLogic';

interface QueueContextType {
  tokens: Token[];
  counters: Counter[];
  services: ServiceCategory[];
  priorities: PriorityLevel[];
  activeUserTokenId: string | null;
  notifications: NotificationAlert[];
  suggestions: IntelligentSuggestion[];
  isSimulationRunning: boolean;
  simulationSpeed: number;
  analytics: QueueAnalytics;
  
  // User Actions
  generateToken: (dto: CreateTokenDto) => Token;
  cancelToken: (tokenId: string, reason?: string) => void;
  setActiveUserTokenId: (id: string | null) => void;
  dismissNotification: (id: string) => void;

  // Staff & Admin Actions
  callNextToken: (counterId: string) => Token | null;
  completeCurrentToken: (counterId: string) => void;
  markNoShow: (counterId: string) => void;
  reassignToken: (tokenId: string, targetCounterId: string) => void;
  updateCounterStatus: (counterId: string, status: CounterStatus) => void;
  reallocateCounterService: (counterId: string, newServiceId: ServiceCategoryId | 'ALL') => void;
  applySuggestion: (suggestionId: string) => void;
  dismissSuggestion: (suggestionId: string) => void;
  triggerManualDelay: (tokenId: string, delayMinutes: number) => void;

  // Simulation Actions
  simulateNextStep: () => void;
  toggleSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  injectRandomCustomer: () => Token;
  resetData: () => void;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tokens, setTokens] = useState<Token[]>(INITIAL_TOKENS);
  const [counters, setCounters] = useState<Counter[]>(INITIAL_COUNTERS);
  const [services] = useState<ServiceCategory[]>(INITIAL_SERVICES);
  const [priorities] = useState<PriorityLevel[]>(INITIAL_PRIORITIES);
  const [activeUserTokenId, setActiveUserTokenId] = useState<string | null>('DOC-104'); // default preview token
  const [notifications, setNotifications] = useState<NotificationAlert[]>([
    {
      id: 'notif-init-1',
      tokenId: 'DOC-104',
      customerName: 'Margaret O\'Connor',
      type: 'TURN_APPROACHING',
      title: 'Queue Position Update',
      message: 'You are now #1 in line for Document Verification! Please stand near Counter 2.',
      timestamp: Date.now() - 60000,
      isRead: false,
      priority: 'high'
    }
  ]);
  const [suggestions, setSuggestions] = useState<IntelligentSuggestion[]>(INITIAL_SUGGESTIONS);
  const [isSimulationRunning, setIsSimulationRunning] = useState<boolean>(false);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const counterStateRef = useRef(counters);
  const tokenStateRef = useRef(tokens);

  useEffect(() => {
    counterStateRef.current = counters;
  }, [counters]);

  useEffect(() => {
    tokenStateRef.current = tokens;
  }, [tokens]);

  // Helper to push a notification alert
  const pushNotification = useCallback((
    tokenId: string,
    customerName: string,
    type: NotificationAlert['type'],
    title: string,
    message: string,
    priority: NotificationAlert['priority'] = 'medium'
  ) => {
    const newAlert: NotificationAlert = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tokenId,
      customerName,
      type,
      title,
      message,
      timestamp: Date.now(),
      isRead: false,
      priority
    };
    setNotifications(prev => [newAlert, ...prev.slice(0, 19)]);
  }, []);

  // Update dynamic wait times for all waiting tokens
  const refreshDynamicWaitTimes = useCallback((currentTokens: Token[], currentCounters: Counter[]) => {
    return currentTokens.map(t => {
      if (t.status !== 'WAITING') return t;
      const calc = calculateDynamicWaitTime(t, currentTokens, currentCounters, services, priorities);
      return {
        ...t,
        estimatedWaitMinutes: calc.estimatedMinutes
      };
    });
  }, [services, priorities]);

  // Generate deterministic token ID: CODE-###
  const generateToken = useCallback((dto: CreateTokenDto): Token => {
    const service = services.find(s => s.id === dto.serviceCategoryId);
    const serviceCode = service ? service.code : 'GEN';

    const existingForService = tokenStateRef.current.filter(t => t.serviceCategoryId === dto.serviceCategoryId);
    const maxSeq = existingForService.reduce((max, t) => Math.max(max, t.sequenceNumber), 100);
    const nextSeq = maxSeq + 1;
    const tokenId = `${serviceCode}-${nextSeq}`;

    const priority = priorities.find(p => p.id === dto.priorityLevelId);

    const tempToken: Token = {
      id: tokenId,
      sequenceNumber: nextSeq,
      customerName: dto.customerName.trim(),
      phoneNumber: dto.phoneNumber.trim(),
      serviceCategoryId: dto.serviceCategoryId,
      priorityLevelId: dto.priorityLevelId,
      status: 'WAITING',
      counterId: null,
      createdAt: Date.now(),
      calledAt: null,
      completedAt: null,
      estimatedWaitMinutes: service ? service.defaultDurationMinutes : 10,
      delayOffsetMinutes: 0,
      notes: dto.notes
    };

    setTokens(prev => {
      const updated = [...prev, tempToken];
      return refreshDynamicWaitTimes(updated, counterStateRef.current);
    });

    setActiveUserTokenId(tokenId);

    pushNotification(
      tokenId,
      dto.customerName,
      'GENERAL',
      'Token Issued Successfully',
      `Welcome ${dto.customerName}! Your token ${tokenId} has been registered under ${priority?.name || 'Standard'}.`,
      'medium'
    );

    return tempToken;
  }, [services, priorities, refreshDynamicWaitTimes, pushNotification]);

  // Cancel Token
  const cancelToken = useCallback((tokenId: string, reason = 'Cancelled by user') => {
    setTokens(prev => {
      const updated = prev.map(t => {
        if (t.id === tokenId) {
          return {
            ...t,
            status: 'CANCELLED' as const,
            cancellationReason: reason,
            completedAt: Date.now()
          };
        }
        return t;
      });
      return refreshDynamicWaitTimes(updated, counterStateRef.current);
    });

    const targetToken = tokenStateRef.current.find(t => t.id === tokenId);
    if (targetToken) {
      pushNotification(
        tokenId,
        targetToken.customerName,
        'GENERAL',
        'Token Cancelled',
        `Token ${tokenId} was cancelled. Any queue positions behind have been adjusted.`,
        'low'
      );
    }
  }, [refreshDynamicWaitTimes, pushNotification]);

  // Call Next Token for a Counter
  const callNextToken = useCallback((counterId: string): Token | null => {
    const counter = counterStateRef.current.find(c => c.id === counterId);
    if (!counter || counter.status !== 'OPEN') return null;

    const liveTokens = tokenStateRef.current;
    const eligibleWaiting = liveTokens.filter(t => {
      if (t.status !== 'WAITING') return false;
      if (counter.assignedServiceId === 'ALL') return true;
      return t.serviceCategoryId === counter.assignedServiceId;
    });

    if (eligibleWaiting.length === 0) {
      return null;
    }

    const sorted = sortQueueTokens(eligibleWaiting, priorities);
    const nextToken = sorted[0];

    setTokens(prev => {
      const updated = prev.map(t => {
        if (t.id === counter.currentServedTokenId && t.status === 'SERVING') {
          return {
            ...t,
            status: 'COMPLETED' as const,
            completedAt: Date.now()
          };
        }
        if (t.id === nextToken.id) {
          return {
            ...t,
            status: 'SERVING' as const,
            counterId: counterId,
            calledAt: Date.now()
          };
        }
        return t;
      });
      return refreshDynamicWaitTimes(updated, counterStateRef.current);
    });

    setCounters(prev =>
      prev.map(c => {
        if (c.id === counterId) {
          return {
            ...c,
            currentServedTokenId: nextToken.id,
            servedCountToday: c.servedCountToday + (c.currentServedTokenId ? 1 : 0)
          };
        }
        return c;
      })
    );

    pushNotification(
      nextToken.id,
      nextToken.customerName,
      'CALLED',
      `Now Calling: ${nextToken.id}`,
      `Please proceed to ${counter.name} (Staff: ${counter.staffName}).`,
      'high'
    );

    const remainingWaiting = eligibleWaiting.filter(t => t.id !== nextToken.id);
    if (remainingWaiting.length > 0) {
      const approaching = sortQueueTokens(remainingWaiting, priorities)[0];
      pushNotification(
        approaching.id,
        approaching.customerName,
        'TURN_APPROACHING',
        'Your Turn is Approaching!',
        `You are next in line! Please prepare your documents and be near ${counter.name}.`,
        'high'
      );
    }

    return nextToken;
  }, [priorities, refreshDynamicWaitTimes, pushNotification]);

  // Complete Current Token
  const completeCurrentToken = useCallback((counterId: string) => {
    const counter = counterStateRef.current.find(c => c.id === counterId);
    if (!counter || !counter.currentServedTokenId) return;

    const currentTokenId = counter.currentServedTokenId;

    setTokens(prev => {
      const updated = prev.map(t => {
        if (t.id === currentTokenId) {
          return {
            ...t,
            status: 'COMPLETED' as const,
            completedAt: Date.now()
          };
        }
        return t;
      });
      return refreshDynamicWaitTimes(updated, counterStateRef.current);
    });

    setCounters(prev =>
      prev.map(c => {
        if (c.id === counterId) {
          return {
            ...c,
            currentServedTokenId: null,
            servedCountToday: c.servedCountToday + 1
          };
        }
        return c;
      })
    );

    const completedToken = tokenStateRef.current.find(t => t.id === currentTokenId);
    if (completedToken) {
      pushNotification(
        currentTokenId,
        completedToken.customerName,
        'GENERAL',
        'Service Completed',
        `Transaction for ${currentTokenId} at ${counter.name} was successfully concluded.`,
        'low'
      );
    }
  }, [refreshDynamicWaitTimes, pushNotification]);

  // Mark No-Show
  const markNoShow = useCallback((counterId: string) => {
    const counter = counterStateRef.current.find(c => c.id === counterId);
    if (!counter || !counter.currentServedTokenId) return;

    const currentTokenId = counter.currentServedTokenId;

    setTokens(prev => {
      const updated = prev.map(t => {
        if (t.id === currentTokenId) {
          return {
            ...t,
            status: 'NO_SHOW' as const,
            completedAt: Date.now(),
            notes: 'Customer did not show up after call'
          };
        }
        return t;
      });
      return refreshDynamicWaitTimes(updated, counterStateRef.current);
    });

    setCounters(prev =>
      prev.map(c => (c.id === counterId ? { ...c, currentServedTokenId: null } : c))
    );

    pushNotification(
      currentTokenId,
      'Customer',
      'GENERAL',
      'Marked as No-Show',
      `Token ${currentTokenId} was recorded as No-Show. Counter ${counter.counterNumber} is now ready for the next customer.`,
      'medium'
    );
  }, [refreshDynamicWaitTimes, pushNotification]);

  // Reassign Token to another counter
  const reassignToken = useCallback((tokenId: string, targetCounterId: string) => {
    const counter = counterStateRef.current.find(c => c.id === targetCounterId);
    if (!counter) return;

    setTokens(prev =>
      prev.map(t => {
        if (t.id === tokenId) {
          return {
            ...t,
            counterId: targetCounterId,
            notes: `Reassigned to ${counter.name}`
          };
        }
        return t;
      })
    );

    const token = tokenStateRef.current.find(t => t.id === tokenId);
    if (token) {
      pushNotification(
        tokenId,
        token.customerName,
        'WAIT_TIME_UPDATED',
        'Counter Reassigned',
        `Your token ${tokenId} has been redirected to ${counter.name}.`,
        'medium'
      );
    }
  }, [pushNotification]);

  // Update Counter Status (OPEN / PAUSED / CLOSED) with edge-case handling
  const updateCounterStatus = useCallback((counterId: string, status: CounterStatus) => {
    setCounters(prev => {
      const updatedCounters = prev.map(c => {
        if (c.id === counterId) {
          return { ...c, status };
        }
        return c;
      });

      setTokens(prevTokens => refreshDynamicWaitTimes(prevTokens, updatedCounters));
      return updatedCounters;
    });

    const targetCounter = counterStateRef.current.find(c => c.id === counterId);
    if (status === 'CLOSED' || status === 'PAUSED') {
      if (targetCounter?.currentServedTokenId) {
        pushNotification(
          targetCounter.currentServedTokenId,
          'Active Customer',
          'WAIT_TIME_UPDATED',
          'Counter Paused/Closed',
          `${targetCounter.name} is now ${status}. Please wait while staff completes or safely transfers your ticket.`,
          'high'
        );
      }
    }
  }, [refreshDynamicWaitTimes, pushNotification]);

  // Reallocate Counter Service Category
  const reallocateCounterService = useCallback((counterId: string, newServiceId: ServiceCategoryId | 'ALL') => {
    setCounters(prev => {
      const updated = prev.map(c => (c.id === counterId ? { ...c, assignedServiceId: newServiceId } : c));
      setTokens(prevTokens => refreshDynamicWaitTimes(prevTokens, updated));
      return updated;
    });

    const counter = counterStateRef.current.find(c => c.id === counterId);
    const serviceName = newServiceId === 'ALL' ? 'All Flexible Services' : services.find(s => s.id === newServiceId)?.name;
    pushNotification(
      'SYSTEM',
      'System Alert',
      'GENERAL',
      'Counter Reallocated',
      `${counter?.name} is now dedicated to: ${serviceName}.`,
      'low'
    );
  }, [services, refreshDynamicWaitTimes, pushNotification]);

  // Apply AI Suggestion with 1-click
  const applySuggestion = useCallback((suggestionId: string) => {
    const suggestion = suggestions.find(s => s.id === suggestionId);
    if (!suggestion) return;

    if (suggestion.suggestedAction.type === 'REALLOCATE_COUNTER' && suggestion.suggestedAction.counterId && suggestion.suggestedAction.targetServiceId) {
      reallocateCounterService(suggestion.suggestedAction.counterId, suggestion.suggestedAction.targetServiceId);
    } else if (suggestion.suggestedAction.type === 'OPEN_COUNTER') {
      const closedCounter = counterStateRef.current.find(c => c.status !== 'OPEN');
      if (closedCounter) {
        updateCounterStatus(closedCounter.id, 'OPEN');
        if (suggestion.suggestedAction.targetServiceId) {
          reallocateCounterService(closedCounter.id, suggestion.suggestedAction.targetServiceId);
        }
      }
    }

    setSuggestions(prev => prev.filter(s => s.id !== suggestionId));
  }, [suggestions, reallocateCounterService, updateCounterStatus]);

  const dismissSuggestion = useCallback((suggestionId: string) => {
    setSuggestions(prev => prev.filter(s => s.id !== suggestionId));
  }, []);

  // Trigger manual or simulated delay (+5 mins)
  const triggerManualDelay = useCallback((tokenId: string, delayMinutes: number) => {
    setTokens(prev => {
      const updated = prev.map(t => {
        if (t.id === tokenId) {
          const newDelay = (t.delayOffsetMinutes || 0) + delayMinutes;
          return {
            ...t,
            delayOffsetMinutes: newDelay,
            estimatedWaitMinutes: Math.max(1, t.estimatedWaitMinutes + delayMinutes)
          };
        }
        return t;
      });
      return updated;
    });

    const token = tokenStateRef.current.find(t => t.id === tokenId);
    if (token) {
      pushNotification(
        tokenId,
        token.customerName,
        'WAIT_TIME_UPDATED',
        'Estimated Wait Time Updated',
        `Notice: Estimated wait time updated (+${delayMinutes} mins due to service complexity at counter).`,
        'medium'
      );
    }
  }, [pushNotification]);

  // Periodically refresh AI suggestions based on live queue depth & idle counters
  useEffect(() => {
    const detected = analyzeQueueAndGenerateSuggestions(tokens, counters, services, priorities);
    if (detected.length > 0) {
      setSuggestions(prev => {
        const existingIds = new Set(prev.map(p => p.id));
        const newOnes = detected.filter(d => !existingIds.has(d.id));
        return [...newOnes, ...prev];
      });
    }
  }, [tokens, counters, services, priorities]);

  // Inject Random Customer for testing/simulation
  const injectRandomCustomer = useCallback((): Token => {
    const sampleNames = [
      'Sarah Connor', 'Jonathan Wick', 'Natasha Romanoff', 'Bruce Wayne',
      'Arthur Pendelton', 'Maya Lin', 'Carlos Santana', 'Zoya Akhtar',
      'Gabriel Silva', 'Ingrid Bergman'
    ];
    const randomName = sampleNames[Math.floor(Math.random() * sampleNames.length)];
    const randomPhone = `+1 (555) ${Math.floor(100 + Math.random() * 900)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const randomService = services[Math.floor(Math.random() * services.length)].id;

    // 80% standard, 10% Senior, 7% PWD, 3% Emergency
    const rand = Math.random();
    let randomPriority: PriorityLevel['id'] = 'STANDARD';
    if (rand < 0.04) randomPriority = 'EMERGENCY';
    else if (rand < 0.12) randomPriority = 'PWD';
    else if (rand < 0.25) randomPriority = 'SENIOR_PREGNANT';

    return generateToken({
      customerName: randomName,
      phoneNumber: randomPhone,
      serviceCategoryId: randomService,
      priorityLevelId: randomPriority
    });
  }, [services, generateToken]);

  // Simulation step: Advances queue
  const simulateNextStep = useCallback(() => {
    // 1. Pick a counter that is serving and randomly finish their service
    const servingCounters = counters.filter(c => c.status === 'OPEN' && c.currentServedTokenId !== null);
    if (servingCounters.length > 0) {
      const chosen = servingCounters[Math.floor(Math.random() * servingCounters.length)];
      completeCurrentToken(chosen.id);
    }

    // 2. Pick an open counter that is idle and call next
    const idleCounters = counters.filter(c => c.status === 'OPEN' && c.currentServedTokenId === null);
    if (idleCounters.length > 0) {
      const chosen = idleCounters[0];
      callNextToken(chosen.id);
    } else if (servingCounters.length === 0) {
      // If all idle, call next on counter 1
      const openCounters = counters.filter(c => c.status === 'OPEN');
      if (openCounters.length > 0) {
        callNextToken(openCounters[0].id);
      }
    }

    // 3. Occasionally inject a new customer (40% probability)
    if (Math.random() < 0.45) {
      injectRandomCustomer();
    }
  }, [counters, completeCurrentToken, callNextToken, injectRandomCustomer]);

  // Simulation timer effect
  useEffect(() => {
    if (!isSimulationRunning) return;

    const intervalMs = Math.max(1000, Math.round(5000 / simulationSpeed));
    const interval = setInterval(() => {
      simulateNextStep();
    }, intervalMs);

    return () => clearInterval(interval);
  }, [isSimulationRunning, simulationSpeed, simulateNextStep]);

  const toggleSimulation = useCallback(() => {
    setIsSimulationRunning(prev => !prev);
  }, []);

  const resetData = useCallback(() => {
    setTokens(INITIAL_TOKENS);
    setCounters(INITIAL_COUNTERS);
    setSuggestions(INITIAL_SUGGESTIONS);
    setActiveUserTokenId('DOC-104');
    setIsSimulationRunning(false);
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  // Compute live analytics
  const analytics: QueueAnalytics = useMemo(() => {
    const totalRegistered = tokens.length;
    const totalServed = tokens.filter(t => t.status === 'COMPLETED').length;
    const totalWaiting = tokens.filter(t => t.status === 'WAITING').length;
    const totalNoShow = tokens.filter(t => t.status === 'NO_SHOW').length;
    const totalCancelled = tokens.filter(t => t.status === 'CANCELLED').length;

    // Calculate average wait time per category
    const completedTokens = tokens.filter(t => t.status === 'COMPLETED' && t.calledAt);
    const avgWaitByService: Record<ServiceCategoryId, number> = {
      GENERAL: 7,
      TELLER: 5,
      MEDICAL: 14,
      DOCUMENT: 11
    };

    services.forEach(s => {
      const servedInService = completedTokens.filter(t => t.serviceCategoryId === s.id);
      if (servedInService.length > 0) {
        const totalWait = servedInService.reduce((sum, t) => {
          const waitMins = Math.max(1, Math.round(((t.calledAt || t.createdAt) - t.createdAt) / 60000));
          return sum + waitMins;
        }, 0);
        avgWaitByService[s.id] = Math.round(totalWait / servedInService.length);
      }
    });

    const activeCountersCount = counters.filter(c => c.status === 'OPEN').length;

    return {
      totalRegistered,
      totalServed,
      totalWaiting,
      totalNoShow,
      totalCancelled,
      averageWaitTimeOverall: Math.round(
        Object.values(avgWaitByService).reduce((a, b) => a + b, 0) / services.length
      ),
      averageWaitTimeByService: avgWaitByService,
      activeCountersCount,
      serviceEfficiencyScore: Math.min(98, Math.max(65, Math.round(100 - (totalWaiting * 2.5)))),
      peakHourTrends: [
        { hour: '09:00', demand: 18, served: 16 },
        { hour: '10:00', demand: 32, served: 28 },
        { hour: '11:00', demand: 45, served: 38 },
        { hour: '12:00', demand: 28, served: 26 },
        { hour: '13:00', demand: 22, served: 22 },
        { hour: '14:00', demand: 38, served: 33 },
        { hour: '15:00 (Now)', demand: 41, served: 35 }
      ]
    };
  }, [tokens, counters, services]);

  return (
    <QueueContext.Provider
      value={{
        tokens,
        counters,
        services,
        priorities,
        activeUserTokenId,
        notifications,
        suggestions,
        isSimulationRunning,
        simulationSpeed,
        analytics,
        generateToken,
        cancelToken,
        setActiveUserTokenId,
        dismissNotification,
        callNextToken,
        completeCurrentToken,
        markNoShow,
        reassignToken,
        updateCounterStatus,
        reallocateCounterService,
        applySuggestion,
        dismissSuggestion,
        triggerManualDelay,
        simulateNextStep,
        toggleSimulation,
        setSimulationSpeed,
        injectRandomCustomer,
        resetData
      }}
    >
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = (): QueueContextType => {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};

