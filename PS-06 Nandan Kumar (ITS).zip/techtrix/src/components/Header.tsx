import React from 'react';
import { useQueue } from '../context/QueueContext';
import {
  Layers,
  Monitor,
  ShieldCheck,
  BarChart3,
  Play,
  Pause,
  FastForward,
  UserPlus,
  RotateCcw,
  Bell,
  Sparkles
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'user' | 'display' | 'admin' | 'analytics';
  onTabChange: (tab: 'user' | 'display' | 'admin' | 'analytics') => void;
  unreadCount: number;
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  unreadCount,
  onOpenNotifications
}) => {
  const {
    isSimulationRunning,
    toggleSimulation,
    simulateNextStep,
    simulationSpeed,
    setSimulationSpeed,
    injectRandomCustomer,
    resetData,
    suggestions
  } = useQueue();

  const activeSuggestionsCount = suggestions.filter(s => !s.dismissed).length;

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 shadow-lg shadow-cyan-500/20 text-white font-black text-xl">
              <span>Q</span>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  QueueSmart <span className="text-cyan-400">AI</span>
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800/60 rounded-full">
                  <Sparkles className="w-3 h-3" /> v2.4 Live
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden md:block">
                Autonomous Digital Flow & Wait-Time Engine
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 shadow-inner">
            <button
              onClick={() => onTabChange('user')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all ${
                currentTab === 'user'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Customer Portal</span>
            </button>

            <button
              onClick={() => onTabChange('display')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all ${
                currentTab === 'display'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>TV Display</span>
            </button>

            <button
              onClick={() => onTabChange('admin')}
              className={`relative flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all ${
                currentTab === 'admin'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Staff Dashboard</span>
              {activeSuggestionsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              )}
            </button>

            <button
              onClick={() => onTabChange('analytics')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all ${
                currentTab === 'analytics'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Analytics</span>
            </button>
          </nav>

          {/* Simulation Controls & Notification Trigger */}
          <div className="flex items-center gap-2">
            
            {/* Simulation Controller Hub */}
            <div className="hidden lg:flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs gap-1">
              <button
                onClick={toggleSimulation}
                title={isSimulationRunning ? "Pause Automated Flow" : "Start Automated Flow"}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-colors ${
                  isSimulationRunning
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30'
                }`}
              >
                {isSimulationRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isSimulationRunning ? 'Simulating' : 'Simulate'}</span>
              </button>

              <button
                onClick={simulateNextStep}
                title="Advance One Step (Call / Complete / Serve)"
                className="p-1.5 rounded-md text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <FastForward className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={injectRandomCustomer}
                title="Inject Random Customer into Queue"
                className="flex items-center gap-1 px-2 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>+Test User</span>
              </button>

              {/* Speed Toggle */}
              <div className="flex items-center border-l border-slate-800 pl-1 ml-1">
                {[1, 2, 5].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setSimulationSpeed(spd)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-medium ${
                      simulationSpeed === spd
                        ? 'bg-cyan-500 text-white font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>

              <button
                onClick={resetData}
                title="Reset Simulation to Initial State"
                className="p-1.5 rounded-md text-slate-400 hover:text-rose-400 hover:bg-slate-800 ml-0.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition"
              title="System Alerts & Customer Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm shadow-rose-500/50">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};

