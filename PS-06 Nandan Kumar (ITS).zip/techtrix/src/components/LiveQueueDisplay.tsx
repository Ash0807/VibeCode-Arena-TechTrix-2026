import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { sortQueueTokens } from '../utils/queueLogic';
import {
  Monitor,
  Volume2,
  VolumeX,
  Clock,
  Users,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

export const LiveQueueDisplay: React.FC = () => {
  const { counters, tokens, services, priorities, analytics } = useQueue();
  const [audioChimeEnabled, setAudioChimeEnabled] = useState(true);

  // Mask customer name for privacy (e.g. John Doe -> John D.***)
  const maskName = (name: string): string => {
    const parts = name.trim().split(' ');
    if (parts.length === 1) return parts[0];
    return `${parts[0]} ${parts[1][0]}.***`;
  };

  // Get waiting tokens sorted by priority rules
  const waitingTokens = sortQueueTokens(
    tokens.filter(t => t.status === 'WAITING'),
    priorities
  );

  return (
    <div className="py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
      
      {/* TV Screen Top Navigation & Live Clock Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-xl text-cyan-400">
            <Monitor className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span>CENTRAL QUEUE DISPLAY</span>
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Live Service Counters & Real-Time Hall Status Monitor
            </p>
          </div>
        </div>

        {/* Global Stats Summary Bar */}
        <div className="flex items-center gap-4 sm:gap-6 bg-slate-950 px-4 py-2.5 rounded-xl border border-slate-800 text-xs">
          <div className="text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Served</span>
            <span className="text-base font-black text-emerald-400 font-mono">{analytics.totalServed}</span>
          </div>
          <div className="h-6 w-px bg-slate-800"></div>
          <div className="text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Currently Waiting</span>
            <span className="text-base font-black text-amber-400 font-mono">{analytics.totalWaiting}</span>
          </div>
          <div className="h-6 w-px bg-slate-800"></div>
          <div className="text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Avg Wait</span>
            <span className="text-base font-black text-cyan-400 font-mono">~{analytics.averageWaitTimeOverall}m</span>
          </div>
          <div className="h-6 w-px bg-slate-800"></div>

          {/* Audio Chime Toggle */}
          <button
            onClick={() => setAudioChimeEnabled(!audioChimeEnabled)}
            className={`p-2 rounded-lg border transition ${
              audioChimeEnabled
                ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
            title={audioChimeEnabled ? 'Audio Chime Enabled' : 'Audio Chime Muted'}
          >
            {audioChimeEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* MAIN SCREEN: Active Service Counters Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Now Serving at Counters</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {counters.filter(c => c.status === 'OPEN').length} Active Desks
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {counters.map((counter) => {
            const currentToken = tokens.find(t => t.id === counter.currentServedTokenId);
            const assignedService = services.find(s => s.id === counter.assignedServiceId);
            const isServing = counter.status === 'OPEN' && currentToken;

            return (
              <div
                key={counter.id}
                className={`rounded-2xl border transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                  isServing
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-cyan-500/60 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/30'
                    : counter.status === 'PAUSED'
                    ? 'bg-slate-900/60 border-amber-500/40 opacity-80'
                    : counter.status === 'CLOSED'
                    ? 'bg-slate-950/80 border-slate-800 opacity-60'
                    : 'bg-slate-900/70 border-slate-800'
                }`}
              >
                {/* Counter Header */}
                <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-base text-white tracking-tight">
                      {counter.name}
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Officer: {counter.staffName}
                    </p>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border ${
                    counter.status === 'OPEN'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : counter.status === 'PAUSED'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  }`}>
                    {counter.status}
                  </span>
                </div>

                {/* Token Display Area */}
                <div className="p-6 text-center flex-1 flex flex-col items-center justify-center">
                  {counter.status !== 'OPEN' ? (
                    <div className="py-6 text-slate-500 space-y-1">
                      <ShieldAlert className="w-8 h-8 mx-auto text-slate-600 mb-1" />
                      <p className="text-sm font-semibold text-slate-400">
                        Desk Currently {counter.status}
                      </p>
                      <p className="text-xs text-slate-400">
                        Please proceed to adjacent open counters
                      </p>
                    </div>
                  ) : currentToken ? (
                    <div className="w-full space-y-2">
                      <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest block">
                        NOW CALLING
                      </span>

                      {/* Giant Token ID */}
                      <div className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white py-2 bg-gradient-to-r from-cyan-300 via-white to-cyan-400 bg-clip-text text-transparent">
                        {currentToken.id}
                      </div>

                      {/* Customer Name Mask */}
                      <div className="text-sm font-semibold text-slate-200">
                        {maskName(currentToken.customerName)}
                      </div>

                      {/* Priority Tag if applicable */}
                      {currentToken.priorityLevelId !== 'STANDARD' && (
                        <div className="mt-2 inline-block">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                            priorities.find(p => p.id === currentToken.priorityLevelId)?.badgeColor
                          }`}>
                            {priorities.find(p => p.id === currentToken.priorityLevelId)?.name}
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="py-6 text-slate-400 space-y-1">
                      <div className="w-3 h-3 rounded-full bg-slate-700 mx-auto mb-2 animate-ping"></div>
                      <p className="text-sm font-medium text-slate-300">Desk Ready</p>
                      <p className="text-xs text-slate-400">
                        Calling next available ticket...
                      </p>
                    </div>
                  )}
                </div>

                {/* Counter Footer Details */}
                <div className="p-3 bg-slate-950/70 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="truncate max-w-[140px] font-medium text-slate-300">
                    {assignedService ? assignedService.name : 'All General Services'}
                  </span>
                  <span className="font-mono text-emerald-400 font-semibold">
                    {counter.servedCountToday} served
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LOWER SECTION: UPCOMING NEXT TICKER & DEPARTMENT QUEUES */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Next in Line Queue Ticker (lg:col-span-8) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>Next in Line (Priority Sorted Live)</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              {waitingTokens.length} waiting total
            </span>
          </div>

          {waitingTokens.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {waitingTokens.slice(0, 6).map((t, idx) => {
                const srv = services.find(s => s.id === t.serviceCategoryId);
                const prio = priorities.find(p => p.id === t.priorityLevelId);

                return (
                  <div
                    key={t.id}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                        #{idx + 1} Next
                      </span>
                      <span className="font-mono text-xs font-black text-white">
                        {t.id}
                      </span>
                    </div>

                    <p className="text-xs font-medium text-slate-300 truncate">
                      {maskName(t.customerName)}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">
                      {srv?.name}
                    </p>

                    <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
                      <span className={`px-1.5 py-0.2 rounded border font-medium ${prio?.badgeColor}`}>
                        {prio?.code}
                      </span>
                      <span className="text-emerald-400 font-mono">
                        ~{t.estimatedWaitMinutes}m wait
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center text-slate-500">
              <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500/60 mb-2" />
              <p className="text-sm font-semibold text-slate-400">All Queues Clear</p>
              <p className="text-xs text-slate-400">
                No customers currently waiting in the active lobby.
              </p>
            </div>
          )}
        </div>

        {/* Department Wait Estimates Quick Card (lg:col-span-4) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2 pb-3 border-b border-slate-800 mb-4">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Department Wait Estimates</span>
            </h3>

            <div className="space-y-3">
              {services.map((srv) => {
                const count = tokens.filter(t => t.status === 'WAITING' && t.serviceCategoryId === srv.id).length;
                const activeCountersCount = counters.filter(
                  c => c.status === 'OPEN' && (c.assignedServiceId === srv.id || c.assignedServiceId === 'ALL')
                ).length;
                const estMins = activeCountersCount > 0 ? Math.round((count * srv.defaultDurationMinutes) / activeCountersCount) : 'N/A';

                return (
                  <div key={srv.id} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                    <div>
                      <p className="font-semibold text-slate-200">{srv.name}</p>
                      <span className="text-[10px] text-slate-400">
                        {count} in queue • {activeCountersCount} desk(s)
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        {typeof estMins === 'number' ? `~${Math.max(2, estMins)}m` : 'Closed'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-400 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            <span>Predictions continuously recalculated via QueueSmart dynamic velocity model.</span>
          </div>
        </div>

      </div>

    </div>
  );
};

