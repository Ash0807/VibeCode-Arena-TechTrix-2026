import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import {
  ServiceCategoryId,
  CounterStatus,
  Token
} from '../types/queue';
import { sortQueueTokens } from '../utils/queueLogic';
import {
  ShieldCheck,
  CheckCircle2,
  PhoneCall,
  UserX,
  ArrowRightLeft,
  AlertCircle,
  Play,
  Pause,
  XCircle,
  Sparkles,
  Zap,
  Clock,
  Filter,
  Search,
  Check,
  ChevronDown,
  Layers,
  Sliders
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    counters,
    tokens,
    services,
    priorities,
    callNextToken,
    completeCurrentToken,
    markNoShow,
    reassignToken,
    updateCounterStatus,
    reallocateCounterService,
    suggestions,
    applySuggestion,
    dismissSuggestion,
    triggerManualDelay,
    analytics
  } = useQueue();

  const [selectedServiceFilter, setSelectedServiceFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [reassignModalToken, setReassignModalToken] = useState<Token | null>(null);

  // Filter tokens
  const waitingTokens = tokens.filter(t => t.status === 'WAITING');
  const sortedWaitingTokens = sortQueueTokens(waitingTokens, priorities);

  const filteredTokens = sortedWaitingTokens.filter(t => {
    const matchesService = selectedServiceFilter === 'ALL' || t.serviceCategoryId === selectedServiceFilter;
    const matchesQuery = t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         t.customerName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesService && matchesQuery;
  });

  const activeSuggestions = suggestions.filter(s => !s.dismissed);

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* Top Header / Role Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Staff & Counter Command Center
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time counter orchestration, triage management & automated bottleneck resolution.
          </p>
        </div>

        {/* Quick Operational Pills */}
        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-slate-300 font-medium">Efficiency Index:</span>
            <span className="font-mono font-bold text-emerald-400">{analytics.serviceEfficiencyScore}%</span>
          </div>

          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center gap-2">
            <span className="text-slate-300 font-medium">Active Counters:</span>
            <span className="font-mono font-bold text-cyan-400">{analytics.activeCountersCount} / {counters.length}</span>
          </div>
        </div>
      </div>

      {/* MODULE D: INTELLIGENT AI ADVISOR & BOTTLENECK DETECTOR */}
      {activeSuggestions.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4" />
              <span>QueueSmart AI Autonomous Optimization Alerts ({activeSuggestions.length})</span>
            </h2>
            <span className="text-[11px] text-slate-400">
              Dynamic workload rebalancing suggestions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeSuggestions.map((sug) => (
              <div
                key={sug.id}
                className={`p-4 rounded-2xl border transition relative overflow-hidden flex flex-col justify-between ${
                  sug.severity === 'critical'
                    ? 'bg-rose-950/30 border-rose-500/50 text-rose-200'
                    : 'bg-amber-950/30 border-amber-500/50 text-amber-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="font-bold text-sm text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      {sug.title}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 border border-white/10 text-white font-bold">
                      {sug.metric}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-4">
                    {sug.message}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/10 gap-2">
                  <button
                    onClick={() => dismissSuggestion(sug.id)}
                    className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg transition"
                  >
                    Dismiss
                  </button>

                  <button
                    onClick={() => applySuggestion(sug.id)}
                    className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md transition flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply Recommendation</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODULE E - PART 1: SERVICE COUNTER HUBS */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>Counter Stations & Terminal Controls</span>
          </h2>
          <span className="text-xs text-slate-400">
            Click status pills to pause/open or reallocate service dedication
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {counters.map((c) => {
            const currentToken = tokens.find(t => t.id === c.currentServedTokenId);
            const assignedService = services.find(s => s.id === c.assignedServiceId);

            return (
              <div
                key={c.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4"
              >
                {/* Counter Header & Status Toggles */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-cyan-400">
                      DESK #{c.counterNumber}
                    </span>

                    {/* Status Dropdown/Selector */}
                    <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10px]">
                      {(['OPEN', 'PAUSED', 'CLOSED'] as CounterStatus[]).map((st) => (
                        <button
                          key={st}
                          onClick={() => updateCounterStatus(c.id, st)}
                          className={`px-2 py-0.5 rounded font-bold transition ${
                            c.status === st
                              ? st === 'OPEN'
                                ? 'bg-emerald-500 text-white'
                                : st === 'PAUSED'
                                ? 'bg-amber-500 text-slate-950'
                                : 'bg-rose-500 text-white'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <h3 className="font-extrabold text-base text-white">{c.name}</h3>
                  <p className="text-xs text-slate-400">Staff: {c.staffName}</p>

                  {/* Reallocation Service Dropdown */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80">
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      Assigned Department:
                    </label>
                    <select
                      value={c.assignedServiceId}
                      onChange={(e) => reallocateCounterService(c.id, e.target.value as ServiceCategoryId | 'ALL')}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="ALL">All Flexible Services</option>
                      {services.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Currently Serving Box */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                  {currentToken ? (
                    <div>
                      <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest block mb-1">
                        Currently Serving
                      </span>
                      <div className="text-2xl font-black font-mono text-white">
                        {currentToken.id}
                      </div>
                      <p className="text-xs font-semibold text-slate-300 truncate mt-0.5">
                        {currentToken.customerName}
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        Started: {currentToken.calledAt ? new Date(currentToken.calledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Now'}
                      </p>
                    </div>
                  ) : (
                    <div className="py-2">
                      <span className="text-xs font-medium text-slate-400 block">
                        Desk is Idle
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Ready to call next ticket
                      </span>
                    </div>
                  )}
                </div>

                {/* Staff Control Buttons */}
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => callNextToken(c.id)}
                      disabled={c.status !== 'OPEN'}
                      className="py-2 px-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:hover:bg-cyan-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Call Next</span>
                    </button>

                    <button
                      onClick={() => completeCurrentToken(c.id)}
                      disabled={!currentToken}
                      className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Complete</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => markNoShow(c.id)}
                      disabled={!currentToken}
                      className="py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 font-medium text-[11px] border border-slate-700 transition flex items-center justify-center gap-1"
                    >
                      <UserX className="w-3 h-3" />
                      <span>No-Show</span>
                    </button>

                    <button
                      onClick={() => currentToken && triggerManualDelay(currentToken.id, 5)}
                      disabled={!currentToken}
                      className="py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-amber-300 font-medium text-[11px] border border-amber-500/30 transition flex items-center justify-center gap-1"
                      title="Add 5 minute delay adjustment"
                    >
                      <Clock className="w-3 h-3" />
                      <span>+5m Delay</span>
                    </button>
                  </div>
                </div>

                {/* Counter Performance Footer */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Served Today: <strong className="text-white font-mono">{c.servedCountToday}</strong></span>
                  <span>Avg: <strong className="text-white font-mono">{c.averageServeTimeMinutes}m</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODULE E - PART 2: LIVE QUEUE REGISTRY & TRIAGE TABLE */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        
        {/* Table Filters & Search */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Active Waiting Queue Registry</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                {waitingTokens.length} in queue
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Sorted by Priority Rules & Arrival Timestamp (Affirmative Action Enforced)
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-56">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search token or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Department Filter */}
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedServiceFilter}
                onChange={(e) => setSelectedServiceFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">All Departments</option>
                {services.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Queue Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">Slot #</th>
                <th className="py-3 px-3">Token ID</th>
                <th className="py-3 px-3">Customer Name</th>
                <th className="py-3 px-3">Department</th>
                <th className="py-3 px-3">Priority Classification</th>
                <th className="py-3 px-3">Wait Estimate</th>
                <th className="py-3 px-3">Arrival Time</th>
                <th className="py-3 px-3 text-right">Triage Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTokens.length > 0 ? (
                filteredTokens.map((t, idx) => {
                  const srv = services.find(s => s.id === t.serviceCategoryId);
                  const prio = priorities.find(p => p.id === t.priorityLevelId);
                  const arrivalMins = Math.round((Date.now() - t.createdAt) / 60000);

                  return (
                    <tr
                      key={t.id}
                      className="hover:bg-slate-800/30 transition group"
                    >
                      <td className="py-3 px-3 font-mono font-bold text-cyan-400">
                        #{idx + 1}
                      </td>
                      <td className="py-3 px-3 font-mono font-black text-white text-sm">
                        {t.id}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-200">
                        {t.customerName}
                        <span className="block text-[10px] text-slate-400 font-mono">
                          {t.phoneNumber}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-300">
                        <span className="font-medium">{srv?.name}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${prio?.badgeColor}`}>
                          {prio?.name}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono font-semibold text-emerald-400">
                        ~{t.estimatedWaitMinutes} mins
                        {t.delayOffsetMinutes > 0 && (
                          <span className="text-[10px] text-amber-400 block font-normal">
                            (+{t.delayOffsetMinutes}m delay)
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-400 font-mono">
                        {arrivalMins}m ago
                      </td>
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Delay Button */}
                          <button
                            onClick={() => triggerManualDelay(t.id, 5)}
                            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-[10px] px-2 flex items-center gap-1"
                            title="Add 5m delay offset"
                          >
                            <Clock className="w-3 h-3" /> +5m
                          </button>

                          {/* Reassign Button */}
                          <button
                            onClick={() => setReassignModalToken(t)}
                            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-[10px] px-2 flex items-center gap-1"
                            title="Reassign to another counter"
                          >
                            <ArrowRightLeft className="w-3 h-3" /> Transfer
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No waiting tokens matching current filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* REASSIGN COUNTER MODAL */}
      {reassignModalToken && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-cyan-400" />
                <span>Reassign Token {reassignModalToken.id}</span>
              </h3>
              <button
                onClick={() => setReassignModalToken(null)}
                className="text-slate-400 hover:text-white"
              >
                <XCircle className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Select target service counter to expedite or transfer customer <strong className="text-white">{reassignModalToken.customerName}</strong>:
            </p>

            <div className="space-y-2">
              {counters.map(counter => (
                <div
                  key={counter.id}
                  onClick={() => {
                    reassignToken(reassignModalToken.id, counter.id);
                    setReassignModalToken(null);
                  }}
                  className="cursor-pointer p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 hover:bg-slate-800 transition flex items-center justify-between"
                >
                  <div>
                    <span className="font-semibold text-xs text-white">{counter.name}</span>
                    <span className="text-[10px] text-slate-400 block">
                      Staff: {counter.staffName} • {counter.status}
                    </span>
                  </div>
                  <span className="text-[11px] font-bold text-cyan-400">
                    Assign →
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

