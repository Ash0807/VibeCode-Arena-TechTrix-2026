import React from 'react';
import { useQueue } from '../context/QueueContext';
import {
  BarChart3,
  TrendingUp,
  Clock,
  Users,
  CheckCircle2,
  AlertOctagon,
  ArrowUpRight,
  ShieldCheck,
  Activity
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { analytics, services, counters, tokens } = useQueue();

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <BarChart3 className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Operational Performance & Queue Analytics
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Data-driven insights into customer throughput, bottleneck frequency, and SLA compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 animate-pulse" /> Live Telemetry
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Throughput</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">
            {analytics.totalServed}
          </div>
          <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-semibold flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +14%
            </span>
            vs previous session
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Active Backlog</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">
            {analytics.totalWaiting}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {analytics.activeCountersCount} active counters serving
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Wait Time</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">
            ~{analytics.averageWaitTimeOverall} <span className="text-base font-normal">mins</span>
          </div>
          <p className="text-xs text-emerald-400 mt-1">
            Within 15-min SLA threshold
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">No-Show / Drop Rate</span>
            <AlertOctagon className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">
            {analytics.totalNoShow}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {((analytics.totalNoShow / Math.max(1, analytics.totalRegistered)) * 100).toFixed(1)}% of total intake
          </p>
        </div>

      </div>

      {/* CHARTS & SERVICE BREAKDOWNS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Hourly Queue Demand vs Served Trends (lg:col-span-8) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>Peak Queue Time Trends (Hourly Influx vs Output)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Identifies peak bottleneck windows to dynamically pre-position staff.
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-2.5 h-2.5 rounded-sm bg-cyan-500"></span> Registered Intake
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span> Successfully Served
              </span>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          <div className="pt-6 pb-2">
            <div className="h-48 flex items-end gap-3 sm:gap-6 justify-between px-2">
              {analytics.peakHourTrends.map((bar, i) => {
                const maxVal = 50;
                const demandHeight = Math.round((bar.demand / maxVal) * 100);
                const servedHeight = Math.round((bar.served / maxVal) * 100);

                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <div className="w-full flex items-end justify-center gap-1.5 h-full">
                      {/* Demand Bar */}
                      <div
                        style={{ height: `${demandHeight}%` }}
                        className="w-1/2 bg-cyan-500/80 hover:bg-cyan-400 rounded-t-md transition-all relative group/bar"
                      >
                        <span className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover/bar:opacity-100 bg-slate-950 border border-slate-800 text-[10px] text-white px-1.5 py-0.5 rounded pointer-events-none transition font-mono">
                          {bar.demand}
                        </span>
                      </div>

                      {/* Served Bar */}
                      <div
                        style={{ height: `${servedHeight}%` }}
                        className="w-1/2 bg-emerald-500/80 hover:bg-emerald-400 rounded-t-md transition-all relative group/bar"
                      >
                        <span className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover/bar:opacity-100 bg-slate-950 border border-slate-800 text-[10px] text-white px-1.5 py-0.5 rounded pointer-events-none transition font-mono">
                          {bar.served}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] sm:text-xs text-slate-400 font-mono">
                      {bar.hour.split(' ')[0]}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl text-xs text-slate-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>
              <strong>Predictive Insight:</strong> Peak influx occurs between 10:30 - 11:45 AM. QueueSmart advises opening Counter 4 as flexible triage 20 minutes prior to anticipated influx.
            </span>
          </div>
        </div>

        {/* Average Wait Time by Category (lg:col-span-4) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2 pb-3 border-b border-slate-800 mb-4">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Wait Times by Service</span>
            </h3>

            <div className="space-y-4">
              {services.map((srv) => {
                const avgWait = analytics.averageWaitTimeByService[srv.id] || srv.defaultDurationMinutes;
                const percentage = Math.min(100, Math.round((avgWait / 25) * 100));

                return (
                  <div key={srv.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">{srv.name}</span>
                      <span className="font-mono font-bold text-cyan-400">{avgWait} mins</span>
                    </div>

                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        style={{ width: `${percentage}%` }}
                        className={`h-full rounded-full ${
                          avgWait > 15 ? 'bg-rose-500' : avgWait > 10 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Counter Utilization Summary */}
          <div className="pt-4 border-t border-slate-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Counter Productivity
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {counters.map(c => (
                <div key={c.id} className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="font-medium text-slate-300 block truncate">{c.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {c.servedCountToday} served • {c.averageServeTimeMinutes}m avg
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};

