import React from 'react';
import { useQueue } from '../context/QueueContext';
import {
  Bell,
  X,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Sparkles,
  Smartphone
} from 'lucide-react';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose
}) => {
  const { notifications, dismissNotification, setActiveUserTokenId } = useQueue();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Bell className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-bold text-base text-white">
                Turn Notifications & System Events
              </h2>
              <p className="text-xs text-slate-400">
                Simulated real-time push alerts sent to customer devices & staff.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alerts List */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1">
          {notifications.length > 0 ? (
            notifications.map((n) => {
              const isUrgent = n.type === 'CALLED' || n.type === 'TURN_APPROACHING';

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    n.type === 'CALLED'
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-100'
                      : n.type === 'TURN_APPROACHING'
                      ? 'bg-amber-950/20 border-amber-500/40 text-amber-100'
                      : 'bg-slate-950 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {n.type === 'CALLED' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      ) : n.type === 'TURN_APPROACHING' ? (
                        <Clock className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                      )}
                      <span className="font-bold text-xs text-white">
                        {n.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                      <button
                        onClick={() => dismissNotification(n.id)}
                        className="text-slate-500 hover:text-slate-300 text-xs"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
                    {n.message}
                  </p>

                  <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                    <span className="font-mono text-cyan-400">
                      Token: {n.tokenId} • {n.customerName}
                    </span>

                    {n.tokenId !== 'SYSTEM' && (
                      <button
                        onClick={() => {
                          setActiveUserTokenId(n.tokenId);
                          onClose();
                        }}
                        className="text-cyan-400 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <Smartphone className="w-3 h-3" /> View Token
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-slate-500">
              <Bell className="w-10 h-10 mx-auto text-slate-700 mb-2" />
              <p className="text-sm font-medium text-slate-400">No active notifications</p>
              <p className="text-xs text-slate-400 mt-1">
                Trigger queue events or start simulation to see notifications stream in.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-xs text-slate-400">
          In production, these events dispatch via SMS Gateway, WebSockets & Push Notifications.
        </div>
      </div>
    </div>
  );
};

