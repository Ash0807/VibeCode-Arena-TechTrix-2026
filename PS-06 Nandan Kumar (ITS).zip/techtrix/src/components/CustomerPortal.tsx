import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import {
  ServiceCategoryId,
  PriorityLevelId,
  CreateTokenDto,
  Token
} from '../types/queue';
import {
  calculateDynamicWaitTime,
  getQueuePositionDetails
} from '../utils/queueLogic';
import {
  HelpCircle,
  CreditCard,
  Activity,
  FileCheck,
  CheckCircle2,
  Clock,
  Users,
  AlertTriangle,
  ArrowRight,
  Shield,
  XCircle,
  Sparkles,
  Info,
  ChevronRight,
  Smartphone
} from 'lucide-react';

const SERVICE_ICONS: Record<string, React.ReactNode> = {
  HelpCircle: <HelpCircle className="w-5 h-5" />,
  CreditCard: <CreditCard className="w-5 h-5" />,
  Activity: <Activity className="w-5 h-5" />,
  FileCheck: <FileCheck className="w-5 h-5" />
};

export const CustomerPortal: React.FC = () => {
  const {
    services,
    priorities,
    tokens,
    counters,
    activeUserTokenId,
    setActiveUserTokenId,
    generateToken,
    cancelToken,
    triggerManualDelay,
    notifications
  } = useQueue();

  // Intake Form State
  const [customerName, setCustomerName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedService, setSelectedService] = useState<ServiceCategoryId>('DOCUMENT');
  const [selectedPriority, setSelectedPriority] = useState<PriorityLevelId>('STANDARD');
  const [specialNotes, setSpecialNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  // Active tracked token
  const activeToken = tokens.find(t => t.id === activeUserTokenId);

  // Filter all waiting tokens for this service to calculate queue details
  const queueDetails = activeToken && activeToken.status === 'WAITING'
    ? getQueuePositionDetails(activeToken, tokens, priorities)
    : null;

  const waitEngineData = activeToken && activeToken.status === 'WAITING'
    ? calculateDynamicWaitTime(activeToken, tokens, counters, services, priorities)
    : null;

  // Relevant notifications for this active user token
  const userNotifications = notifications.filter(n => n.tokenId === activeUserTokenId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      setFormError('Please enter your full name.');
      return;
    }
    if (!phoneNumber.trim()) {
      setFormError('Please provide a contact phone number.');
      return;
    }

    setFormError(null);
    const dto: CreateTokenDto = {
      customerName: customerName.trim(),
      phoneNumber: phoneNumber.trim(),
      serviceCategoryId: selectedService,
      priorityLevelId: selectedPriority,
      notes: specialNotes.trim() ? specialNotes.trim() : undefined
    };

    const newToken = generateToken(dto);
    // Reset form
    setCustomerName('');
    setPhoneNumber('');
    setSpecialNotes('');
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* Hero Banner / Public Intake Intro */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/60 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" /> Self-Service Digital Kiosk & Web Check-in
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Intelligent Virtual Registration & Token Gate
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-300">
            Skip the physical reception line. Select your service, claim a deterministic queue token, and track dynamic AI wait-time predictions in real time on your mobile device.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Registration Intake Form (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <span>1. New Visitor Registration</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Fill in your details to generate an instant digital queue token.
                </p>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-2.5 py-1 rounded-lg">
                Step 1 of 2
              </span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Service Selection Cards */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-3">
                  Choose Service Department <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {services.map((srv) => {
                    const isSelected = selectedService === srv.id;
                    const activeCountersForService = counters.filter(
                      c => c.status === 'OPEN' && (c.assignedServiceId === srv.id || c.assignedServiceId === 'ALL')
                    ).length;
                    const waitingCount = tokens.filter(
                      t => t.status === 'WAITING' && t.serviceCategoryId === srv.id
                    ).length;

                    return (
                      <div
                        key={srv.id}
                        onClick={() => setSelectedService(srv.id)}
                        className={`cursor-pointer rounded-xl p-4 border transition-all duration-200 relative ${
                          isSelected
                            ? 'bg-slate-800/90 border-cyan-500 shadow-md shadow-cyan-500/10 ring-1 ring-cyan-500/40'
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className={`p-2 rounded-lg ${srv.colorTheme.bg} ${srv.colorTheme.text}`}>
                            {SERVICE_ICONS[srv.iconName]}
                          </div>
                          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                            {srv.code}
                          </span>
                        </div>

                        <h3 className="mt-3 font-semibold text-sm text-white">
                          {srv.name}
                        </h3>
                        <p className="mt-1 text-xs text-slate-400 line-clamp-2">
                          {srv.description}
                        </p>

                        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-cyan-400" /> ~{srv.defaultDurationMinutes}m avg
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3 text-amber-400" /> {waitingCount} waiting
                          </span>
                          <span className="text-emerald-400 font-medium">
                            {activeCountersForService} counter{activeCountersForService !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Personal Info Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Customer Full Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eleanor Rigby"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Mobile Phone Number <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. +1 (555) 345-6789"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
                  />
                </div>
              </div>

              {/* Priority Category with Rule Transparency */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Priority Classification & Affirmative Action
                  </label>
                  <span className="text-[11px] text-cyan-400 flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Regulatory Compliant
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {priorities.map((prio) => {
                    const isSelected = selectedPriority === prio.id;
                    return (
                      <div
                        key={prio.id}
                        onClick={() => setSelectedPriority(prio.id)}
                        className={`cursor-pointer rounded-xl p-3 border transition-all text-left ${
                          isSelected
                            ? 'bg-slate-800/90 border-cyan-500 ring-1 ring-cyan-500/50'
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold px-2 py-0.5 rounded border ${prio.badgeColor}`}>
                            {prio.name}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            Weight: {prio.weight}
                          </span>
                        </div>
                        <p className="mt-1.5 text-xs text-slate-300">
                          {prio.description}
                        </p>
                        <p className="mt-1 text-[10px] text-cyan-400/90 italic">
                          ℹ️ {prio.ruleExplanation}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Optional Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Special Accommodation or Service Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Wheelchair assistance required, express notary verification"
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
                />
              </div>

              {formError && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 transition flex items-center justify-center gap-2"
              >
                <span>Generate Digital Queue Token</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* RIGHT COLUMN: Active Token Live Card & Notifications (lg:col-span-5) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Active Token Status Card */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 sm:p-7 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-bold uppercase tracking-wider text-white">
                  Live Customer Token
                </h2>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[11px] font-semibold text-emerald-400">Live Sync</span>
              </div>
            </div>

            {activeToken ? (
              <div className="space-y-5">
                
                {/* Token Badge Header */}
                <div className="bg-gradient-to-b from-slate-950 to-slate-900 border border-slate-700/80 rounded-2xl p-5 text-center relative overflow-hidden shadow-inner">
                  <div className="absolute top-3 right-3">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      activeToken.status === 'SERVING'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 animate-pulse'
                        : activeToken.status === 'WAITING'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>
                      {activeToken.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 font-medium">Your Token ID</p>
                  <div className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white my-2 bg-gradient-to-r from-cyan-400 via-sky-200 to-white bg-clip-text text-transparent">
                    {activeToken.id}
                  </div>
                  <p className="text-sm font-semibold text-slate-200">
                    {activeToken.customerName}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {services.find(s => s.id === activeToken.serviceCategoryId)?.name}
                  </p>

                  {/* Priority Tag */}
                  <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border bg-slate-900 border-slate-700 text-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                    <span>
                      {priorities.find(p => p.id === activeToken.priorityLevelId)?.name}
                    </span>
                  </div>
                </div>

                {/* Queue Position & Prediction Engine Breakdown */}
                {activeToken.status === 'WAITING' && queueDetails && waitEngineData && (
                  <div className="space-y-4">
                    
                    {/* Live Position & Estimated Wait Counter */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 text-center">
                        <span className="text-[11px] text-slate-400 block mb-1">Queue Position</span>
                        <div className="text-2xl font-black text-cyan-400 font-mono">
                          #{queueDetails.position}
                        </div>
                        <span className="text-[10px] text-slate-400">
                          of {queueDetails.totalWaitingInService} in service
                        </span>
                      </div>

                      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 text-center">
                        <span className="text-[11px] text-slate-400 block mb-1">Estimated Wait</span>
                        <div className="text-2xl font-black text-emerald-400 font-mono">
                          ~{waitEngineData.estimatedMinutes} <span className="text-xs font-normal">mins</span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {waitEngineData.activeCounters} active counter(s)
                        </span>
                      </div>
                    </div>

                    {/* Rule Transparency Callout */}
                    <div className="bg-slate-950/90 border border-cyan-500/30 rounded-xl p-3.5 text-xs text-slate-300 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-semibold text-cyan-400">
                        <Info className="w-4 h-4" />
                        <span>Queue Slotting Transparency</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        {queueDetails.transparencyNote}
                      </p>
                      {queueDetails.higherPriorityAhead > 0 && (
                        <p className="text-[10px] text-amber-300/90">
                          Priority tokens ahead: {queueDetails.higherPriorityAhead} (Emergency/PWD/Senior)
                        </p>
                      )}
                    </div>

                    {/* Mathematical Formula Transparency & Disclaimer */}
                    <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 text-[11px] text-slate-400 space-y-2">
                      <div className="flex items-center justify-between text-slate-300 font-medium">
                        <span>Prediction Algorithm Calculation</span>
                        <span className="font-mono text-cyan-400 text-[10px]">Formula Engine</span>
                      </div>
                      <div className="font-mono text-[10px] bg-slate-900/80 p-2 rounded border border-slate-800 text-slate-300">
                        Wait = ({waitEngineData.tokensAhead} ahead × {waitEngineData.avgDurationMinutes}m avg) / {waitEngineData.activeCounters} counters
                        {waitEngineData.priorityAdjustmentMinutes > 0 && ` + ${waitEngineData.priorityAdjustmentMinutes}m priority weight`}
                        {waitEngineData.delayOffsetMinutes > 0 && ` + ${waitEngineData.delayOffsetMinutes}m delay offset`}
                        {' '}= <span className="text-emerald-400 font-bold">{waitEngineData.estimatedMinutes} mins</span>
                      </div>
                      <p className="text-[10px] text-slate-400 italic">
                        ⚠️ <strong className="text-slate-300">Disclaimer:</strong> {waitEngineData.disclaimer}
                      </p>
                    </div>

                    {/* Interactive Testing Simulation Delays */}
                    <div className="pt-2 flex items-center justify-between text-xs">
                      <span className="text-slate-400">Simulate Wait Time Adjustment:</span>
                      <button
                        onClick={() => triggerManualDelay(activeToken.id, 5)}
                        className="text-[11px] px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 flex items-center gap-1"
                      >
                        <Clock className="w-3 h-3" /> +5m Delay Event
                      </button>
                    </div>

                    {/* Cancel Token Action */}
                    <div className="pt-2 border-t border-slate-800">
                      <button
                        onClick={() => cancelToken(activeToken.id, 'User self-cancelled')}
                        className="w-full py-2 px-3 rounded-xl border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 text-xs font-semibold transition flex items-center justify-center gap-1.5"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Cancel My Queue Ticket
                      </button>
                    </div>

                  </div>
                )}

                {/* Being Served View */}
                {activeToken.status === 'SERVING' && (
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 text-center space-y-2">
                    <div className="inline-flex p-2 rounded-full bg-emerald-500/20 text-emerald-400 mb-1">
                      <CheckCircle2 className="w-6 h-6 animate-bounce" />
                    </div>
                    <h3 className="font-bold text-base text-emerald-300">
                      IT IS YOUR TURN!
                    </h3>
                    <p className="text-xs text-slate-300">
                      Please proceed immediately to:
                    </p>
                    <div className="text-lg font-black text-white bg-slate-900 border border-emerald-500/40 rounded-lg py-2 font-mono">
                      {counters.find(c => c.id === activeToken.counterId)?.name || 'Designated Counter'}
                    </div>
                  </div>
                )}

                {/* Completed View */}
                {activeToken.status === 'COMPLETED' && (
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                    <h3 className="font-bold text-sm text-white">Service Completed</h3>
                    <p className="text-xs text-slate-400">
                      Thank you for using QueueSmart AI. Have a wonderful day!
                    </p>
                  </div>
                )}

                {/* Cancelled View */}
                {activeToken.status === 'CANCELLED' && (
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center space-y-2">
                    <XCircle className="w-8 h-8 text-rose-400 mx-auto" />
                    <h3 className="font-bold text-sm text-rose-300">Token Cancelled</h3>
                    <p className="text-xs text-slate-400">
                      This token has been withdrawn from the queue. You may register again at any time.
                    </p>
                  </div>
                )}

              </div>
            ) : (
              <div className="py-12 text-center text-slate-500">
                <Users className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                <p className="text-sm font-medium text-slate-400">No active ticket selected</p>
                <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                  Register using the form on the left or select an existing token from the queue below to preview tracking.
                </p>
              </div>
            )}

            {/* Quick Switch Token Selector (For Testing Multiple Users) */}
            <div className="mt-6 pt-4 border-t border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                Simulate View As Different Customer:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {tokens
                  .filter(t => t.status === 'WAITING' || t.status === 'SERVING')
                  .slice(0, 5)
                  .map(t => (
                    <button
                      key={t.id}
                      onClick={() => setActiveUserTokenId(t.id)}
                      className={`px-2 py-1 text-[11px] font-mono rounded border transition ${
                        activeUserTokenId === t.id
                          ? 'bg-cyan-500 text-white border-cyan-400 font-bold'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {t.id}
                    </button>
                  ))}
              </div>
            </div>

          </div>

          {/* User Notifications Banner (Simulated Alerts) */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center justify-between mb-3">
              <span>Your Turn Alerts & Updates</span>
              <span className="text-[10px] font-mono text-cyan-400">{userNotifications.length} updates</span>
            </h3>

            {userNotifications.length > 0 ? (
              <div className="space-y-2">
                {userNotifications.slice(0, 3).map(n => (
                  <div
                    key={n.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      n.type === 'CALLED'
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-200'
                        : n.type === 'TURN_APPROACHING'
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold mb-1">
                      <span>{n.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed opacity-90">
                      {n.message}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-4">
                No alerts yet. We will notify you when your turn approaches!
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};

