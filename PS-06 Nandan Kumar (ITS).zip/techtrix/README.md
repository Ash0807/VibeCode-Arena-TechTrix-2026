# QueueSmart AI — Next-Gen Intelligent Digital Queue Management Platform

QueueSmart AI is a production-grade, modular digital queue management platform designed for service-driven organizations (hospitals, banks, government administration, and customer intake centers). It dynamically calculates accurate wait-time forecasts, enforces affirmative action priority rules, detects real-time hall bottlenecks, and automates counter reallocation.

---

## 🚀 Key Modules & System Architecture

### 1. Module A: Digital Registration & Deterministic Token Generation
- **Multi-Industry Workflows:** Instant presets for:
  - 🏛️ **Government & Citizen Service Center** (Document Verification `DOC`, Passports `PAS`, Business Permits `LIC`, Inquiries `GEN`).
  - 🏥 **Hospital & Medical Center** (Trauma Triage `EMG`, Outpatient Clinic `MED`, Diagnostic Lab `LAB`, Pharmacy `RX`).
  - 🏦 **Retail Commercial Bank** (Cash Teller `CSH`, Mortgage & Loans `LON`, Wealth Management `INV`, Account Opening `ACC`).
- **Deterministic Token Generator:** Generates unique, structured tokens (e.g. `DOC-101`, `EMG-102`, `CSH-103`) equipped with dynamic **Digital QR Codes** for kiosk check-in scanners.
- **Affirmative Action & Priority Hierarchy:**
  - **Tier 1 — Emergency / Critical** (Weight 400): Immediate priority over all standard & express lanes.
  - **Tier 2 — Persons with Disabilities (PWD)** (Weight 300): Affirmative accessibility slotting.
  - **Tier 3 — Senior Citizens & Expectant Mothers** (Weight 200): Express queue window.
  - **Tier 4 — Standard Arrivals** (Weight 100): First-In, First-Out (FIFO) chronological sequence.
- **Rule Transparency:** Users see transparent explanations of why their position was assigned (e.g., *“You are #2 in line. 1 Emergency token was prioritized ahead per accessibility policy.”*).

---

### 2. Module B: Dynamic Waiting-Time Engine
- **Prediction Algorithm:**
  $$\text{Estimated Wait Time} = \frac{(\text{Tokens Ahead in Queue} \times \text{Average Service Duration})}{\text{Active Service Counters}}$$
- **Variance & Priority Offsets:**
  $$\text{Adjusted Wait Time} = \left\lceil \frac{N_{\text{ahead}} \cdot \bar{D}}{C_{\text{active}}} + \sum_{j=1}^{N_{\text{prio}}} (\bar{D} \cdot \alpha) + \Delta_{\text{offset}} \right\rceil$$
- **Real-Time Disclaimers:** All predictions are explicitly labeled as dynamic algorithmic estimates based on real-time counter velocity.

---

### 3. Module C: Central Queue Display & Synthesized Audio
- **Real-Time Counters Grid:** Highlights currently serving tokens (`DOC-101`, `PAS-102`), counter names, and assigned staff.
- **Audio Chimes & Voice Dispatch:** Synthesized Web Audio API two-tone bell chime (D5 $\to$ A5) and Web Speech API announcement (*"Now serving token DOC-101, please proceed to Desk 1"*).
- **Privacy Masking:** Customer names are displayed in privacy-compliant format (e.g., `Margaret O.***`).
- **Upcoming Next Ticker:** Priority-ordered preview of the next tokens slotted to be called.

---

### 4. Module D: Queue Optimization & Intelligent Bottleneck Advisor
- **Overcrowding Detection:** Flags queues where $\frac{\text{Queue Depth}}{\text{Active Counters}} \ge 5$ (Warning) or $\ge 10$ (Critical).
- **Counter Reallocation Suggestions:**
  > *"Counter 4 is idle. Recommend reallocating to 'Document Verification' due to a spike in queue length."*
- **1-Click Remediation:** Administrative staff can click **Apply Reallocation** to immediately reallocate or open counter desks.

---

### 5. Module E: Staff Command Center & Audit Log Export
- **Staff Controls:** `Call Next`, `Complete`, `Mark No-Show`, and `+5m Delay Offset`.
- **Counter Status Control:** Open, pause, or close counters with automatic queue recalculation.
- **Audit Export:** One-click CSV download (`queuesmart_report.csv`) of all registered customer tokens, wait times, assigned staff, and completion statuses.

---

## 📁 Project Structure

```
techtrix/
├── index.standalone.html    # Standalone interactive distribution with audio chimes & industry presets
├── test-queue-engine.js     # Automated node test suite for priority sorting & wait formulas
├── package.json             # Modern React 18 + TypeScript + Vite + Tailwind configuration
├── vite.config.ts           # Bundler configuration
├── tsconfig.json            # Strict TypeScript configuration
├── tailwind.config.js       # Modern Tailwind dark-mode theme
├── src/
│   ├── types/
│   │   └── queue.ts         # Full TypeScript interfaces & data contracts
│   ├── utils/
│   │   └── queueLogic.ts    # Mathematical sorting, wait time algorithms & bottleneck detection
│   ├── mock/
│   │   └── initialData.ts   # Realistic preloaded tokens, counters, staff & categories
│   ├── context/
│   │   └── QueueContext.tsx # Central state management, actions & simulation engine
│   ├── components/
│   │   ├── Header.tsx       # System navigation & simulation control hub
│   │   ├── CustomerPortal.tsx   # Module A & B: Registration, Token Card & QR Code
│   │   ├── LiveQueueDisplay.tsx # Module C: Central Wall Monitor & TV Hall Display
│   │   ├── AdminDashboard.tsx   # Module D & E: Staff Station Controls & AI Advisor
│   │   ├── AnalyticsView.tsx    # Operational metrics, hourly trends & CSV Export
│   │   └── NotificationModal.tsx# Simulated push alerts & turn updates
│   ├── App.tsx              # Root application coordinator & toast listener
│   ├── main.tsx             # React entrypoint
│   └── index.css            # Tailwind directives & theme styles
└── README.md                # Documentation and architectural guide
```

---

## ⚡ Quick Start & Verification

### Option 1: Instant Standalone Launch (Recommended)
Open [`index.standalone.html`](file:///c:/Users/Nandan%20Kumar/Downloads/techtrix/index.standalone.html) directly in any browser (Chrome, Edge, Firefox).

### Option 2: Run Unit Tests
```powershell
node test-queue-engine.js
```

### Option 3: Modern Vite Development Server
```powershell
npm install
npm run dev
```
