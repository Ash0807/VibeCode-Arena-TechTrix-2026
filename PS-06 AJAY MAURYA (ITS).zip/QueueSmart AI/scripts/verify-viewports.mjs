import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

const ARTIFACT_DIR = 'C:/Users/Ajay Maurya/.gemini/antigravity-ide/brain/ae217a1c-6697-47cf-8e8b-82a2914c201b';
const CHROME_PATH = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const DEBUG_PORT = 9225;

const VIEWPORTS = [
  { name: 'ultramobile-compact', width: 320, height: 640 },
  { name: 'mobile-standard', width: 360, height: 740 },
  { name: 'mobile-iphone12', width: 390, height: 844 },
  { name: 'mobile-iphone-max', width: 430, height: 932 },
  { name: 'tablet-portrait', width: 768, height: 1024 },
  { name: 'tablet-landscape', width: 1024, height: 768 },
  { name: 'laptop-display', width: 1280, height: 800 },
  { name: 'desktop-wide', width: 1440, height: 900 },
  { name: 'large-desktop-ultrawide', width: 1920, height: 1080 }
];

async function main() {
  console.log('🚀 Running 9-Viewport Responsiveness & Overflow Test Suite...');
  
  const chromeProcess = spawn(CHROME_PATH, [
    '--headless=new',
    `--remote-debugging-port=${DEBUG_PORT}`,
    '--disable-gpu',
    '--no-sandbox',
    'about:blank'
  ]);

  await new Promise((r) => setTimeout(r, 2000));

  try {
    const newPageRes = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/new?http://localhost:3000/`, { method: 'PUT' });
    const target = await newPageRes.json();
    const ws = new WebSocket(target.webSocketDebuggerUrl);

    let messageId = 1;
    const pendingPromises = new Map();

    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && pendingPromises.has(msg.id)) {
        const { resolve, reject } = pendingPromises.get(msg.id);
        pendingPromises.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      }
    };

    await new Promise((resolve) => ws.onopen = resolve);

    function sendCommand(method, params = {}) {
      return new Promise((resolve, reject) => {
        const id = messageId++;
        pendingPromises.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    await sendCommand('Page.enable');
    await sendCommand('DOM.enable');
    await sendCommand('Runtime.enable');

    await new Promise((r) => setTimeout(r, 2500));

    console.log('\n--- 📐 EVALUATING VIEWPORT HORIZONTAL OVERFLOW & LAYOUT ---');
    const results = [];

    for (const vp of VIEWPORTS) {
      await sendCommand('Emulation.setDeviceMetricsOverride', {
        width: vp.width,
        height: vp.height,
        deviceScaleFactor: 1,
        mobile: vp.width < 768
      });

      await new Promise((r) => setTimeout(r, 600));

      const evalRes = await sendCommand('Runtime.evaluate', {
        expression: `
          (() => {
            const body = document.body;
            const doc = document.documentElement;
            const scrollWidth = Math.max(doc.scrollWidth, body.scrollWidth);
            const innerWidth = window.innerWidth;
            const hasHorizontalScroll = scrollWidth > innerWidth;
            return {
              scrollWidth,
              innerWidth,
              hasHorizontalScroll,
              overflowPixels: Math.max(0, scrollWidth - innerWidth)
            };
          })()
        `,
        returnByValue: true
      });

      const data = evalRes.result.value;
      const pass = !data.hasHorizontalScroll;
      
      console.log(`Viewport ${vp.width}px (${vp.name}): ${pass ? '✅ PASS' : '❌ FAIL'}`);
      console.log(`  innerWidth: ${data.innerWidth}px | scrollWidth: ${data.scrollWidth}px | overflow: ${data.overflowPixels}px`);

      const screenshot = await sendCommand('Page.captureScreenshot', { format: 'png' });
      const imgPath = path.join(ARTIFACT_DIR, `vp_${vp.width}px.png`);
      fs.writeFileSync(imgPath, Buffer.from(screenshot.data, 'base64'));

      results.push({
        viewport: vp.width,
        name: vp.name,
        pass,
        scrollWidth: data.scrollWidth,
        innerWidth: data.innerWidth,
        overflow: data.overflowPixels
      });
    }

    fs.writeFileSync(
      path.join(ARTIFACT_DIR, 'comprehensive_viewport_results.json'),
      JSON.stringify(results, null, 2)
    );

    ws.close();
  } catch (err) {
    console.error('Error during viewport audit:', err);
  } finally {
    chromeProcess.kill();
  }
}

main();
