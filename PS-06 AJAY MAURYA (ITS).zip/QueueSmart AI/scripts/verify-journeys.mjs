import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

const ARTIFACT_DIR = 'C:/Users/Ajay Maurya/.gemini/antigravity-ide/brain/ae217a1c-6697-47cf-8e8b-82a2914c201b';
const CHROME_PATH = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const DEBUG_PORT = 9224;

async function runJourneys() {
  console.log('🚀 Running Comprehensive UI Journey Capture...');
  
  const chromeProcess = spawn(CHROME_PATH, [
    '--headless=new',
    `--remote-debugging-port=${DEBUG_PORT}`,
    '--disable-gpu',
    '--no-sandbox',
    'about:blank'
  ]);

  await new Promise((r) => setTimeout(r, 2000));

  try {
    const newPageRes = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/new?http://localhost:3000/`, { method: 'PUT' });
    const target = await newPageRes.json();
    const ws = new WebSocket(target.webSocketDebuggerUrl);

    let messageId = 1;
    const pendingPromises = new Map();

    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && pendingPromises.has(msg.id)) {
        const { resolve, reject } = pendingPromises.get(msg.id);
        pendingPromises.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      }
    };

    await new Promise((resolve) => ws.onopen = resolve);

    function sendCommand(method, params = {}) {
      return new Promise((resolve, reject) => {
        const id = messageId++;
        pendingPromises.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    await sendCommand('Page.enable');
    await sendCommand('Runtime.enable');
    
    // Viewport: 390px Mobile
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width: 390,
      height: 844,
      deviceScaleFactor: 1,
      mobile: true
    });
    await new Promise((r) => setTimeout(r, 2000));

    // 1. Digital Pass View: Click on the first waiting token pass button
    await sendCommand('Runtime.evaluate', {
      expression: `
        (() => {
          const passBtn = document.querySelector('button[aria-label*="digital pass"]') || Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Pass') || b.textContent.includes('पास'));
          if (passBtn) passBtn.click();
        })()
      `
    });
    await new Promise((r) => setTimeout(r, 800));

    let snap = await sendCommand('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(ARTIFACT_DIR, 'screen_digital_pass_mobile.png'), Buffer.from(snap.data, 'base64'));
    console.log('✅ Captured: screen_digital_pass_mobile.png');

    // 2. Staff Cockpit View at 1024px
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width: 1024,
      height: 768,
      deviceScaleFactor: 1,
      mobile: false
    });
    await new Promise((r) => setTimeout(r, 600));

    // Back to live queue
    await sendCommand('Runtime.evaluate', {
      expression: `
        (() => {
          const backBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Back') || b.textContent.includes('वापस'));
          if (backBtn) backBtn.click();
          const staffBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Staff Cockpit') || b.textContent.includes('स्टाफ'));
          if (staffBtn) staffBtn.click();
        })()
      `
    });
    await new Promise((r) => setTimeout(r, 1000));

    snap = await sendCommand('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(ARTIFACT_DIR, 'screen_admin_cockpit_desktop.png'), Buffer.from(snap.data, 'base64'));
    console.log('✅ Captured: screen_admin_cockpit_desktop.png');

    // 3. Banking Sector switch test
    await sendCommand('Runtime.evaluate', {
      expression: `
        (() => {
          const backBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Live Display') || b.textContent.includes('लाइव कतार'));
          if (backBtn) backBtn.click();
          const bankingBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Banking') || b.textContent.includes('बैंकिंग'));
          if (bankingBtn) bankingBtn.click();
        })()
      `
    });
    await new Promise((r) => setTimeout(r, 1000));

    snap = await sendCommand('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(ARTIFACT_DIR, 'screen_banking_sector.png'), Buffer.from(snap.data, 'base64'));
    console.log('✅ Captured: screen_banking_sector.png');

    ws.close();
  } catch (err) {
    console.error('Test error:', err);
  } finally {
    chromeProcess.kill();
  }
}

runJourneys();
