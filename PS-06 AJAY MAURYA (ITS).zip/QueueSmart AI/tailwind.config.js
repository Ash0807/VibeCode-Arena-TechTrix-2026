/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        liquid: {
          obsidian: '#0B1020',
          sapphire: '#4F8CFF',
          violet: '#8B5CF6',
          emerald: '#35D6A4',
          amber: '#F59E0B',
          blue: '#4F8CFF',
          green: '#35D6A4',
          cyan: '#38BDF8',
          darkBg: '#0B1020',
          lightBg: '#F8FAFC'
        }
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        'glass-sm': '0 4px 16px 0 rgba(0, 0, 0, 0.25), inset 0 1px 1px 0 rgba(255, 255, 255, 0.2)',
        'glass-md': '0 8px 32px 0 rgba(0, 0, 0, 0.35), inset 0 1px 1.5px 0 rgba(255, 255, 255, 0.25)',
        'glass-lg': '0 16px 48px 0 rgba(0, 0, 0, 0.45), inset 0 1px 2px 0 rgba(255, 255, 255, 0.3)',
        'glass-glow-blue': '0 0 25px rgba(10, 132, 255, 0.35)',
        'glass-glow-green': '0 0 25px rgba(48, 209, 88, 0.35)',
        'glass-glow-violet': '0 0 25px rgba(94, 92, 230, 0.35)',
      },
      backdropBlur: {
        'xs': '2px',
        '3xl': '40px',
      }
    },
  },
  plugins: [],
}
