# Project Roadmap: QueueSmart AI

## Phase Structure

### Phase 1: Foundation, Design System & Project Scaffolding
- [x] GSD setup & Stitch MCP Design System extraction (`assets/62ab387cff3f4e57bb24f8057c2daa65`)
- [x] Vite + React + TypeScript + Tailwind CSS project scaffolding
- [x] Liquid Glass styling system, CSS variables, glassmorphic utilities, Plus Jakarta Sans typography
- [x] Core types, deterministic wait-time mathematical model, and bilingual dictionary (EN/HI)

### Phase 2: Data Architecture & Persistence Layer
- [x] Supabase SQL schema (`supabase/schema.sql`) with tables: `services`, `service_counters`, `queue_tokens`, `appointments`, `priority_rules`, `audit_logs`
- [x] RLS policies, indexing, and triggers
- [x] Unified data layer: Supabase Client + Reactive Mock Engine fallback with local storage persistence and simulated live queue events

### Phase 3: Customer Registration, Digital Pass & Token Tracker
- [x] Multi-sector service browser (Healthcare, Banking, Civic Services)
- [x] Smart registration modal & inline form with priority tier eligibility rules
- [x] Dynamic Digital Pass with QR Code, people-ahead counter, and live countdown
- [x] Token tracking lookup drawer / dialog with audio chime simulation

### Phase 4: Public Live Display & Deterministic Telemetry
- [x] Hero Now Serving bento card with voice announcement visualizer
- [x] Interactive Deterministic Wait-Time Formula card with variable inspector
- [x] Real-time queue velocity & progress meter
- [x] Live Counter status matrix (6 counters per sector) showing status, physician/operator, pace

### Phase 5: Administrative Cockpit & Rule-Based Allocation Assistant
- [x] Operator control panel (Call Next, Complete, Hold, Recall, Skip, Transfer)
- [x] Counter management (Open, Close, Edit capabilities)
- [x] Service category SLA duration configuration
- [x] Operational analytics dashboard (Throughput, Avg Wait, Utilization %)
- [x] Rule-based counter re-allocation engine with transparent bottleneck explanation

### Phase 6: Polish, Verification, Testing & Delivery
- [x] Dark/Light mode theme switching with Apple Liquid Glass shaders
- [x] Hindi/English bilingual instant toggle
- [x] Responsive testing across Mobile, Tablet, and Desktop
- [x] Build & Typecheck validation (`npm run build`)
- [x] End-to-end browser verification via browser sub-agent
- [x] Comprehensive README.md and setup guide
