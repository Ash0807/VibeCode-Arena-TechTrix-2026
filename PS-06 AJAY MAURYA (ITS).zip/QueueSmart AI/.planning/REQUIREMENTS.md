# Scoped Requirements: QueueSmart AI

## Functional Requirements
- [x] **FR1: Service Catalog & Sector Switching**
  - Healthcare / Hospital OPD (Cardiology, Triage, General Medicine, Radiology, Pharmacy)
  - Premier Banking & Forex (Cashier, Loans & Mortgages, Wealth Management, Forex)
  - Citizen & Civic Center (Passport/Aadhaar, Vehicle Registry, Utilities, Trade Licenses)
- [x] **FR2: Customer Token Registration**
  - Name, mobile number/contact, appointment slot option, selected service category
  - Transparent priority tier selection (Emergency/Critical, Senior/Differently-abled, VIP/Express, Regular) with eligibility guidelines
  - Unique token identifier generation (e.g. `H-204`, `B-108`, `C-302`)
- [x] **FR3: Customer Digital Token Pass & Tracker**
  - Dedicated pass card showing Token #, Current Serving, People Ahead, Estimated Wait
  - Dynamic QR code generation for digital kiosk checking & mobile display
  - Live Tracker modal/input to look up any token number anytime
  - Turn proximity visual alert and simulated audio chime notification
- [x] **FR4: Deterministic Waiting-Time Engine**
  - Formula: $T_{\text{wait}} = \frac{N_{\text{ahead}} \times \mu_{\text{service}}}{C_{\text{active}}}$
  - Service-specific average duration ($\mu$) and compatible open counters ($C$)
  - Zero open counters guard (display "Counters paused / estimated time unavailable")
  - Live interactive mathematical formula breakdown inspector card in UI
- [x] **FR5: Live Public Queue Telemetry Display**
  - Now Serving hero highlight with counter assignment
  - Next In Line callouts
  - Waiting tokens carousel / list with priority badges
  - Completed services feed
  - Real-time counter status grid with serving operator, pace, and action triggers
- [x] **FR6: Staff & Admin Management Console**
  - Operator controls: Call Next, Complete Service, Hold, Skip, Recall, Transfer
  - Counter Management: Open/Close counters, reassign staff and service capabilities
  - Service SLA configuration: Adjust mean service durations, priority weights
  - Analytics & Operational Metrics: Throughput count, average wait, counter utilization %
  - Rule-Based Counter Allocation Assistant: Detects bottlenecks, calculates queue load ratio, and suggests opening specific counters with transparent reasoning
- [x] **FR7: Language & Theme Support**
  - English & Hindi (हिन्दी) complete dual-language translation across all views
  - Dark (Apple Liquid Obsidian) and Light (Apple Liquid Frost) modes
- [x] **FR8: Supabase Integration & Dual-Engine Persistence**
  - Complete SQL migration scripts (`supabase/schema.sql`) with tables, indexes, RLS, functions
  - Supabase client with graceful, zero-setup reactive mock engine storing state in `localStorage` + real-time simulation

## Non-Functional Requirements
- **NFR1: Performance**: < 1s initial load, instant state transitions with Framer Motion spring physics
- **NFR2: Accessibility**: High contrast, ARIA tags, reduced motion compliance, keyboard accessible controls
- **NFR3: Security**: Never expose sensitive keys; mock data sanitization; input validation
