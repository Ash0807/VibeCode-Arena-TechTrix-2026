# QueueSmart AI — Project Specification & Context

## Executive Summary
QueueSmart AI is a full-stack, enterprise-grade, Apple-inspired **Liquid Glass** smart queue management platform designed for high-density public and private environments (Hospitals & OPD, Premier Banking, Citizen & Civic Services). It delivers transparent deterministic wait-time modeling, customer digital token generation & pass tracking, live queue telemetries, and staff administrative controls with intelligent rule-based counter allocation.

## Core Pillars
1. **Design & UX Craftsmanship**:
   - Stitch MCP verified design system with multi-layer Liquid Glass optical physics (`backdrop-blur-2xl`, specular top directional 1px edge highlights, chromatic mesh glows in sapphire `#0A84FF`, electric violet `#5E5CE6`, and emerald `#30D158`).
   - Dynamic fluid spring micro-interactions with Framer Motion.
   - Comprehensive Hindi/English bilingual mode and Light/Dark theme adaptation.
2. **Deterministic Wait-Time & Priority Queue Engine**:
   - Transparent mathematical model: `Estimated wait = (People ahead × Average service duration) ÷ Number of compatible open counters`.
   - Priority rules: Emergency / Critical (Tier 1), Senior / Differently-abled (Tier 2), VIP / Express (Tier 3), Regular (Tier 4).
   - Zero-division safety and confidence intervals.
3. **Customer Journey**:
   - Multi-sector service selection (Healthcare OPD, Banking & Forex, Citizen Civic Center).
   - Instant token registration with priority criteria validation.
   - Live Token Pass with dynamic QR code, estimated countdown, live position ahead, turn notification alerts.
   - Real-time token tracking lookup.
4. **Administrative & Counter Management**:
   - Counter operator view: Call Next, Complete, Hold, Recall, Skip, Transfer.
   - Manager cockpit: Counter CRUD, category SLA configuration, operational throughput, counter utilization, and rule-based workload re-balancing suggestions.
5. **Data Architecture & Supabase**:
   - Complete Supabase PostgreSQL schema with RLS policies, indexing, and realtime publication triggers.
   - Resilient dual-mode data layer: seamless production Supabase integration when keys are present, backed by a fully reactive LocalStorage + BroadcastChannel simulation demo engine when offline or testing.
