import { QueueToken, ServiceCounter, Service, PriorityTier, DeterministicTelemetry, AllocationSuggestion } from '../types';

/**
 * Priority rank weights: Lower number = higher priority
 */
export const PRIORITY_WEIGHTS: Record<PriorityTier, number> = {
  emergency: 1,
  senior: 2,
  vip: 3,
  regular: 4,
};

/**
 * Sorts waiting tokens according to multi-tier deterministic queuing rules:
 * 1. Priority Tier (Emergency -> Senior/Differently-abled -> VIP -> Regular)
 * 2. Registration Timestamp (FIFO within the same tier)
 */
export function sortQueueTokens(tokens: QueueToken[]): QueueToken[] {
  return [...tokens].sort((a, b) => {
    // Serving tokens first
    if (a.status === 'serving' && b.status !== 'serving') return -1;
    if (b.status === 'serving' && a.status !== 'serving') return 1;

    // Both waiting tokens: sort by priority weight, then by creation date
    if (a.status === 'waiting' && b.status === 'waiting') {
      const weightA = PRIORITY_WEIGHTS[a.priorityTier] || 4;
      const weightB = PRIORITY_WEIGHTS[b.priorityTier] || 4;
      if (weightA !== weightB) {
        return weightA - weightB;
      }
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }

    return 0;
  });
}

/**
 * Counts compatible counters currently in 'open' or 'busy' operational state
 */
export function getCompatibleOpenCounters(counters: ServiceCounter[], serviceCode: string): ServiceCounter[] {
  return counters.filter(
    (c) =>
      (c.status === 'open' || c.status === 'busy') &&
      c.compatibleServices.includes(serviceCode)
  );
}

/**
 * Deterministic Waiting Time Calculation:
 * Wait Time = (N_ahead * μ_service) / C_open
 *
 * Guarded against zero active counters.
 */
export function calculateDeterministicWait(
  peopleAhead: number,
  avgDurationMinutes: number,
  compatibleOpenCountersCount: number
): { waitMinutes: number; hasZeroCounters: boolean; confidenceBand: { min: number; max: number } } {
  if (compatibleOpenCountersCount <= 0) {
    return {
      waitMinutes: 0,
      hasZeroCounters: true,
      confidenceBand: { min: 0, max: 0 },
    };
  }

  // Formula execution: (N * μ) / C
  const rawWait = (peopleAhead * avgDurationMinutes) / compatibleOpenCountersCount;
  const waitMinutes = Math.max(1, Math.round(rawWait * 10) / 10);

  // Confidence interval: ±15% variance based on human service variance
  const min = Math.max(1, Math.round(waitMinutes * 0.85 * 10) / 10);
  const max = Math.round(waitMinutes * 1.25 * 10) / 10;

  return {
    waitMinutes,
    hasZeroCounters: false,
    confidenceBand: { min, max },
  };
}

/**
 * Calculates live position and wait time for a specific token in queue
 */
export function getTokenQueuePosition(
  token: QueueToken,
  allTokens: QueueToken[],
  counters: ServiceCounter[],
  services: Service[]
): {
  positionAhead: number;
  estimatedWaitMinutes: number;
  hasZeroCounters: boolean;
  servingToken?: QueueToken;
} {
  if (token.status === 'serving') {
    return {
      positionAhead: 0,
      estimatedWaitMinutes: 0,
      hasZeroCounters: false,
    };
  }

  if (token.status === 'completed' || token.status === 'cancelled') {
    return {
      positionAhead: 0,
      estimatedWaitMinutes: 0,
      hasZeroCounters: false,
    };
  }

  // Filter all waiting tokens in the same sector / service
  const waitingTokens = allTokens.filter(
    (t) => t.status === 'waiting' && t.sector === token.sector && t.serviceCode === token.serviceCode
  );

  const sorted = sortQueueTokens(waitingTokens);
  const tokenIndex = sorted.findIndex((t) => t.id === token.id);
  const positionAhead = tokenIndex >= 0 ? tokenIndex : 0;

  const service = services.find((s) => s.code === token.serviceCode);
  const avgDuration = service ? service.avgDurationMinutes : 8.0;

  const openCounters = getCompatibleOpenCounters(counters, token.serviceCode);
  const { waitMinutes, hasZeroCounters } = calculateDeterministicWait(
    positionAhead,
    avgDuration,
    openCounters.length
  );

  const servingToken = allTokens.find(
    (t) => t.status === 'serving' && t.serviceCode === token.serviceCode
  );

  return {
    positionAhead,
    estimatedWaitMinutes: waitMinutes,
    hasZeroCounters,
    servingToken,
  };
}

/**
 * Computes deterministic telemetry breakdown for a service
 */
export function getServiceDeterministicTelemetry(
  service: Service,
  allTokens: QueueToken[],
  counters: ServiceCounter[]
): DeterministicTelemetry {
  const waitingInService = allTokens.filter(
    (t) => t.status === 'waiting' && t.serviceCode === service.code
  );

  const openCounters = getCompatibleOpenCounters(counters, service.code);
  const peopleAhead = waitingInService.length;
  const { waitMinutes, hasZeroCounters, confidenceBand } = calculateDeterministicWait(
    peopleAhead,
    service.avgDurationMinutes,
    openCounters.length
  );

  return {
    serviceCode: service.code,
    serviceName: service.nameEn,
    peopleAhead,
    avgDurationMinutes: service.avgDurationMinutes,
    compatibleOpenCounters: openCounters.length,
    estimatedWaitMinutes: waitMinutes,
    confidenceBand,
    hasZeroCounters,
  };
}

/**
 * Rule-Based Counter Allocation Assistant:
 * Analyzes real-time queues and identifies bottlenecks:
 * - Trigger 1: Service wait time > 18 mins or queue backlog >= 4 patients/customers
 * - Trigger 2: Closed counters exist, or counters serving low-demand categories can be pooled
 * Generates transparent, deterministic staff recommendations.
 */
export function generateAllocationSuggestions(
  services: Service[],
  counters: ServiceCounter[],
  tokens: QueueToken[]
): AllocationSuggestion[] {
  const suggestions: AllocationSuggestion[] = [];

  for (const service of services) {
    const waitingTokens = tokens.filter(
      (t) => t.status === 'waiting' && t.serviceCode === service.code
    );
    const openCounters = getCompatibleOpenCounters(counters, service.code);
    const { waitMinutes } = calculateDeterministicWait(
      waitingTokens.length,
      service.avgDurationMinutes,
      openCounters.length
    );

    // Overcrowding threshold: backlog >= 4 or wait time >= 18 mins
    if (waitingTokens.length >= 4 || (openCounters.length === 0 && waitingTokens.length > 0)) {
      // Find an idle or closed counter in this sector
      const candidateCounter = counters.find(
        (c) =>
          c.sector === service.sector &&
          (c.status === 'closed' || c.status === 'paused' || !c.compatibleServices.includes(service.code))
      );

      if (candidateCounter) {
        const simulatedCountersCount = openCounters.length + 1;
        const waitAfter = Math.max(
          1,
          Math.round(
            ((waitingTokens.length * service.avgDurationMinutes) / simulatedCountersCount) * 10
          ) / 10
        );

        const severity =
          waitingTokens.length >= 7 || openCounters.length === 0 ? 'critical' : 'high';

        suggestions.push({
          id: `alloc-${service.code}-${candidateCounter.counterNumber}`,
          serviceCode: service.code,
          serviceName: service.nameEn,
          severity,
          queueBacklog: waitingTokens.length,
          currentOpenCounters: openCounters.length,
          recommendedCounterNumber: candidateCounter.counterNumber,
          estimatedWaitBefore: waitMinutes,
          estimatedWaitAfter: waitAfter,
          reasoningEn: `Queue backlog is ${waitingTokens.length} patients in ${service.nameEn} with ${openCounters.length} active counter(s). Reallocating Counter ${candidateCounter.counterNumber} (${candidateCounter.operatorName}) is projected to reduce wait time from ${waitMinutes}m down to ${waitAfter}m (-${Math.round(waitMinutes - waitAfter)} mins).`,
          reasoningHi: `${service.nameHi} में ${waitingTokens.length} नागरिक कतार में हैं और केवल ${openCounters.length} काउंटर खुला है। काउंटर ${candidateCounter.counterNumber} को सक्रिय करने से प्रतीक्षा समय ${waitMinutes} मिनट से घटकर ${waitAfter} मिनट रह जाएगा (-${Math.round(waitMinutes - waitAfter)} मिनट बचत)।`,
        });
      }
    }
  }

  return suggestions;
}
