/**
 * Audio Chime Synthesizer using Web Audio API
 * Generates an Apple / Airport style crystal chime tone when tokens are called.
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playQueueChime(): void {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Harmonic pleasant chime frequencies: F5 (698.46 Hz) -> A5 (880 Hz) -> C6 (1046.5 Hz)
    const notes = [698.46, 880.0, 1046.5];

    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + index * 0.14);

      gain.gain.setValueAtTime(0, now + index * 0.14);
      gain.gain.linearRampToValueAtTime(0.25, now + index * 0.14 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + index * 0.14 + 0.85);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + index * 0.14);
      osc.stop(now + index * 0.14 + 0.9);
    });
  } catch (err) {
    console.warn('Audio chime playback blocked or not supported:', err);
  }
}

export function announceTokenTurn(tokenNumber: string, counterNumber: number, lang: 'en' | 'hi' = 'en'): void {
  playQueueChime();

  if ('speechSynthesis' in window) {
    setTimeout(() => {
      try {
        const text =
          lang === 'hi'
            ? `टोकन संख्या ${tokenNumber}, कृपया काउंटर ${counterNumber} पर आएं`
            : `Token number ${tokenNumber}, please proceed to counter ${counterNumber}`;

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;
        utterance.pitch = 1.05;
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('Speech synthesis error:', e);
      }
    }, 600);
  }
}
