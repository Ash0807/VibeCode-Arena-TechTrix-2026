import { createClient } from '@supabase/supabase-js';
import {
  Service,
  ServiceCounter,
  QueueToken,
  PriorityRule,
  AppointmentSlot,
  QueueNotification,
} from '../types';
import {
  INITIAL_SERVICES,
  INITIAL_COUNTERS,
  INITIAL_QUEUE_TOKENS,
  PRIORITY_RULES,
  INITIAL_APPOINTMENTS,
} from './mockData';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl !== 'https://your-project.supabase.co' &&
  !supabaseUrl.includes('placeholder')
);

export const supabase = (isSupabaseConfigured && supabaseUrl && supabaseAnonKey)
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Local Storage Keys
const STORAGE_KEY_SERVICES = 'queuesmart_services';
const STORAGE_KEY_COUNTERS = 'queuesmart_counters';
const STORAGE_KEY_TOKENS = 'queuesmart_tokens';
const STORAGE_KEY_RULES = 'queuesmart_rules';
const STORAGE_KEY_APPOINTMENTS = 'queuesmart_appointments';
const STORAGE_KEY_NOTIFICATIONS = 'queuesmart_notifications';

// Realtime Broadcast Channel for multi-tab synchronization
const realtimeChannel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('queuesmart_sync') : null;

type Listener = () => void;
const listeners: Set<Listener> = new Set();

if (realtimeChannel) {
  realtimeChannel.onmessage = () => {
    listeners.forEach((cb) => cb());
  };
}

export function subscribeToQueueUpdates(callback: () => void): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

function notifySubscribers(): void {
  listeners.forEach((cb) => cb());
  if (realtimeChannel) {
    realtimeChannel.postMessage({ type: 'SYNC_UPDATE', timestamp: Date.now() });
  }
}

// Data Access Layer
export const QueueStorage = {
  getServices(): Service[] {
    const raw = localStorage.getItem(STORAGE_KEY_SERVICES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_SERVICES, JSON.stringify(INITIAL_SERVICES));
      return INITIAL_SERVICES;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_SERVICES;
    }
  },

  getCounters(): ServiceCounter[] {
    const raw = localStorage.getItem(STORAGE_KEY_COUNTERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_COUNTERS, JSON.stringify(INITIAL_COUNTERS));
      return INITIAL_COUNTERS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_COUNTERS;
    }
  },

  saveCounters(counters: ServiceCounter[]): void {
    localStorage.setItem(STORAGE_KEY_COUNTERS, JSON.stringify(counters));
    notifySubscribers();
  },

  getTokens(): QueueToken[] {
    const raw = localStorage.getItem(STORAGE_KEY_TOKENS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_TOKENS, JSON.stringify(INITIAL_QUEUE_TOKENS));
      return INITIAL_QUEUE_TOKENS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_QUEUE_TOKENS;
    }
  },

  saveTokens(tokens: QueueToken[]): void {
    localStorage.setItem(STORAGE_KEY_TOKENS, JSON.stringify(tokens));
    notifySubscribers();
  },

  getPriorityRules(): PriorityRule[] {
    const raw = localStorage.getItem(STORAGE_KEY_RULES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_RULES, JSON.stringify(PRIORITY_RULES));
      return PRIORITY_RULES;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return PRIORITY_RULES;
    }
  },

  getAppointments(): AppointmentSlot[] {
    const raw = localStorage.getItem(STORAGE_KEY_APPOINTMENTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_APPOINTMENTS, JSON.stringify(INITIAL_APPOINTMENTS));
      return INITIAL_APPOINTMENTS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_APPOINTMENTS;
    }
  },

  saveAppointments(appointments: AppointmentSlot[]): void {
    localStorage.setItem(STORAGE_KEY_APPOINTMENTS, JSON.stringify(appointments));
    notifySubscribers();
  },

  getNotifications(): QueueNotification[] {
    const raw = localStorage.getItem(STORAGE_KEY_NOTIFICATIONS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  addNotification(notif: QueueNotification): void {
    const current = this.getNotifications();
    current.unshift(notif);
    localStorage.setItem(STORAGE_KEY_NOTIFICATIONS, JSON.stringify(current.slice(0, 30)));
    notifySubscribers();
  },

  resetAll(): void {
    localStorage.setItem(STORAGE_KEY_SERVICES, JSON.stringify(INITIAL_SERVICES));
    localStorage.setItem(STORAGE_KEY_COUNTERS, JSON.stringify(INITIAL_COUNTERS));
    localStorage.setItem(STORAGE_KEY_TOKENS, JSON.stringify(INITIAL_QUEUE_TOKENS));
    localStorage.setItem(STORAGE_KEY_RULES, JSON.stringify(PRIORITY_RULES));
    localStorage.setItem(STORAGE_KEY_APPOINTMENTS, JSON.stringify(INITIAL_APPOINTMENTS));
    localStorage.removeItem(STORAGE_KEY_NOTIFICATIONS);
    notifySubscribers();
  },
};
