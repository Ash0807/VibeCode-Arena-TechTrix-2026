export const translations = {
  en: {
    appTitle: "QueueSmart AI",
    appSubtitle: "Liquid Glass Smart Queue Intelligence",
    sectors: {
      healthcare: "Apex Memorial Hospital (OPD)",
      banking: "Axis Premier Wealth & Forex",
      civic: "Metro Citizen Service Hub"
    },
    nav: {
      liveBoard: "Live Display",
      myToken: "My Digital Pass",
      trackToken: "Track Ticket",
      staffConsole: "Staff Cockpit",
      adminPanel: "Admin Settings",
      audioChime: "Chime Audio",
      chimeActive: "Audio On",
      chimeMuted: "Audio Muted",
      languageToggle: "हिन्दी",
      themeDark: "Dark Glass",
      themeLight: "Frost Glass",
      registerToken: "Get Token"
    },
    hero: {
      nowServing: "NOW SERVING",
      counter: "Counter",
      nextInLine: "NEXT UP",
      proceedTo: "Please proceed to counter",
      queueBacklog: "In Queue",
      avgWait: "Avg Wait",
      activeCounters: "Open Counters",
      serviceSla: "SLA Adherence",
      mins: "mins",
      people: "people",
      telemetryNotice: "Deterministic Mathematical Queue Modeling v4.2"
    },
    formula: {
      title: "Transparent Deterministic Wait Engine",
      subtitle: "Zero-guessing queue calculation backed by deterministic service-rate physics",
      formulaDisplay: "Estimated Wait = (People Ahead × Mean Service Duration) ÷ Open Compatible Counters",
      peopleAhead: "People Ahead (N)",
      meanDuration: "Mean Service Duration (μ)",
      openCounters: "Open Compatible Counters (C)",
      calculatedResult: "Computed Wait Time",
      confidenceRange: "Confidence Interval (95%)",
      zeroCountersWarning: "Notice: All compatible counters for this service are currently paused or closed. Estimated wait is paused until a counter opens.",
      explainabilityTitle: "How This Estimate Works",
      explainabilityBody: "Unlike black-box AI approximations, QueueSmart AI uses verifiable queuing theory: your wait depends strictly on the patients/customers ahead of you, historical category service speed, and active operational counters."
    },
    registration: {
      title: "Digital Queue Registration",
      subtitle: "Receive your instant live digital pass with deterministic wait countdown",
      selectSector: "Select Department / Service",
      fullName: "Full Name",
      fullNamePlaceholder: "e.g. Rahul Sharma",
      phone: "Mobile Phone Number",
      phonePlaceholder: "e.g. 9876543210",
      priorityTier: "Priority Category",
      priorityTierHelp: "Select if you meet transparent priority eligibility criteria",
      appointmentSlot: "Optional Appointment Slot",
      appointmentNone: "Walk-in Queue (Immediate)",
      notificationChannel: "Notification Channel",
      btnSubmit: "Generate Digital Token",
      btnSubmitting: "Registering & Calculating...",
      privacyNotice: "Protected by HIPAA/DPDP Privacy Guidelines. No credentials or telemetry shared."
    },
    priority: {
      emergency: {
        title: "Emergency / Critical",
        eligibility: "Acute distress, triage level 1-2, trauma or severe cardiac symptoms"
      },
      senior: {
        title: "Senior & Specially-Abled",
        eligibility: "Citizens aged 65+, pregnant women, or persons with physical disabilities"
      },
      vip: {
        title: "VIP / Express Fast-Track",
        eligibility: "Prior booked priority appointments, pre-verified corporate or express pass"
      },
      regular: {
        title: "General Walk-In",
        eligibility: "Standard sequential registration queue"
      }
    },
    pass: {
      digitalPassTitle: "QueueSmart Virtual Pass",
      liveStatus: "LIVE ACTIVE TICKET",
      scanHelp: "Scan QR code at kiosk or counter reader",
      yourTurnSoon: "Alert: Your turn is approaching! Please stand near the counter.",
      yourTurnNow: "It's your turn! Please report to Counter",
      positionAhead: "ahead of you",
      estimatedWaitTime: "Estimated Wait Time",
      serviceDepartment: "Service Department",
      categoryTier: "Priority Class",
      registeredAt: "Issued At",
      btnTrackAnother: "Track Another Ticket",
      btnPrint: "Save / Print Pass"
    },
    counters: {
      title: "Live Counter Telemetry",
      subtitle: "Real-time workstation status, physician/operator allocation, and throughput",
      counter: "Counter",
      statusOpen: "Open & Serving",
      statusBusy: "Serving Ticket",
      statusPaused: "On Short Break",
      statusClosed: "Closed",
      servingNow: "Serving",
      avgPace: "Avg Pace",
      servedToday: "Served Today",
      callNext: "Call Next",
      completeService: "Complete",
      holdRecall: "Recall / Hold"
    },
    admin: {
      cockpitTitle: "Staff Operations Cockpit",
      cockpitSubtitle: "Multi-counter triage control, manual call override, and dynamic queue balancing",
      queueBacklogTab: "Active Queue",
      countersTab: "Counter Allocation",
      recommendationsTab: "Rule-Based Allocation Suggestions",
      callNextBtn: "Call Next",
      completeBtn: "Complete",
      skipBtn: "No-Show",
      recallBtn: "Recall",
      reassignService: "Assign Categories",
      operationalMetrics: "Operational Metrics",
      avgWaitTime: "Average Wait Time",
      totalServed: "Total Completed",
      activeStaff: "Staff on Duty",
      utilizationRate: "Counter Utilization",
      rulesEngineTitle: "Rule-Based Workload Rebalancing Assistant",
      rulesEngineNotice: "Transparent deterministic threshold alerts to prevent bottlenecking",
      applySuggestion: "Apply Allocation",
      appliedSuccess: "Counter Reassigned Successfully"
    },
    tracker: {
      title: "Live Token Tracker",
      subtitle: "Enter any active token number to inspect its queue position and live estimated turn",
      placeholder: "e.g. H-204 or B-105",
      btnSearch: "Track Ticket",
      notFound: "Token not found in active queue. Please verify the ticket number.",
      statusCompleted: "This service has already been completed.",
      statusServing: "Currently being attended to at Counter"
    },
    simulation: {
      title: "Demo & Simulation Controls",
      subtitle: "Test real-time deterministic updates without manual staff typing",
      btnSimulateCustomer: "Add Random Customer",
      btnAdvanceQueue: "Advance Next Token",
      btnOpenAllCounters: "Open All Counters",
      btnReset: "Reset Demo Data"
    }
  },
  hi: {
    appTitle: "QueueSmart AI",
    appSubtitle: "लिक्विड ग्लास स्मार्ट कतार प्रबंधन प्रणाली",
    sectors: {
      healthcare: "एपेक्स मेमोरियल अस्पताल (ओपीडी)",
      banking: "एक्सिस प्रीमियर वेल्थ एवं फॉरेक्स",
      civic: "मेट्रो नागरिक सेवा केंद्र"
    },
    nav: {
      liveBoard: "लाइव डिस्प्ले",
      myToken: "मेरा डिजिटल पास",
      trackToken: "टोकन ट्रैक करें",
      staffConsole: "स्टाफ कॉकपिट",
      adminPanel: "व्यवस्थापक सेटिंग्स",
      audioChime: "ध्वनि उद्घोषणा",
      chimeActive: "ध्वनि चालू",
      chimeMuted: "ध्वनि बंद",
      languageToggle: "English",
      themeDark: "डार्क ग्लास",
      themeLight: "फ्रॉस्ट ग्लास",
      registerToken: "टोकन प्राप्त करें"
    },
    hero: {
      nowServing: "वर्तमान में सेवारत",
      counter: "काउंटर",
      nextInLine: "अगला टोकन",
      proceedTo: "कृपया काउंटर पर पहुंचें",
      queueBacklog: "कतार में",
      avgWait: "औसत प्रतीक्षा",
      activeCounters: "सक्रिय काउंटर",
      serviceSla: "सेवा संतुष्टि दर",
      mins: "मिनट",
      people: "नागरिक",
      telemetryNotice: "पारदर्शी गणितीय कतार मॉडलिंग v4.2"
    },
    formula: {
      title: "पारदर्शी प्रतीक्षा समय गणना इंजन",
      subtitle: "बिना किसी अनुमान के सटीक और पारदर्शी गणितीय कतार गणना",
      formulaDisplay: "अनुमानित प्रतीक्षा = (आगे मौजूद लोग × औसत सेवा समय) ÷ खुले अनुकूल काउंटर",
      peopleAhead: "आगे लोग (N)",
      meanDuration: "औसत सेवा अवधि (μ)",
      openCounters: "खुले अनुकूल काउंटर (C)",
      calculatedResult: "परिकलित प्रतीक्षा समय",
      confidenceRange: "सटीकता सीमा (95%)",
      zeroCountersWarning: "सूचना: इस सेवा के लिए सभी काउंटर फिलहाल बंद हैं। काउंटर खुलने पर समय अपडेट होगा।",
      explainabilityTitle: "यह अनुमान कैसे काम करता है",
      explainabilityBody: "यह प्रणाली किसी गुप्त एआई पर नहीं, बल्कि प्रत्यक्ष गणितीय नियमों पर काम करती है: आपकी प्रतीक्षा समय आपके आगे के लोगों, औसत समय और सक्रिय काउंटरों पर निर्भर करता है।"
    },
    registration: {
      title: "डिजिटल कतार पंजीकरण",
      subtitle: "सटीक प्रतीक्षा समय के साथ तुरंत अपना लाइव डिजिटल पास प्राप्त करें",
      selectSector: "विभाग / सेवा चुनें",
      fullName: "पूरा नाम",
      fullNamePlaceholder: "उदा. राहुल शर्मा",
      phone: "मोबाइल नंबर",
      phonePlaceholder: "उदा. 9876543210",
      priorityTier: "प्राथमिकता श्रेणी",
      priorityTierHelp: "यदि आप पात्रता नियमों को पूरा करते हैं तो उपयुक्त श्रेणी चुनें",
      appointmentSlot: "अपॉइंटमेंट समय (वैकल्पिक)",
      appointmentNone: "सामान्य कतार (तुरंत)",
      notificationChannel: "सूचना माध्यम",
      btnSubmit: "डिजिटल टोकन उत्पन्न करें",
      btnSubmitting: "पंजीकरण और गणना जारी...",
      privacyNotice: "गोपनीयता दिशानिर्देशों के तहत पूर्ण सुरक्षित। आपका डेटा संरक्षित है।"
    },
    priority: {
      emergency: {
        title: "आपातकालीन / गंभीर",
        eligibility: "गंभीर स्थिति, आघात या अत्यधिक आवश्यकता वाले रोगी"
      },
      senior: {
        title: "वरिष्ठ नागरिक एवं दिव्यांग",
        eligibility: "65+ वर्ष के नागरिक, गर्भवती महिलाएं, या दिव्यांग व्यक्ति"
      },
      vip: {
        title: "वीआईपी / एक्सप्रेस पास",
        eligibility: "पूर्व-आरक्षित प्राथमिकता या कॉर्पोरेट अधिकृत पास"
      },
      regular: {
        title: "सामान्य कतार",
        eligibility: "मानक क्रमानुसार पंजीकरण"
      }
    },
    pass: {
      digitalPassTitle: "QueueSmart वर्चुअल पास",
      liveStatus: "लाइव सक्रिय टिकट",
      scanHelp: "काउंटर स्कैनर पर यह क्यूआर कोड दिखाएं",
      yourTurnSoon: "सावधान: आपकी बारी जल्द आने वाली है! कृपया काउंटर के समीप रहें।",
      yourTurnNow: "आपकी बारी आ गई है! कृपया काउंटर पर संपर्क करें",
      positionAhead: "लोग आपसे आगे हैं",
      estimatedWaitTime: "अनुमानित प्रतीक्षा समय",
      serviceDepartment: "सेवा विभाग",
      categoryTier: "प्राथमिकता श्रेणी",
      registeredAt: "जारी समय",
      btnTrackAnother: "अन्य टोकन देखें",
      btnPrint: "पास सुरक्षित करें"
    },
    counters: {
      title: "लाइव काउंटर स्थिति",
      subtitle: "रीयल-टाइम काउंटर संचालन, डॉक्टर/अधिकारी और सेवा गति",
      counter: "काउंटर",
      statusOpen: "खुला और उपलब्ध",
      statusBusy: "टोकन सेवा जारी",
      statusPaused: "अल्प विराम",
      statusClosed: "बंद",
      servingNow: "वर्तमान सेवा",
      avgPace: "औसत गति",
      servedToday: "आज कुल सेवाएं",
      callNext: "अगला बुलाएं",
      completeService: "सेवा पूर्ण",
      holdRecall: "पुनः बुलाएं / रोकें"
    },
    admin: {
      cockpitTitle: "स्टाफ संचालन कॉकपिट",
      cockpitSubtitle: "काउंटर नियंत्रण, टोकन प्रबंधन और कतार संतुलन",
      queueBacklogTab: "सक्रिय कतार",
      countersTab: "काउंटर आवंटन",
      analyticsTab: "दक्षता विश्लेषण",
      recommendationsTab: "काउंटर पुनरावंटन सुझाव",
      callNextBtn: "अगला बुलाएं",
      completeBtn: "पूर्ण करें",
      skipBtn: "अनुपस्थित",
      recallBtn: "पुनः बुलाएं",
      toggleStatus: "चालू / बंद करें",
      reassignService: "सेवाएं बदलें",
      operationalMetrics: "संचालन मेट्रिक्स",
      avgWaitTime: "औसत प्रतीक्षा समय",
      totalServed: "कुल पूर्ण सेवाएं",
      activeStaff: "ड्यूटी पर स्टाफ",
      utilizationRate: "काउंटर उपयोग दर",
      rulesEngineTitle: "नियम-आधारित काउंटर आवंटन सहायक",
      rulesEngineNotice: "भीड़ नियंत्रण और प्रतीक्षा समय घटाने हेतु पारदर्शी नियम-आधारित सुझाव",
      applySuggestion: "सुझाव लागू करें",
      appliedSuccess: "काउंटर सफलतापूर्वक पुनरावंटित किया गया"
    },
    tracker: {
      title: "लाइव टोकन ट्रैकर",
      subtitle: "अपनी कतार स्थिति और अनुमानित समय देखने के लिए टोकन नंबर दर्ज करें",
      placeholder: "उदा. H-204 या B-105",
      btnSearch: "टोकन खोजें",
      notFound: "सक्रिय कतार में टोकन नहीं मिला। कृपया नंबर जांचें।",
      statusCompleted: "यह सेवा पहले ही पूरी हो चुकी है।",
      statusServing: "वर्तमान में काउंटर पर सेवा जारी है"
    },
    simulation: {
      title: "डेमो व सिमुलेशन नियंत्रण",
      subtitle: "बिना मैन्युअल टाइपिंग के रीयल-टाइम अपडेट्स का परीक्षण करें",
      btnSimulateCustomer: "नया ग्राहक जोड़ें",
      btnAdvanceQueue: "कतार आगे बढ़ाएं",
      btnOpenAllCounters: "सभी काउंटर खोलें",
      btnReset: "डेटा रीसेट करें"
    }
  }
};
