import React, { useState, useEffect, useCallback } from 'react';
import {
  Navbar,
} from './components/Navbar';
import {
  HeroTelemetry,
} from './components/HeroTelemetry';
import {
  DeterministicFormulaCard,
} from './components/DeterministicFormulaCard';
import {
  LiveCounterGrid,
} from './components/LiveCounterGrid';
import {
  WaitingQueueList,
} from './components/WaitingQueueList';
import {
  AdminDashboard,
} from './components/AdminDashboard';
import {
  DigitalTokenPass,
} from './components/DigitalTokenPass';
import {
  TokenRegistrationModal,
} from './components/TokenRegistrationModal';
import {
  TokenTrackerDialog,
} from './components/TokenTrackerDialog';
import {
  SimulationController,
} from './components/SimulationController';
import {
  NotificationToast,
} from './components/NotificationToast';
import {
  SectorType,
  Language,
  QueueToken,
  ServiceCounter,
  Service,
  PriorityRule,
  AppointmentSlot,
  QueueNotification,
} from './types';
import {
  QueueStorage,
  subscribeToQueueUpdates,
  isSupabaseConfigured,
} from './lib/supabase';
import {
  calculateDeterministicWait,
  getCompatibleOpenCounters,
  getTokenQueuePosition,
} from './lib/queueEngine';
import {
  announceTokenTurn,
} from './lib/audioChime';
import {
  ShieldCheck,
  Database,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';

export const App: React.FC = () => {
  // Global States
  const [currentSector, setCurrentSector] = useState<SectorType>('healthcare');
  const [lang, setLang] = useState<Language>('en');
  const [isDark, setIsDark] = useState<boolean>(true);
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);
  const [activeView, setActiveView] = useState<'public' | 'admin' | 'pass'>('public');

  // Modal States
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState<boolean>(false);
  const [activeUserToken, setActiveUserToken] = useState<QueueToken | null>(null);

  // Notification States
  const [notifications, setNotifications] = useState<QueueNotification[]>(() => QueueStorage.getNotifications());
  const [isNotificationHistoryOpen, setIsNotificationHistoryOpen] = useState<boolean>(false);

  // Data Store States (Hydrated synchronously on initial render)
  const [services, setServices] = useState<Service[]>(() => QueueStorage.getServices());
  const [counters, setCounters] = useState<ServiceCounter[]>(() => QueueStorage.getCounters());
  const [tokens, setTokens] = useState<QueueToken[]>(() => QueueStorage.getTokens());
  const [priorityRules, setPriorityRules] = useState<PriorityRule[]>(() => QueueStorage.getPriorityRules());
  const [appointments, setAppointments] = useState<AppointmentSlot[]>(() => QueueStorage.getAppointments());

  // Load from Data Store
  const loadData = useCallback(() => {
    setServices(QueueStorage.getServices());
    setCounters(QueueStorage.getCounters());
    setTokens(QueueStorage.getTokens());
    setPriorityRules(QueueStorage.getPriorityRules());
    setAppointments(QueueStorage.getAppointments());
    setNotifications(QueueStorage.getNotifications());
  }, []);

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToQueueUpdates(loadData);
    return () => unsubscribe();
  }, [loadData]);

  // Turn Approaching & Serving In-App Notification Trigger
  useEffect(() => {
    if (!activeUserToken) return;
    const current = tokens.find((t) => t.id === activeUserToken.id);
    if (!current) return;

    if (current.status === 'serving' && activeUserToken.status !== 'serving') {
      setActiveUserToken(current);
      const notif: QueueNotification = {
        id: `notif-${Date.now()}`,
        tokenId: current.id,
        tokenNumber: current.tokenNumber,
        type: 'called',
        titleEn: `Now Serving: ${current.tokenNumber}`,
        titleHi: `अब आपकी बारी: ${current.tokenNumber}`,
        messageEn: `Please proceed to Counter #${current.counterNumber || '01'} immediately.`,
        messageHi: `कृपया तुरंत काउंटर #${current.counterNumber || '01'} पर जाएं।`,
        timestamp: new Date().toISOString(),
      };
      QueueStorage.addNotification(notif);
      setNotifications(QueueStorage.getNotifications());
    } else if (current.status === 'waiting') {
      const { positionAhead } = getTokenQueuePosition(current, tokens, counters, services);
      if (positionAhead > 0 && positionAhead <= 2) {
        const alreadyAlerted = notifications.some(
          (n) => n.tokenId === current.id && n.type === 'turn_approaching' && n.messageEn.includes(`${positionAhead}`)
        );
        if (!alreadyAlerted) {
          const notif: QueueNotification = {
            id: `notif-${Date.now()}`,
            tokenId: current.id,
            tokenNumber: current.tokenNumber,
            type: 'turn_approaching',
            titleEn: `Turn Approaching!`,
            titleHi: `आपकी बारी आने वाली है!`,
            messageEn: `Token ${current.tokenNumber}: Only ${positionAhead} person ahead. Please remain nearby.`,
            messageHi: `टोकन ${current.tokenNumber}: आपके आगे केवल ${positionAhead} व्यक्ति शेष हैं।`,
            timestamp: new Date().toISOString(),
          };
          QueueStorage.addNotification(notif);
          setNotifications(QueueStorage.getNotifications());
        }
      }
    }
  }, [tokens, activeUserToken, counters, services]);

  // Handle Theme Switching
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [isDark]);

  // Sector-filtered collections
  const sectorServices = services.filter((s) => s.sector === currentSector);
  const sectorCounters = counters.filter((c) => c.sector === currentSector);
  const sectorTokens = tokens.filter((tok) => tok.sector === currentSector);

  // Currently Serving Token in this Sector
  const currentlyServing = sectorTokens.find((tok) => tok.status === 'serving');
  const servingCounter = sectorCounters.find(
    (c) => c.id === currentlyServing?.counterId || c.currentTokenNumber === currentlyServing?.tokenNumber
  );

  // Next Token In Line
  const waitingTokens = sectorTokens.filter((tok) => tok.status === 'waiting');
  const nextInLine = waitingTokens[0];
  const recentCompleted = sectorTokens.filter((tok) => tok.status === 'completed');

  // Operational Statistics for Sector
  const openCounters = sectorCounters.filter((c) => c.status === 'open' || c.status === 'busy');
  const avgWait =
    openCounters.length > 0 && waitingTokens.length > 0
      ? Math.round(
          ((waitingTokens.length * 7.5) / Math.max(1, openCounters.length)) * 10
        ) / 10
      : 0;

  // Counter Control Handlers
  const handleCallNextCounter = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter) return;

    const eligible = tokens.filter(
      (tok) => tok.status === 'waiting' && counter.compatibleServices.includes(tok.serviceCode)
    );

    if (eligible.length === 0) {
      alert(lang === 'hi' ? 'इस काउंटर के लिए कोई प्रतीक्षा टोकन नहीं है।' : 'No waiting tickets matching this counter.');
      return;
    }

    const nextTok = eligible[0];

    const updatedTokens = tokens.map((tok) => {
      if (tok.id === counter.currentTokenId && tok.status === 'serving') {
        return {
          ...tok,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          actualWaitMinutes: Math.round(Math.random() * 4 + 5),
        };
      }
      if (tok.id === nextTok.id) {
        return {
          ...tok,
          status: 'serving' as const,
          counterId: counter.id,
          counterNumber: counter.counterNumber,
          calledAt: new Date().toISOString(),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        return {
          ...c,
          status: 'busy' as const,
          currentTokenNumber: nextTok.tokenNumber,
          currentTokenId: nextTok.id,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    setTokens(updatedTokens);
    setCounters(updatedCounters);
    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);

    if (audioEnabled) {
      announceTokenTurn(nextTok.tokenNumber, counter.counterNumber, lang);
    }
  };

  const handleCompleteService = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter || !counter.currentTokenId) return;

    const updatedTokens = tokens.map((tok) => {
      if (tok.id === counter.currentTokenId) {
        return {
          ...tok,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          actualWaitMinutes: Math.round(Math.random() * 4 + 6),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        return {
          ...c,
          status: 'open' as const,
          currentTokenNumber: undefined,
          currentTokenId: undefined,
          totalServedToday: c.totalServedToday + 1,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    setTokens(updatedTokens);
    setCounters(updatedCounters);
    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);
  };

  const handleRecallService = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter || !counter.currentTokenNumber) return;

    if (audioEnabled) {
      announceTokenTurn(counter.currentTokenNumber, counter.counterNumber, lang);
    }
  };

  return (
    <div className={`min-h-screen relative overflow-x-hidden ${isDark ? 'bg-[#0D1117] text-white' : 'bg-[#F2F4F8] text-[#1A1A1A]'}`}>
      {/* Liquid Chromatic Mesh Canvas Underlay */}
      <div className="liquid-mesh-background" />

      {/* Sticky Liquid Glass Navbar */}
      <Navbar
        currentSector={currentSector}
        onSelectSector={setCurrentSector}
        lang={lang}
        onToggleLang={() => setLang(lang === 'en' ? 'hi' : 'en')}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        audioEnabled={audioEnabled}
        onToggleAudio={() => setAudioEnabled(!audioEnabled)}
        onOpenRegister={() => setIsRegisterOpen(true)}
        onOpenTracker={() => setIsTrackerOpen(true)}
        activeView={activeView}
        onSelectView={setActiveView}
        userTokenCount={activeUserToken ? 1 : 0}
        notificationCount={notifications.length}
        onOpenNotifications={() => setIsNotificationHistoryOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6 relative z-10 pb-28 sm:pb-32">
        {/* Pass View (When customer inspects their digital pass) */}
        {activeView === 'pass' && activeUserToken ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setActiveView('public')}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-xs font-semibold text-[#64D2FF] transition-all"
              >
                ← {lang === 'hi' ? 'वापस लाइव कतार डिस्प्ले' : 'Back to Live Queue Display'}
              </button>
            </div>
            <DigitalTokenPass
              token={activeUserToken}
              allTokens={tokens}
              counters={counters}
              services={services}
              lang={lang}
              onOpenTracker={() => setIsTrackerOpen(true)}
              onClose={() => setActiveView('public')}
            />
          </div>
        ) : activeView === 'admin' ? (
          /* Staff Operations Cockpit */
          <AdminDashboard
            counters={sectorCounters}
            services={sectorServices}
            tokens={sectorTokens}
            priorityRules={priorityRules}
            appointments={appointments}
            lang={lang}
            onUpdateCounters={(updated) => {
              setCounters(updated);
              QueueStorage.saveCounters(updated);
            }}
            onUpdateServices={(updated) => {
              setServices(updated);
              localStorage.setItem('queuesmart_services', JSON.stringify(updated));
            }}
            onUpdateTokens={(updated) => {
              setTokens(updated);
              QueueStorage.saveTokens(updated);
            }}
            onUpdateAppointments={(updated) => {
              setAppointments(updated);
              QueueStorage.saveAppointments(updated);
            }}
          />
        ) : (
          /* Public Live Display */
          <>
            {/* Top Telemetry Bento: Now Serving, Next In Line, Queue Metric Chips */}
            <HeroTelemetry
              currentlyServing={currentlyServing}
              servingCounter={servingCounter}
              nextInLine={nextInLine}
              recentCompleted={recentCompleted}
              waitingCount={waitingTokens.length}
              averageWait={avgWait}
              activeCountersCount={openCounters.length}
              lang={lang}
              onOpenRegister={() => setIsRegisterOpen(true)}
            />

            {/* Transparent Deterministic Formula Card */}
            <DeterministicFormulaCard
              services={sectorServices}
              counters={sectorCounters}
              tokens={sectorTokens}
              lang={lang}
            />

            {/* Live Counter Matrix (6 Counters) */}
            <LiveCounterGrid
              counters={sectorCounters}
              services={sectorServices}
              tokens={sectorTokens}
              lang={lang}
              onCallNext={handleCallNextCounter}
              onCompleteService={handleCompleteService}
              onRecallService={handleRecallService}
            />

            {/* Waiting Queue List with Priority Badges */}
            <WaitingQueueList
              tokens={sectorTokens}
              services={sectorServices}
              counters={sectorCounters}
              lang={lang}
              onSelectToken={(tok) => {
                setActiveUserToken(tok);
                setActiveView('pass');
              }}
            />
          </>
        )}
      </main>

      {/* Floating Simulation Dock */}
      <SimulationController
        services={services}
        counters={counters}
        tokens={tokens}
        currentSector={currentSector}
        lang={lang}
        onRefreshData={loadData}
        onUserTokenCreated={(tok) => {
          setActiveUserToken(tok);
        }}
      />

      {/* Modals & Dialogs */}
      <TokenRegistrationModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        services={services}
        counters={counters}
        appointments={appointments}
        currentSector={currentSector}
        lang={lang}
        onTokenGenerated={(token) => {
          setActiveUserToken(token);
          setActiveView('pass');
          const notif: QueueNotification = {
            id: `notif-${Date.now()}`,
            tokenId: token.id,
            tokenNumber: token.tokenNumber,
            type: 'issued',
            titleEn: `Token Issued: ${token.tokenNumber}`,
            titleHi: `टोकन जारी: ${token.tokenNumber}`,
            messageEn: `Your digital queue pass is ready. Estimated wait: ~${token.estimatedWaitMinutes} mins.`,
            messageHi: `आपका डिजिटल पास तैयार है। अनुमानित प्रतीक्षा: ~${token.estimatedWaitMinutes} मिनट।`,
            timestamp: new Date().toISOString(),
          };
          QueueStorage.addNotification(notif);
          setNotifications(QueueStorage.getNotifications());
        }}
      />

      <TokenTrackerDialog
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
        tokens={tokens}
        counters={counters}
        services={services}
        lang={lang}
        onSelectToken={(token) => {
          setActiveUserToken(token);
          setActiveView('pass');
        }}
      />

      {/* Simulated Notifications Component */}
      <NotificationToast
        notifications={notifications}
        lang={lang}
        onDismiss={(id) => {
          setNotifications((prev) => prev.filter((n) => n.id !== id));
        }}
        isOpenHistory={isNotificationHistoryOpen}
        onCloseHistory={() => setIsNotificationHistoryOpen(false)}
      />

      {/* Global Footer */}
      <footer className="mt-12 sm:mt-16 border-t border-white/10 py-6 sm:py-8 px-4 text-center text-xs text-white/50 relative z-10 backdrop-blur-md pb-24 sm:pb-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">QueueSmart AI</span>
            <span>— Apple Liquid Glass Queue Engine</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1.5 text-[#35D6A4]">
              <Database className="w-3.5 h-3.5" />
              <span>
                {isSupabaseConfigured ? 'Supabase Live Connected' : 'Supabase Demo Engine Active'}
              </span>
            </span>

            <span className="flex items-center gap-1.5 text-[#4F8CFF]">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>HIPAA & DPDP Ready</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
