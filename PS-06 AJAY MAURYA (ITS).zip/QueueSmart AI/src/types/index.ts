export type SectorType = 'healthcare' | 'banking' | 'civic';

export type PriorityTier = 'emergency' | 'senior' | 'vip' | 'regular';

export type TokenStatus = 'waiting' | 'serving' | 'completed' | 'skipped' | 'cancelled';

export type CounterStatus = 'open' | 'busy' | 'paused' | 'closed';

export type Language = 'en' | 'hi';

export interface Service {
  code: string;
  sector: SectorType;
  nameEn: string;
  nameHi: string;
  avgDurationMinutes: number;
  prefix: string;
  color: string;
  isActive: boolean;
  descriptionEn: string;
  descriptionHi: string;
}

export interface PriorityRule {
  tierCode: PriorityTier;
  tierNameEn: string;
  tierNameHi: string;
  priorityLevel: number; // 1 = highest, 4 = regular
  color: string;
  badgeBg: string;
  eligibilityEn: string;
  eligibilityHi: string;
}

export interface ServiceCounter {
  id: string;
  counterNumber: number;
  nameEn: string;
  nameHi: string;
  operatorName: string;
  sector: SectorType;
  status: CounterStatus;
  compatibleServices: string[]; // service codes
  currentTokenNumber?: string;
  currentTokenId?: string;
  totalServedToday: number;
  avgPaceMinutes: number;
  lastUpdated: string;
}

export interface QueueToken {
  id: string;
  tokenNumber: string;
  sector: SectorType;
  serviceCode: string;
  customerName: string;
  customerPhone: string;
  priorityTier: PriorityTier;
  status: TokenStatus;
  counterId?: string;
  counterNumber?: number;
  estimatedWaitMinutes: number;
  actualWaitMinutes?: number;
  appointmentTime?: string;
  createdAt: string;
  calledAt?: string;
  completedAt?: string;
  notes?: string;
}

export interface AppointmentSlot {
  id: string;
  serviceCode: string;
  slotTime: string;
  maxCapacity: number;
  bookedCount: number;
  isAvailable: boolean;
}

export interface QueueNotification {
  id: string;
  tokenId: string;
  tokenNumber: string;
  type: 'issued' | 'turn_approaching' | 'called' | 'completed';
  titleEn: string;
  titleHi: string;
  messageEn: string;
  messageHi: string;
  timestamp: string;
}

export interface DeterministicTelemetry {
  serviceCode: string;
  serviceName: string;
  peopleAhead: number;
  avgDurationMinutes: number;
  compatibleOpenCounters: number;
  estimatedWaitMinutes: number;
  confidenceBand: {
    min: number;
    max: number;
  };
  hasZeroCounters: boolean;
}

export interface AllocationSuggestion {
  id: string;
  serviceCode: string;
  serviceName: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  queueBacklog: number;
  currentOpenCounters: number;
  recommendedCounterNumber: number;
  estimatedWaitBefore: number;
  estimatedWaitAfter: number;
  reasoningEn: string;
  reasoningHi: string;
}
