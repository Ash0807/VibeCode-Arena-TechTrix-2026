import React, { useState, useEffect } from 'react';
import {
  Activity,
  Volume2,
  VolumeX,
  Globe,
  Sun,
  Moon,
  PlusCircle,
  Search,
  Sliders,
  Ticket,
  Building2,
  Stethoscope,
  Landmark,
  Menu,
  X,
  Radio,
  Bell,
} from 'lucide-react';
import { SectorType, Language } from '../types';
import { translations } from '../i18n/translations';

interface NavbarProps {
  currentSector: SectorType;
  onSelectSector: (sector: SectorType) => void;
  lang: Language;
  onToggleLang: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenRegister: () => void;
  onOpenTracker: () => void;
  activeView: 'public' | 'admin' | 'pass';
  onSelectView: (view: 'public' | 'admin' | 'pass') => void;
  userTokenCount: number;
  notificationCount?: number;
  onOpenNotifications?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentSector,
  onSelectSector,
  lang,
  onToggleLang,
  isDark,
  onToggleTheme,
  audioEnabled,
  onToggleAudio,
  onOpenRegister,
  onOpenTracker,
  activeView,
  onSelectView,
  userTokenCount,
  notificationCount = 0,
  onOpenNotifications,
}) => {
  const t = translations[lang];
  const [timeStr, setTimeStr] = useState<string>('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString(lang === 'hi' ? 'hi-IN' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lang]);

  const handleMobileNav = (action: () => void) => {
    action();
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-2xl bg-[#090C10]/85 dark:bg-[#090C10]/85 light:bg-white/85 border-b border-white/10 dark:border-white/10 light:border-slate-200 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5">
        <div className="flex items-center justify-between gap-3">
          {/* Brand Identity */}
          <div
            onClick={() => {
              onSelectView('public');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-2.5 cursor-pointer select-none group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#0A84FF] to-[#0066CC] flex items-center justify-center shadow-sm">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-white dark:text-white light:text-slate-900">
                  QueueSmart
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-md bg-[#0A84FF]/15 text-[#0A84FF] border border-[#0A84FF]/25">
                  AI
                </span>
              </div>
              <p className="hidden sm:flex text-[11px] text-white/50 dark:text-white/50 light:text-slate-500 font-medium items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] inline-block" />
                <span>IST {timeStr}</span>
              </p>
            </div>
          </div>

          {/* Desktop Sector Segmented Switcher */}
          <div className="hidden lg:flex items-center p-1 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200">
            <button
              onClick={() => {
                onSelectSector('healthcare');
                onSelectView('public');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentSector === 'healthcare'
                  ? 'bg-[#0A84FF] text-white shadow-sm'
                  : 'text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'अस्पताल (OPD)' : 'Healthcare OPD'}</span>
            </button>

            <button
              onClick={() => {
                onSelectSector('banking');
                onSelectView('public');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentSector === 'banking'
                  ? 'bg-[#5E5CE6] text-white shadow-sm'
                  : 'text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
              }`}
            >
              <Landmark className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'प्रीमियर बैंकिंग' : 'Premier Banking'}</span>
            </button>

            <button
              onClick={() => {
                onSelectSector('civic');
                onSelectView('public');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentSector === 'civic'
                  ? 'bg-[#10B981] text-white shadow-sm'
                  : 'text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'नागरिक सेवा' : 'Citizen Hub'}</span>
            </button>
          </div>

          {/* Desktop Right Utilities & Action Buttons */}
          <div className="hidden md:flex items-center gap-2">
            {/* Audio Chime Toggle */}
            <button
              onClick={onToggleAudio}
              className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all ${
                audioEnabled
                  ? 'bg-[#10B981]/15 border-[#10B981]/30 text-[#10B981]'
                  : 'bg-white/5 border-white/10 text-white/50 hover:text-white'
              }`}
              title={audioEnabled ? t.nav.chimeActive : t.nav.chimeMuted}
            >
              {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Language Switch */}
            <button
              onClick={onToggleLang}
              className="h-9 px-2.5 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-xs font-semibold text-white/80 dark:text-white/80 light:text-slate-700 hover:bg-white/10 flex items-center gap-1.5"
              title="Toggle Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#0A84FF]" />
              <span>{t.nav.languageToggle}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className="w-9 h-9 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-white/80 dark:text-white/80 light:text-slate-700 flex items-center justify-center hover:bg-white/10"
              title="Toggle Theme"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-500" />}
            </button>

            {/* Notification Feed Toggle */}
            <button
              onClick={onOpenNotifications}
              className="relative w-9 h-9 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-white/80 dark:text-white/80 light:text-slate-700 flex items-center justify-center hover:bg-white/10"
              title="Simulated Alerts"
              aria-label="View simulated notifications"
            >
              <Bell className="w-4 h-4 text-[#8B5CF6]" />
              {notificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#4F8CFF] text-[10px] font-bold text-white flex items-center justify-center shadow-sm">
                  {notificationCount}
                </span>
              )}
            </button>

            {/* Track Ticket Dialog Button */}
            <button
              onClick={onOpenTracker}
              className="h-9 px-3 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-xs font-medium text-white/80 dark:text-white/80 light:text-slate-700 hover:bg-white/10 flex items-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5 text-white/60" />
              <span>{t.nav.trackToken}</span>
            </button>

            {/* My Active Pass Button */}
            {userTokenCount > 0 && (
              <button
                onClick={() => onSelectView('pass')}
                className={`h-9 px-3 rounded-xl text-xs font-semibold transition-all border flex items-center gap-1.5 ${
                  activeView === 'pass'
                    ? 'bg-[#8B5CF6] text-white border-transparent'
                    : 'bg-white/5 text-[#c2c1ff] border-[#8B5CF6]/30 hover:bg-[#8B5CF6]/20'
                }`}
              >
                <Ticket className="w-3.5 h-3.5" />
                <span>{t.nav.myToken}</span>
              </button>
            )}

            {/* Staff Cockpit */}
            <button
              onClick={() => onSelectView(activeView === 'admin' ? 'public' : 'admin')}
              className={`h-9 px-3 rounded-xl text-xs font-semibold transition-all border flex items-center gap-1.5 ${
                activeView === 'admin'
                  ? 'bg-white/20 text-white border-white/30'
                  : 'bg-white/5 text-white/70 dark:text-white/70 light:text-slate-600 border-white/10 dark:border-white/10 light:border-slate-200 hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-[#4F8CFF]" />
              <span>{t.nav.staffConsole}</span>
            </button>

            {/* Primary Action Button */}
            <button
              onClick={onOpenRegister}
              className="liquid-button-primary"
            >
              <PlusCircle className="w-4 h-4 mr-1.5" />
              <span>{t.nav.registerToken}</span>
            </button>
          </div>

          {/* Mobile Fast Header Actions (Touch targets >= 44x44px) */}
          <div className="flex md:hidden items-center gap-1">
            <button
              onClick={onOpenNotifications}
              className="relative min-h-[44px] min-w-[44px] rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 text-white/80 dark:text-white/80 light:text-slate-700 flex items-center justify-center active:scale-95"
              aria-label="View simulated notifications"
            >
              <Bell className="w-4 h-4 text-[#8B5CF6]" />
              {notificationCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#4F8CFF] text-[9px] font-bold text-white flex items-center justify-center shadow-sm">
                  {notificationCount}
                </span>
              )}
            </button>

            <button
              onClick={onToggleLang}
              className="min-h-[44px] min-w-[40px] px-1.5 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 text-xs font-bold text-white/80 dark:text-white/80 light:text-slate-700 flex items-center justify-center active:scale-95"
              aria-label="Toggle Language"
            >
              {lang === 'en' ? 'हिन्दी' : 'EN'}
            </button>

            <button
              onClick={onOpenRegister}
              className="min-h-[44px] px-2.5 sm:px-3.5 rounded-xl bg-[#4F8CFF] text-white font-semibold text-xs flex items-center gap-1 shadow-sm active:scale-95"
              aria-label="Get Digital Token"
            >
              <PlusCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="hidden min-[360px]:inline">{t.nav.registerToken}</span>
              <span className="min-[360px]:hidden">Token</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="min-h-[44px] min-w-[40px] rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 text-white/80 dark:text-white/80 light:text-slate-700 flex items-center justify-center active:scale-95"
              aria-label="Open Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Sector Selector Bar */}
        <div className="flex lg:hidden items-center gap-1 mt-2.5 pt-2 border-t border-white/10 dark:border-white/10 light:border-slate-200 overflow-x-auto no-scrollbar pb-0.5">
          <button
            onClick={() => {
              onSelectSector('healthcare');
              onSelectView('public');
            }}
            className={`flex items-center gap-1.5 min-h-[38px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentSector === 'healthcare'
                ? 'bg-[#0A84FF] text-white shadow-sm'
                : 'bg-white/5 text-white/70 dark:text-white/70 light:text-slate-600'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'अस्पताल' : 'Healthcare'}</span>
          </button>

          <button
            onClick={() => {
              onSelectSector('banking');
              onSelectView('public');
            }}
            className={`flex items-center gap-1.5 min-h-[38px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentSector === 'banking'
                ? 'bg-[#5E5CE6] text-white shadow-sm'
                : 'bg-white/5 text-white/70 dark:text-white/70 light:text-slate-600'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'बैंकिंग' : 'Banking'}</span>
          </button>

          <button
            onClick={() => {
              onSelectSector('civic');
              onSelectView('public');
            }}
            className={`flex items-center gap-1.5 min-h-[38px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentSector === 'civic'
                ? 'bg-[#10B981] text-white shadow-sm'
                : 'bg-white/5 text-white/70 dark:text-white/70 light:text-slate-600'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'नागरिक सेवा' : 'Citizen Hub'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu (Full responsiveness on 360px - 768px) */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 dark:border-white/10 light:border-slate-200 bg-[#090C10] dark:bg-[#090C10] light:bg-white px-4 py-4 space-y-3 animate-fadeIn">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleMobileNav(() => onSelectView('public'))}
              className={`min-h-[44px] px-3 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
                activeView === 'public'
                  ? 'bg-white/15 text-white border-white/30'
                  : 'bg-white/5 text-white/70 border-white/10'
              }`}
            >
              <Radio className="w-4 h-4 text-[#0A84FF]" />
              <span>{t.nav.liveBoard}</span>
            </button>

            <button
              onClick={() => handleMobileNav(() => onSelectView('admin'))}
              className={`min-h-[44px] px-3 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
                activeView === 'admin'
                  ? 'bg-white/15 text-white border-white/30'
                  : 'bg-white/5 text-white/70 border-white/10'
              }`}
            >
              <Sliders className="w-4 h-4 text-[#5E5CE6]" />
              <span>{t.nav.staffConsole}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleMobileNav(onOpenTracker)}
              className="min-h-[44px] px-3 rounded-xl bg-white/5 border border-white/10 text-white/80 flex items-center gap-2 text-xs font-medium"
            >
              <Search className="w-4 h-4 text-white/50" />
              <span>{t.nav.trackToken}</span>
            </button>

            {userTokenCount > 0 ? (
              <button
                onClick={() => handleMobileNav(() => onSelectView('pass'))}
                className="min-h-[44px] px-3 rounded-xl bg-[#5E5CE6]/20 border border-[#5E5CE6]/40 text-[#c2c1ff] flex items-center gap-2 text-xs font-semibold"
              >
                <Ticket className="w-4 h-4 text-[#5E5CE6]" />
                <span>{t.nav.myToken}</span>
              </button>
            ) : (
              <button
                onClick={() => handleMobileNav(onOpenRegister)}
                className="min-h-[44px] px-3 rounded-xl bg-[#0A84FF]/20 border border-[#0A84FF]/40 text-[#64D2FF] flex items-center gap-2 text-xs font-semibold"
              >
                <PlusCircle className="w-4 h-4" />
                <span>{t.nav.registerToken}</span>
              </button>
            )}
          </div>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs text-white/60">
            <button
              onClick={onToggleAudio}
              className="min-h-[44px] flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs"
            >
              {audioEnabled ? <Volume2 className="w-4 h-4 text-[#10B981]" /> : <VolumeX className="w-4 h-4" />}
              <span>{audioEnabled ? t.nav.chimeActive : t.nav.chimeMuted}</span>
            </button>

            <button
              onClick={onToggleTheme}
              className="min-h-[44px] flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-400" />}
              <span>{isDark ? t.nav.themeLight : t.nav.themeDark}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
