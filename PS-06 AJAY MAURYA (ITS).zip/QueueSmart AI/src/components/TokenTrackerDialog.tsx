import React, { useState } from 'react';
import {
  X,
  Search,
  Ticket,
  Clock,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { QueueToken, Service, ServiceCounter, Language } from '../types';
import { translations } from '../i18n/translations';
import { getTokenQueuePosition } from '../lib/queueEngine';

interface TokenTrackerDialogProps {
  isOpen: boolean;
  onClose: () => void;
  tokens: QueueToken[];
  counters: ServiceCounter[];
  services: Service[];
  lang: Language;
  onSelectToken: (token: QueueToken) => void;
}

export const TokenTrackerDialog: React.FC<TokenTrackerDialogProps> = ({
  isOpen,
  onClose,
  tokens,
  counters,
  services,
  lang,
  onSelectToken,
}) => {
  const t = translations[lang];
  const [query, setQuery] = useState<string>('');
  const [searched, setSearched] = useState<boolean>(false);
  const [matchedToken, setMatchedToken] = useState<QueueToken | null>(null);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanQuery = query.trim().toUpperCase();
    if (!cleanQuery) return;

    const found = tokens.find(
      (tok) =>
        tok.tokenNumber.toUpperCase() === cleanQuery ||
        tok.customerPhone.includes(cleanQuery)
    );

    setMatchedToken(found || null);
    setSearched(true);
  };

  const getStatusDisplay = (token: QueueToken) => {
    if (token.status === 'serving') {
      return (
        <div className="p-4 rounded-2xl bg-[#0A84FF]/20 border border-[#0A84FF]/40 text-[#64D2FF]">
          <div className="flex items-center gap-2 font-bold text-sm mb-1">
            <Zap className="w-4 h-4 text-[#64D2FF]" />
            <span>{t.tracker.statusServing} {token.counterNumber || '01'}</span>
          </div>
          <p className="text-xs text-white/80">
            {lang === 'hi'
              ? 'कृपया सीधे काउंटर पर पहुंचकर अपना टोकन दिखाएं।'
              : 'Please proceed immediately to the counter to receive service.'}
          </p>
        </div>
      );
    }

    if (token.status === 'completed') {
      return (
        <div className="p-4 rounded-2xl bg-[#30D158]/20 border border-[#30D158]/40 text-[#30D158]">
          <div className="flex items-center gap-2 font-bold text-sm mb-1">
            <CheckCircle className="w-4 h-4" />
            <span>{t.tracker.statusCompleted}</span>
          </div>
          <p className="text-xs text-white/80">
            {lang === 'hi'
              ? 'आपकी सेवा सफलतापूर्वक पूर्ण हो चुकी है।'
              : 'Service finished. Thank you for using QueueSmart AI.'}
          </p>
        </div>
      );
    }

    // Waiting token
    const { positionAhead, estimatedWaitMinutes, hasZeroCounters } = getTokenQueuePosition(
      token,
      tokens,
      counters,
      services
    );

    return (
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-black/30 border border-white/5">
            <span className="text-[11px] text-white/50 block">
              {lang === 'hi' ? 'आगे लोग' : 'People Ahead'}
            </span>
            <span className="text-2xl font-bold text-white tabular-nums">
              {positionAhead}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-black/30 border border-white/5">
            <span className="text-[11px] text-white/50 block">
              {t.pass.estimatedWaitTime}
            </span>
            <span className="text-2xl font-bold text-[#64D2FF] tabular-nums">
              {hasZeroCounters ? 'Paused' : `~${estimatedWaitMinutes}m`}
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            onSelectToken(token);
            onClose();
          }}
          aria-label="View Full Digital Pass"
          className="w-full h-11 rounded-xl liquid-button-primary text-xs font-semibold flex items-center justify-center gap-2 active:scale-[0.98]"
        >
          <span>{lang === 'hi' ? 'डिजिटल पास देखें' : 'View Full Digital Pass'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md liquid-glass-card p-5 sm:p-7 rounded-3xl shadow-2xl border border-white/20">
        <button
          onClick={onClose}
          aria-label="Close ticket tracker"
          className="absolute top-4 right-4 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white/80 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5 sm:mb-6 pr-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0A84FF]/20 text-[#64D2FF] text-xs font-semibold mb-2">
            <Ticket className="w-3.5 h-3.5" />
            <span>Ticket Verification</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            {t.tracker.title}
          </h2>
          <p className="text-xs text-white/60 mt-1">
            {t.tracker.subtitle}
          </p>
        </div>

        <form onSubmit={handleSearch} className="mb-5">
          <div className="flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.tracker.placeholder}
              className="flex-1 h-11 px-3.5 py-2.5 liquid-input-well text-sm uppercase tracking-wider font-mono font-semibold"
            />
            <button
              type="submit"
              className="h-11 px-5 liquid-button-primary text-xs font-bold shrink-0 flex items-center justify-center gap-2 rounded-xl active:scale-[0.98]"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{t.tracker.btnSearch}</span>
            </button>
          </div>
        </form>

        {searched && (
          <div>
            {matchedToken ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div>
                    <span className="text-xs text-white/50 block">Customer</span>
                    <span className="text-sm font-bold text-white">
                      {matchedToken.customerName}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-white/50 block">Token</span>
                    <span className="text-lg font-mono font-extrabold text-[#64D2FF]">
                      {matchedToken.tokenNumber}
                    </span>
                  </div>
                </div>

                {getStatusDisplay(matchedToken)}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center">
                <AlertCircle className="w-6 h-6 text-white/40 mx-auto mb-2" />
                <p className="text-xs text-white/70">
                  {t.tracker.notFound}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
