import React, { useState } from 'react';
import {
  HelpCircle,
  TrendingDown,
  Info,
  Layers,
  Clock,
  Users,
  CheckCircle,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Service, ServiceCounter, QueueToken, Language } from '../types';
import { translations } from '../i18n/translations';
import { calculateDeterministicWait, getCompatibleOpenCounters } from '../lib/queueEngine';

interface DeterministicFormulaCardProps {
  services: Service[];
  counters: ServiceCounter[];
  tokens: QueueToken[];
  lang: Language;
}

export const DeterministicFormulaCard: React.FC<DeterministicFormulaCardProps> = ({
  services,
  counters,
  tokens,
  lang,
}) => {
  const t = translations[lang];
  const [selectedServiceCode, setSelectedServiceCode] = useState<string>(
    services[0]?.code || 'CARD'
  );
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [interactivePeopleAhead, setInteractivePeopleAhead] = useState<number | null>(null);

  const activeService = services.find((s) => s.code === selectedServiceCode) || services[0];

  if (!activeService) {
    return null;
  }

  const waitingTokens = tokens.filter(
    (tok) => tok.status === 'waiting' && tok.serviceCode === activeService.code
  );

  const compatibleOpenCounters = getCompatibleOpenCounters(counters, activeService.code);

  const peopleAhead =
    interactivePeopleAhead !== null ? interactivePeopleAhead : waitingTokens.length;

  const { waitMinutes, hasZeroCounters, confidenceBand } = calculateDeterministicWait(
    peopleAhead,
    activeService.avgDurationMinutes,
    compatibleOpenCounters.length
  );

  return (
    <div className="liquid-glass-card p-4 sm:p-6 md:p-7 mb-6 sm:mb-8 relative overflow-hidden">
      {/* Header and Service Tabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-[#0A84FF]/15 text-[#0A84FF]">
              <Layers className="w-4 h-4" />
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white dark:text-white light:text-slate-900 tracking-tight">
              {t.formula.title}
            </h3>
            <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 text-[10px] font-bold uppercase tracking-wider">
              Deterministic Math
            </span>
          </div>
          <p className="text-xs text-white/50 dark:text-white/50 light:text-slate-500">
            {t.formula.subtitle}
          </p>
        </div>

        {/* Category Tabs (Touch-friendly horizontal scroll) */}
        <div className="flex items-center gap-1.5 p-1 bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 rounded-xl overflow-x-auto no-scrollbar max-w-full">
          {services.map((svc) => (
            <button
              key={svc.code}
              onClick={() => {
                setSelectedServiceCode(svc.code);
                setInteractivePeopleAhead(null);
              }}
              className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedServiceCode === svc.code
                  ? 'bg-[#0A84FF] text-white shadow-sm'
                  : 'text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
              }`}
            >
              {lang === 'hi' ? svc.nameHi : svc.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* Formula Equation Banner (Responsive, never overflows) */}
      <div className="p-3 sm:p-4 rounded-xl liquid-recessed-well mb-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs font-mono">
          <div className="flex items-center gap-2 text-[#0A84FF]">
            <Info className="w-4 h-4 shrink-0 text-[#0A84FF]" />
            <span className="font-semibold text-xs sm:text-sm">
              {t.formula.formulaDisplay}
            </span>
          </div>
          <div className="text-white/40 dark:text-white/40 light:text-slate-400 text-[11px] font-sans">
            T_wait = (N_ahead × μ) ÷ C_open
          </div>
        </div>
      </div>

      {/* Zero Counters Guard Banner */}
      {hasZeroCounters && (
        <div className="p-3.5 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 flex items-start gap-2.5 mb-5 text-xs text-[#EF4444]">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold uppercase tracking-wider block">
              {lang === 'hi' ? 'काउंटर उपलब्ध नहीं' : 'No Active Compatible Counters'}
            </span>
            <p className="text-white/80 dark:text-white/80 light:text-slate-700 mt-0.5">
              {t.formula.zeroCountersWarning}
            </p>
          </div>
        </div>
      )}

      {/* Live Variable Telemetry Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-5">
        {/* Variable 1: People Ahead (N) */}
        <div className="p-4 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-50 border border-white/10 dark:border-white/10 light:border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-white/50 dark:text-white/50 light:text-slate-500 font-medium">
            <span>{t.formula.peopleAhead}</span>
            <Users className="w-4 h-4 text-[#0A84FF]" />
          </div>
          <div className="my-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
              {peopleAhead}
            </span>
            <span className="text-xs text-white/40 ml-1.5">{t.hero.people}</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <input
              type="range"
              min="0"
              max="25"
              value={peopleAhead}
              onChange={(e) => setInteractivePeopleAhead(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-white/20 dark:bg-white/20 light:bg-slate-300 rounded-lg appearance-none cursor-pointer accent-[#0A84FF]"
              aria-label="Adjust people ahead parameter"
            />
            {interactivePeopleAhead !== null && (
              <button
                onClick={() => setInteractivePeopleAhead(null)}
                className="text-[10px] text-white/50 hover:text-white underline whitespace-nowrap"
              >
                Reset
              </button>
            )}
          </div>
        </div>

        {/* Variable 2: Mean Duration (μ) */}
        <div className="p-4 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-50 border border-white/10 dark:border-white/10 light:border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-white/50 dark:text-white/50 light:text-slate-500 font-medium">
            <span>{t.formula.meanDuration}</span>
            <Clock className="w-4 h-4 text-[#F59E0B]" />
          </div>
          <div className="my-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
              {activeService.avgDurationMinutes}
            </span>
            <span className="text-xs text-white/40 ml-1.5">{t.hero.mins}</span>
          </div>
          <span className="text-[11px] text-white/40 dark:text-white/40 light:text-slate-500">
            {lang === 'hi' ? 'विभाग मानक गति' : 'Category Historical SLA'}
          </span>
        </div>

        {/* Variable 3: Open Compatible Counters (C) */}
        <div className="p-4 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-50 border border-white/10 dark:border-white/10 light:border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-white/50 dark:text-white/50 light:text-slate-500 font-medium">
            <span>{t.formula.openCounters}</span>
            <CheckCircle className="w-4 h-4 text-[#10B981]" />
          </div>
          <div className="my-2">
            <span
              className={`text-2xl sm:text-3xl font-extrabold tabular-nums ${
                compatibleOpenCounters.length > 0 ? 'text-white dark:text-white light:text-slate-900' : 'text-[#EF4444]'
              }`}
            >
              {compatibleOpenCounters.length}
            </span>
            <span className="text-xs text-white/40 ml-1.5">
              {lang === 'hi' ? 'सक्रिय' : 'operational'}
            </span>
          </div>
          <span className="text-[11px] text-white/40 dark:text-white/40 light:text-slate-500">
            {compatibleOpenCounters.length > 0
              ? `Counters: ${compatibleOpenCounters.map((c) => `#${c.counterNumber}`).join(', ')}`
              : 'All offline'}
          </span>
        </div>

        {/* Computed Result: Estimated Wait Time */}
        <div className="p-4 rounded-xl bg-[#0A84FF]/10 dark:bg-[#0A84FF]/10 light:bg-blue-50 border border-[#0A84FF]/30 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-[#0A84FF] font-bold">
            <span>{t.formula.calculatedResult}</span>
            <TrendingDown className="w-4 h-4" />
          </div>
          <div className="my-2">
            <span className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
              {hasZeroCounters ? '—' : `~${waitMinutes}`}
            </span>
            {!hasZeroCounters && <span className="text-xs text-white/60 ml-1.5">{t.hero.mins}</span>}
          </div>
          <div className="text-[11px] text-white/60 dark:text-white/60 light:text-slate-600">
            {hasZeroCounters
              ? 'Paused'
              : `${t.formula.confidenceRange}: ${confidenceBand.min}m - ${confidenceBand.max}m`}
          </div>
        </div>
      </div>

      {/* Socratic Explainability Collapsible */}
      <div className="border-t border-white/10 dark:border-white/10 light:border-slate-200 pt-3">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full min-h-[38px] text-xs font-semibold text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white transition-colors"
        >
          <span className="flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-[#0A84FF]" />
            {t.formula.explainabilityTitle}
          </span>
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {isExpanded && (
          <div className="mt-2.5 text-xs text-white/70 dark:text-white/70 light:text-slate-600 leading-relaxed liquid-recessed-well p-3.5 animate-fadeIn">
            <p className="mb-2">{t.formula.explainabilityBody}</p>
            <p className="font-mono text-[11px] text-[#0A84FF]">
              Formula: (N_ahead × μ) ÷ C_open
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
