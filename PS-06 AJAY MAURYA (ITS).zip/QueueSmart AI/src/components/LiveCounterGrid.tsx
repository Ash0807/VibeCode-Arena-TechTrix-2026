import React from 'react';
import {
  Zap,
  Volume2,
  CheckCircle2,
  PauseCircle,
  XCircle,
  PlayCircle,
  Clock,
  User,
  Layers,
} from 'lucide-react';
import { ServiceCounter, QueueToken, Service, Language } from '../types';
import { translations } from '../i18n/translations';

interface LiveCounterGridProps {
  counters: ServiceCounter[];
  services: Service[];
  tokens: QueueToken[];
  lang: Language;
  onCallNext: (counterId: string) => void;
  onCompleteService: (counterId: string) => void;
  onRecallService: (counterId: string) => void;
}

export const LiveCounterGrid: React.FC<LiveCounterGridProps> = ({
  counters,
  services,
  tokens,
  lang,
  onCallNext,
  onCompleteService,
  onRecallService,
}) => {
  const t = translations[lang];

  const getStatusBadge = (status: ServiceCounter['status']) => {
    switch (status) {
      case 'open':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 text-[11px] font-semibold">
            <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-[#10B981]" />
            <span>{t.counters.statusOpen}</span>
          </span>
        );
      case 'busy':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#0A84FF]/15 text-[#0A84FF] border border-[#0A84FF]/30 text-[11px] font-semibold">
            <Zap className="w-3 h-3 text-[#0A84FF]" />
            <span>{t.counters.statusBusy}</span>
          </span>
        );
      case 'paused':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 text-[11px] font-semibold">
            <PauseCircle className="w-3 h-3" />
            <span>{t.counters.statusPaused}</span>
          </span>
        );
      case 'closed':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 dark:bg-white/10 light:bg-slate-200 text-white/50 dark:text-white/50 light:text-slate-600 border border-white/10 text-[11px] font-medium">
            <XCircle className="w-3 h-3" />
            <span>{t.counters.statusClosed}</span>
          </span>
        );
    }
  };

  return (
    <section className="w-full mb-6 sm:mb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-white dark:text-white light:text-slate-900 tracking-tight flex items-center gap-2">
            <span className="p-1 rounded-md bg-[#10B981]/15 text-[#10B981]">
              <Layers className="w-4 h-4" />
            </span>
            <span>{t.counters.title}</span>
          </h3>
          <p className="text-xs text-white/50 dark:text-white/50 light:text-slate-500">
            {t.counters.subtitle}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
        {counters.map((cnt) => {
          return (
            <div
              key={cnt.id}
              className={`liquid-glass-card p-4 sm:p-5 flex flex-col justify-between transition-all ${
                cnt.status === 'busy'
                  ? 'border-[#0A84FF]/40'
                  : cnt.status === 'open'
                  ? 'border-[#10B981]/30'
                  : 'opacity-80'
              }`}
            >
              {/* Counter Header */}
              <div>
                <div className="flex items-center justify-between pb-2.5 border-b border-white/10 dark:border-white/10 light:border-slate-200 gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#0A84FF] bg-[#0A84FF]/15 px-2 py-0.5 rounded-md">
                      C-{String(cnt.counterNumber).padStart(2, '0')}
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-white dark:text-white light:text-slate-900">
                      {lang === 'hi' ? cnt.nameHi : cnt.nameEn}
                    </span>
                  </div>
                  {getStatusBadge(cnt.status)}
                </div>

                {/* Operator Meta & Service Tags */}
                <div className="my-3 space-y-1.5">
                  <div className="text-xs font-medium text-white/80 dark:text-white/80 light:text-slate-700 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-white/40" />
                    <span>{cnt.operatorName}</span>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {cnt.compatibleServices.map((code) => {
                      const svc = services.find((s) => s.code === code);
                      return (
                        <span
                          key={code}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-white/60 dark:text-white/60 light:text-slate-600"
                        >
                          {svc ? (lang === 'hi' ? svc.nameHi : svc.nameEn) : code}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Serving Status Card */}
                <div className="p-3 rounded-xl liquid-recessed-well my-2">
                  <div className="flex items-center justify-between text-[11px] text-white/50 dark:text-white/50 light:text-slate-500">
                    <span className="uppercase tracking-wider">{t.counters.servingNow}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{cnt.avgPaceMinutes}m pace</span>
                    </span>
                  </div>

                  <div className="mt-1 flex items-baseline justify-between">
                    {cnt.currentTokenNumber ? (
                      <span className="text-2xl sm:text-3xl font-extrabold text-[#0A84FF] font-mono tracking-tight">
                        {cnt.currentTokenNumber}
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-white/40 dark:text-white/40 light:text-slate-400 italic">
                        {cnt.status === 'open' ? 'Ready for next token' : 'Desk paused / idle'}
                      </span>
                    )}

                    <span className="text-[11px] text-white/50 dark:text-white/50 light:text-slate-500">
                      {t.counters.servedToday}: <strong className="text-white dark:text-white light:text-slate-900 font-mono">{cnt.totalServedToday}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons (Touch targets: 44px min-height on mobile) */}
              <div className="mt-3 pt-3 border-t border-white/10 dark:border-white/10 light:border-slate-200 grid grid-cols-3 gap-1.5 sm:gap-2">
                <button
                  onClick={() => onCallNext(cnt.id)}
                  disabled={cnt.status === 'closed'}
                  className="min-h-[44px] py-1.5 px-2 rounded-xl liquid-button-primary text-xs font-semibold flex items-center justify-center gap-1 disabled:opacity-40"
                  title="Call Next Token"
                >
                  <PlayCircle className="w-3.5 h-3.5" />
                  <span>{t.counters.callNext}</span>
                </button>

                <button
                  onClick={() => onCompleteService(cnt.id)}
                  disabled={!cnt.currentTokenNumber}
                  className="min-h-[44px] py-1.5 px-2 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-[#10B981] hover:bg-[#10B981]/25 text-xs font-semibold flex items-center justify-center gap-1 disabled:opacity-30"
                  title="Complete Service"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{t.counters.completeService}</span>
                </button>

                <button
                  onClick={() => onRecallService(cnt.id)}
                  disabled={!cnt.currentTokenNumber}
                  className="min-h-[44px] py-1.5 px-2 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 dark:border-white/10 light:border-slate-200 text-white/80 dark:text-white/80 light:text-slate-700 hover:bg-white/10 text-xs font-semibold flex items-center justify-center gap-1 disabled:opacity-30"
                  title="Recall Audio Chime"
                >
                  <Volume2 className="w-3.5 h-3.5 text-[#0A84FF]" />
                  <span>{lang === 'hi' ? 'पुनः' : 'Recall'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
