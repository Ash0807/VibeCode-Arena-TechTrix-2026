import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Shield,
  HeartPulse,
  UserCheck,
  Crown,
  User,
  Clock,
  Phone,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  Service,
  ServiceCounter,
  PriorityTier,
  Language,
  QueueToken,
  AppointmentSlot,
  SectorType,
} from '../types';
import { translations } from '../i18n/translations';
import { QueueStorage } from '../lib/supabase';
import {
  calculateDeterministicWait,
  getCompatibleOpenCounters,
} from '../lib/queueEngine';

interface TokenRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: Service[];
  counters: ServiceCounter[];
  appointments: AppointmentSlot[];
  currentSector: SectorType;
  lang: Language;
  onTokenGenerated: (token: QueueToken) => void;
}

export const TokenRegistrationModal: React.FC<TokenRegistrationModalProps> = ({
  isOpen,
  onClose,
  services,
  counters,
  appointments,
  currentSector,
  lang,
  onTokenGenerated,
}) => {
  const t = translations[lang];

  // Filter services by active sector
  const sectorServices = services.filter((s) => s.sector === currentSector && s.isActive);

  const [selectedServiceCode, setSelectedServiceCode] = useState<string>(
    sectorServices[0]?.code || 'CARD'
  );
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [priorityTier, setPriorityTier] = useState<PriorityTier>('regular');
  const [selectedSlot, setSelectedSlot] = useState<string>('walkin');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const activeService =
    sectorServices.find((s) => s.code === selectedServiceCode) || sectorServices[0];

  if (!activeService) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim()) {
      setErrorMsg(
        lang === 'hi' ? 'कृपया अपना नाम दर्ज करें' : 'Please enter your full name'
      );
      return;
    }

    if (!customerPhone.trim() || customerPhone.trim().length < 8) {
      setErrorMsg(
        lang === 'hi'
          ? 'कृपया एक वैध मोबाइल नंबर दर्ज करें'
          : 'Please enter a valid phone number (minimum 8 digits)'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const existingTokens = QueueStorage.getTokens();

      // Generate readable unique token number
      // e.g. H-204, B-105, C-301
      const prefix = activeService ? activeService.prefix : 'Q';
      const existingInSector = existingTokens.filter((tok) => tok.sector === currentSector);
      const nextSequence = 200 + existingInSector.length + 1;
      const tokenNumber = `${prefix}-${nextSequence}`;

      // Calculate initial deterministic wait
      const openCounters = getCompatibleOpenCounters(counters, selectedServiceCode);
      const waitingAhead = existingTokens.filter(
        (t) => t.status === 'waiting' && t.serviceCode === selectedServiceCode
      ).length;

      const { waitMinutes } = calculateDeterministicWait(
        waitingAhead,
        activeService.avgDurationMinutes,
        openCounters.length
      );

      const newToken: QueueToken = {
        id: `tok-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        tokenNumber,
        sector: currentSector,
        serviceCode: selectedServiceCode,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        priorityTier,
        status: 'waiting',
        estimatedWaitMinutes: waitMinutes,
        appointmentTime: selectedSlot !== 'walkin' ? selectedSlot : undefined,
        createdAt: new Date().toISOString(),
      };

      // Save token to reactive storage
      QueueStorage.saveTokens([...existingTokens, newToken]);

      // Trigger Confetti!
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#0A84FF', '#5E5CE6', '#30D158'],
      });

      // Pass token to parent and close modal
      onTokenGenerated(newToken);
      onClose();
    } catch (err) {
      console.error('Registration error:', err);
      setErrorMsg(
        lang === 'hi'
          ? 'पंजीकरण में त्रुटि। कृपया पुनः प्रयास करें।'
          : 'Registration failed. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full sm:max-w-xl liquid-glass-card rounded-t-3xl sm:rounded-3xl p-5 sm:p-7 max-h-[92vh] sm:max-h-[88vh] overflow-y-auto shadow-2xl border-t sm:border border-white/20">
        {/* Mobile Drag Indicator */}
        <div className="sm:hidden w-12 h-1 rounded-full bg-white/20 mx-auto mb-4" />

        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close registration"
          className="absolute top-4 right-4 sm:top-5 sm:right-5 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white/80 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-5 sm:mb-6 pr-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0A84FF]/20 text-[#64D2FF] text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.appTitle}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {t.registration.title}
          </h2>
          <p className="text-xs sm:text-sm text-white/60 mt-1">
            {t.registration.subtitle}
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-[#FF453A]/15 border border-[#FF453A]/30 text-xs text-[#FF453A] flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
          {/* Service Category Picker */}
          <div>
            <label className="block text-xs font-semibold text-white/80 uppercase tracking-wider mb-2">
              {t.registration.selectSector}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {sectorServices.map((svc) => (
                <button
                  type="button"
                  key={svc.code}
                  onClick={() => setSelectedServiceCode(svc.code)}
                  className={`p-3 rounded-2xl border text-left cursor-pointer transition-all min-h-[52px] ${
                    selectedServiceCode === svc.code
                      ? 'bg-[#0A84FF]/20 border-[#0A84FF] shadow-glass-sm'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-semibold text-sm text-white truncate">
                      {lang === 'hi' ? svc.nameHi : svc.nameEn}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/70 whitespace-nowrap">
                      μ ~{svc.avgDurationMinutes}m
                    </span>
                  </div>
                  <p className="text-[11px] text-white/50 mt-1 line-clamp-1">
                    {lang === 'hi' ? svc.descriptionHi : svc.descriptionEn}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Customer Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <label className="block text-xs font-semibold text-white/80 mb-1.5 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-[#64D2FF]" />
                <span>{t.registration.fullName}</span>
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder={t.registration.fullNamePlaceholder}
                className="w-full h-11 px-3.5 py-2.5 liquid-input-well text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-white/80 mb-1.5 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-[#30D158]" />
                <span>{t.registration.phone}</span>
              </label>
              <input
                type="tel"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder={t.registration.phonePlaceholder}
                className="w-full h-11 px-3.5 py-2.5 liquid-input-well text-sm"
              />
            </div>
          </div>

          {/* Priority Tier Selection with Transparent Rules */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold text-white/80 uppercase tracking-wider">
                {t.registration.priorityTier}
              </label>
              <span className="text-[11px] text-[#64D2FF] flex items-center gap-1">
                <Shield className="w-3 h-3" />
                <span>{t.registration.priorityTierHelp}</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Emergency */}
              <button
                type="button"
                onClick={() => setPriorityTier('emergency')}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all min-h-[52px] ${
                  priorityTier === 'emergency'
                    ? 'bg-[#FF453A]/20 border-[#FF453A]'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2 mb-0.5">
                  <HeartPulse className="w-4 h-4 text-[#FF453A] shrink-0" />
                  <span className="text-xs font-bold text-white">
                    {t.priority.emergency.title}
                  </span>
                </div>
                <p className="text-[11px] text-white/60 line-clamp-1">
                  {t.priority.emergency.eligibility}
                </p>
              </button>

              {/* Senior & Specially-Abled */}
              <button
                type="button"
                onClick={() => setPriorityTier('senior')}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all min-h-[52px] ${
                  priorityTier === 'senior'
                    ? 'bg-[#FF9F0A]/20 border-[#FF9F0A]'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2 mb-0.5">
                  <UserCheck className="w-4 h-4 text-[#FF9F0A] shrink-0" />
                  <span className="text-xs font-bold text-white">
                    {t.priority.senior.title}
                  </span>
                </div>
                <p className="text-[11px] text-white/60 line-clamp-1">
                  {t.priority.senior.eligibility}
                </p>
              </button>

              {/* VIP / Express */}
              <button
                type="button"
                onClick={() => setPriorityTier('vip')}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all min-h-[52px] ${
                  priorityTier === 'vip'
                    ? 'bg-[#5E5CE6]/20 border-[#5E5CE6]'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2 mb-0.5">
                  <Crown className="w-4 h-4 text-[#5E5CE6] shrink-0" />
                  <span className="text-xs font-bold text-white">
                    {t.priority.vip.title}
                  </span>
                </div>
                <p className="text-[11px] text-white/60 line-clamp-1">
                  {t.priority.vip.eligibility}
                </p>
              </button>

              {/* Regular Walk-In */}
              <button
                type="button"
                onClick={() => setPriorityTier('regular')}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all min-h-[52px] ${
                  priorityTier === 'regular'
                    ? 'bg-[#0A84FF]/20 border-[#0A84FF]'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2 mb-0.5">
                  <User className="w-4 h-4 text-[#0A84FF] shrink-0" />
                  <span className="text-xs font-bold text-white">
                    {t.priority.regular.title}
                  </span>
                </div>
                <p className="text-[11px] text-white/60 line-clamp-1">
                  {t.priority.regular.eligibility}
                </p>
              </button>
            </div>
          </div>

          {/* Optional Appointment Slot */}
          <div>
            <label className="block text-xs font-semibold text-white/80 mb-1.5 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-white/60" />
              <span>{t.registration.appointmentSlot}</span>
            </label>
            <select
              value={selectedSlot}
              onChange={(e) => setSelectedSlot(e.target.value)}
              className="w-full h-11 px-3.5 py-2.5 liquid-input-well text-sm bg-[#0D1117] text-white cursor-pointer"
            >
              <option value="walkin">{t.registration.appointmentNone}</option>
              {appointments
                .filter((apt) => apt.serviceCode === selectedServiceCode)
                .map((apt) => (
                  <option
                    key={apt.id}
                    value={apt.slotTime}
                    disabled={!apt.isAvailable}
                  >
                    {apt.slotTime} ({apt.bookedCount}/{apt.maxCapacity} {lang === 'hi' ? 'आरक्षित' : 'booked'})
                    {!apt.isAvailable ? ' - FULL' : ''}
                  </option>
                ))}
            </select>
          </div>

          {/* Privacy Note */}
          <p className="text-[11px] text-white/40 italic">
            {t.registration.privacyNotice}
          </p>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-12 rounded-xl liquid-button-primary text-sm font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
          >
            {isSubmitting ? (
              <span>{t.registration.btnSubmitting}</span>
            ) : (
              <>
                <CheckCircle className="w-4 h-4" />
                <span>{t.registration.btnSubmit}</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
