import React, { useState } from 'react';
import {
  Sparkles,
  UserPlus,
  PlayCircle,
  RotateCcw,
  CheckCircle2,
  ChevronUp,
  ChevronDown,
  Layers,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  Service,
  ServiceCounter,
  QueueToken,
  PriorityTier,
  Language,
  SectorType,
} from '../types';
import { translations } from '../i18n/translations';
import { QueueStorage } from '../lib/supabase';
import { calculateDeterministicWait, getCompatibleOpenCounters } from '../lib/queueEngine';
import { announceTokenTurn } from '../lib/audioChime';

interface SimulationControllerProps {
  services: Service[];
  counters: ServiceCounter[];
  tokens: QueueToken[];
  currentSector: SectorType;
  lang: Language;
  onRefreshData: () => void;
  onUserTokenCreated: (token: QueueToken) => void;
}

const SAMPLE_NAMES = [
  'Aarav Sharma',
  'Devika Sen',
  'Rohan Mehta',
  'Pooja Nair',
  'Vikram Malhotra',
  'Ananya Reddy',
  'Siddharth Joshi',
  'Kavita Pillai',
];

const TIERS: PriorityTier[] = ['regular', 'senior', 'vip', 'emergency'];

export const SimulationController: React.FC<SimulationControllerProps> = ({
  services,
  counters,
  tokens,
  currentSector,
  lang,
  onRefreshData,
  onUserTokenCreated,
}) => {
  const t = translations[lang];
  const [isOpen, setIsOpen] = useState<boolean>(true);

  // 1. Simulate Incoming Customer
  const handleSimulateCustomer = () => {
    const sectorServices = services.filter((s) => s.sector === currentSector && s.isActive);
    if (sectorServices.length === 0) return;

    const randomService = sectorServices[Math.floor(Math.random() * sectorServices.length)];
    const randomName = SAMPLE_NAMES[Math.floor(Math.random() * SAMPLE_NAMES.length)];
    const randomPhone = `98${Math.floor(10000000 + Math.random() * 90000000)}`;
    const randomTier = TIERS[Math.floor(Math.random() * TIERS.length)];

    const existingTokens = QueueStorage.getTokens();
    const existingInSector = existingTokens.filter((tok) => tok.sector === currentSector);
    const tokenNumber = `${randomService.prefix}-${200 + existingInSector.length + 1}`;

    const openCounters = getCompatibleOpenCounters(counters, randomService.code);
    const waitingCount = existingTokens.filter(
      (tok) => tok.status === 'waiting' && tok.serviceCode === randomService.code
    ).length;

    const { waitMinutes } = calculateDeterministicWait(
      waitingCount,
      randomService.avgDurationMinutes,
      openCounters.length
    );

    const newToken: QueueToken = {
      id: `tok-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      tokenNumber,
      sector: currentSector,
      serviceCode: randomService.code,
      customerName: randomName,
      customerPhone: randomPhone,
      priorityTier: randomTier,
      status: 'waiting',
      estimatedWaitMinutes: waitMinutes,
      createdAt: new Date().toISOString(),
    };

    QueueStorage.saveTokens([...existingTokens, newToken]);
    onRefreshData();
    onUserTokenCreated(newToken);

    confetti({
      particleCount: 35,
      spread: 50,
      origin: { y: 0.85, x: 0.85 },
      colors: ['#0A84FF', '#5E5CE6', '#30D158'],
    });
  };

  // 2. Advance Queue (Calls next waiting token on an open counter)
  const handleAdvanceQueue = () => {
    const openCounter = counters.find(
      (c) => (c.status === 'open' || c.status === 'busy') && c.sector === currentSector
    );

    if (!openCounter) {
      alert('No open counter found in this sector. Open a counter first.');
      return;
    }

    const currentTokens = QueueStorage.getTokens();
    const waiting = currentTokens.filter(
      (tok) => tok.status === 'waiting' && openCounter.compatibleServices.includes(tok.serviceCode)
    );

    if (waiting.length === 0) {
      alert('No waiting tokens in this sector.');
      return;
    }

    const nextToken = waiting[0];

    const updatedTokens = currentTokens.map((tok) => {
      if (tok.id === openCounter.currentTokenId && tok.status === 'serving') {
        return {
          ...tok,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          actualWaitMinutes: Math.round(Math.random() * 4 + 6),
        };
      }
      if (tok.id === nextToken.id) {
        return {
          ...tok,
          status: 'serving' as const,
          counterId: openCounter.id,
          counterNumber: openCounter.counterNumber,
          calledAt: new Date().toISOString(),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === openCounter.id) {
        return {
          ...c,
          status: 'busy' as const,
          currentTokenNumber: nextToken.tokenNumber,
          currentTokenId: nextToken.id,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);
    onRefreshData();

    announceTokenTurn(nextToken.tokenNumber, openCounter.counterNumber, lang);
  };

  // 3. Open All Counters
  const handleOpenAllCounters = () => {
    const updatedCounters = counters.map((c) => {
      if (c.sector === currentSector && c.status === 'closed') {
        return { ...c, status: 'open' as const, lastUpdated: new Date().toISOString() };
      }
      return c;
    });
    QueueStorage.saveCounters(updatedCounters);
    onRefreshData();
  };

  // 4. Reset All Demo Data
  const handleResetData = () => {
    if (confirm('Reset demo state back to default seed?')) {
      QueueStorage.resetAll();
      onRefreshData();
    }
  };

  return (
    <div className="fixed bottom-3 right-3 sm:bottom-5 sm:right-5 z-40 max-w-[calc(100vw-24px)] w-80 sm:w-84 animate-fadeIn">
      <div className="liquid-glass-card p-3 shadow-2xl border border-white/20 bg-[#0D1117]/90 backdrop-blur-2xl rounded-2xl">
        <div
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center justify-between pb-1.5 border-b border-white/10 cursor-pointer select-none"
        >
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-[#5E5CE6]/20 text-[#c2c1ff]">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-bold text-white tracking-tight">
              {lang === 'hi' ? 'लाइव सिमुलेशन डॉक' : 'Live Simulation Dock'}
            </span>
          </div>

          <button
            type="button"
            aria-label="Toggle simulation dock"
            className="p-1 rounded-md hover:bg-white/10 text-white/60 hover:text-white active:scale-90 transition-transform"
          >
            {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>

        {isOpen && (
          <div className="pt-2.5 space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleSimulateCustomer}
                className="h-10 px-2 rounded-xl bg-[#0A84FF]/20 border border-[#0A84FF]/40 text-[#64D2FF] hover:bg-[#0A84FF]/30 active:scale-95 font-semibold flex items-center justify-center gap-1.5 transition-all text-xs"
              >
                <UserPlus className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">+ Add User</span>
              </button>

              <button
                onClick={handleAdvanceQueue}
                className="h-10 px-2 rounded-xl bg-[#30D158]/20 border border-[#30D158]/40 text-[#30D158] hover:bg-[#30D158]/30 active:scale-95 font-semibold flex items-center justify-center gap-1.5 transition-all text-xs"
              >
                <PlayCircle className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Advance Token</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleOpenAllCounters}
                className="h-9 px-2 rounded-xl bg-white/5 border border-white/10 text-white/80 hover:bg-white/10 active:scale-95 font-medium flex items-center justify-center gap-1.5 transition-all text-[11px]"
              >
                <CheckCircle2 className="w-3 h-3 text-[#30D158] shrink-0" />
                <span className="truncate">Open All Desks</span>
              </button>

              <button
                onClick={handleResetData}
                className="h-9 px-2 rounded-xl bg-white/5 border border-white/10 text-white/50 hover:text-white hover:bg-white/10 active:scale-95 font-medium flex items-center justify-center gap-1.5 transition-all text-[11px]"
              >
                <RotateCcw className="w-3 h-3 shrink-0" />
                <span className="truncate">Reset Demo</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
