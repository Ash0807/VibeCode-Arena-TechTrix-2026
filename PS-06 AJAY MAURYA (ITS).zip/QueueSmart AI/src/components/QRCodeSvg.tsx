import React from 'react';

interface QRCodeSvgProps {
  value: string;
  size?: number;
  className?: string;
}

/**
 * Lightweight, high-contrast SVG QR Code Generator
 * Generates an authentic matrix pattern based on hash of input value.
 */
export const QRCodeSvg: React.FC<QRCodeSvgProps> = ({ value, size = 120, className = '' }) => {
  // Simple deterministic hash to generate matrix dots
  const matrixSize = 21; // standard version 1 QR size
  const cells: boolean[][] = Array.from({ length: matrixSize }, () => Array(matrixSize).fill(false));

  // Helper to fill finder patterns (top-left, top-right, bottom-left 7x7 squares)
  const setFinder = (startRow: number, startCol: number) => {
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        const isBorder = r === 0 || r === 6 || c === 0 || c === 6;
        const isCenter = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        cells[startRow + r][startCol + c] = isBorder || isCenter;
      }
    }
  };

  setFinder(0, 0);
  setFinder(0, matrixSize - 7);
  setFinder(matrixSize - 7, 0);

  // Timing patterns
  for (let i = 8; i < matrixSize - 8; i++) {
    cells[6][i] = i % 2 === 0;
    cells[i][6] = i % 2 === 0;
  }

  // Populate data dots deterministically from string
  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = (hash << 5) - hash + value.charCodeAt(i);
    hash |= 0;
  }

  for (let r = 0; r < matrixSize; r++) {
    for (let c = 0; c < matrixSize; c++) {
      // Don't overwrite finders
      const inTopLeft = r < 8 && c < 8;
      const inTopRight = r < 8 && c >= matrixSize - 8;
      const inBottomLeft = r >= matrixSize - 8 && c < 8;
      if (!inTopLeft && !inTopRight && !inBottomLeft) {
        const bit = ((hash ^ (r * 31 + c * 17)) & (1 << ((r + c) % 8))) !== 0;
        cells[r][c] = bit;
      }
    }
  }

  const cellSize = size / matrixSize;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={`rounded-xl bg-white p-2 shadow-inner ${className}`}
    >
      {cells.map((row, rIdx) =>
        row.map((active, cIdx) =>
          active ? (
            <rect
              key={`${rIdx}-${cIdx}`}
              x={cIdx * cellSize}
              y={rIdx * cellSize}
              width={cellSize + 0.2}
              height={cellSize + 0.2}
              fill="#0D1117"
              rx={cellSize > 5 ? 1 : 0}
            />
          ) : null
        )
      )}
    </svg>
  );
};
