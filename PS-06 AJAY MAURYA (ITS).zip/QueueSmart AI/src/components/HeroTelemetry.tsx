import React from 'react';
import {
  Volume2,
  Users,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Sparkles,
  Zap,
} from 'lucide-react';
import { QueueToken, ServiceCounter, Language } from '../types';
import { translations } from '../i18n/translations';
import { announceTokenTurn } from '../lib/audioChime';

interface HeroTelemetryProps {
  currentlyServing?: QueueToken;
  servingCounter?: ServiceCounter;
  nextInLine?: QueueToken;
  recentCompleted: QueueToken[];
  waitingCount: number;
  averageWait: number;
  activeCountersCount: number;
  lang: Language;
  onOpenRegister: () => void;
}

export const HeroTelemetry: React.FC<HeroTelemetryProps> = ({
  currentlyServing,
  servingCounter,
  nextInLine,
  recentCompleted,
  waitingCount,
  averageWait,
  activeCountersCount,
  lang,
  onOpenRegister,
}) => {
  const t = translations[lang];

  const handleBroadcastChime = () => {
    if (currentlyServing && servingCounter) {
      announceTokenTurn(currentlyServing.tokenNumber, servingCounter.counterNumber, lang);
    }
  };

  return (
    <section className="w-full mb-6 sm:mb-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-5">
        {/* Primary Executive Card: NOW SERVING */}
        <div className="lg:col-span-7 liquid-glass-card p-4 sm:p-6 md:p-7 flex flex-col justify-between relative overflow-hidden">
          {/* Header Status & Broadcast Trigger */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10 dark:border-white/10 light:border-slate-200">
            <div className="flex items-center gap-2">
              <span className="live-pulse-core w-2.5 h-2.5 rounded-full text-[#10B981] bg-[#10B981]" />
              <span className="text-xs uppercase font-bold tracking-wider text-[#10B981]">
                {t.hero.nowServing}
              </span>
            </div>

            {currentlyServing && servingCounter && (
              <button
                onClick={handleBroadcastChime}
                className="liquid-button-secondary !min-h-[36px] !py-1 !px-3 text-xs flex items-center gap-1.5"
                title="Announce with audio chime"
              >
                <Volume2 className="w-3.5 h-3.5 text-[#0A84FF]" />
                <span>{lang === 'hi' ? 'उद्घोषणा' : 'Chime Call'}</span>
              </button>
            )}
          </div>

          {/* Token Number & Counter Meta */}
          <div className="my-4 sm:my-5">
            {currentlyServing ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider block mb-0.5">
                    {lang === 'hi' ? 'सेवारत टोकन' : 'Active Calling Token'}
                  </span>
                  <div className="text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white dark:text-white light:text-slate-900 tabular-nums">
                    {currentlyServing.tokenNumber}
                  </div>
                </div>

                <div className="sm:text-right space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#0A84FF]/15 text-[#0A84FF] text-xs font-bold border border-[#0A84FF]/25">
                    <Zap className="w-3.5 h-3.5" />
                    <span>
                      {t.hero.counter} {servingCounter ? String(servingCounter.counterNumber).padStart(2, '0') : '01'}
                    </span>
                  </div>
                  <div className="text-sm font-semibold text-white/90 dark:text-white/90 light:text-slate-800">
                    {servingCounter
                      ? lang === 'hi'
                        ? servingCounter.nameHi
                        : servingCounter.nameEn
                      : 'Consultation Desk'}
                  </div>
                  <div className="text-xs text-white/50 dark:text-white/50 light:text-slate-500">
                    {servingCounter?.operatorName || 'Duty Staff'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center sm:text-left">
                <span className="text-2xl sm:text-3xl font-bold text-white/50">
                  {lang === 'hi' ? 'कोई सक्रिय टोकन नहीं' : 'All Desks Ready'}
                </span>
                <p className="text-xs text-white/40 mt-1">
                  {lang === 'hi' ? 'काउंटर उपलब्ध हैं। नया टोकन उत्पन्न करें।' : 'Counters are open and waiting for new registrations.'}
                </p>
              </div>
            )}
          </div>

          {/* Footer: Recent Calls & Next In Line */}
          <div className="pt-3 border-t border-white/10 dark:border-white/10 light:border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
            <div className="flex items-center gap-2 text-white/60 dark:text-white/60 light:text-slate-500">
              <span className="text-[11px] font-medium">{lang === 'hi' ? 'हालिया पूर्ण:' : 'Recent:'}</span>
              <div className="flex items-center gap-1 font-mono">
                {recentCompleted.slice(0, 3).map((tok) => (
                  <span
                    key={tok.id}
                    className="px-2 py-0.5 rounded-md bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 text-white/80 dark:text-white/80 light:text-slate-700 text-[11px]"
                  >
                    {tok.tokenNumber}
                  </span>
                ))}
                {recentCompleted.length === 0 && <span className="text-white/30">—</span>}
              </div>
            </div>

            {nextInLine && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0A84FF]/10 text-[#0A84FF] border border-[#0A84FF]/20 text-xs font-medium">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {t.hero.nextInLine}: <strong className="text-white dark:text-white light:text-slate-900 font-mono font-bold">{nextInLine.tokenNumber}</strong>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Telemetry Metrics Grid (Stacks 2x2 on mobile, 4-col cluster on tablet/desktop) */}
        <div className="lg:col-span-5 grid grid-cols-2 gap-3 sm:gap-4">
          {/* Card 1: In Queue Backlog */}
          <div className="liquid-glass-card p-4 sm:p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider">
                {t.hero.queueBacklog}
              </span>
              <div className="p-1.5 rounded-lg bg-[#0A84FF]/15 text-[#0A84FF]">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="my-1.5">
              <span className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
                {waitingCount}
              </span>
              <span className="text-xs text-white/40 ml-1">{t.hero.people}</span>
            </div>
            <div className="text-[11px] text-[#10B981] flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>{lang === 'hi' ? 'सक्रिय प्रवाह' : 'Optimal Capacity'}</span>
            </div>
          </div>

          {/* Card 2: Deterministic Avg Wait */}
          <div className="liquid-glass-card p-4 sm:p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider">
                {t.hero.avgWait}
              </span>
              <div className="p-1.5 rounded-lg bg-[#F59E0B]/15 text-[#F59E0B]">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="my-1.5">
              <span className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
                ~{averageWait}
              </span>
              <span className="text-xs text-white/40 ml-1">{t.hero.mins}</span>
            </div>
            <div className="text-[11px] text-white/40 dark:text-white/40 light:text-slate-500">
              {lang === 'hi' ? 'पारदर्शी गणना' : 'Deterministic Rate'}
            </div>
          </div>

          {/* Card 3: Operational Counters */}
          <div className="liquid-glass-card p-4 sm:p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider">
                {t.hero.activeCounters}
              </span>
              <div className="p-1.5 rounded-lg bg-[#10B981]/15 text-[#10B981]">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="my-1.5">
              <span className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white light:text-slate-900 tabular-nums">
                {activeCountersCount}
              </span>
              <span className="text-xs text-white/40 ml-1">/ 6 active</span>
            </div>
            <div className="text-[11px] text-[#0A84FF]">
              {lang === 'hi' ? 'डेस्क सक्रिय' : 'Staff Online'}
            </div>
          </div>

          {/* Card 4: Quick Register Touch Target */}
          <div
            onClick={onOpenRegister}
            className="liquid-glass-card p-4 sm:p-5 flex flex-col justify-between cursor-pointer group hover:border-[#0A84FF]/40 transition-all select-none"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#0A84FF] uppercase tracking-wider">
                {lang === 'hi' ? 'नया टोकन' : 'Quick Register'}
              </span>
              <div className="p-1.5 rounded-lg bg-[#0A84FF] text-white group-hover:scale-105 transition-transform">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <div className="my-1">
              <p className="text-sm font-bold text-white dark:text-white light:text-slate-900 group-hover:text-[#0A84FF] transition-colors flex items-center gap-1">
                <span>{lang === 'hi' ? 'टोकन प्राप्त करें' : 'Get Digital Pass'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </p>
              <p className="text-[11px] text-white/40 dark:text-white/40 light:text-slate-500 line-clamp-1 mt-0.5">
                {lang === 'hi' ? 'त्वरित क्यूआर कोड' : 'Instant dynamic pass'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
