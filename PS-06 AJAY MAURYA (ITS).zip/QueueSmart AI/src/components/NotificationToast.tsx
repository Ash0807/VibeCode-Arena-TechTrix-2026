import React, { useState, useEffect } from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  CheckCircle2,
  Volume2,
  Clock,
  Sparkles,
  Zap,
} from 'lucide-react';
import { QueueNotification, Language } from '../types';

interface NotificationToastProps {
  notifications: QueueNotification[];
  lang: Language;
  onDismiss: (id: string) => void;
  isOpenHistory: boolean;
  onCloseHistory: () => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({
  notifications,
  lang,
  onDismiss,
  isOpenHistory,
  onCloseHistory,
}) => {
  const latest = notifications[0];
  const [activeToast, setActiveToast] = useState<QueueNotification | null>(null);

  // Auto-pop the toast when a new notification arrives
  useEffect(() => {
    if (latest) {
      setActiveToast(latest);
      const timer = setTimeout(() => {
        setActiveToast(null);
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [latest?.id]);

  const getIcon = (type: QueueNotification['type']) => {
    switch (type) {
      case 'turn_approaching':
        return <Zap className="w-4 h-4 text-[#F59E0B]" />;
      case 'called':
        return <Volume2 className="w-4 h-4 text-[#4F8CFF] animate-bounce" />;
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-[#35D6A4]" />;
      default:
        return <Bell className="w-4 h-4 text-[#8B5CF6]" />;
    }
  };

  const getBorderColor = (type: QueueNotification['type']) => {
    switch (type) {
      case 'turn_approaching':
        return 'border-[#F59E0B]/50 bg-[#F59E0B]/10';
      case 'called':
        return 'border-[#4F8CFF]/50 bg-[#4F8CFF]/15';
      case 'completed':
        return 'border-[#35D6A4]/50 bg-[#35D6A4]/10';
      default:
        return 'border-[#8B5CF6]/40 bg-[#8B5CF6]/10';
    }
  };

  return (
    <>
      {/* 1. Floating In-App Turn Alert Toast */}
      {activeToast && (
        <div className="fixed top-16 sm:top-20 right-3 sm:right-6 z-50 max-w-[calc(100vw-24px)] w-96 animate-fadeIn">
          <div
            className={`p-4 rounded-2xl liquid-glass-card shadow-2xl border ${getBorderColor(
              activeToast.type
            )} backdrop-blur-2xl transition-all`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-white/10 shrink-0">
                  {getIcon(activeToast.type)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/10 text-white/80">
                      {lang === 'hi' ? 'सूचना अलर्ट' : 'Queue Alert'}
                    </span>
                    <span className="text-[10px] text-white/50">
                      {new Date(activeToast.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white mt-1">
                    {lang === 'hi' ? activeToast.titleHi : activeToast.titleEn}
                  </h4>
                </div>
              </div>

              <button
                onClick={() => {
                  onDismiss(activeToast.id);
                  setActiveToast(null);
                }}
                aria-label="Dismiss notification"
                className="min-w-[32px] min-h-[32px] rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 text-white/70 hover:text-white flex items-center justify-center transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-white/80 mt-2 pl-11">
              {lang === 'hi' ? activeToast.messageHi : activeToast.messageEn}
            </p>
          </div>
        </div>
      )}

      {/* 2. Notification History Feed Drawer / Modal */}
      {isOpenHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md liquid-glass-card p-5 sm:p-7 rounded-3xl shadow-2xl border border-white/20 max-h-[85vh] flex flex-col">
            <button
              onClick={onCloseHistory}
              aria-label="Close notifications feed"
              className="absolute top-4 right-4 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white/80 transition-all"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pb-4 border-b border-white/10 pr-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#8B5CF6]/20 text-[#c2c1ff] text-xs font-semibold mb-2">
                <Bell className="w-3.5 h-3.5" />
                <span>Simulated In-App Feed</span>
              </div>
              <h3 className="text-xl font-bold text-white tracking-tight">
                {lang === 'hi' ? 'लाइव सूचना इतिहास' : 'Live Notification Feed'}
              </h3>
              <p className="text-xs text-white/60 mt-0.5">
                {lang === 'hi'
                  ? 'टर्न निकटता, काउंटर कॉल और प्रतीक्षा समय अपडेट्स'
                  : 'Turn alerts, counter calls, and queue updates'}
              </p>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
              {notifications.length === 0 ? (
                <div className="py-12 text-center text-white/50 text-xs">
                  <Bell className="w-8 h-8 text-white/30 mx-auto mb-2" />
                  <span>{lang === 'hi' ? 'कोई सूचना नहीं है' : 'No notifications yet'}</span>
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getIcon(n.type)}
                        <span className="text-xs font-bold text-white">
                          {lang === 'hi' ? n.titleHi : n.titleEn}
                        </span>
                      </div>
                      <span className="text-[10px] text-white/50 font-mono">
                        {new Date(n.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-white/70 pl-6">
                      {lang === 'hi' ? n.messageHi : n.messageEn}
                    </p>
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-white/10 text-center">
              <span className="text-[11px] text-white/40 italic">
                * Simulated alerts for live prototype demonstration
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
