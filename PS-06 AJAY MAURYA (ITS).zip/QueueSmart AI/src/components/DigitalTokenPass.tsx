import React from 'react';
import {
  Ticket,
  Clock,
  Printer,
  Search,
  BellRing,
  ArrowLeft,
  CheckCircle,
} from 'lucide-react';
import { QueueToken, Service, ServiceCounter, Language } from '../types';
import { translations } from '../i18n/translations';
import { getTokenQueuePosition } from '../lib/queueEngine';
import { QRCodeSvg } from './QRCodeSvg';

interface DigitalTokenPassProps {
  token: QueueToken;
  allTokens: QueueToken[];
  counters: ServiceCounter[];
  services: Service[];
  lang: Language;
  onOpenTracker: () => void;
  onClose?: () => void;
}

export const DigitalTokenPass: React.FC<DigitalTokenPassProps> = ({
  token,
  allTokens,
  counters,
  services,
  lang,
  onOpenTracker,
  onClose,
}) => {
  const t = translations[lang];

  if (!token) return null;

  const service = services.find((s) => s.code === token.serviceCode);

  const { positionAhead, estimatedWaitMinutes, hasZeroCounters, servingToken } =
    getTokenQueuePosition(token, allTokens, counters, services);

  const isServing = token.status === 'serving';
  const isTurnSoon = !isServing && positionAhead <= 1 && token.status === 'waiting';

  const handlePrint = () => {
    window.print();
  };

  const priorityColorMap: Record<string, { bg: string; text: string; label: string }> = {
    emergency: { bg: 'bg-[#EF4444]/15', text: 'text-[#EF4444]', label: t.priority.emergency.title },
    senior: { bg: 'bg-[#F59E0B]/15', text: 'text-[#F59E0B]', label: t.priority.senior.title },
    vip: { bg: 'bg-[#5E5CE6]/15', text: 'text-[#c2c1ff]', label: t.priority.vip.title },
    regular: { bg: 'bg-[#0A84FF]/15', text: 'text-[#0A84FF]', label: t.priority.regular.title },
  };

  const priorityMeta = priorityColorMap[token.priorityTier] || priorityColorMap.regular;

  return (
    <div className="w-full max-w-lg mx-auto my-4 sm:my-6 animate-fadeIn px-2 sm:px-0">
      {/* Turn Proximity Alert Banner */}
      {(isServing || isTurnSoon) && (
        <div className="mb-3.5 p-3.5 sm:p-4 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center gap-3">
          <BellRing className="w-5 h-5 text-[#10B981] shrink-0 animate-bounce" />
          <div className="text-xs">
            <h4 className="font-bold text-white dark:text-white light:text-slate-900 uppercase tracking-wider">
              {isServing ? t.pass.yourTurnNow : t.pass.yourTurnSoon}
            </h4>
            <p className="text-white/80 dark:text-white/80 light:text-slate-600 mt-0.5">
              {isServing
                ? `${t.hero.proceedTo} ${token.counterNumber || '01'}`
                : `${lang === 'hi' ? 'केवल' : 'Only'} ${positionAhead} ${t.pass.positionAhead}`}
            </p>
          </div>
        </div>
      )}

      {/* Main Apple Wallet Style Digital Pass Card */}
      <div className="liquid-glass-card p-5 sm:p-7 relative overflow-hidden border border-white/15 shadow-xl">
        {/* Pass Top Bar */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/10 dark:border-white/10 light:border-slate-200">
          <div className="flex items-center gap-2">
            <Ticket className="w-4 h-4 text-[#0A84FF]" />
            <span className="text-xs uppercase font-bold tracking-wider text-[#0A84FF]">
              {t.pass.digitalPassTitle}
            </span>
          </div>

          <span
            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${priorityMeta.bg} ${priorityMeta.text} border border-white/10`}
          >
            {priorityMeta.label}
          </span>
        </div>

        {/* Pass Core Body: Token & QR Code */}
        <div className="my-5 flex flex-col sm:flex-row items-center justify-between gap-5 text-center sm:text-left">
          <div>
            <span className="text-[11px] text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider block mb-0.5">
              {lang === 'hi' ? 'आपका टोकन नंबर' : 'YOUR DIGITAL TOKEN'}
            </span>
            <div className="text-5xl sm:text-6xl font-extrabold tracking-tight text-white dark:text-white light:text-slate-900 tabular-nums">
              {token.tokenNumber}
            </div>

            <div className="mt-2.5 space-y-0.5">
              <div className="text-sm font-bold text-white/90 dark:text-white/90 light:text-slate-800">
                {token.customerName}
              </div>
              <div className="text-xs text-white/60 dark:text-white/60 light:text-slate-600">
                {service ? (lang === 'hi' ? service.nameHi : service.nameEn) : 'Service Desk'}
              </div>
              {token.appointmentTime && (
                <div className="text-[11px] text-[#10B981] flex items-center justify-center sm:justify-start gap-1 font-mono pt-0.5">
                  <Clock className="w-3 h-3" />
                  <span>Slot: {token.appointmentTime}</span>
                </div>
              )}
            </div>
          </div>

          {/* QR Code Container */}
          <div className="flex flex-col items-center">
            <QRCodeSvg
              value={`QUEUESMART:${token.tokenNumber}:${token.serviceCode}:${token.customerPhone}`}
              size={115}
              className="border border-white/10 shadow-sm"
            />
            <span className="text-[10px] text-white/40 dark:text-white/40 light:text-slate-400 mt-1.5 text-center max-w-[120px]">
              {t.pass.scanHelp}
            </span>
          </div>
        </div>

        {/* Real-Time Telemetry Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3.5 rounded-xl liquid-recessed-well">
          <div>
            <span className="text-[11px] text-white/50 dark:text-white/50 light:text-slate-500 block">
              {lang === 'hi' ? 'आगे लोग' : 'People Ahead'}
            </span>
            <span className="text-xl sm:text-2xl font-bold text-white dark:text-white light:text-slate-900 tabular-nums">
              {isServing ? '0' : positionAhead}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-white/50 dark:text-white/50 light:text-slate-500 block">
              {t.pass.estimatedWaitTime}
            </span>
            <span className="text-xl sm:text-2xl font-bold text-[#0A84FF] tabular-nums">
              {hasZeroCounters ? 'Paused' : isServing ? 'Serving' : `~${estimatedWaitMinutes}m`}
            </span>
          </div>

          <div className="col-span-2 sm:col-span-1">
            <span className="text-[11px] text-white/50 dark:text-white/50 light:text-slate-500 block">
              {t.hero.nowServing}
            </span>
            <span className="text-lg sm:text-xl font-bold text-[#10B981] font-mono">
              {servingToken ? servingToken.tokenNumber : 'None'}
            </span>
          </div>
        </div>

        {/* Footer Actions (Touch targets >= 44px) */}
        <div className="mt-5 pt-3.5 border-t border-white/10 dark:border-white/10 light:border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="min-h-[44px] px-3 rounded-xl liquid-button-secondary text-xs flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.pass.btnPrint}</span>
            </button>
            <button
              onClick={onOpenTracker}
              className="min-h-[44px] px-3 rounded-xl bg-white/5 dark:bg-white/5 light:bg-slate-100 border border-white/10 text-xs text-white/70 dark:text-white/70 light:text-slate-700 hover:text-white flex items-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{t.pass.btnTrackAnother}</span>
            </button>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="min-h-[44px] px-3 text-xs text-white/60 dark:text-white/60 light:text-slate-600 hover:text-white flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'वापस' : 'Live Board'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
