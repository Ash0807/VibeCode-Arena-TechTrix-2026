import React, { useState } from 'react';
import {
  Sliders,
  ShieldCheck,
  Zap,
  PlayCircle,
  CheckCircle2,
  XCircle,
  PauseCircle,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  Users,
  Settings,
  Sparkles,
  Lock,
  Unlock,
  Volume2,
  RefreshCw,
  Plus,
  Calendar,
  Layers,
} from 'lucide-react';
import {
  ServiceCounter,
  Service,
  QueueToken,
  PriorityRule,
  Language,
  AllocationSuggestion,
  AppointmentSlot,
} from '../types';
import { translations } from '../i18n/translations';
import { QueueStorage } from '../lib/supabase';
import {
  generateAllocationSuggestions,
  calculateDeterministicWait,
  getCompatibleOpenCounters,
} from '../lib/queueEngine';
import { announceTokenTurn } from '../lib/audioChime';

interface AdminDashboardProps {
  counters: ServiceCounter[];
  services: Service[];
  tokens: QueueToken[];
  priorityRules: PriorityRule[];
  appointments?: AppointmentSlot[];
  lang: Language;
  onUpdateCounters: (counters: ServiceCounter[]) => void;
  onUpdateServices: (services: Service[]) => void;
  onUpdateTokens: (tokens: QueueToken[]) => void;
  onUpdateAppointments?: (appointments: AppointmentSlot[]) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  counters,
  services,
  tokens,
  priorityRules,
  appointments = [],
  lang,
  onUpdateCounters,
  onUpdateServices,
  onUpdateTokens,
  onUpdateAppointments,
}) => {
  const t = translations[lang];

  // Auth gate: Staff Security PIN
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true); // default unlocked in demo
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  const [activeTab, setActiveTab] = useState<
    'counters' | 'allocations' | 'services' | 'appointments' | 'priority'
  >('counters');

  const [appliedSuggestionId, setAppliedSuggestionId] = useState<string | null>(null);

  // Operational Statistics
  const completedTokens = tokens.filter((tok) => tok.status === 'completed');
  const waitingTokens = tokens.filter((tok) => tok.status === 'waiting');
  const openCounters = counters.filter((c) => c.status === 'open' || c.status === 'busy');

  const totalServed = completedTokens.length;
  const avgWaitMinutes =
    completedTokens.length > 0
      ? Math.round(
          completedTokens.reduce((acc, curr) => acc + (curr.actualWaitMinutes || 8), 0) /
            completedTokens.length
        )
      : 7;

  const counterUtilization = Math.round(
    (counters.filter((c) => c.status === 'busy').length / Math.max(1, counters.length)) * 100
  );

  // Dynamic Rule-Based Counter Rebalancing Suggestions
  const suggestions = generateAllocationSuggestions(services, counters, tokens);

  // Staff Action: Call Next Token for a Counter
  const handleCallNext = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter) return;

    // Find next eligible waiting token
    const eligibleTokens = tokens.filter(
      (tok) => tok.status === 'waiting' && counter.compatibleServices.includes(tok.serviceCode)
    );

    if (eligibleTokens.length === 0) {
      alert(lang === 'hi' ? 'इस काउंटर के लिए कोई प्रतीक्षा टोकन नहीं है।' : 'No waiting tickets matching this counter.');
      return;
    }

    const nextToken = eligibleTokens[0];

    // Mark previous serving token as completed if exists
    const updatedTokens = tokens.map((tok) => {
      if (tok.id === counter.currentTokenId && tok.status === 'serving') {
        return {
          ...tok,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          actualWaitMinutes: Math.round(Math.random() * 5 + 5),
        };
      }
      if (tok.id === nextToken.id) {
        return {
          ...tok,
          status: 'serving' as const,
          counterId: counter.id,
          counterNumber: counter.counterNumber,
          calledAt: new Date().toISOString(),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        return {
          ...c,
          status: 'busy' as const,
          currentTokenNumber: nextToken.tokenNumber,
          currentTokenId: nextToken.id,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    onUpdateTokens(updatedTokens);
    onUpdateCounters(updatedCounters);
    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);

    // Announce Audio Chime
    announceTokenTurn(nextToken.tokenNumber, counter.counterNumber, lang);
  };

  // Staff Action: Complete Service
  const handleComplete = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter || !counter.currentTokenId) return;

    const updatedTokens = tokens.map((tok) => {
      if (tok.id === counter.currentTokenId) {
        return {
          ...tok,
          status: 'completed' as const,
          completedAt: new Date().toISOString(),
          actualWaitMinutes: Math.round(Math.random() * 4 + 6),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        return {
          ...c,
          status: 'open' as const,
          currentTokenNumber: undefined,
          currentTokenId: undefined,
          totalServedToday: c.totalServedToday + 1,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    onUpdateTokens(updatedTokens);
    onUpdateCounters(updatedCounters);
    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);
  };

  // Staff Action: Skip / No Show
  const handleSkip = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter || !counter.currentTokenId) return;

    if (!confirm(lang === 'hi' ? 'क्या आप इस टोकन को अनुपस्थित दर्ज करना चाहते हैं?' : 'Mark current customer as No-Show / Skipped?')) {
      return;
    }

    const updatedTokens = tokens.map((tok) => {
      if (tok.id === counter.currentTokenId) {
        return {
          ...tok,
          status: 'skipped' as const,
          completedAt: new Date().toISOString(),
        };
      }
      return tok;
    });

    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        return {
          ...c,
          status: 'open' as const,
          currentTokenNumber: undefined,
          currentTokenId: undefined,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    onUpdateTokens(updatedTokens);
    onUpdateCounters(updatedCounters);
    QueueStorage.saveTokens(updatedTokens);
    QueueStorage.saveCounters(updatedCounters);
  };

  // Staff Action: Recall Active Customer Turn
  const handleRecall = (counterId: string) => {
    const counter = counters.find((c) => c.id === counterId);
    if (!counter || !counter.currentTokenNumber) return;

    announceTokenTurn(counter.currentTokenNumber, counter.counterNumber, lang);
    QueueStorage.addNotification({
      id: `notif-${Date.now()}`,
      tokenId: counter.currentTokenId || '',
      tokenNumber: counter.currentTokenNumber,
      type: 'called',
      titleEn: `Recall: Token ${counter.currentTokenNumber}`,
      titleHi: `पुनः बुलावा: टोकन ${counter.currentTokenNumber}`,
      messageEn: `Please proceed immediately to Counter #${counter.counterNumber}`,
      messageHi: `कृपया तुरंत काउंटर #${counter.counterNumber} पर पहुंचें`,
      timestamp: new Date().toISOString(),
    });
  };

  // Staff Action: Dynamically Provision a New Counter
  const handleAddCounter = () => {
    const nextNum = Math.max(...counters.map((c) => c.counterNumber), 0) + 1;
    const newCounter: ServiceCounter = {
      id: `cnt-${Date.now()}`,
      counterNumber: nextNum,
      nameEn: `Auxiliary Station ${nextNum}`,
      nameHi: `सहायक काउंटर ${nextNum}`,
      operatorName: `Staff Agent ${nextNum}`,
      sector: counters[0]?.sector || 'healthcare',
      status: 'open',
      compatibleServices: services.map((s) => s.code),
      totalServedToday: 0,
      avgPaceMinutes: 6.5,
      lastUpdated: new Date().toISOString(),
    };
    const updated = [...counters, newCounter];
    onUpdateCounters(updated);
    QueueStorage.saveCounters(updated);
  };

  // Staff Action: Toggle Appointment Slot Availability
  const handleToggleSlot = (slotId: string) => {
    if (!onUpdateAppointments) return;
    const updated = appointments.map((apt) => {
      if (apt.id === slotId) {
        return { ...apt, isAvailable: !apt.isAvailable };
      }
      return apt;
    });
    onUpdateAppointments(updated);
    QueueStorage.saveAppointments(updated);
  };

  // Staff Action: Adjust Slot Capacity
  const handleAdjustSlotCapacity = (slotId: string, delta: number) => {
    if (!onUpdateAppointments) return;
    const updated = appointments.map((apt) => {
      if (apt.id === slotId) {
        return { ...apt, maxCapacity: Math.max(1, apt.maxCapacity + delta) };
      }
      return apt;
    });
    onUpdateAppointments(updated);
    QueueStorage.saveAppointments(updated);
  };

  // Staff Action: Toggle Counter Status
  const handleToggleCounterStatus = (counterId: string) => {
    const updatedCounters = counters.map((c) => {
      if (c.id === counterId) {
        const nextStatus: ServiceCounter['status'] =
          c.status === 'closed' ? 'open' : c.status === 'open' ? 'paused' : 'closed';
        return {
          ...c,
          status: nextStatus,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    onUpdateCounters(updatedCounters);
    QueueStorage.saveCounters(updatedCounters);
  };

  // Staff Action: Apply Rule-Based Allocation Suggestion
  const handleApplySuggestion = (suggestion: AllocationSuggestion) => {
    const updatedCounters = counters.map((c) => {
      if (c.counterNumber === suggestion.recommendedCounterNumber) {
        const newCompat = Array.from(new Set([...c.compatibleServices, suggestion.serviceCode]));
        return {
          ...c,
          status: 'open' as const,
          compatibleServices: newCompat,
          lastUpdated: new Date().toISOString(),
        };
      }
      return c;
    });

    onUpdateCounters(updatedCounters);
    QueueStorage.saveCounters(updatedCounters);
    setAppliedSuggestionId(suggestion.id);
    setTimeout(() => setAppliedSuggestionId(null), 3000);
  };

  // Service SLA Duration Adjustment
  const handleAdjustDuration = (code: string, delta: number) => {
    const updatedServices = services.map((s) => {
      if (s.code === code) {
        const newDur = Math.max(1, Math.round((s.avgDurationMinutes + delta) * 10) / 10);
        return { ...s, avgDurationMinutes: newDur };
      }
      return s;
    });
    onUpdateServices(updatedServices);
    localStorage.setItem('queuesmart_services', JSON.stringify(updatedServices));
  };

  if (!isAuthenticated) {
    return (
      <div className="w-full max-w-md mx-auto my-12 animate-fadeIn">
        <div className="liquid-glass-card p-6 sm:p-8 text-center border border-white/20 shadow-glass-lg relative overflow-hidden">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#4F8CFF]/20 to-[#8B5CF6]/20 border border-white/20 flex items-center justify-center mx-auto mb-4 text-[#4F8CFF] shadow-glass-glow-blue backdrop-blur-md">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-bold text-white tracking-tight mb-1">
            {lang === 'hi' ? 'स्टाफ कॉकपिट प्रमाणीकरण' : 'Staff Cockpit Protected'}
          </h3>
          <p className="text-xs text-white/60 mb-6">
            {lang === 'hi'
              ? 'कृपया व्यवस्थापक नियंत्रण अनलॉक करने के लिए सुरक्षा पिन दर्ज करें (डिफ़ॉल्ट: 1234)'
              : 'Enter staff authorization security PIN to access queue orchestration (Default: 1234)'}
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (pinInput === '1234' || pinInput === '0000' || pinInput === 'admin') {
                setIsAuthenticated(true);
                setPinError('');
                setPinInput('');
              } else {
                setPinError(lang === 'hi' ? 'अमान्य सुरक्षा पिन (1234 आज़माएं)' : 'Invalid staff PIN (Try 1234)');
              }
            }}
            className="space-y-4"
          >
            <input
              type="password"
              maxLength={6}
              value={pinInput}
              onChange={(e) => {
                setPinInput(e.target.value);
                setPinError('');
              }}
              placeholder="••••"
              className="w-full liquid-input-well text-center text-2xl tracking-[0.5em] font-mono text-white placeholder-white/30"
              autoFocus
            />

            {pinError && (
              <p className="text-xs font-semibold text-[#FF453A] flex items-center justify-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{pinError}</span>
              </p>
            )}

            <button
              type="submit"
              className="w-full liquid-button-primary min-h-[46px] rounded-xl text-sm font-bold shadow-glass-sm flex items-center justify-center gap-2"
            >
              <Unlock className="w-4 h-4" />
              <span>{lang === 'hi' ? 'कॉकपिट अनलॉक करें' : 'Unlock Cockpit'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setPinInput('1234');
                setIsAuthenticated(true);
                setPinError('');
              }}
              className="text-xs text-[#4F8CFF] hover:underline pt-2 block mx-auto opacity-80 hover:opacity-100"
            >
              {lang === 'hi' ? 'डेमो पिन (1234) से तुरंत अनलॉक करें' : 'Quick Demo Unlock (1234)'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full mb-12 animate-fadeIn">
      {/* Cockpit Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 liquid-glass-card p-4 sm:p-5 border border-white/10 shadow-glass-sm">
        <div>
          <div className="flex flex-wrap items-center gap-2.5 mb-1.5">
            <span className="p-2 rounded-xl bg-gradient-to-tr from-[#5E5CE6]/30 to-[#8B5CF6]/20 text-[#c2c1ff] border border-white/15 shadow-glass-sm backdrop-blur-md">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">
              {t.admin.cockpitTitle}
            </h2>
            <span className="px-3 py-1 rounded-full bg-[#35D6A4]/15 border border-[#35D6A4]/35 text-[#35D6A4] text-[11px] font-bold flex items-center gap-1.5 shadow-[0_0_12px_rgba(53,214,164,0.18)]">
              <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-[#35D6A4]" />
              <span>Authorized Staff</span>
            </span>
          </div>
          <p className="text-xs md:text-sm text-white/60 pl-0.5">
            {t.admin.cockpitSubtitle}
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => setIsAuthenticated(false)}
            className="liquid-button-secondary min-h-[40px] px-3.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
            title="Lock Staff Cockpit"
          >
            <Lock className="w-3.5 h-3.5 text-white/60" />
            <span>Lock</span>
          </button>
        </div>
      </div>

      {/* Operational Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
        <div className="liquid-glass-card p-4 sm:p-5 relative overflow-hidden group hover:border-white/20 transition-all duration-300 shadow-glass-sm">
          <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#35D6A4]/50 to-transparent" />
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs text-white/60 font-medium">
              {t.admin.totalServed}
            </span>
            <span className="p-1.5 rounded-lg bg-[#35D6A4]/15 text-[#35D6A4] border border-[#35D6A4]/25">
              <TrendingUp className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-white tabular-nums tracking-tight">
            {totalServed}
          </span>
          <span className="text-[10px] sm:text-[11px] text-[#35D6A4] mt-1.5 flex items-center gap-1 font-semibold">
            <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-[#35D6A4]" />
            <span>Today's Throughput</span>
          </span>
        </div>

        <div className="liquid-glass-card p-4 sm:p-5 relative overflow-hidden group hover:border-white/20 transition-all duration-300 shadow-glass-sm">
          <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#64D2FF]/50 to-transparent" />
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs text-white/60 font-medium">
              {t.admin.avgWaitTime}
            </span>
            <span className="p-1.5 rounded-lg bg-[#0A84FF]/15 text-[#64D2FF] border border-[#0A84FF]/25">
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-[#64D2FF] tabular-nums tracking-tight">
            ~{avgWaitMinutes}m
          </span>
          <span className="text-[10px] sm:text-[11px] text-white/50 block mt-1.5">
            Average Actual SLA
          </span>
        </div>

        <div className="liquid-glass-card p-4 sm:p-5 relative overflow-hidden group hover:border-white/20 transition-all duration-300 shadow-glass-sm">
          <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#30D158]/50 to-transparent" />
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs text-white/60 font-medium">
              {t.admin.activeStaff}
            </span>
            <span className="p-1.5 rounded-lg bg-[#30D158]/15 text-[#30D158] border border-[#30D158]/25">
              <Users className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-[#30D158] tabular-nums tracking-tight">
            {openCounters.length}
          </span>
          <span className="text-[10px] sm:text-[11px] text-white/50 block mt-1.5">
            Counters Operational
          </span>
        </div>

        <div className="liquid-glass-card p-4 sm:p-5 relative overflow-hidden group hover:border-white/20 transition-all duration-300 shadow-glass-sm">
          <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#FF9F0A]/50 to-transparent" />
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs text-white/60 font-medium">
              {t.admin.utilizationRate}
            </span>
            <span className="p-1.5 rounded-lg bg-[#FF9F0A]/15 text-[#FF9F0A] border border-[#FF9F0A]/25">
              <Zap className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-2xl sm:text-3xl font-extrabold text-[#FF9F0A] tabular-nums tracking-tight">
            {counterUtilization}%
          </span>
          <span className="text-[10px] sm:text-[11px] text-white/50 block mt-1.5">
            Active Duty Ratio
          </span>
        </div>
      </div>

      {/* Admin Tab Switcher Dock */}
      <div className="liquid-glass-dock p-1.5 mb-6 flex items-center gap-1.5 overflow-x-auto no-scrollbar shadow-glass-md">
        <button
          onClick={() => setActiveTab('counters')}
          className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap active:scale-[0.98] ${
            activeTab === 'counters'
              ? 'bg-gradient-to-b from-[#4F8CFF] to-[#2563EB] text-white shadow-[0_4px_16px_rgba(79,140,255,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] border border-white/25'
              : 'text-white/70 hover:text-white hover:bg-white/10 border border-transparent'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{t.admin.countersTab}</span>
        </button>

        <button
          onClick={() => setActiveTab('allocations')}
          className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all relative whitespace-nowrap active:scale-[0.98] ${
            activeTab === 'allocations'
              ? 'bg-gradient-to-b from-[#8B5CF6] to-[#6D28D9] text-white shadow-[0_4px_16px_rgba(139,92,246,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] border border-white/25'
              : 'text-white/70 hover:text-white hover:bg-white/10 border border-transparent'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{t.admin.recommendationsTab}</span>
          {suggestions.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-[#FF453A] animate-ping" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('services')}
          className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap active:scale-[0.98] ${
            activeTab === 'services'
              ? 'bg-gradient-to-b from-[#4F8CFF] to-[#2563EB] text-white shadow-[0_4px_16px_rgba(79,140,255,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] border border-white/25'
              : 'text-white/70 hover:text-white hover:bg-white/10 border border-transparent'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Category SLA Configuration</span>
        </button>

        <button
          onClick={() => setActiveTab('appointments')}
          className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap active:scale-[0.98] ${
            activeTab === 'appointments'
              ? 'bg-gradient-to-b from-[#4F8CFF] to-[#2563EB] text-white shadow-[0_4px_16px_rgba(79,140,255,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] border border-white/25'
              : 'text-white/70 hover:text-white hover:bg-white/10 border border-transparent'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Appointment Management</span>
        </button>

        <button
          onClick={() => setActiveTab('priority')}
          className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap active:scale-[0.98] ${
            activeTab === 'priority'
              ? 'bg-gradient-to-b from-[#4F8CFF] to-[#2563EB] text-white shadow-[0_4px_16px_rgba(79,140,255,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] border border-white/25'
              : 'text-white/70 hover:text-white hover:bg-white/10 border border-transparent'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Priority Rules & Eligibility</span>
        </button>
      </div>

      {/* Tab 1: Counter Station Operations */}
      {activeTab === 'counters' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-1">
            <span className="text-xs text-white/50 font-medium">
              {counters.length} Operational Stations
            </span>
            <button
              onClick={handleAddCounter}
              className="min-h-[42px] px-4 rounded-xl liquid-button-primary text-xs font-bold flex items-center gap-2 active:scale-95 transition-all shadow-glass-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Add Counter Station</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
            {counters.map((c) => (
              <div
                key={c.id}
                className="liquid-glass-card p-5 flex flex-col justify-between border border-white/10 hover:border-white/25 transition-all duration-300 shadow-glass-md group"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 gap-2">
                    <span className="text-xs font-mono font-bold text-[#4F8CFF] bg-[#4F8CFF]/15 border border-[#4F8CFF]/30 px-2.5 py-1 rounded-lg backdrop-blur-md">
                      Counter #{c.counterNumber}
                    </span>
                    <button
                      onClick={() => handleToggleCounterStatus(c.id)}
                      className={`text-[10px] min-h-[30px] px-3 py-1 rounded-full font-bold border active:scale-95 transition-all flex items-center gap-1.5 backdrop-blur-md ${
                        c.status === 'open' || c.status === 'busy'
                          ? 'bg-[#35D6A4]/20 text-[#35D6A4] border-[#35D6A4]/40 shadow-[0_0_10px_rgba(53,214,164,0.15)]'
                          : c.status === 'paused'
                          ? 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40 shadow-[0_0_10px_rgba(245,158,11,0.15)]'
                          : 'bg-white/10 text-white/40 border-white/10'
                      }`}
                    >
                      {(c.status === 'open' || c.status === 'busy') && (
                        <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-[#35D6A4]" />
                      )}
                      {c.status === 'paused' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                      )}
                      <span>{c.status.toUpperCase()}</span>
                    </button>
                  </div>

                  <div className="my-3.5 space-y-1">
                    <span className="text-sm font-bold text-white block tracking-tight">
                      {lang === 'hi' ? c.nameHi : c.nameEn}
                    </span>
                    <span className="text-xs text-white/60 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-white/40" />
                      <span>{c.operatorName}</span>
                    </span>
                    <div className="flex flex-wrap gap-1 pt-1.5">
                      {c.compatibleServices.map((code) => (
                        <span
                          key={code}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-white/60 font-medium backdrop-blur-sm"
                        >
                          {code}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Serving Token Well */}
                  <div className="p-3.5 rounded-xl liquid-recessed-well my-2.5 border border-white/10 backdrop-blur-md">
                    <div className="flex items-center justify-between text-[10px] text-white/50 uppercase tracking-wider font-semibold">
                      <span>Serving Now</span>
                      <span className="flex items-center gap-1 text-white/40">
                        <Clock className="w-3 h-3" />
                        <span>{c.avgPaceMinutes}m pace</span>
                      </span>
                    </div>
                    <div className="mt-1 flex items-baseline justify-between">
                      <div className="text-2xl sm:text-3xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-[#64D2FF]">
                        {c.currentTokenNumber || '—'}
                      </div>
                      <span className="text-[11px] text-white/50">
                        Served Today: <strong className="text-white font-mono">{c.totalServedToday}</strong>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Operator Control Triggers (4 Tactile Glass Buttons) */}
                <div className="mt-4 pt-3 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleCallNext(c.id)}
                    disabled={c.status === 'closed'}
                    className="min-h-[44px] px-2 rounded-xl liquid-button-primary text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-30 active:scale-95 transition-all"
                    title={t.admin.callNextBtn}
                  >
                    <PlayCircle className="w-4 h-4 shrink-0" />
                    <span>{t.admin.callNextBtn}</span>
                  </button>

                  <button
                    onClick={() => handleComplete(c.id)}
                    disabled={!c.currentTokenNumber}
                    className="min-h-[44px] px-2 rounded-xl liquid-button-emerald text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-30 active:scale-95 transition-all"
                    title={t.admin.completeBtn}
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{t.admin.completeBtn}</span>
                  </button>

                  <button
                    onClick={() => handleRecall(c.id)}
                    disabled={!c.currentTokenNumber}
                    className="min-h-[44px] px-2 rounded-xl liquid-button-violet text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-30 active:scale-95 transition-all"
                    title={t.admin.recallBtn}
                  >
                    <Volume2 className="w-4 h-4 shrink-0" />
                    <span>{t.admin.recallBtn}</span>
                  </button>

                  <button
                    onClick={() => handleSkip(c.id)}
                    disabled={!c.currentTokenNumber}
                    className="min-h-[44px] px-2 rounded-xl liquid-button-amber text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-30 active:scale-95 transition-all"
                    title={t.admin.skipBtn}
                  >
                    <XCircle className="w-4 h-4 shrink-0" />
                    <span>{t.admin.skipBtn}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Appointment Management */}
      {activeTab === 'appointments' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-2xl liquid-glass-card bg-gradient-to-r from-[#4F8CFF]/15 via-white/[0.04] to-transparent border border-[#4F8CFF]/30 backdrop-blur-xl mb-4 shadow-glass-sm">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#4F8CFF]" />
              <span>Appointment Capacity & Slot Control</span>
            </h4>
            <p className="text-xs text-white/70 mt-1">
              Manage pre-booked slots, increase walk-in/appointment capacities, or freeze saturated windows.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
            {appointments.map((apt) => (
              <div
                key={apt.id}
                className="liquid-glass-card p-5 flex flex-col justify-between border border-white/10 hover:border-white/20 transition-all shadow-glass-sm"
              >
                <div>
                  <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
                    <span className="text-xs font-mono font-bold text-[#4F8CFF] bg-[#4F8CFF]/15 border border-[#4F8CFF]/30 px-2.5 py-1 rounded-lg">
                      {apt.slotTime}
                    </span>
                    <button
                      onClick={() => handleToggleSlot(apt.id)}
                      className={`text-[10px] min-h-[30px] px-3 py-0.5 rounded-full font-bold border active:scale-95 transition-all flex items-center gap-1.5 ${
                        apt.isAvailable
                          ? 'bg-[#35D6A4]/20 text-[#35D6A4] border-[#35D6A4]/40'
                          : 'bg-[#FF453A]/20 text-[#FF453A] border-[#FF453A]/40'
                      }`}
                    >
                      {apt.isAvailable && (
                        <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-[#35D6A4]" />
                      )}
                      <span>{apt.isAvailable ? 'OPEN' : 'BLOCKED'}</span>
                    </button>
                  </div>
                  <div className="my-3.5">
                    <span className="text-xs text-white/60 block">Service: {apt.serviceCode}</span>
                    <span className="text-sm font-bold text-white block mt-1">
                      Capacity: <span className="text-[#4F8CFF] font-mono">{apt.bookedCount}</span> / <span className="font-mono">{apt.maxCapacity}</span> booked
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-white/70">
                  <span className="font-medium">Adjust Capacity:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAdjustSlotCapacity(apt.id, -1)}
                      className="liquid-button-secondary min-w-[36px] min-h-[36px] p-0 rounded-lg text-white font-bold flex items-center justify-center text-sm"
                    >
                      -
                    </button>
                    <button
                      onClick={() => handleAdjustSlotCapacity(apt.id, 1)}
                      className="liquid-button-secondary min-w-[36px] min-h-[36px] p-0 rounded-lg text-white font-bold flex items-center justify-center text-sm"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Rule-Based Counter Allocation Assistant */}
      {activeTab === 'allocations' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-2xl liquid-glass-card bg-gradient-to-r from-[#8B5CF6]/15 via-white/[0.04] to-transparent border border-[#8B5CF6]/30 backdrop-blur-xl mb-4 shadow-glass-sm">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#c2c1ff]" />
              <span>{t.admin.rulesEngineTitle}</span>
            </h4>
            <p className="text-xs text-white/70 mt-1">
              {t.admin.rulesEngineNotice}. Recommendations are calculated deterministically when wait time exceeds 18m or backlog exceeds 4 patients.
            </p>
          </div>

          {suggestions.map((sug) => (
            <div
              key={sug.id}
              className="liquid-glass-card p-5 sm:p-6 border border-white/15 hover:border-white/25 transition-all shadow-glass-md relative overflow-hidden"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] px-3 py-1 rounded-full font-bold uppercase flex items-center gap-1.5 ${
                        sug.severity === 'critical'
                          ? 'bg-[#FF453A]/20 text-[#FF453A] border border-[#FF453A]/40'
                          : 'bg-[#FF9F0A]/20 text-[#FF9F0A] border border-[#FF9F0A]/40'
                      }`}
                    >
                      <span className="live-pulse-core w-1.5 h-1.5 rounded-full bg-current" />
                      <span>{sug.severity} Overcrowding</span>
                    </span>
                    <span className="text-sm font-bold text-white">
                      {sug.serviceName}
                    </span>
                  </div>

                  <p className="text-xs text-white/80 max-w-2xl leading-relaxed">
                    {lang === 'hi' ? sug.reasoningHi : sug.reasoningEn}
                  </p>

                  <div className="liquid-recessed-well p-3 border border-white/10 flex items-center gap-4 text-xs font-mono max-w-md">
                    <span className="text-white/60">
                      Wait Before: <strong className="text-[#FF453A]">~{sug.estimatedWaitBefore}m</strong>
                    </span>
                    <span className="text-white/30">→</span>
                    <span className="text-white/60">
                      Projected Wait: <strong className="text-[#35D6A4]">~{sug.estimatedWaitAfter}m</strong>
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleApplySuggestion(sug)}
                  disabled={appliedSuggestionId === sug.id}
                  className="w-full sm:w-auto min-h-[44px] px-6 rounded-xl liquid-button-primary text-xs font-bold shrink-0 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-glass-sm"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {appliedSuggestionId === sug.id
                      ? t.admin.appliedSuccess
                      : t.admin.applySuggestion}
                  </span>
                </button>
              </div>
            </div>
          ))}

          {suggestions.length === 0 && (
            <div className="liquid-glass-card p-8 text-center border border-white/10 shadow-glass-sm">
              <CheckCircle2 className="w-10 h-10 text-[#35D6A4] mx-auto mb-2" />
              <h4 className="text-base font-bold text-white">
                {lang === 'hi' ? 'सभी कतारें संतुलित हैं' : 'All Queues Perfectly Balanced'}
              </h4>
              <p className="text-xs text-white/60 mt-1 max-w-md mx-auto">
                No active service exceeds the congestion threshold. Active counters currently meet demand SLAs.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Service SLA Configuration */}
      {activeTab === 'services' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {services.map((svc) => (
            <div key={svc.code} className="liquid-glass-card p-5 border border-white/10 hover:border-white/20 transition-all shadow-glass-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-bold text-white">
                  {lang === 'hi' ? svc.nameHi : svc.nameEn}
                </span>
                <span className="text-xs font-mono font-bold text-[#64D2FF] bg-[#0A84FF]/20 border border-[#0A84FF]/30 px-2 py-0.5 rounded-md">
                  {svc.code}
                </span>
              </div>

              <p className="text-xs text-white/60 mb-4">
                {lang === 'hi' ? svc.descriptionHi : svc.descriptionEn}
              </p>

              <div className="flex items-center justify-between p-3.5 rounded-xl liquid-recessed-well border border-white/10">
                <span className="text-xs text-white/70">
                  Mean Duration (μ): <strong className="text-white font-mono">{svc.avgDurationMinutes} mins</strong>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleAdjustDuration(svc.code, -0.5)}
                    aria-label="Decrease SLA duration"
                    className="liquid-button-secondary min-w-[36px] min-h-[36px] p-0 rounded-lg text-white font-bold flex items-center justify-center text-sm"
                  >
                    -
                  </button>
                  <button
                    onClick={() => handleAdjustDuration(svc.code, 0.5)}
                    aria-label="Increase SLA duration"
                    className="liquid-button-secondary min-w-[36px] min-h-[36px] p-0 rounded-lg text-white font-bold flex items-center justify-center text-sm"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 4: Priority Rules & Eligibility Inspection */}
      {activeTab === 'priority' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {priorityRules.map((rule) => (
            <div key={rule.tierCode} className="liquid-glass-card p-5 border border-white/10 hover:border-white/20 transition-all shadow-glass-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-white">
                  {lang === 'hi' ? rule.tierNameHi : rule.tierNameEn}
                </span>
                <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-md bg-white/10 border border-white/15 text-[#64D2FF]">
                  Tier {rule.priorityLevel} (Weight {rule.priorityLevel})
                </span>
              </div>
              <p className="text-xs text-white/70 mt-2 leading-relaxed">
                <strong className="text-white/90">{lang === 'hi' ? 'पात्रता नियम:' : 'Eligibility Rules:'}</strong>{' '}
                {lang === 'hi' ? rule.eligibilityHi : rule.eligibilityEn}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
