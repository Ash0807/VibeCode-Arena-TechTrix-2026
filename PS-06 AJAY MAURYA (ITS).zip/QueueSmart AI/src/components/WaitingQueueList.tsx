import React, { useState } from 'react';
import {
  Users,
  Search,
  Clock,
  HeartPulse,
  UserCheck,
  Crown,
  User,
  ArrowRight,
  Ticket,
} from 'lucide-react';
import { QueueToken, Service, ServiceCounter, Language } from '../types';
import { translations } from '../i18n/translations';
import { sortQueueTokens, getTokenQueuePosition } from '../lib/queueEngine';

interface WaitingQueueListProps {
  tokens: QueueToken[];
  services: Service[];
  counters: ServiceCounter[];
  lang: Language;
  onSelectToken: (token: QueueToken) => void;
}

export const WaitingQueueList: React.FC<WaitingQueueListProps> = ({
  tokens,
  services,
  counters,
  lang,
  onSelectToken,
}) => {
  const t = translations[lang];
  const [selectedService, setSelectedService] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const waitingTokens = tokens.filter((tok) => tok.status === 'waiting');
  const sortedTokens = sortQueueTokens(waitingTokens);

  const filteredTokens = sortedTokens.filter((tok) => {
    if (selectedService !== 'all' && tok.serviceCode !== selectedService) return false;
    if (selectedPriority !== 'all' && tok.priorityTier !== selectedPriority) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tok.tokenNumber.toLowerCase().includes(q) ||
        tok.customerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getPriorityBadge = (tier: QueueToken['priorityTier']) => {
    switch (tier) {
      case 'emergency':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 text-[11px] font-bold">
            <HeartPulse className="w-3 h-3" />
            <span>{t.priority.emergency.title}</span>
          </span>
        );
      case 'senior':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 text-[11px] font-bold">
            <UserCheck className="w-3 h-3" />
            <span>{t.priority.senior.title}</span>
          </span>
        );
      case 'vip':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#5E5CE6]/15 text-[#c2c1ff] border border-[#5E5CE6]/30 text-[11px] font-bold">
            <Crown className="w-3 h-3" />
            <span>{t.priority.vip.title}</span>
          </span>
        );
      case 'regular':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#0A84FF]/15 text-[#0A84FF] border border-[#0A84FF]/25 text-[11px] font-bold">
            <User className="w-3 h-3" />
            <span>{t.priority.regular.title}</span>
          </span>
        );
    }
  };

  return (
    <section className="w-full mb-10">
      {/* Title & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-white dark:text-white light:text-slate-900 tracking-tight flex items-center gap-2">
            <span className="p-1 rounded-md bg-[#0A84FF]/15 text-[#0A84FF]">
              <Users className="w-4 h-4" />
            </span>
            <span>{lang === 'hi' ? 'सक्रिय कतार क्रम' : 'Active Queue Order'}</span>
          </h3>
          <p className="text-xs text-white/50 dark:text-white/50 light:text-slate-500">
            {lang === 'hi'
              ? 'बहु-स्तरीय प्राथमिकता और पारदर्शी आगमन क्रम पर आधारित'
              : 'Deterministic priority ranking and verified sequential triage'}
          </p>
        </div>

        {/* Search input (Touch target >= 44px) */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'hi' ? 'टोकन या नाम खोजें...' : 'Filter token / name...'}
            className="w-full pl-9 pr-3 liquid-input-well text-xs"
          />
        </div>
      </div>

      {/* Category Filter Chips (Responsive horizontal scroll) */}
      <div className="flex items-center gap-1.5 mb-4 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setSelectedService('all')}
          className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
            selectedService === 'all'
              ? 'bg-[#0A84FF] text-white shadow-sm'
              : 'bg-white/5 dark:bg-white/5 light:bg-slate-100 text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
          }`}
        >
          {lang === 'hi' ? 'सभी विभाग' : 'All Departments'}
        </button>
        {services.map((svc) => (
          <button
            key={svc.code}
            onClick={() => setSelectedService(svc.code)}
            className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              selectedService === svc.code
                ? 'bg-[#0A84FF] text-white shadow-sm'
                : 'bg-white/5 dark:bg-white/5 light:bg-slate-100 text-white/70 dark:text-white/70 light:text-slate-600 hover:text-white'
            }`}
          >
            {lang === 'hi' ? svc.nameHi : svc.nameEn}
          </button>
        ))}
      </div>

      {/* Mobile Card List (< 768px Viewport) */}
      <div className="md:hidden space-y-2.5">
        {filteredTokens.map((tok, index) => {
          const svc = services.find((s) => s.code === tok.serviceCode);
          const { estimatedWaitMinutes } = getTokenQueuePosition(
            tok,
            tokens,
            counters,
            services
          );

          const nameParts = tok.customerName.split(' ');
          const anonName =
            nameParts.length > 1
              ? `${nameParts[0]} ${nameParts[1][0]}.`
              : tok.customerName;

          return (
            <div
              key={tok.id}
              onClick={() => onSelectToken(tok)}
              className="liquid-glass-card p-3.5 flex items-center justify-between gap-3 cursor-pointer active:scale-[0.99] transition-transform"
            >
              <div className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-lg bg-white/10 dark:bg-white/10 light:bg-slate-200 text-xs font-mono font-bold flex items-center justify-center text-white/80 dark:text-white/80 light:text-slate-700">
                  #{index + 1}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-extrabold text-white dark:text-white light:text-slate-900">
                      {tok.tokenNumber}
                    </span>
                    <span className="text-xs text-white/70 dark:text-white/70 light:text-slate-600">
                      {anonName}
                    </span>
                  </div>
                  <div className="text-[11px] text-white/40 dark:text-white/40 light:text-slate-500 mt-0.5">
                    {svc ? (lang === 'hi' ? svc.nameHi : svc.nameEn) : tok.serviceCode}
                  </div>
                </div>
              </div>

              <div className="text-right flex flex-col items-end gap-1">
                {getPriorityBadge(tok.priorityTier)}
                <span className="text-xs font-mono font-bold text-[#0A84FF]">
                  ~{estimatedWaitMinutes}m
                </span>
              </div>
            </div>
          );
        })}

        {filteredTokens.length === 0 && (
          <div className="liquid-glass-card p-6 text-center text-xs text-white/40 dark:text-white/40 light:text-slate-400">
            {lang === 'hi'
              ? 'इस फ़िल्टर में कोई प्रतीक्षा टोकन नहीं है'
              : 'No waiting tickets matching current filters'}
          </div>
        )}
      </div>

      {/* Desktop Table Layout (>= 768px Viewport) */}
      <div className="hidden md:block liquid-glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/5 dark:bg-white/5 light:bg-slate-100 border-b border-white/10 dark:border-white/10 light:border-slate-200 text-white/50 dark:text-white/50 light:text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4"># Position</th>
                <th className="py-3 px-4">Token</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Priority Tier</th>
                <th className="py-3 px-4">Est. Wait</th>
                <th className="py-3 px-4 text-right">Pass</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 dark:divide-white/5 light:divide-slate-200">
              {filteredTokens.map((tok, index) => {
                const svc = services.find((s) => s.code === tok.serviceCode);
                const { estimatedWaitMinutes } = getTokenQueuePosition(
                  tok,
                  tokens,
                  counters,
                  services
                );

                const nameParts = tok.customerName.split(' ');
                const anonName =
                  nameParts.length > 1
                    ? `${nameParts[0]} ${nameParts[1][0]}.`
                    : tok.customerName;

                return (
                  <tr
                    key={tok.id}
                    onClick={() => onSelectToken(tok)}
                    className="hover:bg-white/5 dark:hover:bg-white/5 light:hover:bg-slate-100 transition-colors cursor-pointer group"
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-white/50 group-hover:text-white">
                      #{index + 1}
                    </td>
                    <td className="py-3.5 px-4 font-mono font-extrabold text-white dark:text-white light:text-slate-900 text-sm group-hover:text-[#0A84FF]">
                      {tok.tokenNumber}
                    </td>
                    <td className="py-3.5 px-4 text-white/90 dark:text-white/90 light:text-slate-800 font-medium">
                      {anonName}
                    </td>
                    <td className="py-3.5 px-4 text-white/70 dark:text-white/70 light:text-slate-600">
                      {svc ? (lang === 'hi' ? svc.nameHi : svc.nameEn) : tok.serviceCode}
                    </td>
                    <td className="py-3.5 px-4">{getPriorityBadge(tok.priorityTier)}</td>
                    <td className="py-3.5 px-4 text-[#0A84FF] font-bold font-mono">
                      ~{estimatedWaitMinutes}m
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <span className="inline-flex items-center gap-1 text-[11px] text-white/50 group-hover:text-white group-hover:translate-x-0.5 transition-transform">
                        <span>Pass</span>
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </td>
                  </tr>
                );
              })}

              {filteredTokens.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-white/40 dark:text-white/40 light:text-slate-400">
                    {lang === 'hi'
                      ? 'इस फ़िल्टर में कोई प्रतीक्षा टोकन नहीं है'
                      : 'No waiting tickets matching current filters'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
