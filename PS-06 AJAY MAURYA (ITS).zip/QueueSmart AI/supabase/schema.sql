-- ====================================================================
-- QueueSmart AI — Supabase Database Migration & Schema
-- Enterprise Smart Queue Management with Transparent Realtime Analytics
-- ====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. SECTORS & SERVICES TABLE
CREATE TABLE IF NOT EXISTS public.services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(10) UNIQUE NOT NULL, -- e.g. 'CARD', 'TRIAGE', 'CASH', 'PASS'
    sector VARCHAR(50) NOT NULL, -- 'healthcare', 'banking', 'civic'
    name_en VARCHAR(100) NOT NULL,
    name_hi VARCHAR(100) NOT NULL,
    avg_duration_minutes NUMERIC(4,1) NOT NULL DEFAULT 8.0,
    prefix VARCHAR(5) NOT NULL DEFAULT 'A',
    color VARCHAR(20) NOT NULL DEFAULT '#0A84FF',
    is_active BOOLEAN NOT NULL DEFAULT true,
    description_en TEXT,
    description_hi TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. PRIORITY CONFIGURATION TABLE
CREATE TABLE IF NOT EXISTS public.priority_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tier_code VARCHAR(20) UNIQUE NOT NULL, -- 'emergency', 'senior', 'vip', 'regular'
    tier_name_en VARCHAR(50) NOT NULL,
    tier_name_hi VARCHAR(50) NOT NULL,
    priority_level INT NOT NULL, -- 1 = highest, 4 = normal
    color VARCHAR(20) NOT NULL,
    eligibility_criteria_en TEXT NOT NULL,
    eligibility_criteria_hi TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. SERVICE COUNTERS TABLE
CREATE TABLE IF NOT EXISTS public.service_counters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    counter_number INT UNIQUE NOT NULL,
    counter_name_en VARCHAR(100) NOT NULL,
    counter_name_hi VARCHAR(100) NOT NULL,
    operator_name VARCHAR(100) NOT NULL,
    sector VARCHAR(50) NOT NULL DEFAULT 'healthcare',
    status VARCHAR(20) NOT NULL DEFAULT 'closed' CHECK (status IN ('open', 'busy', 'paused', 'closed')),
    compatible_service_codes TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    current_token_id UUID,
    total_served_today INT NOT NULL DEFAULT 0,
    avg_pace_minutes NUMERIC(4,1) NOT NULL DEFAULT 6.5,
    last_status_change TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. QUEUE TOKENS TABLE
CREATE TABLE IF NOT EXISTS public.queue_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_number VARCHAR(20) NOT NULL, -- e.g. 'H-204'
    sector VARCHAR(50) NOT NULL,
    service_code VARCHAR(10) NOT NULL REFERENCES public.services(code) ON DELETE RESTRICT,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    priority_tier VARCHAR(20) NOT NULL DEFAULT 'regular' REFERENCES public.priority_rules(tier_code),
    status VARCHAR(20) NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'serving', 'completed', 'skipped', 'cancelled')),
    counter_id UUID REFERENCES public.service_counters(id) ON DELETE SET NULL,
    counter_number INT,
    estimated_wait_minutes NUMERIC(5,1) NOT NULL DEFAULT 0.0,
    actual_wait_minutes NUMERIC(5,1),
    called_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    appointment_time VARCHAR(20),
    notification_channel VARCHAR(20) DEFAULT 'in-app',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. APPOINTMENT SLOTS TABLE
CREATE TABLE IF NOT EXISTS public.appointment_slots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_code VARCHAR(10) NOT NULL REFERENCES public.services(code),
    slot_date DATE NOT NULL,
    slot_time VARCHAR(20) NOT NULL, -- '10:00 - 10:30'
    max_capacity INT NOT NULL DEFAULT 5,
    booked_count INT NOT NULL DEFAULT 0,
    is_available BOOLEAN GENERATED ALWAYS AS (booked_count < max_capacity) STORED,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. AUDIT & QUEUE NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.queue_notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID REFERENCES public.queue_tokens(id) ON DELETE CASCADE,
    token_number VARCHAR(20) NOT NULL,
    event_type VARCHAR(30) NOT NULL, -- 'issued', 'turn_approaching', 'called', 'completed'
    title_en VARCHAR(150) NOT NULL,
    title_hi VARCHAR(150) NOT NULL,
    message_en TEXT NOT NULL,
    message_hi TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- INDEXES FOR HIGH-CONCURRENCY DETERMINISTIC QUEUING
-- ====================================================================
CREATE INDEX IF NOT EXISTS idx_tokens_status ON public.queue_tokens(status);
CREATE INDEX IF NOT EXISTS idx_tokens_service_sector ON public.queue_tokens(sector, service_code);
CREATE INDEX IF NOT EXISTS idx_tokens_priority_created ON public.queue_tokens(priority_tier, created_at);
CREATE INDEX IF NOT EXISTS idx_counters_status ON public.service_counters(status);
CREATE INDEX IF NOT EXISTS idx_notifications_token ON public.queue_notifications(token_id);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.priority_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_counters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.queue_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.queue_notifications ENABLE ROW LEVEL SECURITY;

-- Anonymous users (public queue board / ticket holders) can read services and counters
CREATE POLICY "Public Read Services" ON public.services FOR SELECT USING (true);
CREATE POLICY "Public Read Priority Rules" ON public.priority_rules FOR SELECT USING (true);
CREATE POLICY "Public Read Counters" ON public.service_counters FOR SELECT USING (true);
CREATE POLICY "Public Read Queue Tokens" ON public.queue_tokens FOR SELECT USING (true);
CREATE POLICY "Public Insert Queue Tokens" ON public.queue_tokens FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Read Notifications" ON public.queue_notifications FOR SELECT USING (true);
CREATE POLICY "Public Read Appointment Slots" ON public.appointment_slots FOR SELECT USING (true);

-- Authenticated staff & service role can update counters and queue tokens
CREATE POLICY "Staff Manage Counters" ON public.service_counters FOR ALL USING (auth.role() IN ('authenticated', 'service_role')) WITH CHECK (true);
CREATE POLICY "Staff Manage Queue Tokens" ON public.queue_tokens FOR ALL USING (auth.role() IN ('authenticated', 'service_role')) WITH CHECK (true);

-- ====================================================================
-- REALTIME PUBLICATION SETUP
-- ====================================================================
BEGIN;
  -- Add tables to supabase_realtime publication
  DROP PUBLICATION IF EXISTS supabase_realtime;
  CREATE PUBLICATION supabase_realtime FOR TABLE 
    public.queue_tokens, 
    public.service_counters, 
    public.queue_notifications;
COMMIT;
