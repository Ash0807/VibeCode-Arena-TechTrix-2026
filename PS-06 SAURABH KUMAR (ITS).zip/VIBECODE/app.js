/**
 * QueueSmart AI - Core Logic & Flow
 * Vanilla JavaScript Implementation with FairQueue Priority System
 */

// FairQueue Priority Definitions & Configuration
const PRIORITY_CONFIG = {
  emergency: { rank: 1, label: 'Emergency', icon: '🚨', class: 'emergency', desc: 'Critical / Urgent' },
  elderly: { rank: 2, label: 'Elderly/Accessible', icon: '♿', class: 'elderly', desc: 'Senior & Accessible' },
  normal: { rank: 3, label: 'Normal', icon: '👤', class: 'normal', desc: 'Standard Service' }
};

// Helper: Generate accessible priority badge markup
function getPriorityBadgeHtml(priority) {
  const p = (priority || 'normal').toLowerCase();
  const cfg = PRIORITY_CONFIG[p] || PRIORITY_CONFIG.normal;
  return `<span class="priority-badge ${cfg.class}" aria-label="Priority: ${cfg.label}"><span>${cfg.icon}</span> <span>${cfg.label}</span></span>`;
}

// Helper: Sort waiting customers by FairQueue Priority rules (Emergency -> Elderly -> Normal, FIFO within tier)
function getFairQueueOrder(waitingList) {
  return [...waitingList].sort((a, b) => {
    const rankA = (PRIORITY_CONFIG[a.priority] || PRIORITY_CONFIG.normal).rank;
    const rankB = (PRIORITY_CONFIG[b.priority] || PRIORITY_CONFIG.normal).rank;
    if (rankA !== rankB) {
      return rankA - rankB;
    }
    return (a.createdTimeMs || 0) - (b.createdTimeMs || 0);
  });
}

// Initial Realistic Demo Data (With FairQueue Priority Levels)
const INITIAL_QUEUE_DATA = [
  {
    id: 'tok-100',
    token: 'A-100',
    name: 'David Miller',
    service: 'Cash Deposit & Withdrawal',
    serviceType: 'express',
    priority: 'normal',
    durationMins: 4,
    status: 'serving',
    counter: 'Counter 1',
    createdAt: new Date(Date.now() - 15 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 15 * 60000,
    completedAt: null
  },
  {
    id: 'tok-101',
    token: 'A-101',
    name: 'Sarah Jenkins',
    service: 'Account Opening & KYC',
    serviceType: 'standard',
    priority: 'normal',
    durationMins: 10,
    status: 'waiting',
    counter: null,
    createdAt: new Date(Date.now() - 12 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 12 * 60000,
    completedAt: null
  },
  {
    id: 'tok-102',
    token: 'A-102',
    name: 'Rajesh Sharma',
    service: 'Loan & Mortgage Advisory',
    serviceType: 'advisory',
    priority: 'elderly',
    durationMins: 15,
    status: 'waiting',
    counter: null,
    createdAt: new Date(Date.now() - 9 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 9 * 60000,
    completedAt: null
  },
  {
    id: 'tok-103',
    token: 'A-103',
    name: 'Elena Rostova',
    service: 'Cash Deposit & Withdrawal',
    serviceType: 'express',
    priority: 'emergency',
    durationMins: 5,
    status: 'waiting',
    counter: null,
    createdAt: new Date(Date.now() - 6 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 6 * 60000,
    completedAt: null
  },
  {
    id: 'tok-104',
    token: 'A-104',
    name: 'Michael Chen',
    service: 'Digital Banking & Support',
    serviceType: 'standard',
    priority: 'normal',
    durationMins: 8,
    status: 'waiting',
    counter: null,
    createdAt: new Date(Date.now() - 2 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 2 * 60000,
    completedAt: null
  },
  {
    id: 'tok-098',
    token: 'A-098',
    name: 'Sophia Garcia',
    service: 'Account Opening & KYC',
    serviceType: 'standard',
    priority: 'normal',
    durationMins: 10,
    status: 'completed',
    counter: 'Counter 1',
    createdAt: new Date(Date.now() - 35 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 35 * 60000,
    completedAt: new Date(Date.now() - 25 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  },
  {
    id: 'tok-099',
    token: 'A-099',
    name: 'James Wilson',
    service: 'Card Replacement',
    serviceType: 'express',
    priority: 'elderly',
    durationMins: 4,
    status: 'completed',
    counter: 'Counter 1',
    createdAt: new Date(Date.now() - 28 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now() - 28 * 60000,
    completedAt: new Date(Date.now() - 16 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
];

// Initial Realistic In-App Notifications (Simulated Customer Alerts)
const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif-1',
    type: 'turn',
    title: 'Turn Approaching (A-101)',
    desc: 'Sarah Jenkins is next in line (#1). Please prepare to approach counter.',
    time: 'Just now',
    unread: true,
    targetToken: 'A-101',
    timestamp: Date.now() - 45000
  },
  {
    id: 'notif-2',
    type: 'serving',
    title: 'Counter 1 Serving A-100',
    desc: 'David Miller called to Counter 1 for Cash Deposit & Withdrawal.',
    time: '3 mins ago',
    unread: false,
    targetToken: 'A-100',
    timestamp: Date.now() - 180000
  },
  {
    id: 'notif-3',
    type: 'counter',
    title: 'Counter 1 Online',
    desc: 'Counter 1 initialized and operating smoothly in single-desk mode.',
    time: '15 mins ago',
    unread: false,
    targetToken: null,
    timestamp: Date.now() - 900000
  }
];

// App State
const state = {
  queue: JSON.parse(JSON.stringify(INITIAL_QUEUE_DATA)),
  tokenSequence: 105,
  activeCounters: 1, // Counter 1 active, Counter 2 optional
  configServiceDuration: 6, // Configurable average service duration in minutes
  selectedPriority: 'normal', // Default checked priority for new customers
  lastCallReason: 'Initial demo state: Counter 1 serving David Miller (Normal Priority).',
  currentFilter: 'all',
  searchQuery: '',
  myTokenId: 'tok-101', // Set initially to Sarah Jenkins so judges see a working token card immediately
  soundEnabled: true,
  audioCtx: null,
  // Smart Customer Notification Center State
  notifications: JSON.parse(JSON.stringify(INITIAL_NOTIFICATIONS)),
  notifHistoryHashes: {
    'turn-approaching-tok-101': true,
    'serving-tok-100-Counter 1': true,
    'counter-init-1': true
  },
  lastCrowdLevel: 'Moderate'
};

// Web Audio API Synthesized Chime (100% offline, vanilla JS)
function playChime() {
  if (!state.soundEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    if (!state.audioCtx) {
      state.audioCtx = new AudioContext();
    }
    if (state.audioCtx.state === 'suspended') {
      state.audioCtx.resume();
    }
    const ctx = state.audioCtx;
    const now = ctx.currentTime;

    // First tone (E5 ~ 659.25Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(659.25, now);
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.5);

    // Second tone (C5 ~ 523.25Hz)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(523.25, now + 0.22);
    gain2.gain.setValueAtTime(0.18, now + 0.22);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.22);
    osc2.stop(now + 0.85);
  } catch (e) {
    // Graceful fallback if user hasn't interacted or audio unsupported
    console.debug('Audio not allowed yet or not supported:', e);
  }
}

// Toast Notifications
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let iconSvg = '';
  if (type === 'success') {
    iconSvg = `<svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
  } else if (type === 'warning') {
    iconSvg = `<svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`;
  } else {
    iconSvg = `<svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
  }

  toast.innerHTML = `${iconSvg} <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Smart Customer Notification Center: Helper Functions
function addNotification({ type, title, desc, dedupeKey = null, targetToken = null, showToastAlert = false }) {
  // Deduplication check: prevent duplicate alerts for the same event/status transition
  if (dedupeKey) {
    if (state.notifHistoryHashes[dedupeKey]) {
      return null;
    }
    state.notifHistoryHashes[dedupeKey] = true;
  }

  const notif = {
    id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    type: type || 'wait',
    title: title,
    desc: desc,
    time: 'Just now',
    unread: true,
    targetToken: targetToken || null,
    timestamp: Date.now()
  };

  state.notifications.unshift(notif);

  // Maintain max 35 notifications in history
  if (state.notifications.length > 35) {
    state.notifications.pop();
  }

  renderNotifications();

  if (showToastAlert) {
    const toastType = type === 'completed' ? 'success' : (type === 'turn' || type === 'serving' ? 'info' : 'warning');
    showToast(`${title}: ${desc}`, toastType);
  }

  return notif;
}

function renderNotifications() {
  const notifListEl = document.getElementById('notification-list');
  const badgeEl = document.getElementById('notif-unread-count');
  if (!notifListEl || !badgeEl) return;

  const unreadCount = state.notifications.filter(n => n.unread).length;
  badgeEl.textContent = unreadCount.toString();
  if (unreadCount === 0) {
    badgeEl.classList.add('hidden');
  } else {
    badgeEl.classList.remove('hidden');
  }

  if (state.notifications.length === 0) {
    notifListEl.innerHTML = `
      <div class="notif-empty">
        <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin: 0 auto 0.5rem; display: block;">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        <p>No notifications yet</p>
      </div>
    `;
    return;
  }

  const iconMap = {
    turn: '⏳',
    serving: '🛎️',
    completed: '✅',
    counter: '⚡',
    wait: '⏱️'
  };

  notifListEl.innerHTML = state.notifications.map(notif => {
    const unreadClass = notif.unread ? 'unread' : '';
    const iconChar = iconMap[notif.type] || '🔔';
    return `
      <div class="notif-item ${unreadClass}" data-id="${notif.id}">
        <div class="notif-icon-box ${notif.type}">
          <span>${iconChar}</span>
        </div>
        <div class="notif-content">
          <div class="notif-title-row">
            <span class="notif-title">${escapeHtml(notif.title)}</span>
            <span class="notif-time">${escapeHtml(notif.time)}</span>
          </div>
          <div class="notif-desc">${escapeHtml(notif.desc)}</div>
        </div>
      </div>
    `;
  }).join('');
}

// QueuePulse Smart Load Balancer Calculation & Transparent Rules
function calculateMetrics() {
  const waitingCustomers = state.queue.filter(item => item.status === 'waiting');
  const servingCustomer = state.queue.find(item => item.status === 'serving') || null;
  const completedCustomers = state.queue.filter(item => item.status === 'completed');

  const totalWaiting = waitingCustomers.length;
  const currentlyServingCount = servingCustomer ? 1 : 0;
  const totalCompleted = completedCustomers.length;

  // Actual queue workload in minutes based on validated duration (1-120 mins)
  const avgDuration = Math.min(120, Math.max(1, parseInt(state.configServiceDuration, 10) || 6));
  const activeDesks = Math.max(1, state.activeCounters || 1);
  const totalWorkloadMins = totalWaiting * avgDuration;

  // Projected wait times factoring in active desks
  const avgWaitTime = totalWaiting > 0 
    ? Math.max(1, Math.ceil(totalWorkloadMins / activeDesks)) 
    : 0;
  const projectedOneDeskWait = totalWorkloadMins;
  const projectedTwoDeskWait = Math.max(1, Math.ceil(totalWorkloadMins / 2));

  // Determine 4 Clear Crowd Levels (Low, Moderate, High, Critical)
  let crowdStatus = 'Low';
  let crowdClass = 'low';
  let crowdPercent = 20;

  if (totalWaiting === 0) {
    crowdStatus = 'Low';
    crowdClass = 'low';
    crowdPercent = 10;
  } else if (avgWaitTime > 24 || (state.activeCounters === 1 && totalWaiting >= 6)) {
    crowdStatus = 'Critical';
    crowdClass = 'critical';
    crowdPercent = 100;
  } else if (avgWaitTime >= 15 || (state.activeCounters === 1 && totalWaiting >= 4)) {
    crowdStatus = 'High';
    crowdClass = 'high';
    crowdPercent = 80;
  } else if (avgWaitTime >= 7 || totalWaiting >= 2) {
    crowdStatus = 'Moderate';
    crowdClass = 'moderate';
    crowdPercent = 52;
  } else {
    crowdStatus = 'Low';
    crowdClass = 'low';
    crowdPercent = 25;
  }

  // Transparent Rule Evaluation
  let recommendationTitle = '';
  let recommendationDesc = '';
  let ruleBadge = '';
  let ruleText = '';
  let showCounterButton = false;
  let actionBtnText = '';
  let actionBtnClass = 'btn-admin btn-call-next';

  if (state.activeCounters === 1) {
    // Single Counter Active
    if (crowdStatus === 'Critical') {
      recommendationTitle = '🚨 QueuePulse Alert: CRITICAL QUEUE CONGESTION';
      recommendationDesc = `CRITICAL LOAD: ${totalWaiting} customers waiting! Projected wait is severe at ${avgWaitTime} mins. Activate Counter 2 immediately to restore throughput.`;
      ruleBadge = 'RULE: SCALE-UP-CRITICAL';
      ruleText = `Rule SCALE-UP-CRITICAL Triggered: ${totalWaiting} waiting customers on 1 counter generates an unsustainable ${avgWaitTime}m queue. Activating Counter 2 reduces wait to ~${projectedTwoDeskWait} mins (50% reduction).`;
      showCounterButton = true;
      actionBtnText = '⚡ Open Counter 2 (Critical Scale-Up)';
      actionBtnClass = 'btn-admin btn-call-next pulse-critical';
    } else if (crowdStatus === 'High') {
      recommendationTitle = '⚡ QueuePulse Scaler: High Crowd Congestion';
      recommendationDesc = `Queue density is high (${totalWaiting} waiting, ~${avgWaitTime}m wait). QueuePulse recommends opening Counter 2 immediately to cut wait times to ~${projectedTwoDeskWait} mins.`;
      ruleBadge = 'RULE: SCALE-UP-RECOMMENDED';
      ruleText = `Rule SCALE-UP-RECOMMENDED Triggered: Projected wait (${avgWaitTime}m) exceeds the target 12m SLA threshold. Opening Counter 2 scales capacity to 200%.`;
      showCounterButton = true;
      actionBtnText = '⚡ Apply AI Suggestion: Open Counter 2';
      actionBtnClass = 'btn-admin btn-call-next';
    } else if (crowdStatus === 'Moderate') {
      recommendationTitle = 'Moderate Queue Volume';
      recommendationDesc = `${totalWaiting} customers waiting (~${avgWaitTime}m wait). Counter 1 is handling load stably. Counter 2 is on standby if volume spikes.`;
      ruleBadge = 'RULE: MONITOR-STANDBY';
      ruleText = `Rule MONITOR-STANDBY Evaluated: (${totalWaiting} waiting × ~${avgDuration}m avg) ÷ 1 desk = ${avgWaitTime} mins wait. Volume is within acceptable operational tolerance.`;
      showCounterButton = true;
      actionBtnText = 'Open Counter 2 (Preemptive Scale)';
      actionBtnClass = 'btn-admin btn-call-next';
    } else {
      recommendationTitle = 'Queue Flow is Balanced';
      recommendationDesc = `Traffic is light (${totalWaiting} waiting, ~${avgWaitTime}m wait). Counter 1 provides rapid, cost-efficient service.`;
      ruleBadge = 'RULE: OPTIMAL-SINGLE-DESK';
      ruleText = `Rule OPTIMAL-SINGLE-DESK Evaluated: Single desk capacity is optimal for ${totalWaiting} customer(s). Customer wait time (~${avgWaitTime}m) is well below the 10m SLA target.`;
      showCounterButton = false;
    }
  } else {
    // Dual Counters (2 Active)
    if (totalWaiting <= 2) {
      recommendationTitle = '💡 QueuePulse Optimizer: Surplus Desk Capacity';
      recommendationDesc = `Queue volume is low (${totalWaiting} waiting, ~${avgWaitTime}m wait). Counter 2 can be safely returned to standby to conserve staff resources.`;
      ruleBadge = 'RULE: SCALE-DOWN-STANDBY';
      ruleText = `Rule SCALE-DOWN-STANDBY Triggered: With only ${totalWaiting} waiting customer(s), 2 active desks have surplus capacity. Projected wait on 1 desk would only be ~${projectedOneDeskWait} mins.`;
      showCounterButton = true;
      actionBtnText = 'Close Counter 2 (Return to Standby)';
      actionBtnClass = 'btn-admin btn-skip';
    } else if (crowdStatus === 'Critical') {
      recommendationTitle = '🚨 High Demand: Both Desks Operating at Max';
      recommendationDesc = `Heavy customer flow (${totalWaiting} waiting). Both counters are serving in parallel to prevent runaway wait times.`;
      ruleBadge = 'RULE: DUAL-MAX-SATURATION';
      ruleText = `Rule DUAL-MAX-SATURATION Active: Both desks are vital. Dual processing saves ~${projectedOneDeskWait - avgWaitTime} mins per customer compared to a single desk.`;
      showCounterButton = false;
    } else {
      recommendationTitle = '⚡ Dual Desks Operating in Equilibrium';
      recommendationDesc = `Counters 1 & 2 are actively balancing traffic (${totalWaiting} waiting, ~${avgWaitTime}m wait). Customer flow is stable and well-regulated.`;
      ruleBadge = 'RULE: DUAL-EQUILIBRIUM';
      ruleText = `Rule DUAL-EQUILIBRIUM Evaluated: (${totalWaiting} waiting × ~${avgDuration}m) ÷ 2 desks = ${avgWaitTime} mins wait. Dual throughput maintains rapid customer clearance.`;
      showCounterButton = true;
      actionBtnText = 'Close Counter 2 (Return to Standby)';
      actionBtnClass = 'btn-admin btn-skip';
    }
  }

  return {
    totalWaiting,
    currentlyServingCount,
    servingCustomer,
    totalCompleted,
    avgDuration,
    avgWaitTime,
    crowdStatus,
    crowdClass,
    crowdPercent,
    recommendationTitle,
    recommendationDesc,
    ruleBadge,
    ruleText,
    showCounterButton,
    actionBtnText,
    actionBtnClass
  };
}

// Render Dashboard (KPIs, QueuePulse Smart Load Balancer & Telemetry)
function renderDashboard() {
  const metrics = calculateMetrics();

  // KPI 1: Waiting
  const kpiWaitingEl = document.getElementById('kpi-waiting-count');
  if (kpiWaitingEl) kpiWaitingEl.textContent = metrics.totalWaiting;

  // KPI 2: Currently Serving
  const kpiServingEl = document.getElementById('kpi-serving-count');
  const kpiServingSubEl = document.getElementById('kpi-serving-sub');
  if (kpiServingEl) kpiServingEl.textContent = metrics.currentlyServingCount;
  if (kpiServingSubEl) {
    if (metrics.servingCustomer) {
      kpiServingSubEl.textContent = `${metrics.servingCustomer.token} (${metrics.servingCustomer.name})`;
    } else {
      kpiServingSubEl.textContent = 'Counter Ready for Next';
    }
  }

  // KPI 3: Completed
  const kpiCompletedEl = document.getElementById('kpi-completed-count');
  if (kpiCompletedEl) kpiCompletedEl.textContent = metrics.totalCompleted;

  // KPI 4: Avg Wait Time
  const kpiWaitEl = document.getElementById('kpi-wait-time');
  if (kpiWaitEl) kpiWaitEl.textContent = metrics.avgWaitTime;

  // QueuePulse Smart Load Balancer Card
  const crowdStatusText = document.getElementById('crowd-status-text');
  const crowdFill = document.getElementById('crowd-fill');
  const aiTitle = document.getElementById('ai-rec-title');
  const aiDesc = document.getElementById('ai-rec-desc');
  const aiActionBtn = document.getElementById('ai-action-btn');
  const counterStatusPill = document.getElementById('counter-status-pill');

  if (crowdStatusText) {
    crowdStatusText.textContent = metrics.crowdStatus;
    crowdStatusText.className = `crowd-status-text ${metrics.crowdClass}`;
  }

  if (crowdFill) {
    crowdFill.style.width = `${metrics.crowdPercent}%`;
    if (metrics.crowdClass === 'critical') {
      crowdFill.style.background = '#dc2626';
    } else if (metrics.crowdClass === 'high') {
      crowdFill.style.background = 'var(--danger-solid)';
    } else if (metrics.crowdClass === 'moderate') {
      crowdFill.style.background = 'var(--warning-solid)';
    } else {
      crowdFill.style.background = 'var(--success-solid)';
    }
  }

  if (aiTitle) aiTitle.textContent = metrics.recommendationTitle;
  if (aiDesc) aiDesc.textContent = metrics.recommendationDesc;

  if (aiActionBtn) {
    if (metrics.showCounterButton) {
      aiActionBtn.style.display = 'inline-flex';
      aiActionBtn.textContent = metrics.actionBtnText;
      aiActionBtn.className = metrics.actionBtnClass;
    } else {
      aiActionBtn.style.display = 'none';
    }
  }

  // Telemetry "Why this recommendation?" Elements
  const telWaiting = document.getElementById('telemetry-waiting');
  const telCounters = document.getElementById('telemetry-counters');
  const telDuration = document.getElementById('telemetry-duration');
  const telProjected = document.getElementById('telemetry-projected');
  const telRuleBadge = document.getElementById('telemetry-rule-badge');
  const whyRuleText = document.getElementById('why-rec-rule-text');

  if (telWaiting) telWaiting.textContent = metrics.totalWaiting;
  if (telCounters) telCounters.textContent = state.activeCounters === 2 ? '2 Desks (Active)' : '1 Desk (Active)';
  if (telDuration) telDuration.textContent = `${metrics.avgDuration} mins`;
  if (telProjected) telProjected.textContent = `${metrics.avgWaitTime} mins`;
  if (telRuleBadge) telRuleBadge.textContent = metrics.ruleBadge;
  if (whyRuleText) whyRuleText.textContent = metrics.ruleText;

  if (counterStatusPill) {
    counterStatusPill.textContent = state.activeCounters > 1 
      ? 'Counters 1 & 2 Active' 
      : 'Counter 1 Active • Counter 2 Standby';
  }

  // Check for significant wait-time or crowd volume transitions
  if (state.lastCrowdLevel && state.lastCrowdLevel !== metrics.crowdStatus) {
    if (metrics.crowdStatus === 'Critical') {
      addNotification({
        type: 'wait',
        title: '🚨 Critical Queue Congestion',
        desc: `High traffic surge: ${metrics.totalWaiting} waiting. Projected wait increased to ~${metrics.avgWaitTime}m.`,
        dedupeKey: `crowd-critical-${metrics.totalWaiting}`
      });
    } else if (metrics.crowdStatus === 'High') {
      addNotification({
        type: 'wait',
        title: '⚡ High Queue Demand',
        desc: `Crowd level is now High with ${metrics.totalWaiting} waiting. Projected wait ~${metrics.avgWaitTime}m.`,
        dedupeKey: `crowd-high-${metrics.totalWaiting}`
      });
    } else if ((state.lastCrowdLevel === 'High' || state.lastCrowdLevel === 'Critical') && (metrics.crowdStatus === 'Low' || metrics.crowdStatus === 'Moderate')) {
      addNotification({
        type: 'wait',
        title: 'Queue Load Normalized',
        desc: `Wait times reduced to ~${metrics.avgWaitTime}m as volume eased to ${metrics.crowdStatus}.`,
        dedupeKey: `crowd-eased-${metrics.crowdStatus}-${metrics.totalWaiting}`
      });
    }
    state.lastCrowdLevel = metrics.crowdStatus;
  }

  // Update Admin Current Serving Card
  renderAdminPanel(metrics);

  // Update Token Display Card
  renderTokenDisplay();

  // Update Queue Table
  renderQueueTable();

  // Update Notifications UI
  renderNotifications();
}

// Render Admin Panel
function renderAdminPanel(metrics) {
  const adminTokenEl = document.getElementById('admin-current-token');
  const adminNameEl = document.getElementById('admin-current-name');
  const adminServiceEl = document.getElementById('admin-current-service');
  const adminPriorityEl = document.getElementById('admin-current-priority');
  const adminCallReasonText = document.getElementById('admin-call-reason-text');
  const btnCallNext = document.getElementById('btn-call-next');
  const btnComplete = document.getElementById('btn-complete-service');
  const btnSkip = document.getElementById('btn-skip-customer');

  const serving = metrics.servingCustomer;

  if (serving) {
    if (adminTokenEl) adminTokenEl.textContent = serving.token;
    if (adminNameEl) adminNameEl.textContent = serving.name;
    if (adminServiceEl) adminServiceEl.textContent = `${serving.service} • Assigned to ${serving.counter || 'Counter 1'}`;
    if (adminPriorityEl) adminPriorityEl.innerHTML = getPriorityBadgeHtml(serving.priority);
    if (adminCallReasonText) adminCallReasonText.textContent = state.lastCallReason || 'Currently serving at desk.';
    if (btnComplete) btnComplete.disabled = false;
    if (btnSkip) btnSkip.disabled = false;
  } else {
    if (adminTokenEl) adminTokenEl.textContent = '--';
    if (adminNameEl) adminNameEl.textContent = 'No customer currently being served';
    if (adminServiceEl) adminServiceEl.textContent = 'Click "Call Next Customer" to assign next eligible in line';
    if (adminPriorityEl) adminPriorityEl.innerHTML = '';
    if (adminCallReasonText) adminCallReasonText.textContent = state.lastCallReason || 'Desk idle. Ready for next eligible customer.';
    if (btnComplete) btnComplete.disabled = true;
    if (btnSkip) btnSkip.disabled = true;
  }

  // Disable "Call Next" if no waiting customers
  if (btnCallNext) {
    btnCallNext.disabled = (metrics.totalWaiting === 0);
  }
}

// Render User's Active Token Display
function renderTokenDisplay() {
  const tokenNumberEl = document.getElementById('token-card-number');
  const tokenCustomerEl = document.getElementById('token-card-customer');
  const tokenServiceEl = document.getElementById('token-card-service');
  const tokenPriorityEl = document.getElementById('token-card-priority');
  const tokenAheadEl = document.getElementById('token-card-ahead');
  const tokenWaitEl = document.getElementById('token-card-wait');
  const tokenStatusBadge = document.getElementById('token-card-status');
  const tokenBanner = document.getElementById('token-card-banner');

  // Find user's token or fallback to first waiting
  let activeToken = state.queue.find(item => item.id === state.myTokenId);
  if (!activeToken) {
    const waitingList = state.queue.filter(item => item.status === 'waiting');
    const fairOrdered = getFairQueueOrder(waitingList);
    activeToken = fairOrdered[0] || state.queue[0];
  }

  if (!activeToken) {
    if (tokenNumberEl) tokenNumberEl.textContent = '--';
    if (tokenCustomerEl) tokenCustomerEl.textContent = 'No Active Ticket';
    if (tokenServiceEl) tokenServiceEl.textContent = 'Join the queue to generate your token';
    if (tokenPriorityEl) tokenPriorityEl.innerHTML = '';
    if (tokenAheadEl) tokenAheadEl.textContent = '0';
    if (tokenWaitEl) tokenWaitEl.textContent = '0m';
    if (tokenStatusBadge) {
      tokenStatusBadge.textContent = 'Idle';
      tokenStatusBadge.className = 'status-badge';
    }
    return;
  }

  if (tokenNumberEl) tokenNumberEl.textContent = activeToken.token;
  if (tokenCustomerEl) tokenCustomerEl.textContent = activeToken.name;
  if (tokenServiceEl) tokenServiceEl.textContent = activeToken.service;
  if (tokenPriorityEl) {
    tokenPriorityEl.innerHTML = getPriorityBadgeHtml(activeToken.priority) + ` <span style="font-size:0.7rem; color:var(--text-muted); margin-left:4px;">(${PRIORITY_CONFIG[activeToken.priority]?.desc || 'Standard'})</span>`;
  }

  // Calculate people ahead using FairQueue priority ordering
  let ahead = 0;
  let estimatedWait = 0;

  if (activeToken.status === 'waiting') {
    const waitingList = state.queue.filter(item => item.status === 'waiting');
    const fairOrderedList = getFairQueueOrder(waitingList);
    const myIndex = fairOrderedList.findIndex(item => item.id === activeToken.id);
    ahead = myIndex >= 0 ? myIndex : 0;
    
    // Sum duration of people ahead in priority queue based on validated service duration (1-120 mins)
    const avgDur = Math.min(120, Math.max(1, parseInt(state.configServiceDuration, 10) || 6));
    const activeDesks = Math.max(1, state.activeCounters || 1);
    const sumMins = (ahead + 1) * avgDur;
    estimatedWait = Math.max(1, Math.ceil(sumMins / activeDesks));
  } else if (activeToken.status === 'serving') {
    ahead = 0;
    estimatedWait = 0;
  } else {
    ahead = 0;
    estimatedWait = 0;
  }

  if (tokenAheadEl) tokenAheadEl.textContent = ahead.toString();
  if (tokenWaitEl) tokenWaitEl.textContent = activeToken.status === 'serving' ? 'Now' : `${estimatedWait}m`;

  if (tokenStatusBadge) {
    tokenStatusBadge.textContent = activeToken.status.toUpperCase();
    tokenStatusBadge.className = `status-badge ${activeToken.status}`;
  }

  // Trigger simulated in-app notification when customer's turn is approaching (#1 in line)
  if (activeToken.status === 'waiting' && ahead === 0) {
    addNotification({
      type: 'turn',
      title: `Turn Approaching: Token ${activeToken.token}`,
      desc: `${activeToken.name}, your turn is approaching! You are #1 in line. Prepare your documents.`,
      dedupeKey: `turn-approaching-${activeToken.id}`,
      targetToken: activeToken.token
    });
  }

  // Notify customer when their token changes to Serving or Completed
  if (activeToken.status === 'serving') {
    addNotification({
      type: 'serving',
      title: `Now Serving: Token ${activeToken.token}`,
      desc: `${activeToken.name}, please proceed to ${activeToken.counter || 'Counter 1'} now.`,
      dedupeKey: `serving-${activeToken.id}-${activeToken.counter || 'Counter 1'}`,
      targetToken: activeToken.token
    });
  } else if (activeToken.status === 'completed') {
    addNotification({
      type: 'completed',
      title: `Service Completed: Token ${activeToken.token}`,
      desc: `Service completed for Token ${activeToken.token} (${activeToken.name}).`,
      dedupeKey: `completed-${activeToken.id}`,
      targetToken: activeToken.token
    });
  }

  if (tokenBanner) {
    if (activeToken.status === 'serving') {
      tokenBanner.className = 'token-status-banner';
      tokenBanner.style.background = 'var(--primary-100)';
      tokenBanner.style.color = 'var(--primary-900)';
      tokenBanner.innerHTML = `🔔 <strong>It's your turn!</strong> Please proceed to <strong>${activeToken.counter || 'Counter 1'}</strong> immediately.`;
    } else if (activeToken.status === 'completed') {
      tokenBanner.className = 'token-status-banner';
      tokenBanner.style.background = 'var(--success-bg)';
      tokenBanner.style.color = 'var(--success-text)';
      tokenBanner.innerHTML = `✅ <strong>Service Completed!</strong> Thank you for banking with us.`;
    } else if (activeToken.status === 'skipped') {
      tokenBanner.className = 'token-status-banner';
      tokenBanner.style.background = 'var(--danger-bg)';
      tokenBanner.style.color = 'var(--danger-text)';
      tokenBanner.innerHTML = `⚠️ <strong>Token Skipped.</strong> Please contact reception to re-enter.`;
    } else {
      tokenBanner.className = 'token-status-banner';
      tokenBanner.style.background = 'var(--warning-bg)';
      tokenBanner.style.color = 'var(--warning-text)';
      tokenBanner.innerHTML = `⏱️ <strong>FairQueue Position:</strong> You are <strong>#${ahead + 1}</strong> in line to be served.`;
    }
  }
}

// Render Queue List Table
function renderQueueTable() {
  const tbody = document.getElementById('queue-table-body');
  if (!tbody) return;

  // Filter & Search
  let filtered = state.queue.filter(item => {
    if (state.currentFilter !== 'all' && item.status !== state.currentFilter) {
      return false;
    }
    if (state.searchQuery) {
      const q = state.searchQuery.toLowerCase();
      const matchToken = item.token.toLowerCase().includes(q);
      const matchName = item.name.toLowerCase().includes(q);
      const matchService = item.service.toLowerCase().includes(q);
      const matchPriority = (item.priority || '').toLowerCase().includes(q);
      if (!matchToken && !matchName && !matchService && !matchPriority) return false;
    }
    return true;
  });

  // Update Tab Badges Count
  const countAll = state.queue.length;
  const countWaiting = state.queue.filter(i => i.status === 'waiting').length;
  const countServing = state.queue.filter(i => i.status === 'serving').length;
  const countCompleted = state.queue.filter(i => i.status === 'completed').length;

  const tabCountAll = document.getElementById('count-tab-all');
  const tabCountWaiting = document.getElementById('count-tab-waiting');
  const tabCountServing = document.getElementById('count-tab-serving');
  const tabCountCompleted = document.getElementById('count-tab-completed');

  if (tabCountAll) tabCountAll.textContent = countAll;
  if (tabCountWaiting) tabCountWaiting.textContent = countWaiting;
  if (tabCountServing) tabCountServing.textContent = countServing;
  if (tabCountCompleted) tabCountCompleted.textContent = countCompleted;

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="empty-state">
          <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
          <p>No customers match the current filter or search criteria.</p>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filtered.map(item => {
    const isMyToken = item.id === state.myTokenId;
    const highlightRow = isMyToken ? 'style="background-color: #eff6ff;"' : '';
    const myTag = isMyToken ? '<span style="font-size:0.65rem; background:#2563eb; color:white; padding:1px 5px; border-radius:4px; margin-left:6px; font-weight:700;">YOU</span>' : '';

    return `
      <tr ${highlightRow}>
        <td class="token-cell">
          ${item.token}
          ${myTag}
        </td>
        <td class="customer-cell">
          <div>${escapeHtml(item.name)}</div>
          <div style="font-size: 0.7rem; color: var(--text-muted); font-weight:normal;">Joined: ${item.createdAt}</div>
        </td>
        <td>
          ${getPriorityBadgeHtml(item.priority)}
        </td>
        <td>
          <span class="service-badge">${escapeHtml(item.service)}</span>
        </td>
        <td>
          <span style="font-size:0.8rem; font-weight:600; color:var(--text-secondary);">
            ${item.counter ? item.counter : (item.status === 'waiting' ? '~' + (item.durationMins || 5) + 'm est.' : '--')}
          </span>
        </td>
        <td>
          <span class="status-badge ${item.status}">
            <span style="width:6px; height:6px; border-radius:50%; background:currentColor;"></span>
            ${item.status}
          </span>
        </td>
        <td style="text-align: right;">
          ${item.id !== state.myTokenId ? `
            <button class="btn-ghost-sm" onclick="trackToken('${item.id}')" title="Track in Token Display">
              Track
            </button>
          ` : `
            <span style="font-size:0.75rem; color:var(--primary-600); font-weight:700;">Tracking</span>
          `}
        </td>
      </tr>
    `;
  }).join('');
}

// Utility: Escape HTML
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>'"]/g, 
    tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
  );
}

// Action: Join Queue (Customer Action)
function joinQueue(customerName, serviceName, durationMins = 6, priority = null) {
  if (!customerName || customerName.trim() === '') {
    showToast('Please enter your name to join the queue.', 'warning');
    return null;
  }

  // Prevent duplicate tokens with collision guard
  let tokenNum = `A-${state.tokenSequence++}`;
  while (state.queue.some(item => item.token === tokenNum)) {
    tokenNum = `A-${state.tokenSequence++}`;
  }

  const assignedPriority = priority || state.selectedPriority || 'normal';
  const cfg = PRIORITY_CONFIG[assignedPriority] || PRIORITY_CONFIG.normal;

  const newCustomer = {
    id: `tok-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    token: tokenNum,
    name: customerName.trim(),
    service: serviceName || 'General Inquiry',
    serviceType: 'standard',
    priority: assignedPriority,
    durationMins: durationMins,
    status: 'waiting',
    counter: null,
    createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdTimeMs: Date.now(),
    completedAt: null
  };

  state.queue.push(newCustomer);
  state.myTokenId = newCustomer.id; // Switch active ticket to user's ticket

  // Simulated in-app notification for joining queue
  addNotification({
    type: 'wait',
    title: `Token ${tokenNum} Issued`,
    desc: `${newCustomer.name} joined queue for ${newCustomer.service} [${cfg.label}].`,
    dedupeKey: `token-joined-${newCustomer.id}`,
    targetToken: tokenNum
  });

  playChime();
  showToast(`Token ${tokenNum} generated (${cfg.label})! You have joined the queue.`, 'success');
  renderDashboard();

  // Scroll smoothly to token display on mobile if needed
  const tokenDisplay = document.getElementById('token-display-section');
  if (tokenDisplay && window.innerWidth < 800) {
    tokenDisplay.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return newCustomer;
}

// Action: Track another token
window.trackToken = function(id) {
  state.myTokenId = id;
  renderTokenDisplay();
  renderQueueTable();
  const found = state.queue.find(i => i.id === id);
  if (found) {
    showToast(`Now tracking Token ${found.token} (${found.name})`, 'info');
  }
};

// Action: Admin - Call Next Customer using FairQueue Priority System
function adminCallNext() {
  const waitingList = state.queue.filter(item => item.status === 'waiting');
  if (waitingList.length === 0) {
    showToast('Queue is empty. No customers currently waiting.', 'warning');
    return;
  }

  // If a customer is already currently serving at Counter 1, auto-complete them
  const currentServing = state.queue.find(item => item.status === 'serving');
  if (currentServing) {
    currentServing.status = 'completed';
    currentServing.completedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    addNotification({
      type: 'completed',
      title: `Service Completed: Token ${currentServing.token}`,
      desc: `Service completed for ${currentServing.name} at Counter 1.`,
      dedupeKey: `completed-${currentServing.id}`,
      targetToken: currentServing.token
    });
    showToast(`Token ${currentServing.token} auto-completed as next customer is called.`, 'info');
  }

  // Apply transparent FairQueue priority selection rules
  const fairOrderedList = getFairQueueOrder(waitingList);
  const nextCustomer = fairOrderedList[0];

  const custPriority = nextCustomer.priority || 'normal';
  const cfg = PRIORITY_CONFIG[custPriority] || PRIORITY_CONFIG.normal;

  // Determine why this customer was chosen over others
  const earlierLowerPriority = waitingList.filter(item => 
    item.id !== nextCustomer.id &&
    (item.createdTimeMs || 0) < (nextCustomer.createdTimeMs || 0) &&
    (PRIORITY_CONFIG[item.priority] || PRIORITY_CONFIG.normal).rank > cfg.rank
  );

  let rationale = '';
  if (custPriority === 'emergency') {
    if (earlierLowerPriority.length > 0) {
      rationale = `🚨 Emergency Tier (Rank 1): ${nextCustomer.name} (${nextCustomer.token}) expedited ahead of ${earlierLowerPriority.length} earlier customer(s) with lower priority per FairQueue emergency safety rules.`;
    } else {
      rationale = `🚨 Emergency Tier (Rank 1): ${nextCustomer.name} (${nextCustomer.token}) called on highest priority tier.`;
    }
  } else if (custPriority === 'elderly') {
    if (earlierLowerPriority.length > 0) {
      rationale = `♿ Accessibility Tier (Rank 2): ${nextCustomer.name} (${nextCustomer.token}) prioritized before ${earlierLowerPriority.length} earlier Normal customer(s) per FairQueue accessibility guidelines.`;
    } else {
      rationale = `♿ Accessibility Tier (Rank 2): ${nextCustomer.name} (${nextCustomer.token}) called in Elderly/Accessible tier (FIFO order).`;
    }
  } else {
    rationale = `👤 Standard FIFO Tier (Rank 3): ${nextCustomer.name} (${nextCustomer.token}) called as the earliest waiting arrival in the Normal queue.`;
  }

  state.lastCallReason = rationale;
  nextCustomer.status = 'serving';
  nextCustomer.counter = 'Counter 1';

  // Add Serving notification
  addNotification({
    type: 'serving',
    title: `Now Serving: Token ${nextCustomer.token}`,
    desc: `${nextCustomer.name} called to Counter 1 (${cfg.label}).`,
    dedupeKey: `serving-${nextCustomer.id}-Counter 1`,
    targetToken: nextCustomer.token
  });

  playChime();
  showToast(`Called Token ${nextCustomer.token} (${nextCustomer.name}) [${cfg.label}] to Counter 1!`, 'success');
  renderDashboard();
}

// Action: Admin - Complete Service
function adminCompleteService() {
  const currentServing = state.queue.find(item => item.status === 'serving');
  if (!currentServing) {
    showToast('No customer is currently being served to complete.', 'warning');
    return;
  }

  currentServing.status = 'completed';
  currentServing.completedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  state.lastCallReason = `Service successfully finished for Token ${currentServing.token} (${currentServing.name}). Ready for next call.`;

  // Add Completed notification
  addNotification({
    type: 'completed',
    title: `Service Completed: Token ${currentServing.token}`,
    desc: `Service for ${currentServing.name} finished at ${currentServing.counter || 'Counter 1'}.`,
    dedupeKey: `completed-${currentServing.id}`,
    targetToken: currentServing.token
  });

  playChime();
  showToast(`Service for Token ${currentServing.token} (${currentServing.name}) successfully completed!`, 'success');
  renderDashboard();
}

// Action: Admin - Skip Customer
function adminSkipCustomer() {
  const currentServing = state.queue.find(item => item.status === 'serving');
  if (!currentServing) {
    showToast('No customer currently being served to skip.', 'warning');
    return;
  }

  currentServing.status = 'skipped';
  state.lastCallReason = `Token ${currentServing.token} (${currentServing.name}) was skipped (not present at counter). Ready for next call.`;
  
  // Add Skipped notification
  addNotification({
    type: 'wait',
    title: `Token Skipped: Token ${currentServing.token}`,
    desc: `${currentServing.name} marked as skipped (not present at counter).`,
    dedupeKey: `skipped-${currentServing.id}`,
    targetToken: currentServing.token
  });

  showToast(`Token ${currentServing.token} (${currentServing.name}) marked as skipped.`, 'warning');
  renderDashboard();
}

// Action: Toggle Counter 2 (QueuePulse Smart Load Balancer Action)
function toggleCounter2() {
  if (state.activeCounters === 1) {
    state.activeCounters = 2;
    addNotification({
      type: 'counter',
      title: 'Counter 2 Activated',
      desc: '⚡ Counter 2 is now open. Processing capacity scaled 100%, projected wait times halved.',
      dedupeKey: `counter-opened-${Date.now()}`
    });
    showToast('⚡ Counter 2 activated! Processing capacity scaled by 100%. Projected wait times halved.', 'success');
  } else {
    state.activeCounters = 1;
    addNotification({
      type: 'counter',
      title: 'Counter 2 on Standby',
      desc: 'Counter 2 closed. Queue throughput returned to single desk operation.',
      dedupeKey: `counter-closed-${Date.now()}`
    });
    showToast('Counter 2 closed (Standby). Queue processing recalibrated to single desk.', 'info');
  }
  playChime();
  renderDashboard();
}

// Reset Demo Data
function resetDemoData() {
  state.queue = JSON.parse(JSON.stringify(INITIAL_QUEUE_DATA));
  state.tokenSequence = 105;
  state.activeCounters = 1;
  state.configServiceDuration = 6;
  state.selectedPriority = 'normal';
  state.lastCallReason = 'Initial demo state: Counter 1 serving David Miller (Normal Priority).';
  state.currentFilter = 'all';
  state.searchQuery = '';
  state.myTokenId = 'tok-101';
  
  // Reset Smart Customer Notifications
  state.notifications = JSON.parse(JSON.stringify(INITIAL_NOTIFICATIONS));
  state.notifHistoryHashes = {
    'turn-approaching-tok-101': true,
    'serving-tok-100-Counter 1': true,
    'counter-init-1': true
  };
  state.lastCrowdLevel = 'Moderate';
  
  const configDurationInput = document.getElementById('config-service-duration');
  if (configDurationInput) {
    configDurationInput.value = '6';
  }
  const configPresetsSelect = document.getElementById('config-service-presets');
  if (configPresetsSelect) {
    configPresetsSelect.value = '6';
  }

  // Reset Priority chips in Check-In UI
  const priorityChips = document.querySelectorAll('.priority-chip');
  priorityChips.forEach(c => {
    const isNormal = c.getAttribute('data-priority') === 'normal';
    c.classList.toggle('active', isNormal);
    c.setAttribute('aria-checked', isNormal ? 'true' : 'false');
  });

  showToast('Demo data & FairQueue reset to baseline scenario.', 'info');
  renderDashboard();
}

// Quick Sample Customer Generators for Judges
const SAMPLE_NAMES = [
  'Aarav Patel', 'Emily Watson', 'Marcus Vance', 'Priya Nair', 
  'Carlos Santana', 'Zackary King', 'Aisha Khan', 'Liam O\'Connor'
];

function addQuickCustomer() {
  const randomName = SAMPLE_NAMES[Math.floor(Math.random() * SAMPLE_NAMES.length)];
  const services = [
    { name: 'Cash Deposit & Withdrawal', duration: 4 },
    { name: 'Account Opening & KYC', duration: 10 },
    { name: 'Loan & Mortgage Advisory', duration: 15 },
    { name: 'Digital Banking & Support', duration: 6 }
  ];
  const priorities = ['normal', 'normal', 'elderly', 'emergency']; // Sample realistic spread
  const randService = services[Math.floor(Math.random() * services.length)];
  const randPriority = priorities[Math.floor(Math.random() * priorities.length)];
  
  joinQueue(randomName, randService.name, randService.duration, randPriority);
}

// Event Listeners Initialization
document.addEventListener('DOMContentLoaded', () => {
  // 1. Join Queue Form
  const joinForm = document.getElementById('join-queue-form');
  const nameInput = document.getElementById('customer-name-input');
  let selectedService = 'Account Opening & KYC';
  let selectedDuration = 10;

  // Service chip selector
  const serviceChips = document.querySelectorAll('.service-chip');
  serviceChips.forEach(chip => {
    chip.addEventListener('click', () => {
      serviceChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      selectedService = chip.getAttribute('data-service') || 'General Banking';
      selectedDuration = parseInt(chip.getAttribute('data-duration') || '8', 10);
    });
  });

  // FairQueue Priority Chip selector
  const priorityChips = document.querySelectorAll('.priority-chip');
  priorityChips.forEach(chip => {
    chip.addEventListener('click', () => {
      priorityChips.forEach(c => {
        c.classList.remove('active');
        c.setAttribute('aria-checked', 'false');
      });
      chip.classList.add('active');
      chip.setAttribute('aria-checked', 'true');
      state.selectedPriority = chip.getAttribute('data-priority') || 'normal';
    });
  });

  if (joinForm) {
    joinForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = nameInput.value.trim();
      if (!name) {
        showToast('Please type your customer name.', 'warning');
        nameInput.focus();
        return;
      }
      joinQueue(name, selectedService, selectedDuration, state.selectedPriority);
      nameInput.value = '';
    });
  }

  // Quick prefill buttons for customer name
  const quickFills = document.querySelectorAll('.btn-quick-fill');
  quickFills.forEach(btn => {
    btn.addEventListener('click', () => {
      if (nameInput) {
        nameInput.value = btn.getAttribute('data-name');
        nameInput.focus();
      }
    });
  });

  // 2. QueuePulse Configurable Service Duration (Numeric input with immediate recalculation & validation)
  const configDurationInput = document.getElementById('config-service-duration');
  const configPresetsSelect = document.getElementById('config-service-presets');

  function applyServiceDurationChange(val, showNotificationToast = false) {
    let parsed = parseInt(val, 10);
    if (isNaN(parsed) || parsed < 1) {
      parsed = 1;
    } else if (parsed > 120) {
      parsed = 120;
    }
    parsed = Math.round(parsed);
    state.configServiceDuration = parsed;

    // Keep input field aligned
    if (configDurationInput && configDurationInput.value !== parsed.toString()) {
      configDurationInput.value = parsed.toString();
    }

    // Keep preset dropdown aligned if matching
    if (configPresetsSelect) {
      const match = Array.from(configPresetsSelect.options).find(opt => opt.value === parsed.toString());
      configPresetsSelect.value = match ? parsed.toString() : '';
    }

    // Immediately recalculate and render entire dashboard
    renderDashboard();

    if (showNotificationToast) {
      showToast(`Avg service duration updated to ${parsed} mins. Queue load recalculated.`, 'info');
    }
  }

  if (configDurationInput) {
    configDurationInput.value = (state.configServiceDuration || 6).toString();

    // Recalculate immediately on every input keystroke or arrow step
    configDurationInput.addEventListener('input', (e) => {
      const raw = e.target.value.trim();
      if (raw === '') return; // Allow user to clear to type new number without crashing
      let num = parseInt(raw, 10);
      if (isNaN(num)) return;
      if (num < 1) num = 1;
      if (num > 120) num = 120;
      state.configServiceDuration = Math.round(num);
      renderDashboard();
    });

    // On change, sanitize and enforce strict 1 to 120 bounds
    configDurationInput.addEventListener('change', (e) => {
      applyServiceDurationChange(e.target.value, true);
    });

    // On blur, reset if empty or invalid
    configDurationInput.addEventListener('blur', (e) => {
      if (e.target.value.trim() === '' || isNaN(parseInt(e.target.value, 10))) {
        applyServiceDurationChange(state.configServiceDuration || 6, false);
      }
    });
  }

  // Quick benchmark presets dropdown handler
  if (configPresetsSelect) {
    configPresetsSelect.addEventListener('change', (e) => {
      const selected = parseInt(e.target.value, 10);
      if (!isNaN(selected) && selected >= 1 && selected <= 120) {
        applyServiceDurationChange(selected, true);
      }
    });
  }

  // 3. Admin Action Buttons
  const btnCallNext = document.getElementById('btn-call-next');
  const btnComplete = document.getElementById('btn-complete-service');
  const btnSkip = document.getElementById('btn-skip-customer');
  const aiActionBtn = document.getElementById('ai-action-btn');

  if (btnCallNext) btnCallNext.addEventListener('click', adminCallNext);
  if (btnComplete) btnComplete.addEventListener('click', adminCompleteService);
  if (btnSkip) btnSkip.addEventListener('click', adminSkipCustomer);
  if (aiActionBtn) aiActionBtn.addEventListener('click', toggleCounter2);

  // 4. Queue List Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentFilter = btn.getAttribute('data-filter') || 'all';
      renderQueueTable();
    });
  });

  // 5. Search Filter
  const searchInput = document.getElementById('queue-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value.trim();
      renderQueueTable();
    });
  }

  // 6. Header / Demo Buttons
  const resetBtn = document.getElementById('btn-reset-demo');
  if (resetBtn) resetBtn.addEventListener('click', resetDemoData);

  const addDemoBtn = document.getElementById('btn-add-demo-customer');
  if (addDemoBtn) addDemoBtn.addEventListener('click', addQuickCustomer);

  const soundToggleBtn = document.getElementById('btn-toggle-sound');
  if (soundToggleBtn) {
    soundToggleBtn.addEventListener('click', () => {
      state.soundEnabled = !state.soundEnabled;
      soundToggleBtn.innerHTML = state.soundEnabled 
        ? `<svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg> Sound On`
        : `<svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/></svg> Sound Muted`;
      showToast(state.soundEnabled ? 'Chime sound enabled' : 'Chime sound muted', 'info');
    });
  }

  // 7. Smart Customer Notification Center Event Listeners
  const bellBtn = document.getElementById('btn-notification-bell');
  const notifDropdown = document.getElementById('notification-dropdown');
  const btnNotifClear = document.getElementById('btn-notif-clear');
  const btnNotifMarkRead = document.getElementById('btn-notif-mark-read');
  const notifListEl = document.getElementById('notification-list');

  // Bell click: toggle notification panel
  if (bellBtn && notifDropdown) {
    bellBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = notifDropdown.classList.toggle('show');
      bellBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // Click outside to dismiss notification panel
  document.addEventListener('click', (e) => {
    const bellWrapper = document.querySelector('.notification-bell-wrapper');
    if (notifDropdown && bellWrapper && !bellWrapper.contains(e.target)) {
      notifDropdown.classList.remove('show');
      if (bellBtn) bellBtn.setAttribute('aria-expanded', 'false');
    }
  });

  // Stop clicks inside dropdown from bubbling up and closing panel
  if (notifDropdown) {
    notifDropdown.addEventListener('click', (e) => {
      e.stopPropagation();
    });
  }

  // Clear all notifications
  if (btnNotifClear) {
    btnNotifClear.addEventListener('click', () => {
      state.notifications = [];
      renderNotifications();
      showToast('All notifications cleared.', 'info');
    });
  }

  // Mark all notifications as read
  if (btnNotifMarkRead) {
    btnNotifMarkRead.addEventListener('click', () => {
      state.notifications.forEach(n => { n.unread = false; });
      renderNotifications();
      showToast('All alerts marked as read.', 'info');
    });
  }

  // Notification item click: mark individual alert read and focus token
  if (notifListEl) {
    notifListEl.addEventListener('click', (e) => {
      const itemEl = e.target.closest('.notif-item');
      if (!itemEl) return;
      const notifId = itemEl.getAttribute('data-id');
      const foundNotif = state.notifications.find(n => n.id === notifId);
      if (foundNotif) {
        foundNotif.unread = false;
        renderNotifications();
        if (foundNotif.targetToken) {
          const matchedToken = state.queue.find(q => q.token === foundNotif.targetToken);
          if (matchedToken) {
            state.myTokenId = matchedToken.id;
            renderTokenDisplay();
            renderQueueTable();
          }
        }
      }
    });
  }

  // Initial render
  renderDashboard();
});
