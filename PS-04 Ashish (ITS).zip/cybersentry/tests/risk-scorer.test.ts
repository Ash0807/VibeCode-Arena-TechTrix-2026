import { describe, it, expect } from 'vitest';
import { calculateRiskAssessment } from '../server/services/risk-scorer.js';
import type { Finding } from '../shared/types.js';

describe('Risk Scorer Service', () => {
  it('correctly scores empty findings as low risk and 0 score', () => {
    const assessment = calculateRiskAssessment('url', 'https://example.com', []);
    expect(assessment.riskScore).toBe(0);
    expect(assessment.riskLevel).toBe('low');
    expect(assessment.findings).toHaveLength(0);
    expect(assessment.recommendations.length).toBeGreaterThan(0);
    expect(assessment.limitations.length).toBeGreaterThan(0);
  });

  it('correctly calculates high risk when multiple severe indicators are present', () => {
    const rawFindings: Finding[] = [
      {
        id: '1',
        title: 'Brand Spoofing',
        description: 'Impersonating PayPal',
        severity: 'high',
        category: 'Brand Spoofing',
        whyItMatters: 'Deceives victims into revealing banking logins.',
      },
      {
        id: '2',
        title: 'Direct IP Hostname',
        description: 'Uses raw IP address',
        severity: 'high',
        category: 'Evasion',
        whyItMatters: 'Commonly bypasses domain filters.',
      },
    ];

    const assessment = calculateRiskAssessment('url', 'http://192.168.1.1/paypal', rawFindings);
    expect(assessment.riskScore).toBeGreaterThanOrEqual(60);
    expect(assessment.riskLevel).toBe('high');
    expect(assessment.summary).toContain('High risk detected');
  });

  it('deduplicates findings with the same title', () => {
    const duplicateFindings: Finding[] = [
      {
        id: '1',
        title: 'Repeated Indicator',
        description: 'First occurrence',
        severity: 'medium',
        category: 'Test',
        whyItMatters: 'Testing deduplication',
      },
      {
        id: '2',
        title: 'Repeated Indicator',
        description: 'Second occurrence',
        severity: 'medium',
        category: 'Test',
        whyItMatters: 'Testing deduplication',
      },
    ];

    const assessment = calculateRiskAssessment('sms', 'Sample', duplicateFindings);
    expect(assessment.findings).toHaveLength(1);
    expect(assessment.riskScore).toBe(25);
  });
});
