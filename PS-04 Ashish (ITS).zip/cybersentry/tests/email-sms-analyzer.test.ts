import { describe, it, expect } from 'vitest';
import { analyzeEmail } from '../server/services/email-analyzer.js';
import { analyzeSms } from '../server/services/sms-analyzer.js';

describe('Email & SMS Threat Analyzers', () => {
  it('detects urgent pressure tactics and OTP solicitation in email', () => {
    const text = 'Urgent Notice: Your corporate account will be closed within 24 hours. Please reply with your verification code and OTP immediately.';
    const result = analyzeEmail(text);
    expect(result.riskLevel).toBe('high');
    expect(result.findings.some(f => f.title.includes('Urgency'))).toBe(true);
    expect(result.findings.some(f => f.title.includes('Credential'))).toBe(true);
  });

  it('detects institution spoofing when sender uses free webmail', () => {
    const text = 'Dear user, please update your billing details.';
    const result = analyzeEmail(text, 'security.paypal.support@gmail.com');
    expect(result.findings.some(f => f.title.includes('Free Webmail'))).toBe(true);
  });

  it('detects fake banking alerts and UPI reverse-charge patterns in SMS', () => {
    const sms = 'Dear Customer, your SBI account blocked today. Complete KYC update: http://sbi-unblock.xyz. Also scan QR to receive cash prize of Rs 5000.';
    const result = analyzeSms(sms);
    expect(result.riskLevel).toBe('high');
    expect(result.findings.some(f => f.title.includes('Banking Alert'))).toBe(true);
    expect(result.findings.some(f => f.title.includes('UPI Fraud'))).toBe(true);
  });

  it('detects utility electricity cut-off scam in SMS', () => {
    const sms = 'Dear consumer your electricity power will be disconnected tonight at 9:30 PM due to unpaid electricity bill. Contact officer immediately.';
    const result = analyzeSms(sms);
    expect(result.findings.some(f => f.title.includes('Electricity'))).toBe(true);
    expect(result.riskScore).toBeGreaterThanOrEqual(35);
  });
});
