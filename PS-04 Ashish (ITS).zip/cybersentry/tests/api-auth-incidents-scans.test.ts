import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app } from '../server/index.js';
import { db, initDatabase, hashPassword } from '../server/db/database.js';
import { UserRepo } from '../server/db/repository.js';

describe('CyberSentry REST API Endpoints', () => {
  let userCookie: string;
  let adminCookie: string;
  let createdScanId: string;
  let createdReportId: string;
  let createdIncidentId: string;

  beforeAll(() => {
    initDatabase();
    const admin = UserRepo.findByEmail('admin@cybersentry.local');
    if (admin) {
      db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hashPassword('CyberSentry#Admin2026!'), admin.id);
    }
  });

  it('GET /api/health returns system status', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('healthy');
    expect(res.body.name).toBe('CyberSentry API');
  });

  it('POST /api/auth/register creates a new user account and sets session cookie', async () => {
    const uniqueEmail = `test_${Date.now()}@safety.test`;
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        email: uniqueEmail,
        password: 'SecurePassword123!',
        name: 'Test Analyst',
      });

    expect(res.status).toBe(201);
    expect(res.body.user).toBeDefined();
    expect(res.body.user.email).toBe(uniqueEmail);

    const cookies = res.headers['set-cookie'];
    expect(cookies).toBeDefined();
    userCookie = cookies[0];
  });

  it('POST /api/auth/login logs in admin and sets admin session cookie', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'admin@cybersentry.local',
        password: 'CyberSentry#Admin2026!',
      });

    expect(res.status).toBe(200);
    expect(res.body.user.role).toBe('admin');
    const cookies = res.headers['set-cookie'];
    adminCookie = cookies[0];
  });

  it('POST /api/analyze/url validates and returns structured analysis', async () => {
    const res = await request(app)
      .post('/api/analyze/url')
      .set('Cookie', userCookie)
      .send({
        url: 'http://paypal-verification-update.xyz/login',
      });

    expect(res.status).toBe(200);
    expect(res.body.scanId).toBeDefined();
    expect(res.body.riskLevel).toBe('high');
    expect(res.body.findings.length).toBeGreaterThan(0);
    expect(res.body.recommendations.length).toBeGreaterThan(0);
    expect(res.body.limitations.length).toBeGreaterThan(0);
    createdScanId = res.body.scanId;
  });

  it('POST /api/analyze/text analyzes SMS content with UPI warning', async () => {
    const res = await request(app)
      .post('/api/analyze/text')
      .send({
        type: 'sms',
        content: 'Scan QR and enter your UPI PIN to claim ₹2,000 reward now!',
      });

    expect(res.status).toBe(200);
    expect(res.body.riskLevel).toBe('high');
    expect(res.body.findings.some((f: any) => f.title.includes('UPI'))).toBe(true);
  });

  it('POST /api/analyze/url rejects empty input with 400', async () => {
    const res = await request(app)
      .post('/api/analyze/url')
      .send({ url: '' });

    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });

  it('GET /api/scans lists user scan history', async () => {
    const res = await request(app)
      .get('/api/scans')
      .set('Cookie', userCookie);

    expect(res.status).toBe(200);
    expect(res.body.items).toBeDefined();
    expect(res.body.items.length).toBeGreaterThanOrEqual(1);
  });

  it('POST /api/incidents creates an incident report and returns unique Report ID', async () => {
    const res = await request(app)
      .post('/api/incidents')
      .set('Cookie', userCookie)
      .field('category', 'upi_fraud')
      .field('description', 'Fraudulent QR code sent via WhatsApp asking for UPI PIN to claim reward.')
      .field('suspiciousUrl', 'http://fake-upi-cash.xyz')
      .field('consentGiven', 'true');

    expect(res.status).toBe(201);
    expect(res.body.reportId).toMatch(/^CS-2026-\d{4}$/);
    expect(res.body.incident.status).toBe('Submitted');
    createdReportId = res.body.reportId;
    createdIncidentId = res.body.incident.id;
  });

  it('GET /api/incidents/track/:reportId tracks report status without auth', async () => {
    const res = await request(app).get(`/api/incidents/track/${createdReportId}`);
    expect(res.status).toBe(200);
    expect(res.body.reportId).toBe(createdReportId);
    expect(res.body.status).toBe('Submitted');
    expect(res.body.history).toBeDefined();
    expect(res.body.history.length).toBeGreaterThanOrEqual(1);
  });

  it('PATCH /api/incidents/:id/status rejects regular user with 403', async () => {
    const res = await request(app)
      .patch(`/api/incidents/${createdIncidentId}/status`)
      .set('Cookie', userCookie)
      .send({ status: 'Under Review' });

    expect(res.status).toBe(403);
  });

  it('PATCH /api/incidents/:id/status allows administrator to update status and record history', async () => {
    const res = await request(app)
      .patch(`/api/incidents/${createdIncidentId}/status`)
      .set('Cookie', adminCookie)
      .send({
        status: 'Under Review',
        notes: 'Case assigned to security analyst for review.',
      });

    expect(res.status).toBe(200);
    expect(res.body.incident.status).toBe('Under Review');
    expect(res.body.history.some((h: any) => h.newStatus === 'Under Review')).toBe(true);
  });

  it('DELETE /api/scans/:id deletes scan record', async () => {
    const res = await request(app)
      .delete(`/api/scans/${createdScanId}`)
      .set('Cookie', userCookie);

    expect(res.status).toBe(200);
  });

  it('GET /api/academy/lessons returns 12 cybersecurity lessons', async () => {
    const res = await request(app).get('/api/academy/lessons');
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(12);
  });

  it('GET /api/academy/quiz returns at least 15 questions', async () => {
    const res = await request(app).get('/api/academy/quiz');
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(15);
  });
});
