import { describe, it, expect } from 'vitest';
import { analyzeUrl } from '../server/services/url-analyzer.js';

describe('URL Threat Analyzer', () => {
  it('detects direct IP address hostnames', () => {
    const result = analyzeUrl('http://192.168.1.100/login');
    expect(result.findings.some(f => f.title.includes('Direct IP Address'))).toBe(true);
    expect(result.riskScore).toBeGreaterThanOrEqual(35);
  });

  it('detects embedded userinfo spoofing attempts', () => {
    const result = analyzeUrl('https://google.com@phishing-gateway.com/auth');
    expect(result.findings.some(f => f.title.includes('Embedded User Information'))).toBe(true);
    expect(result.riskLevel).toBe('high');
  });

  it('detects known URL shorteners without executing or visiting', () => {
    const result = analyzeUrl('https://bit.ly/3xYqz7');
    expect(result.findings.some(f => f.title.includes('Known URL Shortening Service'))).toBe(true);
    expect(result.recommendations.some(r => r.title.includes('Unfurl'))).toBe(true);
  });

  it('flags high-risk TLDs and typosquatting for known brands', () => {
    const result = analyzeUrl('http://sbi-kyc-verify-login.xyz/portal');
    expect(result.findings.some(f => f.title.includes('High-Risk Top-Level Domain'))).toBe(true);
    expect(result.findings.some(f => f.title.includes('Brand Impersonation'))).toBe(true);
    expect(result.riskLevel).toBe('high');
  });

  it('handles legitimate domains gracefully without false alarm', () => {
    const result = analyzeUrl('https://google.com');
    expect(result.riskLevel).toBe('low');
    expect(result.findings.filter(f => f.severity === 'high')).toHaveLength(0);
  });

  it('detects internationalized punycode domains', () => {
    const result = analyzeUrl('https://xn--pple-43d.com/login');
    expect(result.findings.some(f => f.title.includes('Punycode'))).toBe(true);
  });
});
