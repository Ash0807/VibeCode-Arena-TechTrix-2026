/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        sentry: {
          bg: '#07111F',
          surface: '#101E30',
          card: '#13233A',
          border: '#1D3352',
          borderLight: '#2A466E',
          primary: '#39D9E8',
          secondary: '#8B7CFF',
          text: '#EDF5FF',
          muted: '#9AABC2',
          riskHigh: '#FB7185',
          riskMedium: '#FBBF24',
          riskLow: '#34D399',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      boxShadow: {
        'glow-primary': '0 0 20px -5px rgba(57, 217, 232, 0.3)',
        'glow-secondary': '0 0 20px -5px rgba(139, 124, 255, 0.3)',
      },
    },
  },
  plugins: [],
}
