import fs from 'node:fs';
import path from 'node:path';
import { createWorker } from 'tesseract.js';
import type { ScanResult } from '../../shared/types.js';
import { analyzeEmail } from './email-analyzer.js';
import { analyzeSms } from './sms-analyzer.js';
import { analyzeUrl } from './url-analyzer.js';

export async function processScreenshot(
  filePath: string,
  userId?: string | null
): Promise<ScanResult> {
  let extractedText = '';
  let ocrError: string | null = null;
  let worker: any = null;

  try {
    // Perform OCR via tesseract.js worker
    worker = await createWorker('eng');
    const { data } = await worker.recognize(filePath);
    extractedText = (data?.text || '').trim();
  } catch (err: any) {
    ocrError = err?.message || 'Failed to extract text from screenshot';
    console.warn('[OCR Service] Error extracting text from image:', ocrError);
  } finally {
    if (worker) {
      try {
        await worker.terminate();
      } catch (e) {
        // ignore cleanup error
      }
    }

    // Always securely delete uploaded temporary image
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (e) {
      console.warn('[OCR Service] Temporary file cleanup warning:', e);
    }
  }

  // Graceful fallback if OCR yielded empty text or encountered an error
  if (!extractedText || extractedText.length < 5) {
    return {
      scanId: crypto.randomUUID(),
      userId: userId || null,
      inputType: 'screenshot',
      riskLevel: 'medium',
      riskScore: 30,
      summary: 'Screenshot was processed, but little to no readable text was recognized by the OCR engine.',
      inputPreview: '[Image uploaded - Insufficient readable text detected]',
      findings: [
        {
          id: crypto.randomUUID(),
          title: 'Low Text Clarity or Empty Screenshot',
          description: ocrError
            ? `OCR processing encountered an issue: ${ocrError}. The image may be corrupted, blurred, or heavily compressed.`
            : 'The optical character recognition (OCR) engine could not identify clear alphanumeric text in the uploaded screenshot.',
          severity: 'medium',
          category: 'OCR Processing',
          whyItMatters: 'Screenshots with high compression, stylized handwritten fonts, or low contrast can hinder automated character detection.',
        },
      ],
      recommendations: [
        {
          id: crypto.randomUUID(),
          title: 'Paste Text Directly or Crop Image',
          action: 'Try cropping closer to the suspicious message text or paste the message directly into the Email or SMS scanner tabs.',
          priority: 'immediate',
        },
      ],
      limitations: [
        'OCR accuracy depends on image resolution, font legibility, and contrast.',
        'No external cloud OCR service was used to ensure your image stayed private on this machine.',
      ],
      method: 'rule_heuristics',
      analyzedAt: new Date().toISOString(),
      extractedText: extractedText || '(No text extracted)',
    };
  }

  // Determine whether the extracted text is a URL, Email, or SMS
  const textLower = extractedText.toLowerCase();
  let baseScan: ScanResult;

  if (textLower.startsWith('http://') || textLower.startsWith('https://') || textLower.startsWith('www.')) {
    baseScan = analyzeUrl(extractedText, userId);
  } else if (textLower.includes('subject:') || textLower.includes('from:') || extractedText.length > 250) {
    baseScan = analyzeEmail(extractedText, undefined, userId);
  } else {
    baseScan = analyzeSms(extractedText, userId);
  }

  // Format as screenshot input type
  return {
    ...baseScan,
    inputType: 'screenshot',
    extractedText,
    inputPreview: `[Screenshot Text]: ${extractedText.slice(0, 150)}${extractedText.length > 150 ? '...' : ''}`,
    limitations: [
      ...baseScan.limitations,
      'Extracted via local optical character recognition (Tesseract). Unclear letters or emojis in the image might alter words.',
    ],
  };
}
