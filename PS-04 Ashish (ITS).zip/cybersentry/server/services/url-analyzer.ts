import type { Finding, Recommendation, ScanResult } from '../../shared/types.js';
import { calculateRiskAssessment } from './risk-scorer.js';
import crypto from 'node:crypto';

const KNOWN_SHORTENERS = new Set([
  'bit.ly',
  'tinyurl.com',
  't.co',
  'cutt.ly',
  'is.gd',
  'rb.gy',
  'ow.ly',
  'rebrand.ly',
  'soo.gd',
  'shorturl.at',
  'v.gd',
]);

const HIGH_RISK_TLDS = new Set([
  '.xyz',
  '.top',
  '.tk',
  '.ml',
  '.ga',
  '.cf',
  '.gq',
  '.cc',
  '.click',
  '.buzz',
  '.club',
  '.work',
  '.icu',
  '.cam',
  '.monster',
  '.live',
  '.rest',
  '.fit',
  '.online',
  '.site',
]);

const TARGETED_BRANDS = [
  { name: 'PayPal', patterns: ['paypal', 'pay-pal', 'paypa1'] },
  { name: 'State Bank of India (SBI)', patterns: ['onlinesbi', 'sbi-bank', 'sbi-kyc', 'sbiyono', 'yonosbi'] },
  { name: 'HDFC Bank', patterns: ['hdfcbank', 'hdfc-net', 'hdfc-kyc', 'hdfc-secure'] },
  { name: 'ICICI Bank', patterns: ['icicibank', 'icici-direct', 'icici-login'] },
  { name: 'India Post', patterns: ['indiapost', 'india-post', 'speedpost-track', 'dak-sewa'] },
  { name: 'Income Tax India', patterns: ['incometax', 'incometaxindia', 'tax-refund', 'it-refund'] },
  { name: 'Google / Gmail', patterns: ['google-account', 'gmail-security', 'accounts-google'] },
  { name: 'Microsoft / Office 365', patterns: ['microsoft-online', 'office365-verify', 'login-live'] },
  { name: 'Apple / iCloud', patterns: ['apple-id', 'icloud-find', 'appleid-login'] },
  { name: 'Netflix', patterns: ['netflix-update', 'netflix-billing', 'netflx'] },
  { name: 'Amazon', patterns: ['amazon-security', 'amazon-pay', 'amazon-order'] },
  { name: 'WhatsApp', patterns: ['whatsapp-web', 'chat-whatsapp', 'whatsapp-gold'] },
  { name: 'UIDAI / Aadhaar', patterns: ['eaadhaar', 'uidai-verify', 'aadhaar-kyc'] },
];

export function analyzeUrl(rawInput: string, userId?: string | null): ScanResult {
  const scanId = crypto.randomUUID();
  const input = rawInput.trim();
  const findings: Finding[] = [];
  const specificRecommendations: Recommendation[] = [];
  const limitations = [
    'Destination server was not queried over the network; offline structural and threat heuristic inspection only.',
    'URL shorteners conceal their true destination; shortener presence increases risk score but is not proof of fraud.',
  ];

  // 1. Basic URL syntax check
  let parsedUrl: URL | null = null;
  let normalizedInput = input;
  if (!/^https?:\/\//i.test(normalizedInput)) {
    // If user forgot protocol, test with http://
    normalizedInput = 'http://' + normalizedInput;
  }

  try {
    parsedUrl = new URL(normalizedInput);
  } catch (err) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Malformed or Invalid URL Structure',
      description: 'The submitted string does not conform to RFC 3986 URL standards.',
      severity: 'medium',
      category: 'Syntax',
      matchedSample: input,
      whyItMatters: 'Attackers sometimes exploit malformed or non-standard URLs to cause parsing discrepancies between security filters and web browsers.',
    });
  }

  if (parsedUrl) {
    const hostname = parsedUrl.hostname.toLowerCase();
    const pathname = parsedUrl.pathname;
    const search = parsedUrl.search;
    const protocol = parsedUrl.protocol.toLowerCase();

    // 2. Check Protocol (HTTP vs HTTPS)
    if (protocol === 'http:') {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Unencrypted HTTP Connection',
        description: 'The destination specifies standard HTTP rather than modern encrypted HTTPS.',
        severity: 'low',
        category: 'Encryption',
        matchedSample: protocol,
        whyItMatters: 'Unencrypted connections expose credentials and data to man-in-the-middle eavesdropping. Note: HTTP is not definitive proof of a scam, but modern legitimate services mandate HTTPS.',
      });
    }

    // 3. Userinfo in URL (e.g., http://google.com@phishing.com)
    if (parsedUrl.username || parsedUrl.password) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Embedded User Information in URL',
        description: `The URL contains userinfo credentials (@ symbol in authority): "${parsedUrl.username}".`,
        severity: 'high',
        category: 'URL Spoofing',
        matchedSample: `${parsedUrl.username}@${hostname}`,
        whyItMatters: 'Attackers frequently place a trusted brand before an "@" symbol (e.g. https://google.com@evil-site.com) to deceive users who only glance at the start of the URL.',
      });
    }

    // 4. IP address hostname check
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6Regex = /^\[?[a-f0-9:]+\]?$/i;
    if (ipv4Regex.test(hostname) || ipv6Regex.test(hostname)) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Direct IP Address Used as Hostname',
        description: `The URL targets raw numerical IP "${hostname}" instead of a registered domain name.`,
        severity: 'high',
        category: 'Hostname Evasion',
        matchedSample: hostname,
        whyItMatters: 'Legitimate consumer and corporate web services use registered domain names. IP addresses are commonly used by attackers to bypass domain reputation blocklists and avoid domain registration records.',
      });
    }

    // 5. Punycode & Homoglyph detection
    if (hostname.includes('xn--')) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Internationalized / Punycode Domain Name',
        description: `Domain contains an encoded punycode prefix ("${hostname}").`,
        severity: 'high',
        category: 'Homoglyph / Punycode',
        matchedSample: hostname,
        whyItMatters: 'Punycode domains (xn--) can render lookalike Cyrillic or Greek characters that look visually identical to Latin characters (e.g., replacing "a" with Cyrillic "а"), tricking users into thinking they are visiting a genuine brand.',
      });
    }

    // 6. Known URL Shorteners
    if (KNOWN_SHORTENERS.has(hostname)) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Known URL Shortening Service',
        description: `The domain "${hostname}" is a generic URL redirection/shortener service.`,
        severity: 'medium',
        category: 'Obfuscation',
        matchedSample: hostname,
        whyItMatters: 'URL shorteners hide the real final destination and any parameters. While used for marketing, cybercriminals frequently use them to bypass email and SMS spam filters.',
      });
      specificRecommendations.push({
        id: crypto.randomUUID(),
        title: 'Unfurl Before Visiting',
        action: 'Never enter credentials through a shortened link without first expanding it via an official link-preview tool or inquiring with the sender.',
        priority: 'immediate',
      });
    }

    // 7. Suspicious TLD check
    for (const tld of HIGH_RISK_TLDS) {
      if (hostname.endsWith(tld)) {
        findings.push({
          id: crypto.randomUUID(),
          title: `High-Risk Top-Level Domain (${tld})`,
          description: `The website utilizes the top-level domain "${tld}", which is statistically overrepresented in cheap disposable phishing domains.`,
          severity: 'medium',
          category: 'Domain Reputation Indicator',
          matchedSample: tld,
          whyItMatters: 'Extremely cheap or free TLDs are frequently registered in bulk for temporary fraud campaigns. This is an indicator, not definitive proof.',
        });
        break;
      }
    }

    // 8. Misleading Subdomains and Deep Subdomain chaining
    const domainParts = hostname.split('.');
    if (domainParts.length >= 4 && !KNOWN_SHORTENERS.has(hostname)) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Excessive Subdomain Stacking',
        description: `The domain structure has ${domainParts.length} levels ("${hostname}").`,
        severity: 'medium',
        category: 'Subdomain Stacking',
        matchedSample: hostname,
        whyItMatters: 'Phishing campaigns often register a cheap base domain and prepend multiple brand names as subdomains (e.g. sbi.co.in.banking-security-update.xyz) to mislead users on mobile viewports.',
      });
    }

    // 9. Targeted Brand Impersonation / Typosquatting
    for (const brand of TARGETED_BRANDS) {
      for (const pattern of brand.patterns) {
        if (hostname.includes(pattern)) {
          // Check if it's the actual legitimate domain
          const isLegitimate =
            (brand.name.includes('PayPal') && (hostname === 'paypal.com' || hostname.endsWith('.paypal.com'))) ||
            (brand.name.includes('SBI') && (hostname === 'onlinesbi.sbi' || hostname === 'sbi.co.in' || hostname.endsWith('.sbi.co.in'))) ||
            (brand.name.includes('HDFC') && (hostname === 'hdfcbank.com' || hostname.endsWith('.hdfcbank.com'))) ||
            (brand.name.includes('ICICI') && (hostname === 'icicibank.com' || hostname.endsWith('.icicibank.com'))) ||
            (brand.name.includes('Google') && (hostname === 'google.com' || hostname.endsWith('.google.com') || hostname === 'gmail.com')) ||
            (brand.name.includes('Microsoft') && (hostname === 'microsoft.com' || hostname.endsWith('.microsoft.com') || hostname.endsWith('.live.com'))) ||
            (brand.name.includes('Apple') && (hostname === 'apple.com' || hostname.endsWith('.apple.com') || hostname.endsWith('.icloud.com'))) ||
            (brand.name.includes('Netflix') && (hostname === 'netflix.com' || hostname.endsWith('.netflix.com'))) ||
            (brand.name.includes('Amazon') && (hostname === 'amazon.com' || hostname.endsWith('.amazon.com') || hostname.endsWith('.amazon.in'))) ||
            (brand.name.includes('India Post') && (hostname === 'indiapost.gov.in' || hostname.endsWith('.indiapost.gov.in'))) ||
            (brand.name.includes('Income Tax') && (hostname === 'incometax.gov.in' || hostname.endsWith('.incometax.gov.in')));

          if (!isLegitimate) {
            findings.push({
              id: crypto.randomUUID(),
              title: `Brand Impersonation / Typosquatting (${brand.name})`,
              description: `The URL contains keywords strongly matching "${brand.name}", but the host does not belong to their verified root domain.`,
              severity: 'high',
              category: 'Brand Spoofing',
              matchedSample: pattern,
              whyItMatters: `Attackers deliberately imitate trusted brands like ${brand.name} to harvest sensitive banking details, passwords, or personal documents.`,
            });
            break;
          }
        }
      }
    }

    // 10. Suspicious keyword patterns in path or query
    const suspiciousKeywords = [
      'login',
      'signin',
      'verify',
      'update-billing',
      'kyc',
      'aadhaar',
      'pan-card',
      'claim-reward',
      'reset-password',
      'unauthorized-access',
      'suspended',
      'secure-session',
      'wallet',
      'crypto-claim',
    ];

    const fullUrlLower = normalizedInput.toLowerCase();
    const matchedKeywords = suspiciousKeywords.filter(k => fullUrlLower.includes(k));
    if (matchedKeywords.length >= 2) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Multiple High-Risk Security / Authentication Keywords',
        description: `URL contains sensitive security keywords: ${matchedKeywords.join(', ')}.`,
        severity: 'medium',
        category: 'Social Engineering Pattern',
        matchedSample: matchedKeywords.join(', '),
        whyItMatters: 'Phishing URLs frequently use urgent administrative phrases (login, kyc, verify, suspended) to lure users into submitting personal or account credentials.',
      });
    }

    // 11. Excessive Length & Complex Encoding
    if (input.length > 120) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Unusually Long URL Length',
        description: `URL length is ${input.length} characters (typical legitimate web links are under 100 characters).`,
        severity: 'low',
        category: 'Complexity',
        matchedSample: `${input.slice(0, 60)}...`,
        whyItMatters: 'Attackers sometimes construct lengthy query strings to push the true domain outside the visible address bar on mobile devices.',
      });
    }

    const percentMatches = input.match(/%[0-9a-fA-F]{2}/g);
    if (percentMatches && percentMatches.length > 5) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'High Degree of URL Percent-Encoding',
        description: `The link contains ${percentMatches.length} encoded byte sequences (%XX).`,
        severity: 'low',
        category: 'Obfuscation',
        matchedSample: percentMatches.slice(0, 3).join(' '),
        whyItMatters: 'While encoding is normal for non-ASCII parameters, heavy encoding can be used to disguise executable payloads or evade simple string filters.',
      });
    }
  }

  const assessment = calculateRiskAssessment(
    'url',
    input,
    findings,
    specificRecommendations,
    limitations
  );

  return {
    scanId,
    userId: userId || null,
    inputType: 'url',
    riskLevel: assessment.riskLevel,
    riskScore: assessment.riskScore,
    summary: assessment.summary,
    inputPreview: input.length > 180 ? input.slice(0, 180) + '...' : input,
    findings: assessment.findings,
    recommendations: assessment.recommendations,
    limitations: assessment.limitations,
    method: 'rule_heuristics',
    analyzedAt: new Date().toISOString(),
  };
}
