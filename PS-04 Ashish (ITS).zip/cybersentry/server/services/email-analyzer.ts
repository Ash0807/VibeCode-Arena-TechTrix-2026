import type { Finding, Recommendation, ScanResult } from '../../shared/types.js';
import { calculateRiskAssessment } from './risk-scorer.js';
import crypto from 'node:crypto';

export function analyzeEmail(
  content: string,
  sender?: string,
  userId?: string | null
): ScanResult {
  const scanId = crypto.randomUUID();
  const text = content.trim();
  const textLower = text.toLowerCase();
  const findings: Finding[] = [];
  const specificRecommendations: Recommendation[] = [];
  const limitations = [
    'Analysis was performed on pasted text without cryptographic email headers (SPF, DKIM, DMARC) or raw envelope data.',
    'Authenticity of sender display name or email address cannot be cryptographically proven solely from pasted content.',
  ];

  // 1. Sender address analysis (if provided)
  if (sender && sender.trim().length > 0) {
    const senderClean = sender.trim().toLowerCase();
    const freeProviders = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'protonmail.com'];
    const financialNames = ['paypal', 'bank', 'sbi', 'hdfc', 'icici', 'incometax', 'support', 'security', 'netflix', 'amazon', 'apple'];

    const hasFinancialKeyword = financialNames.some(name => senderClean.includes(name));
    const isFreeProvider = freeProviders.some(fp => senderClean.endsWith(`@${fp}`));

    if (hasFinancialKeyword && isFreeProvider) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Institutional Sender Using Free Webmail Domain',
        description: `The sender address ("${sender}") references an enterprise or financial brand, but originates from a public webmail provider.`,
        severity: 'high',
        category: 'Sender Impersonation',
        matchedSample: sender,
        whyItMatters: 'Legitimate institutions send correspondence exclusively from their official registered corporate domains, never free public mail services.',
      });
    }

    if (senderClean.includes('..') || senderClean.includes('xn--') || /[0-9]{4,}@/.test(senderClean)) {
      findings.push({
        id: crypto.randomUUID(),
        title: 'Anomalous Sender Email Address Syntax',
        description: `The sender email address ("${sender}") exhibits unusual formatting, number sequences, or punycode.`,
        severity: 'medium',
        category: 'Sender Discrepancy',
        matchedSample: sender,
        whyItMatters: 'Spoofed and disposable email addresses often randomize local parts or use homoglyphs to impersonate real brands.',
      });
    }
  }

  // 2. Urgent / Pressure Tactics
  const urgencyPatterns = [
    { regex: /\b(within 24 hours|within 12 hours|immediate action required|act immediately|urgent notice|final warning|account will be closed|permanently deleted|legal action)\b/i, label: 'High-pressure deadline' },
    { regex: /\b(strictly confidential|do not inform anyone|keep this secret)\b/i, label: 'Secrecy demand' },
  ];

  for (const { regex, label } of urgencyPatterns) {
    const match = text.match(regex);
    if (match) {
      findings.push({
        id: crypto.randomUUID(),
        title: `Urgency / Pressure Tactic (${label})`,
        description: `Found coercive psychological pressure: "${match[0]}".`,
        severity: 'high',
        category: 'Psychological Manipulation',
        matchedSample: match[0],
        whyItMatters: 'Cybercriminals intentionally manufacture extreme urgency to trigger panic, forcing victims into taking hasty actions before verifying the sender.',
      });
      break;
    }
  }

  // 3. Credential & Sensitive Data Requests (Password, OTP, PIN)
  const credentialPatterns = [
    { regex: /\b(one[\s-]?time[\s-]?password|otp|verification code|security code)\b.*\b(share|send|reply with|enter here|forward|provide)\b/i, label: 'OTP disclosure request' },
    { regex: /\b(share|send|reply with|enter|provide|forward)\b.*\b(one[\s-]?time[\s-]?password|otp|verification code|security code)\b/i, label: 'OTP solicitation request' },
    { regex: /\b(send your password|enter your password|update your credentials|verify your pin|debit card pin|cvv|atm pin)\b/i, label: 'Password or PIN request' },
  ];

  for (const { regex, label } of credentialPatterns) {
    const match = text.match(regex);
    if (match) {
      findings.push({
        id: crypto.randomUUID(),
        title: `Explicit Credential / Secret Request (${label})`,
        description: `Message appears to solicit secrets or credentials: "${match[0]}".`,
        severity: 'high',
        category: 'Credential Harvesting',
        matchedSample: match[0],
        whyItMatters: 'Legitimate entities will never ask for your passwords, PINs, or OTPs. Sharing these grants attackers direct access to your accounts and funds.',
      });
      specificRecommendations.push({
        id: crypto.randomUUID(),
        title: 'Never Share One-Time Passwords',
        action: 'OTPs are for your eyes only. No genuine bank executive or support engineer will ever ask you to read out or forward an OTP.',
        priority: 'immediate',
      });
      break;
    }
  }

  // 4. Financial & Payment Solicitations
  const paymentPatterns = [
    { regex: /\b(update your (bank|billing|credit card) details|payment failed|unpaid invoice|suspended billing|wire transfer|cryptocurrency transfer)\b/i, label: 'Banking/billing modification' },
    { regex: /\b(gift card|steam card|apple gift card|bitcoin|usdt)\b.*\b(pay|purchase|send)\b/i, label: 'Irreversible payment demand' },
  ];

  for (const { regex, label } of paymentPatterns) {
    const match = text.match(regex);
    if (match) {
      findings.push({
        id: crypto.randomUUID(),
        title: `Financial or Payment Demand (${label})`,
        description: `Detected solicitation for payment or billing info: "${match[0]}".`,
        severity: 'high',
        category: 'Financial Fraud Indicator',
        matchedSample: match[0],
        whyItMatters: 'Demands for gift cards, crypto, or immediate banking updates are classical hallmarks of business email compromise (BEC) and invoice scams.',
      });
      break;
    }
  }

  // 5. Account Suspension & Security Threat Language
  const suspensionMatch = text.match(/\b(account has been suspended|restricted access|unauthorized activity detected|compromised account|verify your identity immediately)\b/i);
  if (suspensionMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Security Threat / Account Lockout Warning',
      description: `Message alleges security jeopardy: "${suspensionMatch[0]}".`,
      severity: 'medium',
      category: 'Fear Inducement',
      matchedSample: suspensionMatch[0],
      whyItMatters: 'Fake suspension notices are designed to make users click malicious verification links rather than checking their account directly in an app or browser bookmark.',
    });
  }

  // 6. Prize, Lottery, or Unexpected Reward Scams
  const prizeMatch = text.match(/\b(congratulations|you have won|lottery prize|unclaimed reward|cash grant|beneficiary|inheritance fund|exclusive gift)\b/i);
  if (prizeMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Unsolicited Prize or Reward Announcement',
      description: `Message claims user won unexpected funds: "${prizeMatch[0]}".`,
      severity: 'medium',
      category: 'Advance-Fee / Lottery Scam',
      matchedSample: prizeMatch[0],
      whyItMatters: 'Advance-fee scams lure victims with promises of high prizes, eventually demanding an "administrative fee", "tax clearance", or bank details to release the nonexistent funds.',
    });
  }

  // 7. Embedded Links in Pasted Email
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  const foundUrls = text.match(urlRegex) || [];
  if (foundUrls.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      title: `Embedded External Link(s) Detected (${foundUrls.length})`,
      description: `The message contains direct external hyperlink(s). First detected: "${foundUrls[0]}".`,
      severity: 'medium',
      category: 'Hyperlink Risk',
      matchedSample: foundUrls[0],
      whyItMatters: 'Phishing emails direct targets to deceptive landing pages. Never click links directly from unverified emails; open the service manually in a fresh browser tab.',
    });
  }

  // 8. Impersonation of Authority / Management
  const authorityMatch = text.match(/\b(it support desk|help desk|ceo|managing director|fraud investigation unit|cyber cell|federal authority|internal revenue)\b/i);
  if (authorityMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Authority or Executive Impersonation Pattern',
      description: `Sender claims high-level authority: "${authorityMatch[0]}".`,
      severity: 'medium',
      category: 'Authority Bias',
      matchedSample: authorityMatch[0],
      whyItMatters: 'Attackers exploit respect for authority to deter targets from questioning unusual instructions or seeking second opinions.',
    });
  }

  const assessment = calculateRiskAssessment(
    'email',
    text,
    findings,
    specificRecommendations,
    limitations
  );

  return {
    scanId,
    userId: userId || null,
    inputType: 'email',
    riskLevel: assessment.riskLevel,
    riskScore: assessment.riskScore,
    summary: assessment.summary,
    inputPreview: text.length > 180 ? text.slice(0, 180) + '...' : text,
    findings: assessment.findings,
    recommendations: assessment.recommendations,
    limitations: assessment.limitations,
    method: 'rule_heuristics',
    analyzedAt: new Date().toISOString(),
  };
}
