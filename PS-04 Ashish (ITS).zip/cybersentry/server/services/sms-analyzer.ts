import type { Finding, Recommendation, ScanResult } from '../../shared/types.js';
import { calculateRiskAssessment } from './risk-scorer.js';
import crypto from 'node:crypto';

export function analyzeSms(content: string, userId?: string | null): ScanResult {
  const scanId = crypto.randomUUID();
  const text = content.trim();
  const textLower = text.toLowerCase();
  const findings: Finding[] = [];
  const specificRecommendations: Recommendation[] = [];
  const limitations = [
    'SMS sender header / shortcode alphanumeric spoofing was not checked (only raw text provided).',
    'Heuristics flag typical smishing linguistic markers and payment fraud vectors; legitimate service SMS alerts occasionally share similar brevity.',
  ];

  // 1. Fake Bank Alert & KYC Block threats
  const kycBankMatch = text.match(/\b(dear (customer|user|sbi|hdfc|icici|axis|pnb)|account (blocked|suspended|deactivated|frozen)|update (your )?(pan|aadhaar|kyc)|complete kyc today|netbanking will be blocked)\b/i);
  if (kycBankMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Fake Banking Alert / KYC Suspension Threat',
      description: `Message alleges banking lockout or KYC expiration: "${kycBankMatch[0]}".`,
      severity: 'high',
      category: 'Banking Smishing',
      matchedSample: kycBankMatch[0],
      whyItMatters: 'Banks never send SMS with external links warning that your account or debit card will be blocked immediately for lack of KYC.',
    });
    specificRecommendations.push({
      id: crypto.randomUUID(),
      title: 'Do Not Click KYC Links',
      action: 'Visit your official bank branch or log in securely through the bank official mobile application to check KYC status.',
      priority: 'immediate',
    });
  }

  // 2. UPI & Payment PIN scams ("Scan QR to receive money" or "Enter UPI PIN to receive cashback")
  const upiMatch = text.match(/\b(upi pin|enter pin to receive|scan qr to receive|cashback.*claim|gpay reward|phonepe reward|paytm cashback)\b/i);
  if (upiMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'UPI Fraud Pattern / Reverse Charge Scheme',
      description: `Detected UPI PIN or scan-to-receive language: "${upiMatch[0]}".`,
      severity: 'high',
      category: 'UPI Scam Indicator',
      matchedSample: upiMatch[0],
      whyItMatters: 'CRITICAL RULE: You NEVER need to enter your UPI PIN or scan a QR code to RECEIVE money. UPI PIN is solely required when money leaves your bank account.',
    });
    specificRecommendations.push({
      id: crypto.randomUUID(),
      title: 'UPI PIN is Strictly for Sending Money',
      action: 'Entering your UPI PIN authorizes a withdrawal. Never enter your UPI PIN upon receiving a prompt or link.',
      priority: 'immediate',
    });
  }

  // 3. Fake Delivery Notification (India Post, Courier, Depot)
  const deliveryMatch = text.match(/\b(delivery failed|package (delayed|undelivered|held)|update address|courier warehouse|redelivery fee|customs duty.*pay|india post)\b/i);
  if (deliveryMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Postal / Parcel Delivery Impersonation',
      description: `Detected package failure or address update notification: "${deliveryMatch[0]}".`,
      severity: 'medium',
      category: 'Courier Smishing',
      matchedSample: deliveryMatch[0],
      whyItMatters: 'Postal smishing campaigns send millions of texts asking victims to pay a small nominal fee (e.g. ₹15 - ₹50) to "reschedule delivery", capturing credit card and CVV details on lookalike forms.',
    });
  }

  // 4. Electricity / Utility Disconnection Threats
  const utilityMatch = text.match(/\b(electricity (bill|office|power)|will be (disconnected|cut off) tonight|unpaid electricity bill|contact (officer|helpline))\b/i);
  if (utilityMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Utility / Electricity Power Cut Scam',
      description: `Detected threatening power disconnection alert: "${utilityMatch[0]}".`,
      severity: 'high',
      category: 'Utility Extortion',
      matchedSample: utilityMatch[0],
      whyItMatters: 'Widespread scam where fraudsters threaten imminent power cut-offs, instructing victims to call a personal mobile number and install remote-access apps (AnyDesk/TeamViewer).',
    });
  }

  // 5. Part-time Job / YouTube / Telegram task scams
  const jobMatch = text.match(/\b(part[\s-]?time job|work from home|earn \d+.*daily|like youtube videos|rating products|telegram (group|task)|daily payout)\b/i);
  if (jobMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Task-Based / Part-Time Job Scam',
      description: `Detected promise of effortless high earnings: "${jobMatch[0]}".`,
      severity: 'high',
      category: 'Task Fraud / Ponzi',
      matchedSample: jobMatch[0],
      whyItMatters: 'Prevalent employment scam where victims are paid small sums initially for simple tasks, then pressured into depositing large sums in fraudulent investment schemes.',
    });
  }

  // 6. Suspicious Shortened Links or Unknown URLs in SMS
  const urlRegex = /(https?:\/\/[^\s]+|bit\.ly\/[^\s]+|t\.co\/[^\s]+|tinyurl\.com\/[^\s]+|[a-z0-9\-]+\.(xyz|top|cc|site|live|click)\/[^\s]*)/gi;
  const matchedUrls = text.match(urlRegex) || [];
  if (matchedUrls.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Embedded URL in SMS Message',
      description: `Message includes link: "${matchedUrls[0]}".`,
      severity: 'medium',
      category: 'Smishing Vector',
      matchedSample: matchedUrls[0],
      whyItMatters: 'SMS text lacks rich metadata; fraudsters use short links to redirect recipients to credential-stealing portals.',
    });
  }

  // 7. OTP and Authentication Codes
  const otpMatch = text.match(/\b(otp|one time password|secret code|verification code)\b.*\b(do not share|valid for \d+ min|shared with|call)\b/i);
  if (otpMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Authentication / OTP Notification Detected',
      description: `Message contains security code references: "${otpMatch[0]}".`,
      severity: 'info',
      category: 'Authentication Context',
      matchedSample: otpMatch[0],
      whyItMatters: 'If you did not initiate this transaction or login, your credentials may already be known to an attacker attempting to access your account.',
    });
  }

  // 8. Lottery / Lucky Draw Scams (e.g., KBC, Car, Cash)
  const lotteryMatch = text.match(/\b(kbc lottery|congratulations.*winner|won ₹|lucky draw|claim your prize|cheque ready)\b/i);
  if (lotteryMatch) {
    findings.push({
      id: crypto.randomUUID(),
      title: 'Bogus Lottery / Lucky Draw Award',
      description: `Claims winner status for unentered lottery: "${lotteryMatch[0]}".`,
      severity: 'high',
      category: 'Advance-Fee Scam',
      matchedSample: lotteryMatch[0],
      whyItMatters: 'Unsolicited lottery winnings are fraudulent. Scammers demand upfront "GST processing charges" or bank details.',
    });
  }

  const assessment = calculateRiskAssessment(
    'sms',
    text,
    findings,
    specificRecommendations,
    limitations
  );

  return {
    scanId,
    userId: userId || null,
    inputType: 'sms',
    riskLevel: assessment.riskLevel,
    riskScore: assessment.riskScore,
    summary: assessment.summary,
    inputPreview: text.length > 180 ? text.slice(0, 180) + '...' : text,
    findings: assessment.findings,
    recommendations: assessment.recommendations,
    limitations: assessment.limitations,
    method: 'rule_heuristics',
    analyzedAt: new Date().toISOString(),
  };
}
