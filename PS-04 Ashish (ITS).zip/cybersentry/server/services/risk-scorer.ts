import type { Finding, Recommendation, RiskLevel, ScanResult, InputType } from '../../shared/types.js';
import crypto from 'node:crypto';

export interface ScoredAssessment {
  riskScore: number;
  riskLevel: RiskLevel;
  summary: string;
  findings: Finding[];
  recommendations: Recommendation[];
  limitations: string[];
}

export function calculateRiskAssessment(
  inputType: InputType,
  inputPreview: string,
  rawFindings: Finding[],
  specificRecommendations: Recommendation[] = [],
  specificLimitations: string[] = []
): ScoredAssessment {
  // Deduplicate findings by title
  const uniqueFindingsMap = new Map<string, Finding>();
  for (const f of rawFindings) {
    if (!uniqueFindingsMap.has(f.title)) {
      uniqueFindingsMap.set(f.title, f);
    }
  }
  const findings = Array.from(uniqueFindingsMap.values());

  // Heuristic point calculation:
  // Info: 5, Low: 15, Medium: 25, High: 40
  let rawScore = 0;
  let hasHighSeverity = false;

  for (const f of findings) {
    switch (f.severity) {
      case 'high':
        rawScore += 40;
        hasHighSeverity = true;
        break;
      case 'medium':
        rawScore += 25;
        break;
      case 'low':
        rawScore += 15;
        break;
      case 'info':
        rawScore += 5;
        break;
    }
  }

  // Cap score between 0 and 100
  const riskScore = Math.min(100, Math.max(0, rawScore));

  // Determine risk level based on calibrated thresholds:
  // Severe indicators or cumulative points >= 40 warrant high risk designation
  let riskLevel: RiskLevel = 'low';
  if (riskScore >= 50 || (hasHighSeverity && riskScore >= 40)) {
    riskLevel = 'high';
  } else if (riskScore >= 25) {
    riskLevel = 'medium';
  } else {
    riskLevel = 'low';
  }

  // Generate plain-English summary
  let summary = '';
  if (riskLevel === 'high') {
    summary = `High risk detected. Identified ${findings.length} warning indicator(s), including high-severity patterns often associated with credential harvesting, impersonation, or financial fraud. Exercise extreme caution.`;
  } else if (riskLevel === 'medium') {
    summary = `Moderate risk detected. Found ${findings.length} indicator(s) that warrant verification. The message or URL exhibits suspicious characteristics commonly used in social engineering.`;
  } else {
    summary = findings.length > 0
      ? `Low risk indicators observed (${findings.length} minor pattern(s)). While no overt attack vectors were confirmed, remain vigilant.`
      : `No known suspicious patterns or attack indicators were detected in this submission.`;
  }

  // Base recommendations
  const recommendations: Recommendation[] = [...specificRecommendations];

  if (riskLevel === 'high') {
    recommendations.unshift(
      {
        id: crypto.randomUUID(),
        title: 'Do Not Click Links or Reply',
        action: 'Avoid interacting with any links, buttons, or phone numbers in this message. Do not download attached files.',
        priority: 'immediate',
      },
      {
        id: crypto.randomUUID(),
        title: 'Never Disclose Credentials or PINs',
        action: 'Legitimate banks, government portals, and services never request your passwords, OTPs, or UPI PINs via email or SMS.',
        priority: 'immediate',
      }
    );
  } else if (riskLevel === 'medium') {
    recommendations.unshift({
      id: crypto.randomUUID(),
      title: 'Verify Through Official Channels',
      action: 'Contact the organization directly using their official website or verified customer care number, not the contact info in this message.',
      priority: 'recommended',
    });
  } else {
    recommendations.push({
      id: crypto.randomUUID(),
      title: 'Standard Security Caution',
      action: 'Always confirm the sender identity and destination URL before entering personal details, even if a message appears harmless.',
      priority: 'optional',
    });
  }

  // Universal limitations and uncertainties
  const limitations = [
    'Static heuristic analysis provides risk indicators, not definitive proof of maliciousness or absolute safety.',
    'A low score does not guarantee the content is safe; zero-day phishing sites or tailored spear-phishing may bypass standard heuristics.',
    'No remote network connections or live destinations were visited to preserve your privacy and avoid triggering malicious infrastructure.',
    ...specificLimitations,
  ];

  return {
    riskScore,
    riskLevel,
    summary,
    findings,
    recommendations,
    limitations,
  };
}
