import type { Request, Response, NextFunction } from 'express';
import { SessionRepo } from '../db/repository.js';
import type { User } from '../../shared/types.js';

export interface AuthenticatedRequest extends Request {
  user?: User;
  sessionId?: string;
}

export function optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const sessionId = req.cookies?.cybersentry_session;
  if (sessionId) {
    const user = SessionRepo.findValid(sessionId);
    if (user) {
      req.user = user;
      req.sessionId = sessionId;
    }
  }
  next();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const sessionId = req.cookies?.cybersentry_session;
  if (!sessionId) {
    return res.status(401).json({ error: 'Authentication required. Please sign in.' });
  }

  const user = SessionRepo.findValid(sessionId);
  if (!user) {
    res.clearCookie('cybersentry_session');
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }

  req.user = user;
  req.sessionId = sessionId;
  next();
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
    }
    next();
  });
}
