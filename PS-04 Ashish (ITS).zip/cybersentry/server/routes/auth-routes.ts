import { Router } from 'express';
import { z } from 'zod';
import { UserRepo, SessionRepo } from '../db/repository.js';
import { hashPassword, verifyPassword } from '../db/database.js';
import { authLimiter } from '../middleware/rate-limiter.js';
import { requireAuth, type AuthenticatedRequest } from '../middleware/auth-middleware.js';

const router = Router();

const RegisterSchema = z.object({
  email: z.string().email('Please provide a valid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
  name: z.string().optional(),
});

const LoginSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(1, 'Password is required'),
});

router.post('/register', authLimiter, (req, res) => {
  const parsed = RegisterSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0]?.message || 'Invalid input data' });
  }

  const { email, password, name } = parsed.data;
  const existing = UserRepo.findByEmail(email);
  if (existing) {
    return res.status(409).json({ error: 'An account with this email address already exists.' });
  }

  const user = UserRepo.create({
    email,
    password_hash: hashPassword(password),
    role: 'user',
    name,
  });

  const sessionId = SessionRepo.create(user.id);
  const secureCookie = process.env.COOKIE_SECURE === 'true' || process.env.NODE_ENV === 'production';

  res.cookie('cybersentry_session', sessionId, {
    httpOnly: true,
    secure: secureCookie,
    sameSite: 'lax',
    maxAge: 7 * 24 * 3600 * 1000,
  });

  return res.status(201).json({
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      createdAt: user.createdAt,
    },
  });
});

router.post('/login', authLimiter, (req, res) => {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0]?.message || 'Invalid credentials' });
  }

  const { email, password } = parsed.data;
  const user = UserRepo.findByEmail(email);

  if (!user || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const sessionId = SessionRepo.create(user.id);
  const secureCookie = process.env.COOKIE_SECURE === 'true' || process.env.NODE_ENV === 'production';

  res.cookie('cybersentry_session', sessionId, {
    httpOnly: true,
    secure: secureCookie,
    sameSite: 'lax',
    maxAge: 7 * 24 * 3600 * 1000,
  });

  return res.json({
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      createdAt: user.createdAt,
    },
  });
});

router.post('/logout', (req: AuthenticatedRequest, res) => {
  const sessionId = req.cookies?.cybersentry_session;
  if (sessionId) {
    SessionRepo.delete(sessionId);
  }
  res.clearCookie('cybersentry_session');
  return res.json({ message: 'Successfully logged out.' });
});

router.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  return res.json({ user: req.user });
});

export default router;
