import { Router } from 'express';
import { AnalyticsRepo } from '../db/repository.js';
import { optionalAuth, type AuthenticatedRequest } from '../middleware/auth-middleware.js';

const router = Router();

router.get('/stats', optionalAuth, (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const stats = AnalyticsRepo.getStats(req.user?.id, isAdmin);
  return res.json(stats);
});

export default router;
