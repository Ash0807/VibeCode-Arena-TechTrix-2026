import { Router } from 'express';
import { z } from 'zod';
import { ACADEMY_LESSONS, QUIZ_QUESTIONS } from '../services/academy-data.js';
import { QuizRepo } from '../db/repository.js';
import { optionalAuth, requireAuth, type AuthenticatedRequest } from '../middleware/auth-middleware.js';

const router = Router();

// Get All Lessons
router.get('/lessons', (_req, res) => {
  return res.json(ACADEMY_LESSONS);
});

// Get Specific Lesson
router.get('/lessons/:id', (req, res) => {
  const lesson = ACADEMY_LESSONS.find(l => l.id === req.params.id);
  if (!lesson) {
    return res.status(404).json({ error: 'Lesson not found.' });
  }
  return res.json(lesson);
});

// Get Quiz Questions
router.get('/quiz', (_req, res) => {
  return res.json(QUIZ_QUESTIONS);
});

const QuizSubmissionSchema = z.object({
  quizIdentifier: z.string().default('cyber-awareness-core'),
  answers: z.array(
    z.object({
      questionId: z.string(),
      selectedIndex: z.number(),
    })
  ),
});

// Submit Quiz Attempt
router.post('/quiz/attempts', optionalAuth, (req: AuthenticatedRequest, res) => {
  const parsed = QuizSubmissionSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid quiz attempt data format.' });
  }

  const { quizIdentifier, answers: userAnswers } = parsed.data;

  let score = 0;
  const gradedAnswers = userAnswers.map(ans => {
    const question = QUIZ_QUESTIONS.find(q => q.id === ans.questionId);
    const isCorrect = question ? question.correctIndex === ans.selectedIndex : false;
    if (isCorrect) score += 1;
    return {
      questionId: ans.questionId,
      selectedIndex: ans.selectedIndex,
      isCorrect,
    };
  });

  const attempt = QuizRepo.saveAttempt({
    userId: req.user?.id || null,
    quizIdentifier,
    score,
    totalQuestions: QUIZ_QUESTIONS.length,
    answers: gradedAnswers,
  });

  return res.status(201).json(attempt);
});

// Get User Quiz History
router.get('/quiz/history', requireAuth, (req: AuthenticatedRequest, res) => {
  const attempts = QuizRepo.getAttempts(req.user!.id);
  return res.json(attempts);
});

export default router;
