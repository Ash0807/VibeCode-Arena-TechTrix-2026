import { Router } from 'express';
import { z } from 'zod';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { IncidentRepo } from '../db/repository.js';
import { reportLimiter } from '../middleware/rate-limiter.js';
import { optionalAuth, requireAuth, requireAdmin, type AuthenticatedRequest } from '../middleware/auth-middleware.js';
import { evidenceUpload } from '../middleware/upload-middleware.js';
import type { IncidentCategory, IncidentStatus } from '../../shared/types.js';

const router = Router();

const ValidCategories = [
  'phishing',
  'upi_fraud',
  'impersonation',
  'fake_website',
  'account_compromise',
  'shopping_fraud',
  'social_engineering',
  'other',
] as const;

const ValidStatuses = ['Submitted', 'Under Review', 'Resolved', 'Closed'] as const;

// Create Incident
router.post(
  '/',
  reportLimiter,
  optionalAuth,
  evidenceUpload.single('evidence'),
  (req: AuthenticatedRequest, res) => {
    const { category, description, suspiciousUrl, contactInfo, consentGiven } = req.body;

    if (!category || !ValidCategories.includes(category as any)) {
      return res.status(400).json({ error: 'Please select a valid incident category.' });
    }

    if (!description || description.trim().length < 10) {
      return res.status(400).json({ error: 'Please provide an incident description of at least 10 characters.' });
    }

    if (consentGiven !== 'true' && consentGiven !== true) {
      return res.status(400).json({ error: 'Consent and privacy acknowledgement is required to submit a report.' });
    }

    // Generate readable random Report ID: CS-2026-XXXX
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const reportId = `CS-2026-${randomSuffix}`;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    const incident = IncidentRepo.create({
      id,
      reportId,
      userId: req.user?.id || null,
      category: category as IncidentCategory,
      description: description.trim(),
      suspiciousUrl: suspiciousUrl ? suspiciousUrl.trim() : undefined,
      evidenceFileName: req.file ? req.file.filename : undefined,
      evidenceOriginalName: req.file ? req.file.originalname : undefined,
      contactInfo: contactInfo ? contactInfo.trim() : undefined,
      status: 'Submitted',
      consentGiven: true,
      createdAt: now,
      updatedAt: now,
    });

    return res.status(201).json({
      message: 'Incident reported successfully.',
      reportId: incident.reportId,
      incident,
    });
  }
);

// List Incidents
router.get('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const page = parseInt(req.query.page as string || '1', 10);
  const limit = parseInt(req.query.limit as string || '10', 10);
  const category = req.query.category as any;
  const status = req.query.status as any;
  const search = req.query.search as string | undefined;

  // If user is not logged in and not admin, return empty list
  if (!req.user && !isAdmin) {
    return res.json({ items: [], total: 0, page: 1, totalPages: 1 });
  }

  const result = IncidentRepo.list({
    userId: req.user?.id,
    isAdmin,
    category,
    status,
    search,
    page,
    limit,
  });

  return res.json(result);
});

// Track by Report ID (e.g. CS-2026-9481)
router.get('/track/:reportId', (req, res) => {
  const { reportId } = req.params;
  const incident = IncidentRepo.findByReportId(reportId);

  if (!incident) {
    return res.status(404).json({ error: 'No incident report found matching this tracking ID.' });
  }

  const history = IncidentRepo.getStatusHistory(incident.id);

  // Return public tracking view (scrub private contact info)
  return res.json({
    reportId: incident.reportId,
    category: incident.category,
    description: incident.description,
    suspiciousUrl: incident.suspiciousUrl,
    hasEvidence: Boolean(incident.evidenceFileName),
    status: incident.status,
    createdAt: incident.createdAt,
    updatedAt: incident.updatedAt,
    history,
  });
});

// Get Single Incident Details
router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const incident = IncidentRepo.findById(req.params.id);
  if (!incident) {
    return res.status(404).json({ error: 'Incident not found.' });
  }

  const isAdmin = req.user?.role === 'admin';
  const isOwner = req.user?.id && incident.userId === req.user.id;

  if (!isAdmin && !isOwner) {
    return res.status(403).json({ error: 'Unauthorized to view this incident report.' });
  }

  const history = IncidentRepo.getStatusHistory(incident.id);
  return res.json({ incident, history });
});

// Admin Status Update with Audit Log
router.patch('/:id/status', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { status, notes } = req.body;

  if (!status || !ValidStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status. Must be: Submitted, Under Review, Resolved, or Closed.' });
  }

  const changedBy = req.user?.name || req.user?.email || 'Administrator';
  const updated = IncidentRepo.updateStatus(req.params.id, status as IncidentStatus, changedBy, notes);

  if (!updated) {
    return res.status(404).json({ error: 'Incident not found.' });
  }

  const history = IncidentRepo.getStatusHistory(updated.id);
  return res.json({ incident: updated, history, message: `Status updated to ${status}.` });
});

// Download Evidence (authorized owner or admin only)
router.get('/:id/evidence', optionalAuth, (req: AuthenticatedRequest, res) => {
  const incident = IncidentRepo.findById(req.params.id);
  if (!incident || !incident.evidenceFileName) {
    return res.status(404).json({ error: 'Evidence file not found.' });
  }

  const isAdmin = req.user?.role === 'admin';
  const isOwner = req.user?.id && incident.userId === req.user.id;

  if (!isAdmin && !isOwner) {
    return res.status(403).json({ error: 'Unauthorized access to evidence.' });
  }

  const filePath = path.resolve(process.cwd(), 'uploads', incident.evidenceFileName);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'File is no longer available on disk.' });
  }

  return res.download(filePath, incident.evidenceOriginalName || 'incident_evidence');
});

export default router;
