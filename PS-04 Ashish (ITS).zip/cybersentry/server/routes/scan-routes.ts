import { Router } from 'express';
import { z } from 'zod';
import { ScanRepo } from '../db/repository.js';
import { analyzeUrl } from '../services/url-analyzer.js';
import { analyzeEmail } from '../services/email-analyzer.js';
import { analyzeSms } from '../services/sms-analyzer.js';
import { processScreenshot } from '../services/ocr-service.js';
import { enhanceWithOptionalAi } from '../services/ai-service.js';
import { scanLimiter } from '../middleware/rate-limiter.js';
import { optionalAuth, type AuthenticatedRequest } from '../middleware/auth-middleware.js';
import { screenshotUpload } from '../middleware/upload-middleware.js';

const router = Router();

const UrlScanSchema = z.object({
  url: z.string().min(1, 'Please enter a URL to scan').max(2000, 'URL is too long'),
});

const TextScanSchema = z.object({
  type: z.enum(['email', 'sms']),
  content: z.string().min(1, 'Please enter message content to analyze').max(10000, 'Content exceeds length limit'),
  sender: z.string().max(320).optional(),
});

// Analyze URL
router.post('/url', scanLimiter, optionalAuth, async (req: AuthenticatedRequest, res) => {
  const parsed = UrlScanSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0]?.message || 'Invalid URL' });
  }

  try {
    let result = analyzeUrl(parsed.data.url, req.user?.id);
    result = await enhanceWithOptionalAi(result);
    ScanRepo.create(result);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to analyze URL: ' + (err?.message || 'Internal error') });
  }
});

// Analyze Email or SMS
router.post('/text', scanLimiter, optionalAuth, async (req: AuthenticatedRequest, res) => {
  const parsed = TextScanSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0]?.message || 'Invalid input data' });
  }

  const { type, content, sender } = parsed.data;

  try {
    let result = type === 'email'
      ? analyzeEmail(content, sender, req.user?.id)
      : analyzeSms(content, req.user?.id);

    result = await enhanceWithOptionalAi(result);
    ScanRepo.create(result);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to analyze message: ' + (err?.message || 'Internal error') });
  }
});

// Analyze Screenshot
router.post(
  '/image',
  scanLimiter,
  optionalAuth,
  screenshotUpload.single('screenshot'),
  async (req: AuthenticatedRequest, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an image file (PNG, JPEG, WebP).' });
    }

    try {
      let result = await processScreenshot(req.file.path, req.user?.id);
      result = await enhanceWithOptionalAi(result);
      ScanRepo.create(result);
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to process screenshot: ' + (err?.message || 'Internal error') });
    }
  }
);

// Get Scan History
router.get('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const page = parseInt(req.query.page as string || '1', 10);
  const limit = parseInt(req.query.limit as string || '10', 10);
  const search = req.query.search as string | undefined;
  const riskLevel = req.query.riskLevel as any;
  const inputType = req.query.inputType as any;
  const isAdmin = req.user?.role === 'admin';

  const history = ScanRepo.list({
    userId: req.user?.id,
    isAdmin,
    search,
    riskLevel,
    inputType,
    page,
    limit,
  });

  return res.json(history);
});

// Get Single Scan by ID
router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const scan = ScanRepo.findById(req.params.id, req.user?.id, isAdmin);
  if (!scan) {
    return res.status(404).json({ error: 'Scan result not found or access restricted.' });
  }
  return res.json(scan);
});

// Delete Single Scan
router.delete('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const success = ScanRepo.delete(req.params.id, req.user?.id, isAdmin);
  if (!success) {
    return res.status(404).json({ error: 'Scan not found or unauthorized to delete.' });
  }
  return res.json({ message: 'Scan result successfully deleted.' });
});

// Clear All Scan History
router.delete('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const deletedCount = ScanRepo.clearHistory(req.user?.id, isAdmin);
  return res.json({ message: `Successfully cleared ${deletedCount} scan records.` });
});

export default router;
