import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import fs from 'node:fs';
import dotenv from 'dotenv';
import { initDatabase } from './db/database.js';
import authRoutes from './routes/auth-routes.js';
import scanRoutes from './routes/scan-routes.js';
import incidentRoutes from './routes/incident-routes.js';
import dashboardRoutes from './routes/dashboard-routes.js';
import academyRoutes from './routes/academy-routes.js';

dotenv.config();

// Initialize Database & seed if empty
initDatabase();

export const app = express();
const PORT = process.env.PORT || 5000;
const clientUrl = process.env.CLIENT_URL || 'http://localhost:3000';

// Security Headers Middleware
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Privacy-conscious HTTP logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    // Don't log sensitive payload data or parameters
    console.info(`[${new Date().toISOString()}] ${req.method} ${req.baseUrl + req.path} - ${res.statusCode} (${duration}ms)`);
  });
  next();
});

// Middleware configuration
app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like mobile apps, curl, or same-origin)
      if (!origin || origin === clientUrl || origin.startsWith('http://localhost:')) {
        callback(null, true);
      } else {
        callback(null, true);
      }
    },
    credentials: true,
  })
);

app.use(cookieParser());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health Check API
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'healthy',
    name: 'CyberSentry API',
    tagline: 'Your Digital Safety Guardian',
    timestamp: new Date().toISOString(),
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/analyze', scanRoutes);
app.use('/api/scans', scanRoutes);
app.use('/api/incidents', incidentRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/academy', academyRoutes);

// In production, serve the built frontend
const distPath = path.resolve(process.cwd(), 'dist', 'public');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.resolve(distPath, 'index.html'));
  });
}

// Global Error Handler (Sanitized for security)
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[CyberSentry Unhandled Error]', err?.message || err);
  const status = err.status || 500;
  const message = status === 500 ? 'An unexpected server error occurred. Please try again.' : err.message;
  res.status(status).json({ error: message });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`🛡️ CyberSentry Security Server listening on http://localhost:${PORT}`);
  });
}
