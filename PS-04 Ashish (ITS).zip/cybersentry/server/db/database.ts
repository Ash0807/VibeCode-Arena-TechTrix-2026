import { createRequire } from 'node:module';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';

const require = createRequire(import.meta.url);
const { DatabaseSync } = require('node:sqlite');

const dbPath = process.env.DATABASE_PATH || path.resolve(process.cwd(), 'data', 'cybersentry.db');
const dbDir = path.dirname(dbPath);

if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

export const db = new DatabaseSync(dbPath);

// Enable WAL mode & foreign keys
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

export function initDatabase() {
  // Migrations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS _migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      applied_at TEXT NOT NULL
    );
  `);

  // Apply migrations
  applyMigration('001_initial_schema', () => {
    db.exec(`
      -- Users Table
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'user')),
        name TEXT,
        created_at TEXT NOT NULL
      );

      -- Sessions Table for secure cookie authentication
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      -- Scans Table
      CREATE TABLE IF NOT EXISTS scans (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        input_type TEXT NOT NULL CHECK(input_type IN ('url', 'email', 'sms', 'screenshot')),
        risk_level TEXT NOT NULL CHECK(risk_level IN ('low', 'medium', 'high')),
        risk_score INTEGER NOT NULL,
        summary TEXT NOT NULL,
        input_preview TEXT NOT NULL,
        findings_json TEXT NOT NULL,
        recommendations_json TEXT NOT NULL,
        limitations_json TEXT NOT NULL,
        method TEXT NOT NULL,
        extracted_text TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      -- Incidents Table
      CREATE TABLE IF NOT EXISTS incidents (
        id TEXT PRIMARY KEY,
        report_id TEXT NOT NULL UNIQUE,
        user_id TEXT,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        suspicious_url TEXT,
        evidence_file_name TEXT,
        evidence_original_name TEXT,
        contact_info TEXT,
        status TEXT NOT NULL DEFAULT 'Submitted' CHECK(status IN ('Submitted', 'Under Review', 'Resolved', 'Closed')),
        consent_given INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      -- Incident Status History Table
      CREATE TABLE IF NOT EXISTS incident_status_history (
        id TEXT PRIMARY KEY,
        incident_id TEXT NOT NULL,
        previous_status TEXT NOT NULL,
        new_status TEXT NOT NULL,
        changed_by TEXT NOT NULL,
        notes TEXT,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE
      );

      -- Quiz Attempts Table
      CREATE TABLE IF NOT EXISTS quiz_attempts (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        quiz_identifier TEXT NOT NULL,
        score INTEGER NOT NULL,
        total_questions INTEGER NOT NULL,
        answers_json TEXT NOT NULL,
        completed_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      -- Indexes for fast queries & analytics
      CREATE INDEX IF NOT EXISTS idx_scans_user_created ON scans(user_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_scans_risk_type ON scans(risk_level, input_type);
      CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_incidents_report_id ON incidents(report_id);
      CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
    `);
  });

  // Seed default admin and initial sample records if users is empty
  seedInitialData();
}

function applyMigration(name: string, fn: () => void) {
  const check = db.prepare('SELECT id FROM _migrations WHERE name = ?').get(name);
  if (!check) {
    fn();
    db.prepare('INSERT INTO _migrations (name, applied_at) VALUES (?, ?)').run(name, new Date().toISOString());
  }
}

// Password hashing utility using standard scrypt
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

export function verifyPassword(password: string, combinedHash: string): boolean {
  try {
    const [salt, key] = combinedHash.split(':');
    if (!salt || !key) return false;
    const keyBuffer = Buffer.from(key, 'hex');
    const derivedKey = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(keyBuffer, derivedKey);
  } catch {
    return false;
  }
}

function seedInitialData() {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM users');
  const { count } = countStmt.get() as { count: number };

  if (count === 0) {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@cybersentry.local';
    const adminPassword = process.env.ADMIN_PASSWORD || 'CyberSentry#Admin2026!';
    const adminId = crypto.randomUUID();

    const insertUser = db.prepare(`
      INSERT INTO users (id, email, password_hash, role, name, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    insertUser.run(adminId, adminEmail.toLowerCase(), hashPassword(adminPassword), 'admin', 'CyberSentry Security Team', new Date().toISOString());

    // Also seed a standard demo user for easy testing
    const demoUserId = crypto.randomUUID();
    insertUser.run(demoUserId, 'user@cybersentry.local', hashPassword('UserSafe123!'), 'user', 'Alex Mercer', new Date().toISOString());

    // Seed fictional incident reports clearly labeled for demo purposes
    const insertIncident = db.prepare(`
      INSERT INTO incidents (id, report_id, user_id, category, description, suspicious_url, status, consent_given, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);

    const insertHistory = db.prepare(`
      INSERT INTO incident_status_history (id, incident_id, previous_status, new_status, changed_by, notes, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const demoIncidents = [
      {
        id: crypto.randomUUID(),
        reportId: 'CS-2026-9481',
        category: 'upi_fraud',
        description: '[DEMO INCIDENT] Received fake QR code request on WhatsApp asking to enter UPI PIN to receive cash prize of ₹5,000.',
        url: 'http://win-cash-reward2026.top/claim',
        status: 'Under Review',
        timeOffsetHours: 4,
      },
      {
        id: crypto.randomUUID(),
        reportId: 'CS-2026-8172',
        category: 'phishing',
        description: '[DEMO INCIDENT] Email pretending to be from Income Tax Department demanding immediate tax refund verification via external link.',
        url: 'http://incometax-refund-portal.support-tax.com',
        status: 'Submitted',
        timeOffsetHours: 12,
      },
      {
        id: crypto.randomUUID(),
        reportId: 'CS-2026-7320',
        category: 'account_compromise',
        description: '[DEMO INCIDENT] Unauthorized login notification from unknown IP on social media account after clicking a lookalike verification link.',
        url: 'https://security-verify-insta-login.cc',
        status: 'Resolved',
        timeOffsetHours: 48,
      },
      {
        id: crypto.randomUUID(),
        reportId: 'CS-2026-5519',
        category: 'shopping_fraud',
        description: '[DEMO INCIDENT] Purchased discounted smartphone from advertised Instagram store. Website disappeared immediately after payment.',
        url: 'https://mega-electronic-deals.store',
        status: 'Closed',
        timeOffsetHours: 96,
      },
    ];

    for (const inc of demoIncidents) {
      const date = new Date(Date.now() - inc.timeOffsetHours * 3600000).toISOString();
      insertIncident.run(inc.id, inc.reportId, demoUserId, inc.category, inc.description, inc.url, inc.status, date, date);
      insertHistory.run(
        crypto.randomUUID(),
        inc.id,
        'Submitted',
        inc.status,
        'System Initializer (Demo Data)',
        'Initial demonstration status recorded.',
        date
      );
    }
  }
}
