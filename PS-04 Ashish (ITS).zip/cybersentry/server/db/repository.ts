import { db } from './database.js';
import type {
  User,
  ScanResult,
  Incident,
  IncidentStatusHistory,
  QuizAttempt,
  IncidentStatus,
  RiskLevel,
  InputType,
  IncidentCategory,
} from '../../shared/types.js';
import crypto from 'node:crypto';

export const UserRepo = {
  findByEmail(email: string): (User & { password_hash: string }) | null {
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase()) as any;
    if (!row) return null;
    return {
      id: row.id,
      email: row.email,
      password_hash: row.password_hash,
      role: row.role,
      name: row.name,
      createdAt: row.created_at,
    };
  },

  findById(id: string): User | null {
    const row = db.prepare('SELECT id, email, role, name, created_at FROM users WHERE id = ?').get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      email: row.email,
      role: row.role,
      name: row.name,
      createdAt: row.created_at,
    };
  },

  create(user: { email: string; password_hash: string; role?: 'admin' | 'user'; name?: string }): User {
    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    const role = user.role || 'user';
    db.prepare(`
      INSERT INTO users (id, email, password_hash, role, name, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, user.email.toLowerCase(), user.password_hash, role, user.name || null, createdAt);

    return {
      id,
      email: user.email.toLowerCase(),
      role,
      name: user.name,
      createdAt,
    };
  },
};

export const SessionRepo = {
  create(userId: string, maxAgeMs: number = 7 * 24 * 3600 * 1000): string {
    const sessionId = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + maxAgeMs).toISOString();
    const createdAt = new Date().toISOString();

    db.prepare(`
      INSERT INTO sessions (id, user_id, expires_at, created_at)
      VALUES (?, ?, ?, ?)
    `).run(sessionId, userId, expiresAt, createdAt);

    return sessionId;
  },

  findValid(sessionId: string): (User & { sessionId: string }) | null {
    const now = new Date().toISOString();
    const row = db.prepare(`
      SELECT s.id as session_id, s.expires_at, u.id, u.email, u.role, u.name, u.created_at
      FROM sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.id = ? AND s.expires_at > ?
    `).get(sessionId, now) as any;

    if (!row) return null;
    return {
      sessionId: row.session_id,
      id: row.id,
      email: row.email,
      role: row.role,
      name: row.name,
      createdAt: row.created_at,
    };
  },

  delete(sessionId: string): void {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
  },

  cleanExpired(): void {
    const now = new Date().toISOString();
    db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now);
  },
};

export const ScanRepo = {
  create(scan: ScanResult): ScanResult {
    db.prepare(`
      INSERT INTO scans (
        id, user_id, input_type, risk_level, risk_score, summary, input_preview,
        findings_json, recommendations_json, limitations_json, method, extracted_text, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      scan.scanId,
      scan.userId || null,
      scan.inputType,
      scan.riskLevel,
      scan.riskScore,
      scan.summary,
      scan.inputPreview,
      JSON.stringify(scan.findings),
      JSON.stringify(scan.recommendations),
      JSON.stringify(scan.limitations),
      scan.method,
      scan.extractedText || null,
      scan.analyzedAt
    );
    return scan;
  },

  findById(id: string, userId?: string | null, isAdmin: boolean = false): ScanResult | null {
    let query = 'SELECT * FROM scans WHERE id = ?';
    const params: any[] = [id];

    if (!isAdmin && userId) {
      query += ' AND (user_id = ? OR user_id IS NULL)';
      params.push(userId);
    } else if (!isAdmin && !userId) {
      query += ' AND user_id IS NULL';
    }

    const row = db.prepare(query).get(...params) as any;
    if (!row) return null;
    return this.mapRow(row);
  },

  list(filters: {
    userId?: string | null;
    isAdmin?: boolean;
    search?: string;
    riskLevel?: RiskLevel | 'all';
    inputType?: InputType | 'all';
    page?: number;
    limit?: number;
  }): { items: ScanResult[]; total: number; page: number; totalPages: number } {
    const page = Math.max(1, filters.page || 1);
    const limit = Math.min(50, Math.max(1, filters.limit || 10));
    const offset = (page - 1) * limit;

    const conditions: string[] = [];
    const params: any[] = [];

    if (!filters.isAdmin) {
      if (filters.userId) {
        conditions.push('(user_id = ? OR user_id IS NULL)');
        params.push(filters.userId);
      } else {
        conditions.push('user_id IS NULL');
      }
    }

    if (filters.riskLevel && filters.riskLevel !== 'all') {
      conditions.push('risk_level = ?');
      params.push(filters.riskLevel);
    }

    if (filters.inputType && filters.inputType !== 'all') {
      conditions.push('input_type = ?');
      params.push(filters.inputType);
    }

    if (filters.search) {
      conditions.push('(summary LIKE ? OR input_preview LIKE ?)');
      params.push(`%${filters.search}%`, `%${filters.search}%`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countRow = db.prepare(`SELECT COUNT(*) as count FROM scans ${whereClause}`).get(...params) as any;
    const total = countRow ? countRow.count : 0;

    const rows = db.prepare(`
      SELECT * FROM scans
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset) as any[];

    return {
      items: rows.map(r => this.mapRow(r)),
      total,
      page,
      totalPages: Math.ceil(total / limit) || 1,
    };
  },

  delete(id: string, userId?: string | null, isAdmin: boolean = false): boolean {
    let query = 'DELETE FROM scans WHERE id = ?';
    const params: any[] = [id];

    if (!isAdmin) {
      if (userId) {
        query += ' AND (user_id = ? OR user_id IS NULL)';
        params.push(userId);
      } else {
        query += ' AND user_id IS NULL';
      }
    }

    const res = db.prepare(query).run(...params);
    return res.changes > 0;
  },

  clearHistory(userId?: string | null, isAdmin: boolean = false): number {
    let query = 'DELETE FROM scans';
    const params: any[] = [];

    if (!isAdmin) {
      if (userId) {
        query += ' WHERE (user_id = ? OR user_id IS NULL)';
        params.push(userId);
      } else {
        query += ' WHERE user_id IS NULL';
      }
    }

    const res = db.prepare(query).run(...params);
    return res.changes;
  },

  mapRow(row: any): ScanResult {
    return {
      scanId: row.id,
      userId: row.user_id,
      inputType: row.input_type,
      riskLevel: row.risk_level,
      riskScore: row.risk_score,
      summary: row.summary,
      inputPreview: row.input_preview,
      findings: JSON.parse(row.findings_json || '[]'),
      recommendations: JSON.parse(row.recommendations_json || '[]'),
      limitations: JSON.parse(row.limitations_json || '[]'),
      method: row.method,
      extractedText: row.extracted_text,
      analyzedAt: row.created_at,
    };
  },
};

export const IncidentRepo = {
  create(incident: Incident): Incident {
    db.prepare(`
      INSERT INTO incidents (
        id, report_id, user_id, category, description, suspicious_url,
        evidence_file_name, evidence_original_name, contact_info, status, consent_given, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      incident.id,
      incident.reportId,
      incident.userId || null,
      incident.category,
      incident.description,
      incident.suspiciousUrl || null,
      incident.evidenceFileName || null,
      incident.evidenceOriginalName || null,
      incident.contactInfo || null,
      incident.status,
      incident.consentGiven ? 1 : 0,
      incident.createdAt,
      incident.updatedAt
    );

    // Initial status history entry
    db.prepare(`
      INSERT INTO incident_status_history (id, incident_id, previous_status, new_status, changed_by, notes, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      crypto.randomUUID(),
      incident.id,
      'None',
      incident.status,
      incident.contactInfo ? 'Incident Reporter' : 'Anonymous Reporter',
      'Report submitted to platform.',
      incident.createdAt
    );

    return incident;
  },

  findByReportId(reportId: string): Incident | null {
    const row = db.prepare('SELECT * FROM incidents WHERE report_id = ?').get(reportId.toUpperCase()) as any;
    if (!row) return null;
    return this.mapRow(row);
  },

  findById(id: string): Incident | null {
    const row = db.prepare('SELECT * FROM incidents WHERE id = ?').get(id) as any;
    if (!row) return null;
    return this.mapRow(row);
  },

  list(filters: {
    userId?: string | null;
    isAdmin?: boolean;
    category?: IncidentCategory | 'all';
    status?: IncidentStatus | 'all';
    search?: string;
    page?: number;
    limit?: number;
  }): { items: Incident[]; total: number; page: number; totalPages: number } {
    const page = Math.max(1, filters.page || 1);
    const limit = Math.min(50, Math.max(1, filters.limit || 10));
    const offset = (page - 1) * limit;

    const conditions: string[] = [];
    const params: any[] = [];

    if (!filters.isAdmin) {
      if (filters.userId) {
        conditions.push('user_id = ?');
        params.push(filters.userId);
      } else {
        return { items: [], total: 0, page: 1, totalPages: 1 };
      }
    }

    if (filters.category && filters.category !== 'all') {
      conditions.push('category = ?');
      params.push(filters.category);
    }

    if (filters.status && filters.status !== 'all') {
      conditions.push('status = ?');
      params.push(filters.status);
    }

    if (filters.search) {
      conditions.push('(report_id LIKE ? OR description LIKE ? OR suspicious_url LIKE ?)');
      params.push(`%${filters.search}%`, `%${filters.search}%`, `%${filters.search}%`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const countRow = db.prepare(`SELECT COUNT(*) as count FROM incidents ${whereClause}`).get(...params) as any;
    const total = countRow ? countRow.count : 0;

    const rows = db.prepare(`
      SELECT * FROM incidents
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset) as any[];

    return {
      items: rows.map(r => this.mapRow(r)),
      total,
      page,
      totalPages: Math.ceil(total / limit) || 1,
    };
  },

  updateStatus(incidentId: string, newStatus: IncidentStatus, changedBy: string, notes?: string): Incident | null {
    const incident = this.findById(incidentId);
    if (!incident) return null;

    const now = new Date().toISOString();
    const prevStatus = incident.status;

    db.prepare(`
      UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?
    `).run(newStatus, now, incidentId);

    db.prepare(`
      INSERT INTO incident_status_history (id, incident_id, previous_status, new_status, changed_by, notes, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(crypto.randomUUID(), incidentId, prevStatus, newStatus, changedBy, notes || null, now);

    return this.findById(incidentId);
  },

  getStatusHistory(incidentId: string): IncidentStatusHistory[] {
    const rows = db.prepare(`
      SELECT * FROM incident_status_history WHERE incident_id = ? ORDER BY timestamp ASC
    `).all(incidentId) as any[];

    return rows.map(r => ({
      id: r.id,
      incidentId: r.incident_id,
      previousStatus: r.previous_status,
      newStatus: r.new_status,
      changedBy: r.changed_by,
      notes: r.notes,
      timestamp: r.timestamp,
    }));
  },

  mapRow(row: any): Incident {
    return {
      id: row.id,
      reportId: row.report_id,
      userId: row.user_id,
      category: row.category,
      description: row.description,
      suspiciousUrl: row.suspicious_url,
      evidenceFileName: row.evidence_file_name,
      evidenceOriginalName: row.evidence_original_name,
      contactInfo: row.contact_info,
      status: row.status,
      consentGiven: Boolean(row.consent_given),
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  },
};

export const QuizRepo = {
  saveAttempt(attempt: {
    userId?: string | null;
    quizIdentifier: string;
    score: number;
    totalQuestions: number;
    answers: { questionId: string; selectedIndex: number; isCorrect: boolean }[];
  }): QuizAttempt {
    const id = crypto.randomUUID();
    const completedAt = new Date().toISOString();

    db.prepare(`
      INSERT INTO quiz_attempts (id, user_id, quiz_identifier, score, total_questions, answers_json, completed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      attempt.userId || null,
      attempt.quizIdentifier,
      attempt.score,
      attempt.totalQuestions,
      JSON.stringify(attempt.answers),
      completedAt
    );

    return {
      id,
      userId: attempt.userId,
      quizIdentifier: attempt.quizIdentifier,
      score: attempt.score,
      totalQuestions: attempt.totalQuestions,
      answers: attempt.answers,
      completedAt,
    };
  },

  getAttempts(userId: string): QuizAttempt[] {
    const rows = db.prepare(`
      SELECT * FROM quiz_attempts WHERE user_id = ? ORDER BY completed_at DESC
    `).all(userId) as any[];

    return rows.map(r => ({
      id: r.id,
      userId: r.user_id,
      quizIdentifier: r.quiz_identifier,
      score: r.score,
      totalQuestions: r.total_questions,
      answers: JSON.parse(r.answers_json || '[]'),
      completedAt: r.completed_at,
    }));
  },
};

export const AnalyticsRepo = {
  getStats(userId?: string | null, isAdmin: boolean = false) {
    // Total scans
    const scanFilter = !isAdmin && userId ? 'WHERE (user_id = ? OR user_id IS NULL)' : '';
    const scanParams = !isAdmin && userId ? [userId] : [];

    const totalScans = (db.prepare(`SELECT COUNT(*) as count FROM scans ${scanFilter}`).get(...scanParams) as any)?.count || 0;
    const highRisk = (db.prepare(`SELECT COUNT(*) as count FROM scans ${scanFilter ? scanFilter + ' AND' : 'WHERE'} risk_level = 'high'`).get(...scanParams) as any)?.count || 0;
    const medRisk = (db.prepare(`SELECT COUNT(*) as count FROM scans ${scanFilter ? scanFilter + ' AND' : 'WHERE'} risk_level = 'medium'`).get(...scanParams) as any)?.count || 0;
    const lowRisk = (db.prepare(`SELECT COUNT(*) as count FROM scans ${scanFilter ? scanFilter + ' AND' : 'WHERE'} risk_level = 'low'`).get(...scanParams) as any)?.count || 0;

    // Incidents
    const incFilter = !isAdmin && userId ? 'WHERE user_id = ?' : '';
    const incParams = !isAdmin && userId ? [userId] : [];

    const totalReports = (db.prepare(`SELECT COUNT(*) as count FROM incidents ${incFilter}`).get(...incParams) as any)?.count || 0;
    const pendingReports = (db.prepare(`SELECT COUNT(*) as count FROM incidents ${incFilter ? incFilter + ' AND' : 'WHERE'} status IN ('Submitted', 'Under Review')`).get(...incParams) as any)?.count || 0;
    const resolvedReports = (db.prepare(`SELECT COUNT(*) as count FROM incidents ${incFilter ? incFilter + ' AND' : 'WHERE'} status IN ('Resolved', 'Closed')`).get(...incParams) as any)?.count || 0;

    // Recent scans
    const recentScansRows = db.prepare(`SELECT * FROM scans ${scanFilter} ORDER BY created_at DESC LIMIT 5`).all(...scanParams) as any[];
    const recentScans = recentScansRows.map(r => ScanRepo.mapRow(r));

    // Recent incidents
    const recentIncRows = db.prepare(`SELECT * FROM incidents ${incFilter} ORDER BY created_at DESC LIMIT 5`).all(...incParams) as any[];
    const recentIncidents = recentIncRows.map(r => IncidentRepo.mapRow(r));

    // Risk distribution
    const riskDistribution = [
      { name: 'High Risk', value: highRisk, color: '#FB7185' },
      { name: 'Medium Risk', value: medRisk, color: '#FBBF24' },
      { name: 'Low Risk', value: lowRisk, color: '#34D399' },
    ];

    // Trends calculation for the last 7 days
    const trendsMap = new Map<string, { url: number; email: number; sms: number; screenshot: number }>();
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 86400000);
      const key = d.toISOString().split('T')[0];
      trendsMap.set(key, { url: 0, email: 0, sms: 0, screenshot: 0 });
    }

    const scansLast7Days = db.prepare(`
      SELECT input_type, strftime('%Y-%m-%d', created_at) as day, COUNT(*) as count
      FROM scans
      ${scanFilter}
      GROUP BY day, input_type
    `).all(...scanParams) as any[];

    for (const row of scansLast7Days) {
      if (trendsMap.has(row.day)) {
        const item = trendsMap.get(row.day)!;
        if (row.input_type === 'url') item.url += row.count;
        if (row.input_type === 'email') item.email += row.count;
        if (row.input_type === 'sms') item.sms += row.count;
        if (row.input_type === 'screenshot') item.screenshot += row.count;
      }
    }

    const scanTrends = Array.from(trendsMap.entries()).map(([date, counts]) => ({
      date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      ...counts,
    }));

    return {
      totalScans,
      highRiskCount: highRisk,
      mediumRiskCount: medRisk,
      lowRiskCount: lowRisk,
      totalReports,
      pendingReports,
      resolvedReports,
      riskDistribution,
      scanTrends,
      recentScans,
      recentIncidents,
      isDemoData: totalScans === 0 && totalReports > 0,
    };
  },
};
