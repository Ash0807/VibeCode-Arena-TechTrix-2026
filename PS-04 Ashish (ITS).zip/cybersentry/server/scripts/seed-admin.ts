import dotenv from 'dotenv';
import { db, initDatabase, hashPassword } from '../db/database.js';
import { UserRepo } from '../db/repository.js';
import crypto from 'node:crypto';

dotenv.config();

initDatabase();

const email = (process.argv[2] || process.env.ADMIN_EMAIL || 'admin@cybersentry.local').toLowerCase();
const password = process.argv[3] || process.env.ADMIN_PASSWORD || 'CyberSentry#Admin2026!';
const name = process.argv[4] || 'CyberSentry Security Team';

const existing = UserRepo.findByEmail(email);

if (existing) {
  db.prepare(`
    UPDATE users SET role = 'admin', password_hash = ?, name = ? WHERE id = ?
  `).run(hashPassword(password), name, existing.id);
  console.log(`✅ Administrator account updated for ${email}`);
} else {
  const id = crypto.randomUUID();
  db.prepare(`
    INSERT INTO users (id, email, password_hash, role, name, created_at)
    VALUES (?, ?, ?, 'admin', ?, ?)
  `).run(id, email, hashPassword(password), name, new Date().toISOString());
  console.log(`✅ New Administrator account created: ${email}`);
}

console.log(`🛡️ Admin Credentials:\n   Email: ${email}\n   Password: ${password}`);
