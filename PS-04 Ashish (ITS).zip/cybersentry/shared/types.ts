export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name?: string;
  createdAt: string;
}

export type InputType = 'url' | 'email' | 'sms' | 'screenshot';
export type RiskLevel = 'low' | 'medium' | 'high';

export interface Finding {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'info';
  category: string;
  matchedSample?: string;
  whyItMatters: string;
}

export interface Recommendation {
  id: string;
  title: string;
  action: string;
  priority: 'immediate' | 'recommended' | 'optional';
}

export interface ScanResult {
  scanId: string;
  userId?: string | null;
  inputType: InputType;
  riskLevel: RiskLevel;
  riskScore: number; // 0 to 100
  summary: string;
  inputPreview: string;
  findings: Finding[];
  recommendations: Recommendation[];
  limitations: string[];
  method: 'rule_heuristics' | 'ai_enhanced' | 'threat_intelligence';
  analyzedAt: string;
  extractedText?: string;
}

export type IncidentCategory =
  | 'phishing'
  | 'upi_fraud'
  | 'impersonation'
  | 'fake_website'
  | 'account_compromise'
  | 'shopping_fraud'
  | 'social_engineering'
  | 'other';

export type IncidentStatus = 'Submitted' | 'Under Review' | 'Resolved' | 'Closed';

export interface Incident {
  id: string;
  reportId: string;
  userId?: string | null;
  category: IncidentCategory;
  description: string;
  suspiciousUrl?: string;
  evidenceFileName?: string;
  evidenceOriginalName?: string;
  contactInfo?: string;
  status: IncidentStatus;
  consentGiven: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface IncidentStatusHistory {
  id: string;
  incidentId: string;
  previousStatus: IncidentStatus;
  newStatus: IncidentStatus;
  changedBy: string;
  notes?: string;
  timestamp: string;
}

export interface Lesson {
  id: string;
  title: string;
  category: string;
  readTime: string;
  summary: string;
  realWorldExample: string;
  warningSigns: string[];
  checklist: string[];
  whatToDoIfAffected: string[];
  relatedLessons: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category: string;
  relatedLessonId?: string;
}

export interface QuizAttempt {
  id: string;
  userId?: string | null;
  quizIdentifier: string;
  score: number;
  totalQuestions: number;
  completedAt: string;
  answers: {
    questionId: string;
    selectedIndex: number;
    isCorrect: boolean;
  }[];
}

export interface DashboardStats {
  totalScans: number;
  highRiskCount: number;
  mediumRiskCount: number;
  lowRiskCount: number;
  totalReports: number;
  pendingReports: number;
  resolvedReports: number;
  riskDistribution: { name: string; value: number; color: string }[];
  scanTrends: { date: string; url: number; email: number; sms: number; screenshot: number }[];
  recentScans: ScanResult[];
  recentIncidents: Incident[];
  isDemoData?: boolean;
}
