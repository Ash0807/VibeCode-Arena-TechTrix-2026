# CyberSentry — Your Digital Safety Guardian 🛡️

**Tagline:** Your Digital Safety Guardian.

CyberSentry is a production-grade cybersecurity verification and awareness platform designed to protect individuals and organizations from modern social engineering, phishing, UPI payment fraud, smishing, and identity theft. The platform empowers users to safely inspect suspicious URLs, emails, SMS messages, and screenshots without exposing themselves to malicious infrastructure or executing untrusted code.

---

## 🌟 Key Features

### 1. Multi-Modal Threat Scanner
- **URL Scanner:** Static structural inspection detecting punycode/homoglyph attacks (`xn--`), userinfo credential stuffing (`user:pass@host`), raw IP hostnames, misleading subdomain stacking, suspicious brand typosquatting (SBI, HDFC, PayPal, Google, Amazon, India Post, Income Tax), unencrypted HTTP connections, and known shorteners (`bit.ly`, `tinyurl.com`).
- **Email Scanner:** Identifies urgency & pressure coercion, unauthorized requests for credentials/OTPs/PINs, financial wire/cryptocurrency solicitations, authority impersonation, and sender domain discrepancies (such as institutions using free `@gmail.com` webmail).
- **SMS & Chat Scanner:** Calibrated detection for UPI reverse-charge traps ("enter PIN to receive cashback"), fake KYC account deactivation threats, postal parcel redelivery smishing, and utility power-cut extortion schemes.
- **Screenshot OCR Scanner:** Safe client/server image processing for PNG, JPEG, and WebP screenshots using local Tesseract OCR. Extracts text without cloud leakage, enables user review, and runs the heuristic engine.

### 2. Transparent Heuristic Risk Engine & Results
- **Deterministic Risk Scoring:** Calibrated scoring (0 to 100) and risk levels (Low, Medium, High).
- **"Why This Matters" Explanations:** Plain-English educational rationale for every detected pattern.
- **Prioritized Recommendations:** Categorized into Immediate Actions, Recommended Verification, and Optional Hygiene.
- **System Limitations & Uncertainties:** Transparent disclosure that heuristic indicators indicate risk rather than definitive certainty, and no live destinations are visited to protect user privacy and avoid triggering adversary tracking.

### 3. Incident Reporting & Public Tracking
- **Structured Incident Reporting:** Supports reporting phishing, UPI fraud, impersonation, fake websites, account compromise, and shopping scams with optional file evidence attachment.
- **Unique Report Identifiers:** Generates trackable IDs (e.g. `CS-2026-9481`).
- **Status Stepper Timeline:** Real-time visualization through progression stages: `Submitted` ➔ `Under Review` ➔ `Resolved` ➔ `Closed`.
- **Audit History:** Full log of timestamps, status changes, and reviewer notes.
- **Official Emergency Reporting:** Direct integration and guidance for India's National Cybercrime Portal (`cybercrime.gov.in`), Citizen Financial Cyber Fraud Helpline (`1930`), DoT Chakshu portal, and RBI Sachet.

### 4. Cyber Academy & Interactive Certification Quiz
- **12 In-Depth Lessons:** Covering Phishing, Smishing, UPI Fraud, OTP Impersonation, Password Management, MFA Security, Fake Websites, QR Code Quishing, Social Engineering, Safe Browsing, Account Recovery, and Reporting Cybercrime in India.
- **15-Question Interactive Quiz:** One question at a time with instant feedback, explanations, animated progress, performance badges (Cyber Guardian, Security Aware Defender), and retry capabilities.

### 5. Administrator Triage Console
- **Guarded Server-Side Authorization:** Role-based access control protecting administrative endpoints and UI.
- **Incident Queue:** Search, filter by status or category, review evidence, update case statuses with reviewer audit notes.
- **Aggregated Analytics:** Live metrics for total scans, risk distribution, pending reports, and weekly trend graphs.

### 6. User Privacy & Settings
- **Strict Data Sovereignty:** Zero retention of passwords, banking PINs, or raw OTPs.
- **Export & Delete Controls:** One-click offline JSON export and complete scan history erasure.

---

## 🛠️ Technology Stack

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, Lucide React icons, Recharts, React Router v6.
- **Backend:** Node.js v24, Express, TypeScript, Zod, Built-in `node:sqlite` with WAL mode and foreign keys.
- **Security:** Scrypt password hashing, HTTP-only session cookies (`SameSite: lax`), rate limiting, CSRF protection, file upload validation (multer with MIME & size limits).
- **Testing:** Vitest, Supertest, React Testing Library.

---

## 📂 Project Structure

```
cybersentry/
├── data/                         # SQLite database storage (cybersentry.db)
├── uploads/                      # Secure temporary evidence & upload directory
├── server/
│   ├── db/
│   │   ├── database.ts           # node:sqlite connection, migrations & initial seed
│   │   └── repository.ts         # User, Session, Scan, Incident, and Analytics repos
│   ├── middleware/
│   │   ├── auth-middleware.ts    # Session verification & admin role guards
│   │   ├── rate-limiter.ts       # Rate limiting on auth, scan, and report endpoints
│   │   └── upload-middleware.ts  # Multer file validation with MIME & size checks
│   ├── routes/
│   │   ├── auth-routes.ts        # Register, Login, Logout, Me
│   │   ├── scan-routes.ts        # URL, Text, Image scanning & history management
│   │   ├── incident-routes.ts    # Report creation, tracking, status updates, evidence
│   │   ├── dashboard-routes.ts   # Aggregate analytics & trend charts
│   │   └── academy-routes.ts     # 12 Lessons, 15 Quiz questions & attempts
│   ├── services/
│   │   ├── risk-scorer.ts        # Calibrated 0-100 scoring & summary generation
│   │   ├── url-analyzer.ts       # URL RFC parsing, punycode, brand typosquatting
│   │   ├── email-analyzer.ts     # Urgency, BEC, credential request patterns
│   │   ├── sms-analyzer.ts       # Smishing, UPI fraud, electricity extortion
│   │   ├── ocr-service.ts        # Local Tesseract OCR processing with fallback
│   │   ├── ai-service.ts         # Optional AI enhancement with schema validation
│   │   ├── threat-intel-service.ts # Optional threat intelligence feed adapter
│   │   └── academy-data.ts       # Original lesson content & 15 quiz questions
│   ├── scripts/
│   │   └── seed-admin.ts         # CLI administrator creation script
│   └── index.ts                  # Express server entry point & static SPA serving
├── src/
│   ├── components/
│   │   ├── ShieldLogo.tsx        # Brand shield logo component
│   │   ├── Sidebar.tsx           # Collapsible desktop sidebar & mobile drawer
│   │   ├── Navbar.tsx            # Header with status indicator & quick scan CTA
│   │   ├── Footer.tsx            # Official emergency helpline banner & disclaimers
│   │   ├── ConfirmModal.tsx      # Reusable confirmation dialog for destructive actions
│   │   └── Toast.tsx             # Toast notification alerts
│   ├── context/
│   │   ├── AuthContext.tsx       # User session state & login/register/logout hooks
│   │   └── ToastContext.tsx      # Success, warning, error, info toast system
│   ├── pages/
│   │   ├── Dashboard.tsx         # Executive overview, metrics, Recharts trends
│   │   ├── ThreatScanner.tsx     # 4-mode scanner with sample presets & live results
│   │   ├── AnalysisResults.tsx   # Detailed report, risk meter, "Why It Matters"
│   │   ├── ScanHistory.tsx       # Search, filter, pagination, single/all deletion
│   │   ├── IncidentReporting.tsx # Step-by-step incident documentation form
│   │   ├── IncidentTracking.tsx  # Public/user Report ID status lookup & timeline
│   │   ├── IncidentDetail.tsx    # Case file view with admin status transition controls
│   │   ├── CyberAcademy.tsx      # 12-lesson educational catalog with category filter
│   │   ├── LessonDetail.tsx      # Full lesson guide, real scenario & checklists
│   │   ├── InteractiveQuiz.tsx   # 15 questions, instant feedback & performance rank
│   │   ├── AdminDashboard.tsx    # Admin incident queue, status changer & audit trail
│   │   ├── UserSettings.tsx      # Privacy notice, JSON export & data erasure
│   │   ├── Login.tsx             # Authentication form with quick-fill demo buttons
│   │   └── Register.tsx          # Account creation with validation
│   ├── App.tsx                   # React Router routing & layout structure
│   ├── main.tsx                  # React entry point
│   └── index.css                 # Tailwind CSS & custom dark SaaS scrollbar styles
├── shared/
│   └── types.ts                  # Shared TypeScript interfaces & models
├── tests/
│   ├── risk-scorer.test.ts       # Unit tests for scoring logic & deduplication
│   ├── url-analyzer.test.ts      # Unit tests for URL heuristics & typosquatting
│   ├── email-sms-analyzer.test.ts# Unit tests for urgency, BEC & UPI scam detection
│   └── api-auth-incidents-scans.test.ts # Supertest API integration test suite
├── .env.example                  # Environment configuration template
├── package.json
├── tailwind.config.js            # Custom CyberSentry dark theme palette
├── vite.config.ts                # Vite config with API proxying & aliases
└── vitest.config.ts              # Vitest test runner configuration
```

---

## 🚀 Installation and Setup

### 1. Prerequisites
- **Node.js:** v20+ or v24+ (Node v24 includes built-in `node:sqlite`).
- **NPM:** v10+.

### 2. Clone / Locate Directory
```bash
cd "C:\Users\Aaryan Pal\.gemini\antigravity\scratch\cybersentry"
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Default `.env` settings:
```env
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000
DATABASE_PATH=./data/cybersentry.db
SESSION_SECRET=cybersentry-super-secure-production-secret-change-in-prod-min-32-chars
COOKIE_SECURE=false
MAX_UPLOAD_SIZE_MB=5
ADMIN_EMAIL=admin@cybersentry.local
ADMIN_PASSWORD=CyberSentry#Admin2026!
```

### 5. Seed Initial Administrator & Demo Data
The application automatically creates database tables, indices, and seeds the initial administrator and demonstration incidents on startup. You can also re-run the CLI seed script anytime:
```bash
npm run seed:admin
```

---

## 🏃 Running the Application

### Option A: Unified Production Build (Recommended)
Build both the frontend and backend, then serve them together on port 5000:
```bash
npm run build
npm start
```
Open **`http://localhost:5000`** in your browser.

### Option B: Concurrent Development Mode
Runs the backend API on port 5000 and Vite HMR dev server on port 3000:
```bash
npm run dev
```
Open **`http://localhost:3000`** in your browser.

---

## 🧪 Automated Testing & Verification

Run the complete test suite (Unit tests + Supertest API integration tests):
```bash
npm test
```

### Test Results Summary:
```
✓ tests/risk-scorer.test.ts (3 tests)
✓ tests/url-analyzer.test.ts (6 tests)
✓ tests/email-sms-analyzer.test.ts (4 tests)
✓ tests/api-auth-incidents-scans.test.ts (14 tests)

Test Files  4 passed (4)
Tests       27 passed (27)
```

Verified test coverage includes:
- URL parsing, syntax validation, direct IP detection, punycode, and typosquatting.
- Email urgency, authority bias, and credential solicitation patterns.
- SMS banking smishing, fake delivery notices, and UPI reverse-charge traps.
- Risk scoring calibration, threshold logic, and finding deduplication.
- API authentication, password hashing, and session cookie issuance.
- Role-based authorization: non-admin users receive `403 Forbidden` on admin endpoints.
- Incident report generation (`CS-2026-XXXX`) and public status tracking.
- Admin status updates with notes and audit history persistence.
- Private scan history isolation and single/bulk deletion.
- Input validation and empty/invalid request error handling.

---

## 🛡️ Security & Privacy Considerations

1. **Zero Credential Harvesting:** Users are warned to redact passwords, OTPs, and card numbers. The platform never persistently stores credentials or payment PINs.
2. **SSRF & Adversary Tracking Prevention:** The backend never visits, renders, or executes remote URLs submitted by users. All link analyses are static and structural.
3. **Local OCR Processing:** Tesseract OCR executes on the local server without transmitting uploaded user screenshots to external third-party APIs.
4. **Session Isolation:** Scans and incidents are isolated by user session. Non-admin users cannot access other users' private scan logs.
5. **No False Guarantees:** The engine clearly discloses that heuristic evaluations are indicators rather than definitive safety certifications.

---

## 🔑 Demo Credentials

| Role | Email | Password |
|---|---|---|
| **Administrator** | `admin@cybersentry.local` | `CyberSentry#Admin2026!` |
| **Standard User** | `user@cybersentry.local` | `UserSafe123!` |

*(Both accounts are pre-seeded in the local database and can also be autofilled with one click on the `/login` screen).*
