import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { UserPlus, Lock, Mail, User, ShieldAlert } from 'lucide-react';
import { ShieldLogo } from '../components/ShieldLogo';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    if (password.length < 8) {
      setErrorMsg('Password must be at least 8 characters long.');
      return;
    }

    setIsSubmitting(true);
    const result = await register(email, password, name.trim() || undefined);
    setIsSubmitting(false);

    if (result.success) {
      toastSuccess('Account Created', 'Welcome to CyberSentry Guardian.');
      navigate('/');
    } else {
      setErrorMsg(result.error || 'Failed to create account.');
      toastError('Registration Failed', result.error);
    }
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center p-4 animate-fadeIn">
      <div className="max-w-md w-full rounded-3xl bg-[#101E30] border border-[#1D3352] p-8 shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <ShieldLogo size={42} showText={false} />
          </div>
          <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Create Guardian Account</h1>
          <p className="text-xs text-[#9AABC2]">
            Keep your scan history secure and track your incident escalations
          </p>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-[#FB7185]/15 border border-[#FB7185]/40 text-xs text-[#FB7185]">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Full Name (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Alex Mercer"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <User className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Email Address *
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="analyst@domain.com"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <Mail className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Password (min 8 chars) *
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <Lock className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Confirm Password *
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <Lock className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] font-bold text-xs shadow-glow-primary hover:opacity-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <UserPlus className="w-4 h-4" />
            <span>{isSubmitting ? 'Creating Account...' : 'Create Account'}</span>
          </button>
        </form>

        <div className="text-center text-xs text-[#9AABC2]">
          Already have an account?{' '}
          <NavLink to="/login" className="text-[#39D9E8] font-bold hover:underline">
            Sign In here
          </NavLink>
        </div>
      </div>
    </div>
  );
};
