import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { LogIn, Lock, Mail, ShieldAlert, Sparkles, ArrowRight } from 'lucide-react';
import { ShieldLogo } from '../components/ShieldLogo';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const from = (location.state as any)?.from?.pathname || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const result = await login(email, password);
    setIsSubmitting(false);

    if (result.success) {
      toastSuccess('Signed In', 'Welcome to CyberSentry Guardian.');
      navigate(from, { replace: true });
    } else {
      setErrorMsg(result.error || 'Invalid email or password.');
      toastError('Login Failed', result.error);
    }
  };

  const handleQuickFill = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center p-4 animate-fadeIn">
      <div className="max-w-md w-full rounded-3xl bg-[#101E30] border border-[#1D3352] p-8 shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <ShieldLogo size={42} showText={false} />
          </div>
          <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Sign In to CyberSentry</h1>
          <p className="text-xs text-[#9AABC2]">
            Access your private threat scan history and incident tracking files
          </p>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-[#FB7185]/15 border border-[#FB7185]/40 text-xs text-[#FB7185]">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Email Address
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="analyst@cybersentry.local"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <Mail className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-1.5 uppercase tracking-wider">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
              />
              <Lock className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] font-bold text-xs shadow-glow-primary hover:opacity-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <LogIn className="w-4 h-4" />
            <span>{isSubmitting ? 'Authenticating...' : 'Sign In'}</span>
          </button>
        </form>

        {/* Evaluation Demo Quick-Fill Buttons */}
        <div className="pt-4 border-t border-[#1D3352] space-y-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#9AABC2] block text-center">
            Demo Credentials (Click to Autofill)
          </span>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <button
              type="button"
              onClick={() => handleQuickFill('user@cybersentry.local', 'UserSafe123!')}
              className="p-2 rounded-lg bg-[#07111F] hover:bg-[#13233A] border border-[#1D3352] text-[#39D9E8] text-center transition-colors"
            >
              Demo User
            </button>
            <button
              type="button"
              onClick={() => handleQuickFill('admin@cybersentry.local', 'CyberSentry#Admin2026!')}
              className="p-2 rounded-lg bg-[#07111F] hover:bg-[#13233A] border border-[#8B7CFF]/40 text-[#8B7CFF] text-center transition-colors font-semibold"
            >
              Demo Admin
            </button>
          </div>
        </div>

        <div className="text-center text-xs text-[#9AABC2]">
          Don't have an account yet?{' '}
          <NavLink to="/register" className="text-[#39D9E8] font-bold hover:underline">
            Register here
          </NavLink>
        </div>
      </div>
    </div>
  );
};
