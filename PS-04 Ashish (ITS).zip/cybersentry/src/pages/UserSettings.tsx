import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Settings,
  ShieldCheck,
  User,
  Trash2,
  Download,
  AlertTriangle,
  Lock,
  Eye,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ConfirmModal } from '../components/ConfirmModal';

export const UserSettings: React.FC = () => {
  const { user } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();
  const [clearDataModalOpen, setClearDataModalOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleExportData = async () => {
    setIsExporting(true);
    try {
      const res = await fetch('/api/scans?limit=50', { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to retrieve scan records');
      const data = await res.json();

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cybersentry_scans_export_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toastSuccess('Export Complete', 'Downloaded your scan records.');
    } catch (err: any) {
      toastError('Export Failed', err?.message || 'Could not export data');
    } finally {
      setIsExporting(false);
    }
  };

  const handleClearAllData = async () => {
    try {
      const res = await fetch('/api/scans', { method: 'DELETE', credentials: 'include' });
      if (res.ok) {
        toastSuccess('Data Deleted', 'All your stored scan results have been permanently erased.');
        setClearDataModalOpen(false);
      } else {
        toastError('Failed to erase data', 'Server error deleting records.');
      }
    } catch {
      toastError('Network Error', 'Error communicating with server.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn pb-12">
      <div>
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-[#39D9E8]/10 text-[#39D9E8]">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Settings & Privacy</h1>
            <p className="text-xs text-[#9AABC2]">
              Manage your profile, data retention controls, and review platform privacy policies
            </p>
          </div>
        </div>
      </div>

      {/* Account Profile Card */}
      <div className="p-6 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-4 shadow-xl">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2]">
          User Identity & Session
        </h2>

        {user ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#07111F] border border-[#1D3352]">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#39D9E8]/20 border border-[#39D9E8]/40 flex items-center justify-center text-[#39D9E8] font-bold text-base uppercase">
                {user.name ? user.name[0] : user.email[0]}
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#EDF5FF]">{user.name || 'Security Analyst'}</h3>
                <p className="text-xs text-[#9AABC2]">{user.email}</p>
                <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#39D9E8]/10 text-[#39D9E8] uppercase">
                  {user.role} Role
                </span>
              </div>
            </div>

            <div className="text-xs text-[#9AABC2]">
              <span>Member since: {new Date(user.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-[#07111F] border border-[#1D3352] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-[#EDF5FF]">Anonymous Session</h3>
              <p className="text-xs text-[#9AABC2]">
                You are currently exploring as an anonymous guest. Scans are saved to your local browser session.
              </p>
            </div>
            <NavLink
              to="/login"
              className="px-4 py-2 rounded-xl bg-[#39D9E8] text-[#07111F] font-bold text-xs shadow-glow-primary self-start sm:self-auto shrink-0"
            >
              Sign In / Register
            </NavLink>
          </div>
        )}
      </div>

      {/* Privacy Policy & Architectural Protections */}
      <div className="p-6 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-4 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#34D399]">
          <ShieldCheck className="w-4 h-4" />
          <span>Platform Privacy Architecture & Principles</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-[#07111F] border border-[#1D3352] space-y-2">
            <h4 className="font-bold text-[#EDF5FF] flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#39D9E8]" />
              Zero Credential Storage
            </h4>
            <p className="text-[#9AABC2] leading-relaxed">
              CyberSentry strictly prohibits collecting or persisting passwords, UPI PINs, banking cards,
              or OTP tokens. Always redact private keys before uploading.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#07111F] border border-[#1D3352] space-y-2">
            <h4 className="font-bold text-[#EDF5FF] flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-[#8B7CFF]" />
              Local Heuristic Verification
            </h4>
            <p className="text-[#9AABC2] leading-relaxed">
              Threat scoring is executed locally on the server using rule-based heuristics and local Tesseract
              OCR. No submitted links are visited over the network to prevent SSRF and tracking.
            </p>
          </div>
        </div>
      </div>

      {/* Data Sovereignty & Retention Controls */}
      <div className="p-6 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-4 shadow-xl">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2]">
          Data Sovereignty & User Controls
        </h2>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#07111F] border border-[#1D3352]">
          <div>
            <h3 className="text-sm font-bold text-[#EDF5FF]">Export Security History</h3>
            <p className="text-xs text-[#9AABC2]">
              Download an offline JSON archive of all your heuristic scan results and findings.
            </p>
          </div>
          <button
            onClick={handleExportData}
            disabled={isExporting}
            className="px-4 py-2 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#39D9E8] border border-[#1D3352] transition-colors flex items-center gap-2 self-start sm:self-auto shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Exporting...' : 'Export JSON'}</span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#07111F] border border-[#FB7185]/30">
          <div>
            <h3 className="text-sm font-bold text-[#FB7185]">Permanently Erase Stored History</h3>
            <p className="text-xs text-[#9AABC2]">
              Instantly delete all historical scan records and associated findings from the database.
            </p>
          </div>
          <button
            onClick={() => setClearDataModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-[#FB7185]/10 hover:bg-[#FB7185]/20 text-xs font-semibold text-[#FB7185] border border-[#FB7185]/30 transition-colors flex items-center gap-2 self-start sm:self-auto shrink-0"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All Data</span>
          </button>
        </div>
      </div>

      <ConfirmModal
        isOpen={clearDataModalOpen}
        title="Permanently Delete All Scan Data?"
        message="This action will delete all your threat analysis logs, risk scores, and findings. This operation cannot be reversed."
        confirmText="Erase Everything"
        onConfirm={handleClearAllData}
        onCancel={() => setClearDataModalOpen(false)}
      />
    </div>
  );
};
