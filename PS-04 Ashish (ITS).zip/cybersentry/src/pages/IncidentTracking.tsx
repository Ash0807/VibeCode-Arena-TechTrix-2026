import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Search,
  SearchCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  PhoneCall,
  ExternalLink,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import type { IncidentStatus, IncidentStatusHistory } from '@shared/types';
import { useToast } from '../context/ToastContext';

interface TrackedReport {
  reportId: string;
  category: string;
  description: string;
  suspiciousUrl?: string;
  hasEvidence: boolean;
  status: IncidentStatus;
  createdAt: string;
  updatedAt: string;
  history: IncidentStatusHistory[];
}

const STATUS_STEPS: IncidentStatus[] = ['Submitted', 'Under Review', 'Resolved', 'Closed'];

export const IncidentTracking: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { error: toastError } = useToast();

  const initialId = searchParams.get('id') || '';
  const [reportIdInput, setReportIdInput] = useState(initialId);
  const [report, setReport] = useState<TrackedReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const fetchIncident = async (idToSearch: string) => {
    if (!idToSearch.trim()) return;
    setLoading(true);
    setHasSearched(true);
    try {
      const res = await fetch(`/api/incidents/track/${encodeURIComponent(idToSearch.trim())}`);
      const data = await res.json();
      if (!res.ok) {
        setReport(null);
        toastError('Report Not Found', data.error || 'No incident found with this tracking ID.');
      } else {
        setReport(data);
      }
    } catch {
      toastError('Network Error', 'Failed to communicate with the tracking server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialId) {
      fetchIncident(initialId);
    }
  }, [initialId]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchIncident(reportIdInput);
  };

  const getStepIndex = (status: IncidentStatus) => {
    return STATUS_STEPS.indexOf(status);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-[#39D9E8]/10 text-[#39D9E8]">
            <SearchCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Incident Status Tracking</h1>
            <p className="text-xs text-[#9AABC2]">
              Track verification progress and review investigation logs using your Report ID
            </p>
          </div>
        </div>
      </div>

      {/* Lookup Search Bar */}
      <div className="p-6 rounded-3xl bg-[#101E30] border border-[#1D3352] shadow-xl">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={reportIdInput}
              onChange={e => setReportIdInput(e.target.value)}
              placeholder="Enter Report ID (e.g. CS-2026-9481)"
              className="w-full px-4 py-3 pl-11 rounded-xl bg-[#07111F] border border-[#1D3352] text-sm text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8] font-mono uppercase"
            />
            <Search className="w-5 h-5 text-[#9AABC2] absolute left-3.5 top-3.5" />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#39D9E8] hover:bg-[#2fc0ce] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all flex items-center justify-center gap-2 shrink-0"
          >
            <span>{loading ? 'Searching...' : 'Track Report'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-[#9AABC2]">
          <span>Try sample demo reports:</span>
          <button
            type="button"
            onClick={() => {
              setReportIdInput('CS-2026-9481');
              fetchIncident('CS-2026-9481');
            }}
            className="px-2 py-0.5 rounded bg-[#13233A] hover:bg-[#1D3352] font-mono text-[#39D9E8] transition-colors"
          >
            CS-2026-9481
          </button>
          <button
            type="button"
            onClick={() => {
              setReportIdInput('CS-2026-8172');
              fetchIncident('CS-2026-8172');
            }}
            className="px-2 py-0.5 rounded bg-[#13233A] hover:bg-[#1D3352] font-mono text-[#39D9E8] transition-colors"
          >
            CS-2026-8172
          </button>
          <button
            type="button"
            onClick={() => {
              setReportIdInput('CS-2026-7320');
              fetchIncident('CS-2026-7320');
            }}
            className="px-2 py-0.5 rounded bg-[#13233A] hover:bg-[#1D3352] font-mono text-[#39D9E8] transition-colors"
          >
            CS-2026-7320
          </button>
        </div>
      </div>

      {/* Incident Result Display */}
      {report && (
        <div className="space-y-6 animate-fadeIn">
          {/* Status Header Card */}
          <div className="p-6 lg:p-8 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-6 shadow-2xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#1D3352]">
              <div>
                <span className="text-xs font-bold font-mono text-[#39D9E8] uppercase tracking-wider">
                  Report Identifier: {report.reportId}
                </span>
                <h2 className="text-xl font-bold text-[#EDF5FF] capitalize mt-1">
                  {report.category.replace('_', ' ')} Incident
                </h2>
                <p className="text-xs text-[#9AABC2] mt-0.5">
                  Logged on {new Date(report.createdAt).toLocaleString()}
                </p>
              </div>

              <span
                className={`text-xs font-bold px-3 py-1 rounded-full uppercase self-start sm:self-auto ${
                  report.status === 'Resolved'
                    ? 'bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40'
                    : report.status === 'Under Review'
                    ? 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40'
                    : report.status === 'Closed'
                    ? 'bg-[#9AABC2]/20 text-[#9AABC2] border border-[#9AABC2]/40'
                    : 'bg-[#39D9E8]/20 text-[#39D9E8] border border-[#39D9E8]/40'
                }`}
              >
                Status: {report.status}
              </span>
            </div>

            {/* Visual Status Stepper */}
            <div>
              <div className="flex items-center justify-between relative mb-2">
                <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-[#1D3352] -translate-y-1/2 z-0" />
                <div
                  className="absolute top-1/2 left-0 h-0.5 bg-[#39D9E8] -translate-y-1/2 z-0 transition-all duration-500"
                  style={{
                    width: `${(getStepIndex(report.status) / (STATUS_STEPS.length - 1)) * 100}%`,
                  }}
                />

                {STATUS_STEPS.map((step, idx) => {
                  const currentIdx = getStepIndex(report.status);
                  const isDone = idx <= currentIdx;
                  const isCurrent = idx === currentIdx;

                  return (
                    <div key={step} className="relative z-10 flex flex-col items-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isDone
                            ? 'bg-[#39D9E8] text-[#07111F] shadow-glow-primary'
                            : 'bg-[#101E30] text-[#9AABC2] border-2 border-[#1D3352]'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                      </div>
                      <span
                        className={`text-[10px] mt-2 font-semibold text-center whitespace-nowrap ${
                          isCurrent ? 'text-[#39D9E8]' : isDone ? 'text-[#EDF5FF]' : 'text-[#9AABC2]'
                        }`}
                      >
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Description Details */}
            <div className="p-4 rounded-xl bg-[#07111F] border border-[#1D3352] space-y-2 text-xs">
              <span className="font-bold uppercase tracking-wider text-[#9AABC2] block">
                Reported Incident Narrative
              </span>
              <p className="text-[#EDF5FF] leading-relaxed">{report.description}</p>
              {report.suspiciousUrl && (
                <div className="pt-2 font-mono text-[#39D9E8] break-all">
                  Target Destination: {report.suspiciousUrl}
                </div>
              )}
            </div>

            {/* Status History Timeline */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] mb-3">
                Investigation Audit Trail
              </h3>
              <div className="space-y-3">
                {report.history.map(item => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] flex items-start gap-3 text-xs"
                  >
                    <Clock className="w-4 h-4 text-[#39D9E8] shrink-0 mt-0.5" />
                    <div className="flex-1 space-y-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-bold text-[#EDF5FF]">
                          Status Changed to: <span className="text-[#39D9E8]">{item.newStatus}</span>
                        </span>
                        <span className="text-[11px] text-[#9AABC2]">
                          {new Date(item.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#9AABC2]">
                        Audited by: <strong className="text-[#EDF5FF]">{item.changedBy}</strong>
                      </div>
                      {item.notes && (
                        <p className="text-xs text-[#EDF5FF] mt-1 bg-[#07111F]/60 p-2 rounded-lg border border-[#1D3352]/60">
                          {item.notes}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {hasSearched && !report && !loading && (
        <div className="p-12 rounded-3xl bg-[#101E30] border border-[#1D3352] text-center space-y-3">
          <AlertTriangle className="w-10 h-10 text-[#FB7185] mx-auto" />
          <h3 className="text-base font-bold text-[#EDF5FF]">No Incident Record Found</h3>
          <p className="text-xs text-[#9AABC2] max-w-sm mx-auto">
            Please double-check the Report ID format (e.g. CS-2026-XXXX). If you just submitted a report,
            ensure the ID matches your submission screen.
          </p>
        </div>
      )}
    </div>
  );
};
