import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Link2,
  Mail,
  MessageSquare,
  Camera,
  ShieldAlert,
  Trash2,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  Upload,
  CheckCircle2,
  HelpCircle,
  FileText,
} from 'lucide-react';
import type { InputType, ScanResult } from '@shared/types';
import { useToast } from '../context/ToastContext';

const PRESETS = {
  url: [
    {
      label: 'Suspicious Bank Impersonation',
      value: 'http://sbi-bank-kyc-verify-portal.top/login.php?user=alert',
    },
    {
      label: 'Lookalike PayPal Domain',
      value: 'http://paypal.com.account-update.xyz/login',
    },
    {
      label: 'Direct Numerical IP Hostname',
      value: 'http://192.168.1.105/secure-billing',
    },
    {
      label: 'Legitimate Web Domain',
      value: 'https://google.com',
    },
  ],
  email: [
    {
      label: 'Urgent Account Termination Phishing',
      value:
        'Urgent Security Notice: Your corporate email account will be permanently deactivated within 24 hours due to suspicious login attempts. To prevent immediate termination, click the link below and reply with your employee ID, password, and two-factor verification code to the IT Support Desk.',
      sender: 'it-security-support@free-mail-provider.com',
    },
    {
      label: 'Advance-Fee Lottery Scam',
      value:
        'Congratulations! You have been selected as the sole winner of the International Heritage Trust grant of $750,000 USD. To release your bank transfer, submit your full bank account numbers, IFSC, and a processing clearance fee of $150 via cryptocurrency immediately.',
      sender: 'claims@heritage-lottery-global.xyz',
    },
  ],
  sms: [
    {
      label: 'Fake SBI KYC Block Scam',
      value:
        'Dear Customer, Your SBI NetBanking has been blocked today due to pending KYC update. Complete verification immediately at http://sbi-kyc-update.xyz to avoid permanent debit card deactivation.',
    },
    {
      label: 'UPI Cashback PIN Trap',
      value:
        'PhonePe Reward: Congratulations! You have received ₹3,500 cashback. Click here to scan QR code and enter your UPI PIN to claim money into your account.',
    },
    {
      label: 'Electricity Power Cut Extortion',
      value:
        'Dear Consumer, Your electricity power will be disconnected at 9:30 PM tonight from the power office because your previous month bill was unpaid. Call officer immediately at 9876543210.',
    },
  ],
};

export const ThreatScanner: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { error: toastError, success: toastSuccess } = useToast();

  const initialMode = (searchParams.get('mode') as InputType) || 'url';
  const [activeTab, setActiveTab] = useState<InputType>(initialMode);

  // Inputs
  const [urlInput, setUrlInput] = useState('');
  const [emailContent, setEmailContent] = useState('');
  const [emailSender, setEmailSender] = useState('');
  const [smsContent, setSmsContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);

  // States
  const [isScanning, setIsScanning] = useState(false);
  const [scanStep, setScanStep] = useState<string>('');
  const [latestResult, setLatestResult] = useState<ScanResult | null>(null);

  useEffect(() => {
    const mode = searchParams.get('mode') as InputType;
    if (mode && ['url', 'email', 'sms', 'screenshot'].includes(mode)) {
      setActiveTab(mode);
    }
  }, [searchParams]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        toastError('Invalid file type', 'Please select a PNG, JPEG, or WebP screenshot.');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        toastError('File too large', 'Screenshot file size must be under 5MB.');
        return;
      }
      setSelectedFile(file);
      setFilePreview(URL.createObjectURL(file));
    }
  };

  const handleClear = () => {
    setUrlInput('');
    setEmailContent('');
    setEmailSender('');
    setSmsContent('');
    setSelectedFile(null);
    setFilePreview(null);
    setLatestResult(null);
  };

  const handleAnalyze = async () => {
    setIsScanning(true);
    setLatestResult(null);

    try {
      if (activeTab === 'url') {
        if (!urlInput.trim()) {
          toastError('URL required', 'Please enter a URL or website address to analyze.');
          setIsScanning(false);
          return;
        }

        setScanStep('Parsing destination URL structure & RFC syntax...');
        await new Promise(r => setTimeout(r, 400));
        setScanStep('Checking homoglyphs, punycode, subdomains, and brand patterns...');

        const res = await fetch('/api/analyze/url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ url: urlInput }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to analyze URL');

        setLatestResult(data);
        toastSuccess('URL Analysis Complete', `Risk evaluation: ${data.riskLevel.toUpperCase()}`);
      } else if (activeTab === 'email') {
        if (!emailContent.trim()) {
          toastError('Content required', 'Please paste the email body to analyze.');
          setIsScanning(false);
          return;
        }

        setScanStep('Evaluating social engineering, authority bias, and urgency markers...');
        await new Promise(r => setTimeout(r, 400));
        setScanStep('Inspecting credential solicitation and sender domain alignment...');

        const res = await fetch('/api/analyze/text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            type: 'email',
            content: emailContent,
            sender: emailSender || undefined,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to analyze email');

        setLatestResult(data);
        toastSuccess('Email Analysis Complete', `Risk evaluation: ${data.riskLevel.toUpperCase()}`);
      } else if (activeTab === 'sms') {
        if (!smsContent.trim()) {
          toastError('Content required', 'Please paste the SMS text message.');
          setIsScanning(false);
          return;
        }

        setScanStep('Checking smishing indicators, bank alerts, and fake KYC notices...');
        await new Promise(r => setTimeout(r, 400));
        setScanStep('Analyzing UPI reverse-charge patterns and shortened links...');

        const res = await fetch('/api/analyze/text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            type: 'sms',
            content: smsContent,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to analyze SMS');

        setLatestResult(data);
        toastSuccess('SMS Analysis Complete', `Risk evaluation: ${data.riskLevel.toUpperCase()}`);
      } else if (activeTab === 'screenshot') {
        if (!selectedFile) {
          toastError('Screenshot required', 'Please upload an image file to perform OCR analysis.');
          setIsScanning(false);
          return;
        }

        setScanStep('Running local OCR character recognition (Tesseract)...');
        const formData = new FormData();
        formData.append('screenshot', selectedFile);

        const res = await fetch('/api/analyze/image', {
          method: 'POST',
          credentials: 'include',
          body: formData,
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to process screenshot');

        setLatestResult(data);
        toastSuccess('Screenshot Processed', `OCR completed. Risk: ${data.riskLevel.toUpperCase()}`);
      }
    } catch (err: any) {
      toastError('Analysis Error', err?.message || 'Failed to complete threat analysis');
    } finally {
      setIsScanning(false);
      setScanStep('');
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fadeIn">
      {/* Title & Privacy Warning Banner */}
      <div>
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-[#39D9E8]/10 text-[#39D9E8]">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Threat Scanner</h1>
            <p className="text-xs text-[#9AABC2]">
              Multi-modal inspection engine for suspicious URLs, emails, SMS texts, and screenshots
            </p>
          </div>
        </div>

        {/* Essential Privacy Warning Alert */}
        <div className="mt-4 p-4 rounded-2xl bg-[#101E30] border border-[#FBBF24]/40 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <div className="text-xs text-[#EDF5FF] leading-relaxed">
            <strong className="text-[#FBBF24] font-semibold">User Privacy Notice:</strong> Please
            redact or omit personal identifying information (real passwords, complete bank card numbers,
            Aadhaar/PAN credentials, or one-time passwords) before submitting. CyberSentry evaluates
            structural and linguistic threat indicators locally.
          </div>
        </div>
      </div>

      {/* Main Scanner Box */}
      <div className="rounded-3xl bg-[#101E30] border border-[#1D3352] overflow-hidden shadow-2xl">
        {/* Input Mode Tabs */}
        <div className="flex border-b border-[#1D3352] bg-[#07111F]/60 overflow-x-auto">
          <button
            onClick={() => setActiveTab('url')}
            className={`flex items-center gap-2.5 px-6 py-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'url'
                ? 'border-[#39D9E8] text-[#39D9E8] bg-[#101E30]'
                : 'border-transparent text-[#9AABC2] hover:text-[#EDF5FF]'
            }`}
          >
            <Link2 className="w-4 h-4" />
            <span>URL Scanner</span>
          </button>

          <button
            onClick={() => setActiveTab('email')}
            className={`flex items-center gap-2.5 px-6 py-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'email'
                ? 'border-[#8B7CFF] text-[#8B7CFF] bg-[#101E30]'
                : 'border-transparent text-[#9AABC2] hover:text-[#EDF5FF]'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Email Scanner</span>
          </button>

          <button
            onClick={() => setActiveTab('sms')}
            className={`flex items-center gap-2.5 px-6 py-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'sms'
                ? 'border-[#FBBF24] text-[#FBBF24] bg-[#101E30]'
                : 'border-transparent text-[#9AABC2] hover:text-[#EDF5FF]'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>SMS & Chat Scanner</span>
          </button>

          <button
            onClick={() => setActiveTab('screenshot')}
            className={`flex items-center gap-2.5 px-6 py-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'screenshot'
                ? 'border-[#34D399] text-[#34D399] bg-[#101E30]'
                : 'border-transparent text-[#9AABC2] hover:text-[#EDF5FF]'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Screenshot OCR</span>
          </button>
        </div>

        <div className="p-6 lg:p-8 space-y-6">
          {/* URL Tab Content */}
          {activeTab === 'url' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
                  Target Website URL
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={urlInput}
                    onChange={e => setUrlInput(e.target.value)}
                    placeholder="e.g. http://paypal.com.verify-login.xyz/update"
                    className="w-full px-4 py-3.5 pl-11 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8] font-mono text-sm transition-colors"
                  />
                  <Link2 className="w-5 h-5 text-[#9AABC2] absolute left-3.5 top-3.5" />
                </div>
                <p className="text-[11px] text-[#9AABC2] mt-1.5">
                  Static inspection only: destination is evaluated for typosquatting, userinfo spoofing,
                  punycode, and suspicious TLDs without visiting the remote host.
                </p>
              </div>

              {/* URL Sample Presets */}
              <div className="pt-2">
                <span className="text-[11px] font-semibold text-[#9AABC2] uppercase tracking-wider block mb-2">
                  Demonstration Presets:
                </span>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.url.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setUrlInput(preset.value)}
                      className="px-3 py-1.5 rounded-lg bg-[#13233A] border border-[#1D3352] hover:border-[#39D9E8]/40 text-xs text-[#EDF5FF] transition-colors"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Email Tab Content */}
          {activeTab === 'email' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
                  Sender Address (Optional)
                </label>
                <input
                  type="text"
                  value={emailSender}
                  onChange={e => setEmailSender(e.target.value)}
                  placeholder="e.g. security-team@paypal-notice.com"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#8B7CFF] text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
                  Pasted Email Content / Message Body
                </label>
                <textarea
                  rows={6}
                  value={emailContent}
                  onChange={e => setEmailContent(e.target.value)}
                  placeholder="Paste the suspicious email text here..."
                  className="w-full p-4 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#8B7CFF] text-sm leading-relaxed"
                />
              </div>

              {/* Email Sample Presets */}
              <div className="pt-1">
                <span className="text-[11px] font-semibold text-[#9AABC2] uppercase tracking-wider block mb-2">
                  Demonstration Presets:
                </span>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.email.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setEmailContent(preset.value);
                        if (preset.sender) setEmailSender(preset.sender);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#13233A] border border-[#1D3352] hover:border-[#8B7CFF]/40 text-xs text-[#EDF5FF] transition-colors"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SMS Tab Content */}
          {activeTab === 'sms' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
                  SMS / WhatsApp Message Text
                </label>
                <textarea
                  rows={5}
                  value={smsContent}
                  onChange={e => setSmsContent(e.target.value)}
                  placeholder="e.g. Dear customer your SBI acct blocked today. Click http://sbi-kyc.xyz..."
                  className="w-full p-4 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#FBBF24] text-sm leading-relaxed"
                />
              </div>

              {/* SMS Sample Presets */}
              <div className="pt-1">
                <span className="text-[11px] font-semibold text-[#9AABC2] uppercase tracking-wider block mb-2">
                  Demonstration Presets:
                </span>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.sms.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSmsContent(preset.value)}
                      className="px-3 py-1.5 rounded-lg bg-[#13233A] border border-[#1D3352] hover:border-[#FBBF24]/40 text-xs text-[#EDF5FF] transition-colors"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Screenshot Tab Content */}
          {activeTab === 'screenshot' && (
            <div className="space-y-4">
              <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
                Upload Message or Website Screenshot
              </label>

              <div className="border-2 border-dashed border-[#1D3352] hover:border-[#34D399]/50 rounded-2xl p-6 text-center transition-colors bg-[#07111F]/50">
                {filePreview ? (
                  <div className="space-y-3">
                    <img
                      src={filePreview}
                      alt="Uploaded screenshot preview"
                      className="max-h-60 mx-auto rounded-xl border border-[#1D3352] shadow-lg object-contain"
                    />
                    <div className="flex items-center justify-center gap-3">
                      <span className="text-xs font-mono text-[#EDF5FF]">{selectedFile?.name}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedFile(null);
                          setFilePreview(null);
                        }}
                        className="text-xs text-[#FB7185] hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Remove image</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-[#34D399]/10 text-[#34D399] flex items-center justify-center mx-auto">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[#EDF5FF]">
                        Drag and drop screenshot here, or browse
                      </p>
                      <p className="text-xs text-[#9AABC2] mt-1">
                        PNG, JPEG, WebP up to 5MB. Optical character recognition extracts message text locally.
                      </p>
                    </div>
                    <label className="inline-block px-4 py-2 rounded-xl bg-[#13233A] border border-[#1D3352] hover:border-[#34D399]/50 text-xs font-semibold text-[#EDF5FF] cursor-pointer transition-colors">
                      Select Screenshot File
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons & Scanning Animation */}
          <div className="pt-4 border-t border-[#1D3352] flex flex-wrap items-center justify-between gap-4">
            <button
              type="button"
              onClick={handleClear}
              disabled={isScanning}
              className="px-4 py-2 rounded-xl bg-transparent hover:bg-[#13233A] text-xs font-semibold text-[#9AABC2] hover:text-[#EDF5FF] border border-transparent transition-colors flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear Inputs</span>
            </button>

            <button
              type="button"
              onClick={handleAnalyze}
              disabled={isScanning}
              className={`px-6 py-3 rounded-xl font-bold text-sm shadow-lg transition-all flex items-center gap-2 ${
                isScanning
                  ? 'bg-[#13233A] text-[#9AABC2] cursor-not-allowed border border-[#1D3352]'
                  : 'bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] shadow-glow-primary hover:opacity-95'
              }`}
            >
              <ShieldAlert className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Analyzing Heuristics...' : 'Run Security Analysis'}</span>
            </button>
          </div>

          {/* Real-time Analysis Progress */}
          {isScanning && (
            <div className="p-4 rounded-xl bg-[#07111F] border border-[#39D9E8]/30 flex items-center gap-3 animate-pulse">
              <Sparkles className="w-5 h-5 text-[#39D9E8]" />
              <div className="text-xs text-[#EDF5FF]">{scanStep || 'Evaluating security parameters...'}</div>
            </div>
          )}
        </div>
      </div>

      {/* Immediate Results Card Preview */}
      {latestResult && (
        <div className="rounded-3xl bg-[#101E30] border border-[#1D3352] p-6 lg:p-8 space-y-6 shadow-2xl animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#1D3352]">
            <div className="flex items-center gap-3">
              <div
                className={`p-3 rounded-2xl ${
                  latestResult.riskLevel === 'high'
                    ? 'bg-[#FB7185]/20 text-[#FB7185]'
                    : latestResult.riskLevel === 'medium'
                    ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                    : 'bg-[#34D399]/20 text-[#34D399]'
                }`}
              >
                <ShieldAlert className="w-8 h-8" />
              </div>
              <div>
                <div className="flex items-center gap-2.5">
                  <span
                    className={`text-xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                      latestResult.riskLevel === 'high'
                        ? 'bg-[#FB7185]/20 text-[#FB7185] border border-[#FB7185]/40'
                        : latestResult.riskLevel === 'medium'
                        ? 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40'
                        : 'bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40'
                    }`}
                  >
                    {latestResult.riskLevel} Risk
                  </span>
                  <span className="text-xs font-mono text-[#9AABC2]">
                    Score: {latestResult.riskScore}/100
                  </span>
                </div>
                <h3 className="text-lg font-bold text-[#EDF5FF] mt-1">
                  Analysis Report for {latestResult.inputType.toUpperCase()}
                </h3>
              </div>
            </div>

            <button
              onClick={() => navigate(`/results/${latestResult.scanId}`)}
              className="px-5 py-2.5 rounded-xl bg-[#39D9E8] hover:bg-[#2fc0ce] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all flex items-center gap-2 self-start sm:self-auto"
            >
              <span>View Full Report</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <p className="text-sm text-[#EDF5FF] leading-relaxed bg-[#07111F]/70 p-4 rounded-xl border border-[#1D3352]">
            {latestResult.summary}
          </p>

          {/* Quick Findings Summary */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] mb-3">
              Detected Warning Indicators ({latestResult.findings.length})
            </h4>
            {latestResult.findings.length > 0 ? (
              <div className="space-y-2.5">
                {latestResult.findings.slice(0, 3).map(f => (
                  <div
                    key={f.id}
                    className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] flex items-start gap-3"
                  >
                    <AlertTriangle
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        f.severity === 'high'
                          ? 'text-[#FB7185]'
                          : f.severity === 'medium'
                          ? 'text-[#FBBF24]'
                          : 'text-[#39D9E8]'
                      }`}
                    />
                    <div>
                      <span className="text-xs font-bold text-[#EDF5FF] block">{f.title}</span>
                      <p className="text-xs text-[#9AABC2] mt-0.5">{f.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-[#34D399]/10 border border-[#34D399]/30 text-xs text-[#34D399] flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>No overt indicators found. Standard caution still advised.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
