import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Filter,
  Trash2,
  ShieldAlert,
  ArrowRight,
  Clock,
  Fingerprint,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import type { ScanResult, RiskLevel, InputType } from '@shared/types';
import { ConfirmModal } from '../components/ConfirmModal';
import { useToast } from '../context/ToastContext';

export const ScanHistory: React.FC = () => {
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const [scans, setScans] = useState<ScanResult[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [riskFilter, setRiskFilter] = useState<RiskLevel | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<InputType | 'all'>('all');

  // Modals
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [clearAllModalOpen, setClearAllModalOpen] = useState(false);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        search: search.trim(),
        riskLevel: riskFilter,
        inputType: typeFilter,
      });

      const res = await fetch(`/api/scans?${params.toString()}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch scans');
      const data = await res.json();
      setScans(data.items || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch (err: any) {
      toastError('Error', err?.message || 'Could not load scan history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, [page, riskFilter, typeFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadHistory();
  };

  const handleDeleteSingle = async () => {
    if (!deleteTargetId) return;
    try {
      const res = await fetch(`/api/scans/${deleteTargetId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (res.ok) {
        toastSuccess('Deleted', 'Scan removed successfully.');
        setDeleteTargetId(null);
        loadHistory();
      } else {
        toastError('Failed to delete', 'Scan could not be removed.');
      }
    } catch {
      toastError('Network error', 'Failed to communicate with server.');
    }
  };

  const handleClearAll = async () => {
    try {
      const res = await fetch('/api/scans', {
        method: 'DELETE',
        credentials: 'include',
      });
      if (res.ok) {
        toastSuccess('History Cleared', 'All your saved scan records have been removed.');
        setClearAllModalOpen(false);
        setPage(1);
        loadHistory();
      } else {
        toastError('Failed to clear', 'Could not clear history.');
      }
    } catch {
      toastError('Network error', 'Failed to communicate with server.');
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Scan History</h1>
          <p className="text-xs text-[#9AABC2]">
            Inspect, search, and manage your past cybersecurity assessments
          </p>
        </div>

        {scans.length > 0 && (
          <button
            onClick={() => setClearAllModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-[#FB7185]/10 hover:bg-[#FB7185]/20 text-[#FB7185] border border-[#FB7185]/30 text-xs font-semibold transition-colors flex items-center gap-2 self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Search & Filter Controls */}
      <div className="p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] flex flex-col md:flex-row items-center gap-3">
        <form onSubmit={handleSearchSubmit} className="flex-1 w-full relative">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search scans by URL, snippet, or summary..."
            className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8]"
          />
          <Search className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
        </form>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={riskFilter}
            onChange={e => {
              setRiskFilter(e.target.value as any);
              setPage(1);
            }}
            aria-label="Filter by Risk Level"
            className="px-3 py-2.5 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#39D9E8]"
          >
            <option value="all">All Risk Levels</option>
            <option value="high">High Risk</option>
            <option value="medium">Medium Risk</option>
            <option value="low">Low Risk</option>
          </select>

          <select
            value={typeFilter}
            onChange={e => {
              setTypeFilter(e.target.value as any);
              setPage(1);
            }}
            aria-label="Filter by Input Type"
            className="px-3 py-2.5 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#39D9E8]"
          >
            <option value="all">All Types</option>
            <option value="url">URLs</option>
            <option value="email">Emails</option>
            <option value="sms">SMS</option>
            <option value="screenshot">Screenshots</option>
          </select>
        </div>
      </div>

      {/* History List */}
      {loading ? (
        <div className="p-12 text-center text-[#9AABC2] space-y-3">
          <ShieldAlert className="w-8 h-8 text-[#39D9E8] animate-spin mx-auto" />
          <p className="text-xs">Loading records...</p>
        </div>
      ) : scans.length > 0 ? (
        <div className="space-y-3">
          {scans.map(scan => (
            <div
              key={scan.scanId}
              className="p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#39D9E8]/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
            >
              <div
                onClick={() => navigate(`/results/${scan.scanId}`)}
                className="flex items-start gap-3.5 flex-1 min-w-0 cursor-pointer"
              >
                <div
                  className={`p-2.5 rounded-xl mt-0.5 shrink-0 ${
                    scan.riskLevel === 'high'
                      ? 'bg-[#FB7185]/20 text-[#FB7185]'
                      : scan.riskLevel === 'medium'
                      ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                      : 'bg-[#34D399]/20 text-[#34D399]'
                  }`}
                >
                  <ShieldAlert className="w-5 h-5" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                        scan.riskLevel === 'high'
                          ? 'bg-[#FB7185]/20 text-[#FB7185]'
                          : scan.riskLevel === 'medium'
                          ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                          : 'bg-[#34D399]/20 text-[#34D399]'
                      }`}
                    >
                      {scan.riskLevel} Risk
                    </span>
                    <span className="text-[11px] font-mono text-[#9AABC2]">
                      Score: {scan.riskScore}/100
                    </span>
                    <span className="text-xs text-[#1D3352]">•</span>
                    <span className="text-[10px] uppercase font-bold text-[#39D9E8] px-2 py-0.5 rounded bg-[#39D9E8]/10">
                      {scan.inputType}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-[#EDF5FF] truncate group-hover:text-[#39D9E8] transition-colors">
                    {scan.inputPreview}
                  </p>

                  <div className="flex items-center gap-4 text-[10px] text-[#9AABC2] mt-1.5">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(scan.analyzedAt).toLocaleDateString()}{' '}
                      {new Date(scan.analyzedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span>{scan.findings.length} indicator(s) identified</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#1D3352]/70 w-full sm:w-auto justify-between sm:justify-start">
                <button
                  onClick={() => navigate(`/results/${scan.scanId}`)}
                  className="px-3 py-1.5 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#EDF5FF] border border-[#1D3352] transition-colors flex items-center gap-1.5"
                >
                  <span>View Details</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#39D9E8]" />
                </button>

                <button
                  onClick={() => setDeleteTargetId(scan.scanId)}
                  className="p-2 rounded-xl text-[#9AABC2] hover:text-[#FB7185] hover:bg-[#FB7185]/10 transition-colors"
                  title="Delete scan record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4 border-t border-[#1D3352] text-xs text-[#9AABC2]">
              <div>
                Showing page {page} of {totalPages} ({total} scans total)
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page <= 1}
                  className="p-2 rounded-lg bg-[#101E30] border border-[#1D3352] disabled:opacity-40 disabled:cursor-not-allowed text-[#EDF5FF]"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  disabled={page >= totalPages}
                  className="p-2 rounded-lg bg-[#101E30] border border-[#1D3352] disabled:opacity-40 disabled:cursor-not-allowed text-[#EDF5FF]"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="p-12 rounded-2xl bg-[#101E30] border border-[#1D3352] text-center space-y-3">
          <ShieldCheck className="w-10 h-10 text-[#39D9E8]/30 mx-auto" />
          <h3 className="text-sm font-bold text-[#EDF5FF]">No Scan Records Found</h3>
          <p className="text-xs text-[#9AABC2] max-w-sm mx-auto">
            You have not performed any scans matching the current search criteria, or history has been cleared.
          </p>
          <button
            onClick={() => navigate('/scanner')}
            className="px-4 py-2 rounded-xl bg-[#39D9E8] text-[#07111F] font-bold text-xs shadow-glow-primary"
          >
            Launch Scanner
          </button>
        </div>
      )}

      {/* Delete Single Modal */}
      <ConfirmModal
        isOpen={Boolean(deleteTargetId)}
        title="Delete Scan Record?"
        message="Are you sure you want to permanently delete this scan record from your private history?"
        confirmText="Delete Record"
        onConfirm={handleDeleteSingle}
        onCancel={() => setDeleteTargetId(null)}
      />

      {/* Clear All Modal */}
      <ConfirmModal
        isOpen={clearAllModalOpen}
        title="Clear Entire Scan History?"
        message="This action will permanently delete all your stored scan results and security findings. This cannot be undone."
        confirmText="Clear All Data"
        onConfirm={handleClearAll}
        onCancel={() => setClearAllModalOpen(false)}
      />
    </div>
  );
};
