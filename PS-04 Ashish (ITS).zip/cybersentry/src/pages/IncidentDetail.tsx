import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  FileWarning,
  Clock,
  User,
  ShieldCheck,
  Download,
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import type { Incident, IncidentStatusHistory, IncidentStatus } from '@shared/types';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const IncidentDetail: React.FC = () => {
  const { reportId } = useParams<{ reportId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();

  const [incident, setIncident] = useState<Incident | null>(null);
  const [history, setHistory] = useState<IncidentStatusHistory[]>([]);
  const [loading, setLoading] = useState(true);

  // Admin status update state
  const [selectedStatus, setSelectedStatus] = useState<IncidentStatus>('Submitted');
  const [adminNotes, setAdminNotes] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchDetail = async () => {
    if (!reportId) return;
    try {
      const res = await fetch(`/api/incidents/track/${encodeURIComponent(reportId)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch incident');
      setIncident(data);
      setHistory(data.history || []);
      setSelectedStatus(data.status);
    } catch (err: any) {
      toastError('Error', err?.message || 'Could not find incident report.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDetail();
  }, [reportId]);

  const handleStatusUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incident) return;
    setIsUpdating(true);

    try {
      // Find full incident by tracking ID or id
      const res = await fetch(`/api/incidents/${(incident as any).id || (incident as any).reportId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          status: selectedStatus,
          notes: adminNotes.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Status update failed');

      toastSuccess('Status Updated', `Report status changed to ${selectedStatus}`);
      setAdminNotes('');
      fetchDetail();
    } catch (err: any) {
      toastError('Update Failed', err?.message || 'Could not update status.');
    } finally {
      setIsUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-[#9AABC2] space-y-3">
        <FileWarning className="w-10 h-10 text-[#39D9E8] animate-spin" />
        <p className="text-xs">Loading incident details...</p>
      </div>
    );
  }

  if (!incident) {
    return (
      <div className="p-8 text-center space-y-3">
        <AlertTriangle className="w-10 h-10 text-[#FB7185] mx-auto" />
        <h2 className="text-lg font-bold text-[#EDF5FF]">Incident Not Found</h2>
        <button
          onClick={() => navigate('/incidents/track')}
          className="px-4 py-2 rounded-xl bg-[#39D9E8] text-[#07111F] text-xs font-bold"
        >
          Return to Incident Tracking
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-xs font-semibold text-[#9AABC2] hover:text-[#EDF5FF] transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </button>

      {/* Main Incident Card */}
      <div className="p-6 lg:p-8 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#1D3352]">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-extrabold text-[#39D9E8]">
                {incident.reportId}
              </span>
              <span className="text-xs text-[#9AABC2]">•</span>
              <span className="text-xs text-[#EDF5FF] font-semibold capitalize">
                {incident.category.replace('_', ' ')}
              </span>
            </div>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF] mt-1">
              Incident Case File
            </h1>
            <p className="text-xs text-[#9AABC2] mt-0.5">
              Submitted on {new Date(incident.createdAt).toLocaleString()}
            </p>
          </div>

          <span
            className={`text-xs font-bold px-3 py-1 rounded-full uppercase self-start sm:self-auto ${
              incident.status === 'Resolved'
                ? 'bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40'
                : incident.status === 'Under Review'
                ? 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40'
                : incident.status === 'Closed'
                ? 'bg-[#9AABC2]/20 text-[#9AABC2] border border-[#9AABC2]/40'
                : 'bg-[#39D9E8]/20 text-[#39D9E8] border border-[#39D9E8]/40'
            }`}
          >
            {incident.status}
          </span>
        </div>

        {/* Narrative & Details */}
        <div className="space-y-4">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] mb-1.5">
              Incident Narrative
            </h3>
            <p className="text-sm text-[#EDF5FF] leading-relaxed p-4 rounded-xl bg-[#07111F] border border-[#1D3352]">
              {incident.description}
            </p>
          </div>

          {incident.suspiciousUrl && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] mb-1.5">
                Reported URL / Online Entity
              </h3>
              <div className="p-3 rounded-xl bg-[#07111F] border border-[#1D3352] font-mono text-xs text-[#39D9E8] break-all">
                {incident.suspiciousUrl}
              </div>
            </div>
          )}

          {incident.evidenceFileName && (
            <div className="pt-2">
              <a
                href={`/api/incidents/${incident.id}/evidence`}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#39D9E8] border border-[#1D3352] transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download Attached Evidence ({incident.evidenceOriginalName || 'Evidence File'})</span>
              </a>
            </div>
          )}
        </div>

        {/* Administrator Status Update Action */}
        {user?.role === 'admin' && (
          <div className="p-5 rounded-2xl bg-[#07111F] border border-[#8B7CFF]/40 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#8B7CFF]">
              <ShieldCheck className="w-4 h-4" />
              <span>Administrator Investigation Controls</span>
            </div>

            <form onSubmit={handleStatusUpdate} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[#9AABC2] mb-1 font-semibold">Change Status</label>
                  <select
                    value={selectedStatus}
                    onChange={e => setSelectedStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#101E30] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#8B7CFF]"
                  >
                    <option value="Submitted">Submitted</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Closed">Closed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#9AABC2] mb-1 font-semibold">Investigation Note</label>
                  <input
                    type="text"
                    value={adminNotes}
                    onChange={e => setAdminNotes(e.target.value)}
                    placeholder="Enter audit note for reporter timeline..."
                    className="w-full px-3 py-2 rounded-xl bg-[#101E30] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#8B7CFF]"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="px-4 py-2 rounded-xl bg-[#8B7CFF] hover:bg-[#7a6aeb] text-white text-xs font-bold transition-all shadow-glow-secondary disabled:opacity-50"
                >
                  {isUpdating ? 'Saving...' : 'Record Status Transition'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Status History Timeline */}
        <div className="pt-4 border-t border-[#1D3352]">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] mb-3">
            Investigation History Timeline
          </h3>
          <div className="space-y-3">
            {history.map(item => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] flex items-start gap-3 text-xs"
              >
                <Clock className="w-4 h-4 text-[#39D9E8] shrink-0 mt-0.5" />
                <div className="flex-1 space-y-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-[#EDF5FF]">
                      Status: <span className="text-[#39D9E8]">{item.newStatus}</span>
                    </span>
                    <span className="text-[11px] text-[#9AABC2]">
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#9AABC2]">
                    Recorded by: <strong className="text-[#EDF5FF]">{item.changedBy}</strong>
                  </div>
                  {item.notes && (
                    <p className="text-xs text-[#EDF5FF] mt-1 bg-[#07111F]/60 p-2 rounded-lg border border-[#1D3352]/60">
                      {item.notes}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
