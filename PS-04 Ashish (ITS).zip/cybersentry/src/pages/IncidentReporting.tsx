import React, { useState } from 'react';
import { useNavigate, useSearchParams, NavLink } from 'react-router-dom';
import {
  FileWarning,
  Send,
  Upload,
  AlertTriangle,
  CheckCircle2,
  PhoneCall,
  ExternalLink,
  ShieldCheck,
  Calendar,
  Link as LinkIcon,
  User,
  ArrowRight,
} from 'lucide-react';
import type { IncidentCategory } from '@shared/types';
import { useToast } from '../context/ToastContext';

const CATEGORIES: { value: IncidentCategory; label: string; desc: string }[] = [
  { value: 'phishing', label: 'Phishing Scam', desc: 'Deceptive emails or portals harvesting logins or credentials' },
  { value: 'upi_fraud', label: 'UPI / Payment Fraud', desc: 'QR code reverse charges, fraudulent collect requests, fake cashback' },
  { value: 'impersonation', label: 'Identity / Authority Impersonation', desc: 'Pretending to be bank manager, police officer, or telecom agent' },
  { value: 'fake_website', label: 'Fake Website / Typosquatting', desc: 'Cloned bank, airline, or e-commerce sites mimicking real services' },
  { value: 'account_compromise', label: 'Account Takeover / Breach', desc: 'Unauthorized logins, MFA fatigue, or hijacked social/email accounts' },
  { value: 'shopping_fraud', label: 'Online Shopping Fraud', desc: 'Fraudulent storefronts taking payment without delivering goods' },
  { value: 'social_engineering', label: 'Social Engineering / Extortion', desc: 'Electricity cut threats, courier parcel redelivery, remote app traps' },
  { value: 'other', label: 'Other Cyber Incident', desc: 'Harassment, malware distribution, or unclassified security events' },
];

export const IncidentReporting: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const prefillUrl = searchParams.get('url') || '';

  const [category, setCategory] = useState<IncidentCategory>('phishing');
  const [description, setDescription] = useState('');
  const [suspiciousUrl, setSuspiciousUrl] = useState(prefillUrl);
  const [contactInfo, setContactInfo] = useState('');
  const [consentGiven, setConsentGiven] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedReportId, setSubmittedReportId] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!description.trim() || description.trim().length < 10) {
      toastError('Description required', 'Please provide at least 10 characters explaining what happened.');
      return;
    }

    if (!consentGiven) {
      toastError('Consent required', 'You must acknowledge the platform privacy and reporting statement.');
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('category', category);
      formData.append('description', description.trim());
      if (suspiciousUrl.trim()) formData.append('suspiciousUrl', suspiciousUrl.trim());
      if (contactInfo.trim()) formData.append('contactInfo', contactInfo.trim());
      formData.append('consentGiven', 'true');
      if (selectedFile) formData.append('evidence', selectedFile);

      const res = await fetch('/api/incidents', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit incident');

      setSubmittedReportId(data.reportId);
      toastSuccess('Incident Documented', `Report ID ${data.reportId} generated.`);
    } catch (err: any) {
      toastError('Submission Error', err?.message || 'Could not record incident');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submittedReportId) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn py-6">
        <div className="p-8 rounded-3xl bg-[#101E30] border border-[#34D399]/40 text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-[#34D399]/15 text-[#34D399] flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#34D399]">
              Incident Documented Successfully
            </span>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Your Tracking Identifier</h1>
          </div>

          <div className="p-4 rounded-2xl bg-[#07111F] border border-[#1D3352] inline-block font-mono text-xl font-bold text-[#39D9E8] tracking-widest">
            {submittedReportId}
          </div>

          <p className="text-xs text-[#9AABC2] max-w-md mx-auto leading-relaxed">
            Your incident has been recorded in the platform database with the initial status of{' '}
            <strong className="text-[#39D9E8]">Submitted</strong>. You can monitor progress and review
            investigation notes at any time using this tracking ID.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={() => navigate(`/incidents/track?id=${submittedReportId}`)}
              className="px-5 py-2.5 rounded-xl bg-[#39D9E8] hover:bg-[#2fc0ce] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all flex items-center gap-2"
            >
              <span>Track Incident Status</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setSubmittedReportId(null);
                setDescription('');
                setSuspiciousUrl('');
                setSelectedFile(null);
                setConsentGiven(false);
              }}
              className="px-4 py-2.5 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-[#EDF5FF] text-xs font-semibold border border-[#1D3352] transition-colors"
            >
              Report Another Incident
            </button>
          </div>
        </div>

        {/* Crucial Law Enforcement Disclaimer */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#FB7185]/40 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#FB7185] uppercase tracking-wider">
            <PhoneCall className="w-4 h-4 animate-pulse" />
            <span>Important Legal & Police Reporting Disclosure</span>
          </div>
          <p className="text-xs text-[#EDF5FF] leading-relaxed">
            CyberSentry is an internal awareness platform and incident documentation registry. Submitting
            this report <strong>does NOT</strong> automatically notify the police, financial banks, or
            government authorities. If you suffered monetary loss:
          </p>
          <div className="p-4 rounded-xl bg-[#07111F] border border-[#1D3352] space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#EDF5FF]">1. National Cyber Fraud Helpline:</span>
              <a href="tel:1930" className="font-bold text-[#FB7185] hover:underline">
                Dial 1930
              </a>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#EDF5FF]">2. Official Cyber Crime Portal:</span>
              <a
                href="https://cybercrime.gov.in"
                target="_blank"
                rel="noreferrer"
                className="text-[#39D9E8] hover:underline flex items-center gap-1"
              >
                <span>cybercrime.gov.in</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-[#FB7185]/10 text-[#FB7185]">
            <FileWarning className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Report a Cyber Incident</h1>
            <p className="text-xs text-[#9AABC2]">
              Document suspicious interactions, fraudulent links, or extortion attempts for triage
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Category Selection */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
          <label className="block text-xs font-bold text-[#EDF5FF] uppercase tracking-wider">
            1. Select Incident Category *
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {CATEGORIES.map(cat => (
              <label
                key={cat.value}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                  category === cat.value
                    ? 'bg-[#39D9E8]/10 border-[#39D9E8] text-[#EDF5FF]'
                    : 'bg-[#07111F] border-[#1D3352] text-[#9AABC2] hover:border-[#1D3352]/90'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#EDF5FF]">{cat.label}</span>
                  <input
                    type="radio"
                    name="incidentCategory"
                    value={cat.value}
                    checked={category === cat.value}
                    onChange={() => setCategory(cat.value)}
                    className="accent-[#39D9E8]"
                  />
                </div>
                <span className="text-[11px] text-[#9AABC2] leading-tight">{cat.desc}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Description & URLs */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
              2. Detailed Incident Description *
            </label>
            <textarea
              rows={5}
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe what occurred, what claims the scammer made, any numbers or accounts mentioned..."
              className="w-full p-4 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8] text-sm leading-relaxed"
            />
            <p className="text-[11px] text-[#9AABC2] mt-1">
              Do not include real passwords, complete payment card numbers, or current one-time PINs.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
              Suspicious Website / Link (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={suspiciousUrl}
                onChange={e => setSuspiciousUrl(e.target.value)}
                placeholder="e.g. http://fake-lottery-portal.xyz"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8] text-xs font-mono"
              />
              <LinkIcon className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>
        </div>

        {/* Evidence Attachment & Contact Info */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
              3. Attach Evidence Screenshot or File (Optional)
            </label>
            <div className="border border-dashed border-[#1D3352] rounded-xl p-4 text-center bg-[#07111F]/50">
              {selectedFile ? (
                <div className="flex items-center justify-between p-2 rounded-lg bg-[#13233A] text-xs">
                  <span className="font-mono text-[#EDF5FF] truncate">{selectedFile.name}</span>
                  <button
                    type="button"
                    onClick={() => setSelectedFile(null)}
                    className="text-[#FB7185] hover:underline"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block">
                  <Upload className="w-6 h-6 text-[#9AABC2] mx-auto mb-1.5" />
                  <span className="text-xs text-[#39D9E8] font-semibold hover:underline">
                    Browse evidence file
                  </span>
                  <span className="text-[11px] text-[#9AABC2] block mt-0.5">
                    PNG, JPEG, WebP, PDF, or TXT up to 5MB
                  </span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,application/pdf,text/plain"
                    onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        setSelectedFile(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#EDF5FF] mb-2 uppercase tracking-wider">
              Contact Email / Phone (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={contactInfo}
                onChange={e => setContactInfo(e.target.value)}
                placeholder="Optional email or mobile for investigator updates"
                className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#39D9E8] text-xs"
              />
              <User className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
            </div>
          </div>
        </div>

        {/* Consent and Privacy Acknowledgement */}
        <div className="p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-2">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              required
              checked={consentGiven}
              onChange={e => setConsentGiven(e.target.checked)}
              className="mt-1 accent-[#39D9E8]"
            />
            <span className="text-xs text-[#EDF5FF] leading-relaxed">
              I acknowledge that this report is submitted for internal security verification and platform
              awareness. I confirm that I have removed personal credentials, and I understand this report
              does not replace legal police complaints or emergency bank hotlines.
            </span>
          </label>
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-end gap-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`px-8 py-3.5 rounded-xl font-bold text-sm shadow-lg transition-all flex items-center gap-2 ${
              isSubmitting
                ? 'bg-[#13233A] text-[#9AABC2] cursor-not-allowed'
                : 'bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] shadow-glow-primary hover:opacity-95'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{isSubmitting ? 'Documenting Incident...' : 'Submit Incident Report'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
