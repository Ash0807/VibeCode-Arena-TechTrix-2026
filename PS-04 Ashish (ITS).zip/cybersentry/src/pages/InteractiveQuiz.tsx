import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  Award,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Sparkles,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import type { QuizQuestion } from '@shared/types';
import { useToast } from '../context/ToastContext';

export const InteractiveQuiz: React.FC = () => {
  const { success: toastSuccess } = useToast();

  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(true);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [userAnswers, setUserAnswers] = useState<
    { questionId: string; selectedIndex: number; isCorrect: boolean }[]
  >([]);
  const [quizFinished, setQuizFinished] = useState(false);

  useEffect(() => {
    fetch('/api/academy/quiz')
      .then(res => res.json())
      .then(data => setQuestions(data))
      .catch(err => console.error('Failed to load quiz:', err))
      .finally(() => setLoading(false));
  }, []);

  const currentQ = questions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctIndex;
    setUserAnswers(prev => [
      ...prev,
      {
        questionId: currentQ.id,
        selectedIndex: idx,
        isCorrect,
      },
    ]);
  };

  const handleNext = async () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      // Finished!
      setQuizFinished(true);

      // Submit attempt to server
      try {
        await fetch('/api/academy/quiz/attempts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            quizIdentifier: 'cyber-awareness-core',
            answers: userAnswers,
          }),
        });
        toastSuccess('Quiz Recorded', 'Your progress has been logged.');
      } catch (e) {
        console.warn('Failed to record quiz attempt:', e);
      }
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setUserAnswers([]);
    setQuizFinished(false);
  };

  const score = userAnswers.filter(a => a.isCorrect).length;
  const percentage = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-[#9AABC2] space-y-3">
        <HelpCircle className="w-8 h-8 text-[#8B7CFF] animate-spin" />
        <p className="text-xs">Preparing cybersecurity assessment...</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="p-8 text-center text-[#9AABC2]">
        <HelpCircle className="w-8 h-8 mx-auto mb-2 text-[#FB7185]" />
        <p className="text-sm">No quiz questions currently available.</p>
      </div>
    );
  }

  // Final Results Screen
  if (quizFinished) {
    return (
      <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
        <div className="p-8 rounded-3xl bg-[#101E30] border border-[#1D3352] text-center space-y-6 shadow-2xl">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#39D9E8]/20 to-[#8B7CFF]/20 border border-[#39D9E8]/40 flex items-center justify-center mx-auto shadow-glow-primary">
            <Award className="w-10 h-10 text-[#39D9E8]" />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#39D9E8]">
              Assessment Complete
            </span>
            <h1 className="text-3xl font-extrabold text-[#EDF5FF]">Your Cyber Safety Score</h1>
          </div>

          <div className="flex items-center justify-center gap-2">
            <span className="text-5xl font-black text-[#EDF5FF]">{score}</span>
            <span className="text-2xl font-bold text-[#9AABC2]">/ {questions.length}</span>
            <span className="text-xl font-extrabold text-[#39D9E8] ml-2">({percentage}%)</span>
          </div>

          {/* Performance Badge */}
          <div className="max-w-md mx-auto">
            {percentage >= 85 ? (
              <div className="p-4 rounded-2xl bg-[#34D399]/10 border border-[#34D399]/40 text-xs text-[#34D399] space-y-1">
                <span className="font-extrabold uppercase tracking-wider block text-sm">
                  🛡️ Rank: Cyber Guardian
                </span>
                <p className="text-[#EDF5FF]/90">
                  Exceptional vigilance! You accurately recognized subtle UPI fraud traps, typosquatting domains,
                  and psychological social engineering techniques.
                </p>
              </div>
            ) : percentage >= 65 ? (
              <div className="p-4 rounded-2xl bg-[#FBBF24]/10 border border-[#FBBF24]/40 text-xs text-[#FBBF24] space-y-1">
                <span className="font-extrabold uppercase tracking-wider block text-sm">
                  ⚠️ Rank: Security Aware Defender
                </span>
                <p className="text-[#EDF5FF]/90">
                  Good foundational knowledge, but a few advanced scams slipped through. Review the lesson
                  materials on reverse UPI payments and fake KYC SMS messages.
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-[#FB7185]/10 border border-[#FB7185]/40 text-xs text-[#FB7185] space-y-1">
                <span className="font-extrabold uppercase tracking-wider block text-sm">
                  🚨 Rank: Vulnerable to Social Engineering
                </span>
                <p className="text-[#EDF5FF]/90">
                  You are at high risk of falling for modern smishing, fake delivery alerts, or reverse-charge
                  QR codes. We strongly recommend studying the Cyber Academy modules.
                </p>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={handleRestart}
              className="px-5 py-2.5 rounded-xl bg-[#39D9E8] hover:bg-[#2fc0ce] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Quiz</span>
            </button>
            <NavLink
              to="/academy"
              className="px-5 py-2.5 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-[#EDF5FF] text-xs font-semibold border border-[#1D3352] transition-colors flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-[#8B7CFF]" />
              <span>Study Lessons</span>
            </NavLink>
          </div>
        </div>

        {/* Detailed Question by Question Review */}
        <div className="space-y-4">
          <h2 className="text-base font-extrabold text-[#EDF5FF]">Detailed Answer Review</h2>
          <div className="space-y-3">
            {questions.map((q, idx) => {
              const attempt = userAnswers.find(a => a.questionId === q.id);
              const isCorrect = attempt ? attempt.isCorrect : false;

              return (
                <div
                  key={q.id}
                  className={`p-5 rounded-2xl border ${
                    isCorrect
                      ? 'bg-[#101E30] border-[#34D399]/40'
                      : 'bg-[#101E30] border-[#FB7185]/40'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-[#FB7185] shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 space-y-2">
                      <div className="text-xs font-bold text-[#EDF5FF]">
                        <span className="text-[#9AABC2]">Q{idx + 1}: </span>
                        {q.question}
                      </div>

                      <div className="text-xs space-y-1">
                        {!isCorrect && attempt && (
                          <div className="text-[#FB7185]">
                            Your Answer: <span>{q.options[attempt.selectedIndex]}</span>
                          </div>
                        )}
                        <div className="text-[#34D399] font-medium">
                          Correct Answer: <span>{q.options[q.correctIndex]}</span>
                        </div>
                      </div>

                      <div className="text-xs text-[#9AABC2] bg-[#07111F] p-3 rounded-xl border border-[#1D3352]/70 leading-relaxed">
                        <strong className="text-[#EDF5FF] block mb-0.5">Explanation:</strong>
                        {q.explanation}
                      </div>

                      {q.relatedLessonId && (
                        <NavLink
                          to={`/academy/${q.relatedLessonId}`}
                          className="text-[11px] font-semibold text-[#8B7CFF] hover:underline inline-flex items-center gap-1"
                        >
                          <span>Review Related Lesson</span>
                          <ChevronRight className="w-3 h-3" />
                        </NavLink>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Active Question Card
  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn">
      {/* Progress Bar Header */}
      <div className="p-6 rounded-3xl bg-[#101E30] border border-[#1D3352] shadow-xl space-y-4">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-[#39D9E8] uppercase tracking-wider">
            Cyber Awareness Quiz
          </span>
          <span className="text-[#EDF5FF]">
            Question {currentIndex + 1} of {questions.length}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-[#07111F] overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>

        <div className="pt-2">
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-[#13233A] text-[#9AABC2] border border-[#1D3352]">
            Category: {currentQ.category}
          </span>
          <h2 className="text-base font-extrabold text-[#EDF5FF] mt-2 leading-relaxed">
            {currentQ.question}
          </h2>
        </div>

        {/* Options */}
        <div className="space-y-2.5 pt-2">
          {currentQ.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrectOption = idx === currentQ.correctIndex;

            let optionStyle = 'bg-[#07111F] border-[#1D3352] text-[#EDF5FF] hover:border-[#39D9E8]/40';
            if (isAnswered) {
              if (isCorrectOption) {
                optionStyle = 'bg-[#34D399]/15 border-[#34D399] text-[#EDF5FF] font-semibold';
              } else if (isSelected) {
                optionStyle = 'bg-[#FB7185]/15 border-[#FB7185] text-[#EDF5FF]';
              } else {
                optionStyle = 'bg-[#07111F]/50 border-[#1D3352]/50 text-[#9AABC2] opacity-60';
              }
            }

            return (
              <button
                key={idx}
                type="button"
                disabled={isAnswered}
                onClick={() => handleSelectOption(idx)}
                className={`w-full p-4 rounded-2xl border text-left text-xs transition-all flex items-start gap-3 ${optionStyle}`}
              >
                <div
                  className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 text-[11px] font-bold ${
                    isAnswered && isCorrectOption
                      ? 'border-[#34D399] bg-[#34D399] text-[#07111F]'
                      : isAnswered && isSelected
                      ? 'border-[#FB7185] bg-[#FB7185] text-white'
                      : 'border-[#1D3352] text-[#9AABC2]'
                  }`}
                >
                  {String.fromCharCode(65 + idx)}
                </div>
                <span className="flex-1 leading-relaxed">{option}</span>
              </button>
            );
          })}
        </div>

        {/* Instant Answer Explanation Feedback */}
        {isAnswered && (
          <div
            className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-1.5 animate-fadeIn ${
              selectedOption === currentQ.correctIndex
                ? 'bg-[#34D399]/10 border-[#34D399]/40 text-[#EDF5FF]'
                : 'bg-[#FB7185]/10 border-[#FB7185]/40 text-[#EDF5FF]'
            }`}
          >
            <div className="flex items-center gap-2 font-bold">
              {selectedOption === currentQ.correctIndex ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-[#34D399]" />
                  <span className="text-[#34D399]">Correct!</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-[#FB7185]" />
                  <span className="text-[#FB7185]">Incorrect</span>
                </>
              )}
            </div>
            <p className="text-[#9AABC2]">{currentQ.explanation}</p>
          </div>
        )}

        {/* Next Question CTA */}
        {isAnswered && (
          <div className="pt-2 flex justify-end">
            <button
              onClick={handleNext}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all flex items-center gap-2"
            >
              <span>
                {currentIndex + 1 < questions.length ? 'Next Question' : 'View Final Results'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
