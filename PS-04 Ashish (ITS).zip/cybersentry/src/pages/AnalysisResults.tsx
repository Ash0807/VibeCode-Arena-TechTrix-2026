import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, NavLink } from 'react-router-dom';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Fingerprint,
  Cpu,
  HelpCircle,
  FileWarning,
  Trash2,
  ArrowLeft,
  CheckCircle2,
  ExternalLink,
  BookOpen,
  Share2,
  Sparkles,
} from 'lucide-react';
import type { ScanResult } from '@shared/types';
import { ConfirmModal } from '../components/ConfirmModal';
import { useToast } from '../context/ToastContext';

export const AnalysisResults: React.FC = () => {
  const { scanId } = useParams<{ scanId: string }>();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const [scan, setScan] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  useEffect(() => {
    if (!scanId) return;
    fetch(`/api/scans/${scanId}`, { credentials: 'include' })
      .then(res => {
        if (!res.ok) throw new Error('Scan not found or restricted');
        return res.json();
      })
      .then(data => setScan(data))
      .catch(err => {
        console.error(err);
        toastError('Not Found', 'Unable to load scan results.');
      })
      .finally(() => setLoading(false));
  }, [scanId]);

  const handleDelete = async () => {
    if (!scan) return;
    try {
      const res = await fetch(`/api/scans/${scan.scanId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (res.ok) {
        toastSuccess('Deleted', 'Scan record was removed.');
        navigate('/history');
      } else {
        toastError('Failed to delete', 'Could not delete scan record.');
      }
    } catch {
      toastError('Network Error', 'Error communicating with server.');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-[#9AABC2] space-y-4">
        <ShieldAlert className="w-12 h-12 text-[#39D9E8] animate-spin" />
        <p className="text-sm">Loading security inspection report...</p>
      </div>
    );
  }

  if (!scan) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center space-y-4">
        <AlertTriangle className="w-12 h-12 text-[#FB7185] mx-auto" />
        <h2 className="text-xl font-bold text-[#EDF5FF]">Report Unavailable</h2>
        <p className="text-sm text-[#9AABC2]">
          This scan could not be found or access is restricted by data retention policies.
        </p>
        <button
          onClick={() => navigate('/scanner')}
          className="px-5 py-2.5 rounded-xl bg-[#39D9E8] text-[#07111F] font-bold text-xs"
        >
          Return to Threat Scanner
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fadeIn">
      {/* Top Nav / Actions Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-xs font-semibold text-[#9AABC2] hover:text-[#EDF5FF] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Scanner</span>
        </button>

        <div className="flex items-center gap-3">
          <NavLink
            to={`/report?url=${encodeURIComponent(scan.inputPreview.slice(0, 150))}`}
            className="px-4 py-2 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#EDF5FF] border border-[#1D3352] transition-colors flex items-center gap-2"
          >
            <FileWarning className="w-4 h-4 text-[#FB7185]" />
            <span>Escalate as Incident</span>
          </NavLink>

          <button
            onClick={() => setDeleteModalOpen(true)}
            className="p-2 rounded-xl bg-[#101E30] hover:bg-[#FB7185]/10 text-[#9AABC2] hover:text-[#FB7185] border border-[#1D3352] transition-colors"
            title="Delete scan"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Security Score Banner */}
      <div className="rounded-3xl bg-[#101E30] border border-[#1D3352] p-6 lg:p-8 shadow-2xl relative overflow-hidden">
        <div
          className={`absolute top-0 right-0 w-80 h-80 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16 ${
            scan.riskLevel === 'high'
              ? 'bg-[#FB7185]/10'
              : scan.riskLevel === 'medium'
              ? 'bg-[#FBBF24]/10'
              : 'bg-[#34D399]/10'
          }`}
        />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div
              className={`p-4 rounded-2xl shrink-0 ${
                scan.riskLevel === 'high'
                  ? 'bg-[#FB7185]/20 text-[#FB7185] border border-[#FB7185]/40'
                  : scan.riskLevel === 'medium'
                  ? 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40'
                  : 'bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40'
              }`}
            >
              <ShieldAlert className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                    scan.riskLevel === 'high'
                      ? 'bg-[#FB7185]/20 text-[#FB7185]'
                      : scan.riskLevel === 'medium'
                      ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                      : 'bg-[#34D399]/20 text-[#34D399]'
                  }`}
                >
                  {scan.riskLevel} Risk Classification
                </span>
                <span className="text-xs text-[#9AABC2]">Input: {scan.inputType.toUpperCase()}</span>
              </div>
              <h1 className="text-2xl font-extrabold text-[#EDF5FF]">
                CyberSentry Verification Report
              </h1>
              <p className="text-xs text-[#9AABC2] flex items-center gap-4 pt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {new Date(scan.analyzedAt).toLocaleString()}
                </span>
                <span className="flex items-center gap-1 font-mono">
                  <Fingerprint className="w-3.5 h-3.5" />
                  {scan.scanId.slice(0, 8)}...
                </span>
              </p>
            </div>
          </div>

          {/* Risk Score Gauge Circle */}
          <div className="flex items-center gap-4 bg-[#07111F]/60 p-4 rounded-2xl border border-[#1D3352] self-start md:self-auto">
            <div className="text-right">
              <div className="text-3xl font-black text-[#EDF5FF] leading-none">
                {scan.riskScore}
                <span className="text-sm font-normal text-[#9AABC2]">/100</span>
              </div>
              <div className="text-[10px] uppercase font-bold text-[#9AABC2] tracking-wider mt-1">
                Heuristic Risk Score
              </div>
            </div>
            <div
              className={`w-3.5 h-12 rounded-full ${
                scan.riskLevel === 'high'
                  ? 'bg-[#FB7185]'
                  : scan.riskLevel === 'medium'
                  ? 'bg-[#FBBF24]'
                  : 'bg-[#34D399]'
              }`}
            />
          </div>
        </div>

        {/* Executive Summary */}
        <div className="mt-6 p-4 rounded-xl bg-[#07111F] border border-[#1D3352] text-sm text-[#EDF5FF] leading-relaxed">
          {scan.summary}
        </div>
      </div>

      {/* Input Preview & Extracted OCR Text (if applicable) */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2]">
          Analyzed Content Preview
        </h3>
        <div className="p-4 rounded-xl bg-[#07111F] border border-[#1D3352] font-mono text-xs text-[#EDF5FF] break-all leading-relaxed max-h-48 overflow-y-auto">
          {scan.extractedText || scan.inputPreview}
        </div>
        {scan.extractedText && (
          <p className="text-[11px] text-[#34D399] flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Extracted via local Tesseract OCR engine with zero cloud leakage</span>
          </p>
        )}
      </div>

      {/* Warning Indicators with "Why This Matters" */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-extrabold text-[#EDF5FF]">
            Detected Threat Indicators ({scan.findings.length})
          </h2>
          <span className="text-xs text-[#9AABC2]">Transparent rule-based heuristic findings</span>
        </div>

        {scan.findings.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {scan.findings.map(finding => (
              <div
                key={finding.id}
                className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-xl mt-0.5 shrink-0 ${
                        finding.severity === 'high'
                          ? 'bg-[#FB7185]/20 text-[#FB7185]'
                          : finding.severity === 'medium'
                          ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                          : 'bg-[#39D9E8]/20 text-[#39D9E8]'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#EDF5FF]">{finding.title}</h4>
                      <p className="text-xs text-[#9AABC2] mt-0.5">{finding.description}</p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full shrink-0 ${
                      finding.severity === 'high'
                        ? 'bg-[#FB7185]/20 text-[#FB7185]'
                        : finding.severity === 'medium'
                        ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                        : 'bg-[#39D9E8]/20 text-[#39D9E8]'
                    }`}
                  >
                    {finding.severity}
                  </span>
                </div>

                {finding.matchedSample && (
                  <div className="p-2.5 rounded-lg bg-[#07111F] text-xs font-mono text-[#39D9E8] border border-[#1D3352]/70">
                    Matched Pattern: <span className="text-[#EDF5FF]">{finding.matchedSample}</span>
                  </div>
                )}

                {/* Why This Matters Explainer */}
                <div className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] text-xs">
                  <span className="font-bold text-[#EDF5FF] flex items-center gap-1.5 mb-1 text-[11px] uppercase tracking-wider text-[#39D9E8]">
                    <HelpCircle className="w-3.5 h-3.5" />
                    Why This Matters:
                  </span>
                  <p className="text-[#9AABC2] leading-relaxed">{finding.whyItMatters}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 rounded-2xl bg-[#101E30] border border-[#34D399]/40 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-[#34D399] mx-auto" />
            <h3 className="text-sm font-bold text-[#EDF5FF]">No Warning Indicators Detected</h3>
            <p className="text-xs text-[#9AABC2] max-w-md mx-auto">
              This submission contains no common phishing syntax, brand typosquatting, or urgency keywords.
              However, novel or targeted attacks may still occur. Always verify independently.
            </p>
          </div>
        )}
      </div>

      {/* Prioritized Recommendations */}
      <div className="space-y-4">
        <h2 className="text-base font-extrabold text-[#EDF5FF]">Recommended Next Steps</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {scan.recommendations.map(rec => (
            <div
              key={rec.id}
              className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-2"
            >
              <div className="flex items-center justify-between">
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    rec.priority === 'immediate'
                      ? 'bg-[#FB7185]/20 text-[#FB7185]'
                      : rec.priority === 'recommended'
                      ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                      : 'bg-[#34D399]/20 text-[#34D399]'
                  }`}
                >
                  {rec.priority} Action
                </span>
              </div>
              <h4 className="text-sm font-bold text-[#EDF5FF]">{rec.title}</h4>
              <p className="text-xs text-[#9AABC2] leading-relaxed">{rec.action}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Limitations and Uncertainty Disclosure */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#9AABC2]">
          <Cpu className="w-4 h-4 text-[#8B7CFF]" />
          <span>System Limitations & Uncertainty Disclosure</span>
        </div>
        <ul className="space-y-2 text-xs text-[#9AABC2]">
          {scan.limitations.map((limit, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#39D9E8] font-bold">•</span>
              <span>{limit}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Bottom Navigation CTAs */}
      <div className="pt-4 flex flex-wrap items-center justify-between gap-4 border-t border-[#1D3352]">
        <NavLink
          to="/scanner"
          className="px-5 py-2.5 rounded-xl bg-[#39D9E8] hover:bg-[#2fc0ce] text-[#07111F] font-bold text-xs shadow-glow-primary transition-all"
        >
          Scan Another Item
        </NavLink>

        <div className="flex items-center gap-3">
          <NavLink
            to="/academy"
            className="px-4 py-2 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#EDF5FF] border border-[#1D3352] transition-colors flex items-center gap-1.5"
          >
            <BookOpen className="w-4 h-4 text-[#8B7CFF]" />
            <span>Read Related Lessons</span>
          </NavLink>

          <NavLink
            to="/history"
            className="px-4 py-2 rounded-xl bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#EDF5FF] border border-[#1D3352] transition-colors"
          >
            Scan History
          </NavLink>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteModalOpen}
        title="Delete Scan Record?"
        message="Are you sure you want to permanently delete this scan result? This cannot be undone."
        confirmText="Delete Record"
        onConfirm={handleDelete}
        onCancel={() => setDeleteModalOpen(false)}
      />
    </div>
  );
};
