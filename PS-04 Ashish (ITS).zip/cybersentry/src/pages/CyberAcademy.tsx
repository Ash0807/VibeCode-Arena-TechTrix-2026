import React, { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  BookOpen,
  Clock,
  Search,
  ArrowRight,
  ShieldCheck,
  Award,
  Sparkles,
} from 'lucide-react';
import type { Lesson } from '@shared/types';

export const CyberAcademy: React.FC = () => {
  const navigate = useNavigate();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    fetch('/api/academy/lessons')
      .then(res => res.json())
      .then(data => setLessons(data))
      .catch(err => console.error('Failed to load lessons:', err))
      .finally(() => setLoading(false));
  }, []);

  const categories = ['all', ...Array.from(new Set(lessons.map(l => l.category)))];

  const filteredLessons = lessons.filter(l => {
    const matchesSearch =
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.summary.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'all' || l.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-8 max-w-6xl mx-auto animate-fadeIn">
      {/* Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#101E30] via-[#13233A] to-[#101E30] border border-[#1D3352] p-6 lg:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B7CFF]/15 border border-[#8B7CFF]/30 text-xs font-semibold text-[#8B7CFF]">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>CyberSentry Defense Curriculum</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-[#EDF5FF]">
              Cyber Academy
            </h1>
            <p className="text-sm text-[#9AABC2] leading-relaxed">
              Equip yourself with practical cybersecurity defense knowledge. Learn the psychology of
              scammers, recognize social engineering attacks, and safeguard your financial accounts.
            </p>
          </div>

          <NavLink
            to="/quiz"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8B7CFF] to-[#39D9E8] text-[#07111F] font-bold text-xs shadow-glow-secondary hover:opacity-95 transition-all flex items-center gap-2 shrink-0 self-start md:self-auto"
          >
            <Award className="w-4 h-4" />
            <span>Take Certification Quiz</span>
          </NavLink>
        </div>
      </div>

      {/* Search and Category Filter */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search cybersecurity lessons by topic..."
            className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#101E30] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#8B7CFF]"
          />
          <Search className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors capitalize ${
                selectedCategory === cat
                  ? 'bg-[#8B7CFF] text-white shadow-glow-secondary'
                  : 'bg-[#101E30] text-[#9AABC2] hover:text-[#EDF5FF] border border-[#1D3352]'
              }`}
            >
              {cat === 'all' ? 'All Lessons' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Lesson Cards Grid */}
      {loading ? (
        <div className="p-12 text-center text-[#9AABC2] space-y-3">
          <GraduationCap className="w-8 h-8 text-[#8B7CFF] animate-spin mx-auto" />
          <p className="text-xs">Loading lessons...</p>
        </div>
      ) : filteredLessons.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredLessons.map(lesson => (
            <div
              key={lesson.id}
              onClick={() => navigate(`/academy/${lesson.id}`)}
              className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#8B7CFF]/50 transition-all cursor-pointer flex flex-col justify-between group shadow-lg"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full bg-[#8B7CFF]/15 text-[#8B7CFF] border border-[#8B7CFF]/30">
                    {lesson.category}
                  </span>
                  <span className="text-[11px] text-[#9AABC2] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {lesson.readTime}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#EDF5FF] group-hover:text-[#39D9E8] transition-colors leading-snug">
                  {lesson.title}
                </h3>

                <p className="text-xs text-[#9AABC2] line-clamp-3 leading-relaxed">
                  {lesson.summary}
                </p>
              </div>

              <div className="mt-4 pt-4 border-t border-[#1D3352]/70 flex items-center justify-between text-xs font-semibold text-[#8B7CFF] group-hover:text-[#39D9E8] transition-colors">
                <span>Read Lesson Guide</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 rounded-2xl bg-[#101E30] border border-[#1D3352] text-center space-y-3">
          <BookOpen className="w-8 h-8 text-[#9AABC2]/40 mx-auto" />
          <h3 className="text-sm font-bold text-[#EDF5FF]">No Lessons Found</h3>
          <p className="text-xs text-[#9AABC2]">Try adjusting your search query or category filter.</p>
        </div>
      )}
    </div>
  );
};
