import React, { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  ShieldCheck,
  FileWarning,
  Camera,
  Mail,
  Link2,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  ArrowRight,
  BookOpen,
  Award,
  Sparkles,
  Info,
  Clock,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import type { DashboardStats, ScanResult, Incident } from '@shared/types';
import { useAuth } from '../context/AuthContext';

const DAILY_TIPS = [
  {
    title: 'UPI PIN Verification Golden Rule',
    tip: 'You never need to enter your UPI PIN or scan a QR code to receive money. If an online buyer tells you to enter a PIN to receive a payment, it is 100% a fraud attempt.',
    category: 'Financial Safety',
  },
  {
    title: 'Inspect Email Sender Domain Closely',
    tip: 'Look beyond the sender display name. Fraudsters often use names like "SBI Security Desk" paired with generic Gmail or lookalike domains like sbi-support-bank.xyz.',
    category: 'Phishing Defense',
  },
  {
    title: 'The "Golden Hour" of Cyber Fraud',
    tip: 'If you fall victim to financial cyber fraud, dial 1930 immediately. Reporting within 1-2 hours drastically maximizes law enforcement ability to freeze funds in mule accounts.',
    category: 'Emergency Action',
  },
  {
    title: 'Shortened Links Conceal Intent',
    tip: 'Never input passwords or sensitive OTPs on pages reached via generic URL shorteners (bit.ly, tinyurl) without verifying the root domain in your browser bar.',
    category: 'Safe Browsing',
  },
];

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [tipIndex] = useState(() => Math.floor(Math.random() * DAILY_TIPS.length));

  useEffect(() => {
    fetch('/api/dashboard/stats', { credentials: 'include' })
      .then(res => res.json())
      .then(data => {
        setStats(data);
      })
      .catch(err => console.error('Failed to load dashboard stats:', err))
      .finally(() => setLoading(false));
  }, []);

  const currentTip = DAILY_TIPS[tipIndex];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Welcome & Security Posture Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#101E30] via-[#13233A] to-[#101E30] border border-[#1D3352] p-6 lg:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#39D9E8]/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#39D9E8]/10 border border-[#39D9E8]/30 text-xs font-semibold text-[#39D9E8]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>CyberSentry Autonomous Protection</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold text-[#EDF5FF] tracking-tight">
              Welcome back{user?.name ? `, ${user.name}` : ''}
            </h1>
            <p className="text-sm text-[#9AABC2] leading-relaxed">
              Verify suspicious emails, links, and SMS messages before they compromise your privacy
              or financial accounts. Your proactive digital safety hub is running with active heuristic rules.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <NavLink
              to="/scanner"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] font-bold text-sm shadow-glow-primary hover:opacity-95 transition-all flex items-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Scan Suspicious Threat</span>
            </NavLink>
            <NavLink
              to="/report"
              className="px-5 py-2.5 rounded-xl bg-[#101E30] hover:bg-[#13233A] text-[#EDF5FF] border border-[#1D3352] font-semibold text-sm transition-all flex items-center gap-2"
            >
              <FileWarning className="w-4 h-4 text-[#FB7185]" />
              <span>Report Incident</span>
            </NavLink>
          </div>
        </div>

        {stats?.isDemoData && (
          <div className="mt-6 pt-4 border-t border-[#1D3352]/70 flex items-center gap-2 text-xs text-[#FBBF24]">
            <Info className="w-4 h-4 shrink-0" />
            <span>
              <strong>Demonstration Mode:</strong> Sample incidents are seeded for exploration. Live scans you submit will appear dynamically in your dashboard metrics.
            </span>
          </div>
        )}
      </div>

      {/* Quick Action Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button
          onClick={() => navigate('/scanner?mode=url')}
          className="flex flex-col items-start p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#39D9E8]/50 hover:bg-[#13233A] transition-all group text-left"
        >
          <div className="p-2.5 rounded-xl bg-[#39D9E8]/10 text-[#39D9E8] mb-3 group-hover:scale-110 transition-transform">
            <Link2 className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-[#EDF5FF]">Scan a URL</span>
          <span className="text-xs text-[#9AABC2] mt-0.5">Analyze link syntax & brand spoofing</span>
        </button>

        <button
          onClick={() => navigate('/scanner?mode=email')}
          className="flex flex-col items-start p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#8B7CFF]/50 hover:bg-[#13233A] transition-all group text-left"
        >
          <div className="p-2.5 rounded-xl bg-[#8B7CFF]/10 text-[#8B7CFF] mb-3 group-hover:scale-110 transition-transform">
            <Mail className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-[#EDF5FF]">Email Scanner</span>
          <span className="text-xs text-[#9AABC2] mt-0.5">Detect urgency, BEC & credential asks</span>
        </button>

        <button
          onClick={() => navigate('/scanner?mode=screenshot')}
          className="flex flex-col items-start p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#34D399]/50 hover:bg-[#13233A] transition-all group text-left"
        >
          <div className="p-2.5 rounded-xl bg-[#34D399]/10 text-[#34D399] mb-3 group-hover:scale-110 transition-transform">
            <Camera className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-[#EDF5FF]">Screenshot OCR</span>
          <span className="text-xs text-[#9AABC2] mt-0.5">Extract & verify message screenshots</span>
        </button>

        <button
          onClick={() => navigate('/report')}
          className="flex flex-col items-start p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] hover:border-[#FB7185]/50 hover:bg-[#13233A] transition-all group text-left"
        >
          <div className="p-2.5 rounded-xl bg-[#FB7185]/10 text-[#FB7185] mb-3 group-hover:scale-110 transition-transform">
            <FileWarning className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-[#EDF5FF]">Report Incident</span>
          <span className="text-xs text-[#9AABC2] mt-0.5">Document fraud & receive report ID</span>
        </button>
      </div>

      {/* Aggregate Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between text-[#9AABC2] text-xs font-medium mb-2">
            <span>Total Threats Scanned</span>
            <ShieldCheck className="w-4 h-4 text-[#39D9E8]" />
          </div>
          <div className="text-3xl font-extrabold text-[#EDF5FF]">
            {loading ? '—' : stats?.totalScans ?? 0}
          </div>
          <div className="text-xs text-[#9AABC2] mt-1.5 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-[#34D399]" />
            <span>Cumulative verification queries</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between text-[#9AABC2] text-xs font-medium mb-2">
            <span>High-Risk Findings</span>
            <AlertTriangle className="w-4 h-4 text-[#FB7185]" />
          </div>
          <div className="text-3xl font-extrabold text-[#FB7185]">
            {loading ? '—' : stats?.highRiskCount ?? 0}
          </div>
          <div className="text-xs text-[#9AABC2] mt-1.5">
            Severe scam or impersonation patterns
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between text-[#9AABC2] text-xs font-medium mb-2">
            <span>Moderate Warnings</span>
            <AlertTriangle className="w-4 h-4 text-[#FBBF24]" />
          </div>
          <div className="text-3xl font-extrabold text-[#FBBF24]">
            {loading ? '—' : stats?.mediumRiskCount ?? 0}
          </div>
          <div className="text-xs text-[#9AABC2] mt-1.5">
            Ambiguous or shortlink warnings
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between text-[#9AABC2] text-xs font-medium mb-2">
            <span>Incidents Documented</span>
            <FileWarning className="w-4 h-4 text-[#8B7CFF]" />
          </div>
          <div className="text-3xl font-extrabold text-[#8B7CFF]">
            {loading ? '—' : stats?.totalReports ?? 0}
          </div>
          <div className="text-xs text-[#9AABC2] mt-1.5">
            {stats?.pendingReports ?? 0} awaiting review
          </div>
        </div>
      </div>

      {/* Visual Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Threat Distribution Chart */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#EDF5FF]">Threat Severity Distribution</h2>
            <span className="text-[11px] text-[#9AABC2]">Historical scans</span>
          </div>

          <div className="h-56 flex items-center justify-center">
            {stats && (stats.totalScans > 0 || stats.riskDistribution.some(d => d.value > 0)) ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.riskDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {stats.riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#101E30',
                      border: '1px solid #1D3352',
                      borderRadius: '12px',
                      color: '#EDF5FF',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center text-[#9AABC2] text-xs">
                <ShieldCheck className="w-10 h-10 text-[#39D9E8]/30 mb-2" />
                <span>Submit scans to view threat distribution</span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-around pt-3 border-t border-[#1D3352]/70 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FB7185]" />
              <span className="text-[#9AABC2]">High: {stats?.highRiskCount ?? 0}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FBBF24]" />
              <span className="text-[#9AABC2]">Med: {stats?.mediumRiskCount ?? 0}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#34D399]" />
              <span className="text-[#9AABC2]">Low: {stats?.lowRiskCount ?? 0}</span>
            </div>
          </div>
        </div>

        {/* Scan Trends by Input Type */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-[#EDF5FF]">Activity Trends (Last 7 Days)</h2>
              <p className="text-xs text-[#9AABC2]">Volume across URL, Email, SMS, and Screenshot inputs</p>
            </div>
          </div>

          <div className="h-56">
            {stats && stats.scanTrends && stats.scanTrends.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.scanTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1D3352" vertical={false} />
                  <XAxis dataKey="date" stroke="#9AABC2" fontSize={11} tickLine={false} />
                  <YAxis stroke="#9AABC2" fontSize={11} tickLine={false} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#101E30',
                      border: '1px solid #1D3352',
                      borderRadius: '12px',
                      color: '#EDF5FF',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="url" name="URLs" fill="#39D9E8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="email" name="Emails" fill="#8B7CFF" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="sms" name="SMS" fill="#FBBF24" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="screenshot" name="Screenshots" fill="#34D399" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-[#9AABC2] text-xs">
                No trend data available
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-5 pt-3 border-t border-[#1D3352]/70 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#39D9E8]" />
              <span className="text-[#9AABC2]">URLs</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#8B7CFF]" />
              <span className="text-[#9AABC2]">Emails</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FBBF24]" />
              <span className="text-[#9AABC2]">SMS</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#34D399]" />
              <span className="text-[#9AABC2]">Screenshots</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tip of the Day & Cyber Academy Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Daily Safety Advice */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#39D9E8]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Security Tip of the Day</span>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#13233A] text-[#9AABC2] border border-[#1D3352]">
                {currentTip.category}
              </span>
            </div>
            <h3 className="text-base font-bold text-[#EDF5FF] mb-2">{currentTip.title}</h3>
            <p className="text-sm text-[#9AABC2] leading-relaxed">{currentTip.tip}</p>
          </div>
          <div className="mt-5 pt-4 border-t border-[#1D3352]/70 flex items-center justify-between">
            <span className="text-xs text-[#9AABC2]">Knowledge is your strongest defense</span>
            <NavLink
              to="/academy"
              className="text-xs font-semibold text-[#39D9E8] hover:underline flex items-center gap-1"
            >
              <span>Explore Cyber Academy</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </NavLink>
          </div>
        </div>

        {/* Interactive Quiz CTA */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#101E30] to-[#13233A] border border-[#1D3352] flex flex-col justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B7CFF] mb-3">
              <Award className="w-3.5 h-3.5" />
              <span>Cyber Awareness Certification</span>
            </div>
            <h3 className="text-base font-bold text-[#EDF5FF] mb-2">Test Your Threat Detection Skills</h3>
            <p className="text-sm text-[#9AABC2] leading-relaxed">
              Take our 15-question interactive cybersecurity quiz. Learn to spot UPI traps, phishing domains,
              MFA fatigue attacks, and advance-fee scams with instant explanations.
            </p>
          </div>
          <div className="mt-5 pt-4 border-t border-[#1D3352]/70 flex items-center justify-between">
            <span className="text-xs text-[#9AABC2]">15 Comprehensive Questions</span>
            <NavLink
              to="/quiz"
              className="px-4 py-2 rounded-xl bg-[#8B7CFF] hover:bg-[#7a6aeb] text-white font-semibold text-xs transition-all shadow-glow-secondary flex items-center gap-1.5"
            >
              <span>Start Quiz</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </NavLink>
          </div>
        </div>
      </div>

      {/* Recent Activity Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Scans */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#EDF5FF]">Recent Threat Scans</h2>
            <NavLink to="/history" className="text-xs font-semibold text-[#39D9E8] hover:underline">
              View All History
            </NavLink>
          </div>

          {stats?.recentScans && stats.recentScans.length > 0 ? (
            <div className="space-y-3">
              {stats.recentScans.map(scan => (
                <div
                  key={scan.scanId}
                  onClick={() => navigate(`/results/${scan.scanId}`)}
                  className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] hover:border-[#39D9E8]/40 transition-all cursor-pointer flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-lg shrink-0 ${
                        scan.riskLevel === 'high'
                          ? 'bg-[#FB7185]/15 text-[#FB7185]'
                          : scan.riskLevel === 'medium'
                          ? 'bg-[#FBBF24]/15 text-[#FBBF24]'
                          : 'bg-[#34D399]/15 text-[#34D399]'
                      }`}
                    >
                      <ShieldAlert className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#EDF5FF] truncate group-hover:text-[#39D9E8] transition-colors">
                        {scan.inputPreview}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-[#9AABC2] mt-0.5">
                        <span className="uppercase font-medium">{scan.inputType}</span>
                        <span>•</span>
                        <span>Score: {scan.riskScore}/100</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        scan.riskLevel === 'high'
                          ? 'bg-[#FB7185]/20 text-[#FB7185]'
                          : scan.riskLevel === 'medium'
                          ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                          : 'bg-[#34D399]/20 text-[#34D399]'
                      }`}
                    >
                      {scan.riskLevel}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#9AABC2] group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-[#9AABC2] text-xs">
              <ShieldCheck className="w-8 h-8 text-[#39D9E8]/30 mx-auto mb-2" />
              <p>No recent scans found.</p>
              <NavLink to="/scanner" className="text-[#39D9E8] font-semibold hover:underline mt-1 inline-block">
                Run your first threat scan
              </NavLink>
            </div>
          )}
        </div>

        {/* Recent Incidents */}
        <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#EDF5FF]">Recent Incident Reports</h2>
            <NavLink to="/incidents/track" className="text-xs font-semibold text-[#39D9E8] hover:underline">
              Track Any Report ID
            </NavLink>
          </div>

          {stats?.recentIncidents && stats.recentIncidents.length > 0 ? (
            <div className="space-y-3">
              {stats.recentIncidents.map(inc => (
                <div
                  key={inc.id}
                  onClick={() => navigate(`/incidents/${inc.reportId}`)}
                  className="p-3.5 rounded-xl bg-[#13233A] border border-[#1D3352] hover:border-[#8B7CFF]/40 transition-all cursor-pointer flex items-center justify-between gap-3 group"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold text-[#39D9E8]">
                        {inc.reportId}
                      </span>
                      <span className="text-[10px] text-[#9AABC2] capitalize">
                        {inc.category.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-xs text-[#9AABC2] line-clamp-1 group-hover:text-[#EDF5FF] transition-colors">
                      {inc.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        inc.status === 'Resolved'
                          ? 'bg-[#34D399]/20 text-[#34D399]'
                          : inc.status === 'Under Review'
                          ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                          : inc.status === 'Closed'
                          ? 'bg-[#9AABC2]/20 text-[#9AABC2]'
                          : 'bg-[#39D9E8]/20 text-[#39D9E8]'
                      }`}
                    >
                      {inc.status}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#9AABC2] group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-[#9AABC2] text-xs">
              <FileWarning className="w-8 h-8 text-[#FB7185]/30 mx-auto mb-2" />
              <p>No incidents submitted yet.</p>
              <NavLink to="/report" className="text-[#39D9E8] font-semibold hover:underline mt-1 inline-block">
                Report a cyber incident
              </NavLink>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
