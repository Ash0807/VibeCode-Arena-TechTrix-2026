import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  ShieldCheck,
  FileWarning,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Search,
  Filter,
  Download,
  Lock,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  User,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import type { Incident, IncidentStatus, IncidentCategory, IncidentStatusHistory } from '@shared/types';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const AdminDashboard: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<IncidentStatus | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<IncidentCategory | 'all'>('all');

  // Modal / Selected Incident
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [incidentHistory, setIncidentHistory] = useState<IncidentStatusHistory[]>([]);
  const [newStatus, setNewStatus] = useState<IncidentStatus>('Under Review');
  const [reviewNote, setReviewNote] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchIncidents = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        search: search.trim(),
        status: statusFilter,
        category: categoryFilter,
      });

      const res = await fetch(`/api/incidents?${params.toString()}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Unauthorized or failed to load incident queue');
      const data = await res.json();
      setIncidents(data.items || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch (err: any) {
      toastError('Access Error', err?.message || 'Failed to fetch incident queue');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchIncidents();
    }
  }, [user, page, statusFilter, categoryFilter]);

  const openIncidentModal = async (inc: Incident) => {
    setSelectedIncident(inc);
    setNewStatus(inc.status);
    setReviewNote('');
    try {
      const res = await fetch(`/api/incidents/track/${inc.reportId}`);
      if (res.ok) {
        const data = await res.json();
        setIncidentHistory(data.history || []);
      }
    } catch {
      setIncidentHistory([]);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIncident) return;
    setIsUpdating(true);

    try {
      const res = await fetch(`/api/incidents/${selectedIncident.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          status: newStatus,
          notes: reviewNote.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status');

      toastSuccess('Status Updated', `Report ${selectedIncident.reportId} transitioned to ${newStatus}`);
      setSelectedIncident(null);
      fetchIncidents();
    } catch (err: any) {
      toastError('Update Error', err?.message || 'Failed to update status');
    } finally {
      setIsUpdating(false);
    }
  };

  if (authLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-[#9AABC2] space-y-3">
        <ShieldCheck className="w-8 h-8 text-[#8B7CFF] animate-spin" />
        <p className="text-xs">Verifying administrator clearance...</p>
      </div>
    );
  }

  // Admin Route Protection Guard
  if (!user || user.role !== 'admin') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 rounded-3xl bg-[#101E30] border border-[#FB7185]/40 text-center space-y-4 shadow-2xl">
        <div className="w-14 h-14 rounded-2xl bg-[#FB7185]/15 text-[#FB7185] flex items-center justify-center mx-auto">
          <Lock className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-[#EDF5FF]">Administrator Clearance Required</h2>
        <p className="text-xs text-[#9AABC2] leading-relaxed">
          Access to the CyberSentry triage command queue is restricted to authorized platform security personnel.
        </p>
        <div className="pt-2">
          <NavLink
            to="/login"
            className="inline-block px-5 py-2.5 rounded-xl bg-[#39D9E8] text-[#07111F] font-bold text-xs shadow-glow-primary"
          >
            Sign In with Admin Account
          </NavLink>
        </div>
        <p className="text-[11px] text-[#9AABC2] pt-2">
          Demo Admin: <code className="text-[#39D9E8]">admin@cybersentry.local</code>
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl mx-auto animate-fadeIn">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 lg:p-8 rounded-3xl bg-[#101E30] border border-[#1D3352] shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B7CFF]/15 border border-[#8B7CFF]/30 text-xs font-semibold text-[#8B7CFF] mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Administrator Command Console</span>
          </div>
          <h1 className="text-2xl font-extrabold text-[#EDF5FF]">Incident Triage & Response</h1>
          <p className="text-xs text-[#9AABC2]">
            Review documented incidents, update statuses, audit investigation logs, and coordinate remediation
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-[#07111F] border border-[#1D3352] text-right">
            <div className="text-xl font-black text-[#EDF5FF] leading-none">{total}</div>
            <div className="text-[10px] uppercase font-bold text-[#9AABC2] tracking-wider mt-0.5">
              Total Queue
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-[#101E30] border border-[#1D3352] flex flex-col md:flex-row items-center gap-3">
        <form
          onSubmit={e => {
            e.preventDefault();
            setPage(1);
            fetchIncidents();
          }}
          className="relative flex-1 w-full"
        >
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search queue by Report ID, description, or URL..."
            className="w-full px-4 py-2.5 pl-10 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] placeholder-[#9AABC2]/60 focus:outline-none focus:border-[#8B7CFF]"
          />
          <Search className="w-4 h-4 text-[#9AABC2] absolute left-3.5 top-3" />
        </form>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={e => {
              setStatusFilter(e.target.value as any);
              setPage(1);
            }}
            aria-label="Filter by Status"
            className="px-3 py-2.5 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#8B7CFF]"
          >
            <option value="all">All Statuses</option>
            <option value="Submitted">Submitted</option>
            <option value="Under Review">Under Review</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>

          <select
            value={categoryFilter}
            onChange={e => {
              setCategoryFilter(e.target.value as any);
              setPage(1);
            }}
            aria-label="Filter by Category"
            className="px-3 py-2.5 rounded-xl bg-[#07111F] border border-[#1D3352] text-xs text-[#EDF5FF] focus:outline-none focus:border-[#8B7CFF]"
          >
            <option value="all">All Categories</option>
            <option value="phishing">Phishing</option>
            <option value="upi_fraud">UPI Fraud</option>
            <option value="impersonation">Impersonation</option>
            <option value="fake_website">Fake Website</option>
            <option value="account_compromise">Account Takeover</option>
            <option value="shopping_fraud">Shopping Fraud</option>
            <option value="social_engineering">Social Engineering</option>
          </select>
        </div>
      </div>

      {/* Incident Queue Table */}
      <div className="rounded-2xl bg-[#101E30] border border-[#1D3352] overflow-hidden shadow-xl">
        {loading ? (
          <div className="p-12 text-center text-[#9AABC2] space-y-3">
            <ShieldCheck className="w-8 h-8 text-[#8B7CFF] animate-spin mx-auto" />
            <p className="text-xs">Fetching incidents...</p>
          </div>
        ) : incidents.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#07111F]/70 text-[#9AABC2] uppercase font-bold border-b border-[#1D3352]">
                <tr>
                  <th className="px-5 py-3.5">Report ID</th>
                  <th className="px-4 py-3.5">Category</th>
                  <th className="px-4 py-3.5">Description</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5">Date</th>
                  <th className="px-4 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D3352]/70">
                {incidents.map(inc => (
                  <tr key={inc.id} className="hover:bg-[#13233A]/60 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-bold text-[#39D9E8]">
                      {inc.reportId}
                    </td>
                    <td className="px-4 py-3.5 capitalize text-[#EDF5FF]">
                      {inc.category.replace('_', ' ')}
                    </td>
                    <td className="px-4 py-3.5 max-w-xs truncate text-[#9AABC2]">
                      {inc.description}
                    </td>
                    <td className="px-4 py-3.5">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase ${
                          inc.status === 'Resolved'
                            ? 'bg-[#34D399]/20 text-[#34D399]'
                            : inc.status === 'Under Review'
                            ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                            : inc.status === 'Closed'
                            ? 'bg-[#9AABC2]/20 text-[#9AABC2]'
                            : 'bg-[#39D9E8]/20 text-[#39D9E8]'
                        }`}
                      >
                        {inc.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-[#9AABC2] whitespace-nowrap">
                      {new Date(inc.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <button
                        onClick={() => openIncidentModal(inc)}
                        className="px-3 py-1 rounded-lg bg-[#13233A] hover:bg-[#8B7CFF] text-[#EDF5FF] font-semibold text-xs transition-colors"
                      >
                        Manage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center text-[#9AABC2] space-y-2">
            <CheckCircle2 className="w-8 h-8 text-[#34D399] mx-auto" />
            <h3 className="text-sm font-bold text-[#EDF5FF]">Incident Queue Clear</h3>
            <p className="text-xs">No reports currently matching the active filters.</p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-[#1D3352] text-xs text-[#9AABC2]">
            <span>Page {page} of {totalPages}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="p-1.5 rounded-lg bg-[#07111F] border border-[#1D3352] disabled:opacity-40"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
                className="p-1.5 rounded-lg bg-[#07111F] border border-[#1D3352] disabled:opacity-40"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Selected Incident Detail & Status Update Modal */}
      {selectedIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#101E30] border border-[#1D3352] rounded-3xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#1D3352]">
              <div>
                <span className="font-mono text-xs font-bold text-[#39D9E8]">
                  {selectedIncident.reportId}
                </span>
                <h3 className="text-lg font-bold text-[#EDF5FF] capitalize">
                  {selectedIncident.category.replace('_', ' ')}
                </h3>
              </div>
              <button
                onClick={() => setSelectedIncident(null)}
                className="text-[#9AABC2] hover:text-white text-xs font-semibold px-2 py-1 rounded bg-[#13233A]"
              >
                Close
              </button>
            </div>

            {/* Description */}
            <div className="p-4 rounded-xl bg-[#07111F] border border-[#1D3352] space-y-2 text-xs">
              <span className="font-bold text-[#9AABC2] uppercase tracking-wider block">
                Reported Incident Narrative
              </span>
              <p className="text-[#EDF5FF] leading-relaxed">{selectedIncident.description}</p>
              {selectedIncident.suspiciousUrl && (
                <p className="text-[#39D9E8] font-mono break-all pt-1">
                  URL: {selectedIncident.suspiciousUrl}
                </p>
              )}
              {selectedIncident.contactInfo && (
                <p className="text-[#9AABC2] pt-1">
                  Reporter Contact: <strong className="text-[#EDF5FF]">{selectedIncident.contactInfo}</strong>
                </p>
              )}
            </div>

            {/* Evidence Link */}
            {selectedIncident.evidenceFileName && (
              <a
                href={`/api/incidents/${selectedIncident.id}/evidence`}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#13233A] hover:bg-[#1D3352] text-xs font-semibold text-[#39D9E8] border border-[#1D3352]"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Attached Evidence</span>
              </a>
            )}

            {/* Status Update Form */}
            <form onSubmit={handleUpdateStatus} className="p-4 rounded-xl bg-[#07111F] border border-[#8B7CFF]/40 space-y-3">
              <span className="text-xs font-bold text-[#8B7CFF] uppercase tracking-wider block">
                Update Case Status & Notes
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[#9AABC2] mb-1">New Status</label>
                  <select
                    value={newStatus}
                    onChange={e => setNewStatus(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl bg-[#101E30] border border-[#1D3352] text-[#EDF5FF]"
                  >
                    <option value="Submitted">Submitted</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Closed">Closed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#9AABC2] mb-1">Audit Note (visible to user)</label>
                  <input
                    type="text"
                    value={reviewNote}
                    onChange={e => setReviewNote(e.target.value)}
                    placeholder="e.g. Blocklist requested / Evidence verified"
                    className="w-full p-2.5 rounded-xl bg-[#101E30] border border-[#1D3352] text-[#EDF5FF]"
                  />
                </div>
              </div>
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="px-5 py-2 rounded-xl bg-[#8B7CFF] text-white text-xs font-bold shadow-glow-secondary disabled:opacity-50"
                >
                  {isUpdating ? 'Saving...' : 'Confirm Status Change'}
                </button>
              </div>
            </form>

            {/* Audit History */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#9AABC2] block">
                Status Audit Trail ({incidentHistory.length})
              </span>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {incidentHistory.map(h => (
                  <div key={h.id} className="p-2.5 rounded-lg bg-[#13233A] text-xs flex flex-col gap-0.5">
                    <div className="flex justify-between text-[#9AABC2] text-[11px]">
                      <span>By: <strong className="text-[#EDF5FF]">{h.changedBy}</strong></span>
                      <span>{new Date(h.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="font-semibold text-[#39D9E8]">Status: {h.newStatus}</div>
                    {h.notes && <div className="text-[#EDF5FF] text-[11px]">{h.notes}</div>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
