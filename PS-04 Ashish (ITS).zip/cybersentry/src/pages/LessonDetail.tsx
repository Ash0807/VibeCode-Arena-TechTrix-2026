import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, NavLink } from 'react-router-dom';
import {
  GraduationCap,
  Clock,
  ArrowLeft,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Award,
  ArrowRight,
  BookOpen,
} from 'lucide-react';
import type { Lesson } from '@shared/types';

export const LessonDetail: React.FC = () => {
  const { lessonId } = useParams<{ lessonId: string }>();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!lessonId) return;
    fetch(`/api/academy/lessons/${lessonId}`)
      .then(res => {
        if (!res.ok) throw new Error('Lesson not found');
        return res.json();
      })
      .then(data => setLesson(data))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, [lessonId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-[#9AABC2] space-y-3">
        <GraduationCap className="w-8 h-8 text-[#8B7CFF] animate-spin" />
        <p className="text-xs">Loading lesson material...</p>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="p-8 text-center space-y-3">
        <AlertTriangle className="w-10 h-10 text-[#FB7185] mx-auto" />
        <h2 className="text-lg font-bold text-[#EDF5FF]">Lesson Not Found</h2>
        <button
          onClick={() => navigate('/academy')}
          className="px-4 py-2 rounded-xl bg-[#39D9E8] text-[#07111F] text-xs font-bold"
        >
          Return to Cyber Academy
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn pb-12">
      <button
        onClick={() => navigate('/academy')}
        className="flex items-center gap-2 text-xs font-semibold text-[#9AABC2] hover:text-[#EDF5FF] transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Academy</span>
      </button>

      {/* Lesson Header */}
      <div className="p-6 lg:p-8 rounded-3xl bg-[#101E30] border border-[#1D3352] space-y-4 shadow-2xl">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold uppercase px-2.5 py-0.5 rounded-full bg-[#8B7CFF]/15 text-[#8B7CFF] border border-[#8B7CFF]/30">
            {lesson.category}
          </span>
          <span className="text-xs text-[#9AABC2] flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {lesson.readTime}
          </span>
        </div>

        <h1 className="text-2xl lg:text-3xl font-extrabold text-[#EDF5FF] leading-tight">
          {lesson.title}
        </h1>

        <p className="text-sm text-[#9AABC2] leading-relaxed">
          {lesson.summary}
        </p>

        <div className="pt-2 flex items-center gap-3">
          <NavLink
            to="/quiz"
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8B7CFF] to-[#39D9E8] text-[#07111F] font-bold text-xs shadow-glow-secondary hover:opacity-95 transition-all flex items-center gap-2"
          >
            <Award className="w-4 h-4" />
            <span>Test Knowledge with Quiz</span>
          </NavLink>
        </div>
      </div>

      {/* Real-World Case Study Scenario */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#39D9E8]">
          <BookOpen className="w-4 h-4" />
          <span>Fictional Real-World Scenario</span>
        </div>
        <p className="text-xs text-[#EDF5FF] leading-relaxed bg-[#07111F] p-4 rounded-xl border border-[#1D3352] italic">
          "{lesson.realWorldExample}"
        </p>
      </div>

      {/* Warning Signs */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#FB7185]">
          <AlertTriangle className="w-4 h-4" />
          <span>Red Flags & Common Warning Signs</span>
        </div>
        <ul className="space-y-2.5 text-xs">
          {lesson.warningSigns.map((sign, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-[#EDF5FF]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FB7185] mt-1.5 shrink-0" />
              <span>{sign}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Prevention Checklist */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#34D399]">
          <CheckCircle2 className="w-4 h-4" />
          <span>Actionable Prevention Checklist</span>
        </div>
        <ul className="space-y-2.5 text-xs">
          {lesson.checklist.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-[#EDF5FF]">
              <CheckCircle2 className="w-4 h-4 text-[#34D399] shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* What To Do If Affected */}
      <div className="p-6 rounded-2xl bg-[#101E30] border border-[#1D3352] space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#FBBF24]">
          <ShieldAlert className="w-4 h-4" />
          <span>Incident Response: What To Do If Compromised</span>
        </div>
        <ol className="space-y-2.5 text-xs list-decimal list-inside text-[#EDF5FF]">
          {lesson.whatToDoIfAffected.map((action, idx) => (
            <li key={idx} className="leading-relaxed">
              <span className="ml-1 text-[#9AABC2]">{action}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Related Lessons */}
      {lesson.relatedLessons.length > 0 && (
        <div className="pt-4 border-t border-[#1D3352] space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AABC2]">
            Recommended Related Topics
          </h3>
          <div className="flex flex-wrap gap-2">
            {lesson.relatedLessons.map(relId => (
              <NavLink
                key={relId}
                to={`/academy/${relId}`}
                className="px-3 py-1.5 rounded-lg bg-[#13233A] hover:bg-[#1D3352] border border-[#1D3352] text-xs font-semibold text-[#39D9E8] transition-colors flex items-center gap-1.5"
              >
                <span className="capitalize">{relId.replace(/-/g, ' ')}</span>
                <ArrowRight className="w-3 h-3" />
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
