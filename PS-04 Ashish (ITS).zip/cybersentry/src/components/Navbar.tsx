import React from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, ShieldAlert, Sparkles, User, LogIn } from 'lucide-react';
import { ShieldLogo } from './ShieldLogo';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenMobile: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenMobile }) => {
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#07111F]/90 backdrop-blur-md border-b border-[#1D3352] px-4 lg:px-8 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="lg:hidden p-2 rounded-xl bg-[#101E30] border border-[#1D3352] text-[#9AABC2] hover:text-[#EDF5FF]"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="lg:hidden">
          <ShieldLogo size={30} showText={true} />
        </div>
        <div className="hidden lg:flex items-center gap-2 text-xs text-[#9AABC2]">
          <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
          <span>Active Threat Heuristic Engine v2.4</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <NavLink
          to="/scanner"
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#39D9E8] to-[#8B7CFF] text-[#07111F] font-bold text-xs shadow-glow-primary hover:opacity-95 transition-all"
        >
          <ShieldAlert className="w-4 h-4" />
          <span className="hidden sm:inline">Launch Threat Scanner</span>
          <span className="sm:hidden">Scan</span>
        </NavLink>

        {user ? (
          <NavLink
            to="/settings"
            className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-[#101E30] border border-[#1D3352] hover:border-[#39D9E8]/40 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-[#39D9E8]/20 text-[#39D9E8] flex items-center justify-center font-bold text-xs uppercase">
              {user.name ? user.name[0] : user.email[0]}
            </div>
            <span className="hidden sm:inline text-xs font-medium text-[#EDF5FF]">
              {user.name || user.email.split('@')[0]}
            </span>
          </NavLink>
        ) : (
          <NavLink
            to="/login"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#101E30] border border-[#1D3352] text-xs font-semibold text-[#EDF5FF] hover:border-[#39D9E8]/40 transition-colors"
          >
            <LogIn className="w-3.5 h-3.5 text-[#39D9E8]" />
            <span>Sign In</span>
          </NavLink>
        )}
      </div>
    </header>
  );
};
