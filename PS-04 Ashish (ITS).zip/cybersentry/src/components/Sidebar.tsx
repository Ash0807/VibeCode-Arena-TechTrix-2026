import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  ShieldAlert,
  History,
  FileWarning,
  SearchCheck,
  GraduationCap,
  HelpCircle,
  ShieldCheck,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  LogIn,
  User as UserIcon,
} from 'lucide-react';
import { ShieldLogo } from './ShieldLogo';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  onToggle,
  mobileOpen,
  onCloseMobile,
}) => {
  const { user, logout } = useAuth();

  const navItems = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/scanner', label: 'Threat Scanner', icon: ShieldAlert, highlight: true },
    { to: '/history', label: 'Scan History', icon: History },
    { to: '/report', label: 'Report Incident', icon: FileWarning },
    { to: '/incidents/track', label: 'Track Incident', icon: SearchCheck },
    { to: '/academy', label: 'Cyber Academy', icon: GraduationCap },
    { to: '/quiz', label: 'Interactive Quiz', icon: HelpCircle },
    ...(user?.role === 'admin'
      ? [{ to: '/admin', label: 'Admin Command', icon: ShieldCheck, admin: true }]
      : []),
    { to: '/settings', label: 'Settings & Privacy', icon: Settings },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex flex-col bg-[#101E30] border-r border-[#1D3352] transition-all duration-300 ease-in-out ${
          collapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-[#1D3352]">
          <NavLink to="/" onClick={onCloseMobile} className="flex items-center gap-2 overflow-hidden">
            <ShieldLogo size={34} showText={!collapsed} />
          </NavLink>
          <button
            onClick={onToggle}
            className="hidden lg:flex items-center justify-center w-7 h-7 rounded-lg bg-[#13233A] border border-[#1D3352] text-[#9AABC2] hover:text-[#EDF5FF] hover:border-[#39D9E8]/40 transition-colors"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onCloseMobile}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                    isActive
                      ? 'bg-[#39D9E8]/10 text-[#39D9E8] border border-[#39D9E8]/30 font-semibold'
                      : 'text-[#9AABC2] hover:text-[#EDF5FF] hover:bg-[#13233A]'
                  } ${item.highlight && !isActive ? 'hover:border-[#39D9E8]/30' : ''} ${
                    item.admin && !isActive ? 'text-[#8B7CFF] hover:text-white' : ''
                  }`
                }
              >
                <Icon
                  className={`w-5 h-5 shrink-0 transition-transform group-hover:scale-105 ${
                    item.highlight ? 'text-[#39D9E8]' : item.admin ? 'text-[#8B7CFF]' : ''
                  }`}
                />
                {!collapsed && (
                  <span className="truncate flex-1">
                    {item.label}
                    {item.admin && (
                      <span className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#8B7CFF]/20 text-[#8B7CFF]">
                        ADMIN
                      </span>
                    )}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* User Card & Authentication */}
        <div className="p-3 border-t border-[#1D3352] bg-[#07111F]/40">
          {user ? (
            <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-[#13233A] border border-[#1D3352]">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-[#39D9E8]/20 border border-[#39D9E8]/40 flex items-center justify-center text-[#39D9E8] font-bold text-xs uppercase shrink-0">
                  {user.name ? user.name.slice(0, 2) : user.email.slice(0, 2)}
                </div>
                {!collapsed && (
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-[#EDF5FF] truncate">
                      {user.name || user.email.split('@')[0]}
                    </p>
                    <p className="text-[10px] text-[#9AABC2] truncate capitalize">
                      {user.role} Account
                    </p>
                  </div>
                )}
              </div>
              <button
                onClick={() => logout()}
                className="p-1.5 text-[#9AABC2] hover:text-[#FB7185] hover:bg-[#FB7185]/10 rounded-lg transition-colors shrink-0"
                title="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <NavLink
              to="/login"
              onClick={onCloseMobile}
              className={`flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold bg-[#39D9E8]/10 text-[#39D9E8] border border-[#39D9E8]/30 hover:bg-[#39D9E8]/20 transition-all ${
                collapsed ? 'px-2' : ''
              }`}
            >
              <LogIn className="w-4 h-4 shrink-0" />
              {!collapsed && <span>Sign In</span>}
            </NavLink>
          )}
        </div>
      </aside>
    </>
  );
};
