import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  isDestructive = true,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#101E30] border border-[#1D3352] rounded-2xl max-w-md w-full p-6 shadow-2xl">
        <div className="flex items-center gap-3.5 mb-4">
          <div className={`p-2.5 rounded-xl ${isDestructive ? 'bg-[#FB7185]/15 text-[#FB7185]' : 'bg-[#39D9E8]/15 text-[#39D9E8]'}`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-[#EDF5FF]">{title}</h3>
        </div>
        <p className="text-sm text-[#9AABC2] mb-6 leading-relaxed">{message}</p>
        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-xl text-sm font-medium text-[#9AABC2] hover:text-[#EDF5FF] hover:bg-[#13233A] border border-transparent transition-colors"
          >
            {cancelText}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-4 py-2 rounded-xl text-sm font-semibold text-white shadow-lg transition-all ${
              isDestructive
                ? 'bg-[#FB7185] hover:bg-[#e0566b] shadow-[#FB7185]/20'
                : 'bg-[#39D9E8] hover:bg-[#2bc4d3] text-[#07111F] shadow-[#39D9E8]/20'
            }`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};
