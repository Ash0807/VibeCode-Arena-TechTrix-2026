import React from 'react';

interface ShieldLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const ShieldLogo: React.FC<ShieldLogoProps> = ({
  className = '',
  size = 32,
  showText = true,
}) => {
  return (
    <div className={`flex items-center gap-2.5 font-bold tracking-tight select-none ${className}`}>
      <div
        className="relative flex items-center justify-center rounded-xl bg-gradient-to-br from-[#101E30] to-[#13233A] border border-[#1D3352] p-1.5 shadow-lg group-hover:border-[#39D9E8]/50 transition-colors"
        style={{ width: size, height: size }}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          className="w-full h-full text-[#39D9E8] drop-shadow-[0_0_8px_rgba(57,217,232,0.6)]"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <path d="m9 12 2 2 4-4" stroke="#8B7CFF" strokeWidth="2.2" />
        </svg>
        <div className="absolute inset-0 rounded-xl bg-[#39D9E8]/10 blur-sm pointer-events-none" />
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className="text-lg font-extrabold tracking-wide text-[#EDF5FF] leading-tight">
            Cyber<span className="text-[#39D9E8]">Sentry</span>
          </span>
          <span className="text-[10px] uppercase font-semibold tracking-wider text-[#9AABC2] -mt-0.5">
            Guardian
          </span>
        </div>
      )}
    </div>
  );
};
