import React from 'react';
import { ShieldCheck, PhoneCall, Globe, AlertTriangle, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-auto border-t border-[#1D3352] bg-[#07111F]/80 text-[#9AABC2] text-xs">
      {/* Official Emergency Banner */}
      <div className="bg-[#101E30]/70 border-b border-[#1D3352]/60 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-[#EDF5FF] font-medium">
            <PhoneCall className="w-4 h-4 text-[#FB7185] animate-pulse" />
            <span>Emergency Cyber Incident in India?</span>
            <span className="text-[#FB7185] font-bold">Dial 1930</span>
            <span className="text-xs text-[#9AABC2] hidden md:inline">
              (National Citizen Financial Cyber Fraud Reporting System)
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <a
              href="https://cybercrime.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-[#39D9E8] transition-colors"
            >
              <span>cybercrime.gov.in</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="https://sancharsaathi.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-[#39D9E8] transition-colors"
            >
              <span>Chakshu Portal</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="https://sachet.rbi.org.in"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-[#39D9E8] transition-colors"
            >
              <span>RBI Sachet</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#39D9E8]" />
          <span className="font-semibold text-[#EDF5FF]">CyberSentry</span>
          <span>— Your Digital Safety Guardian. All rights reserved.</span>
        </div>
        <div className="text-[11px] text-center md:text-right max-w-xl text-[#9AABC2]/80">
          Disclaimer: CyberSentry is an educational risk-awareness and static verification system.
          Heuristic indicators do not constitute legal advice or replace formal police FIR filings.
        </div>
      </div>
    </footer>
  );
};
