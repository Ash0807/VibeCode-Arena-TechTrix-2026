import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { Dashboard } from './pages/Dashboard';
import { ThreatScanner } from './pages/ThreatScanner';
import { AnalysisResults } from './pages/AnalysisResults';
import { ScanHistory } from './pages/ScanHistory';
import { IncidentReporting } from './pages/IncidentReporting';
import { IncidentTracking } from './pages/IncidentTracking';
import { IncidentDetail } from './pages/IncidentDetail';
import { CyberAcademy } from './pages/CyberAcademy';
import { LessonDetail } from './pages/LessonDetail';
import { InteractiveQuiz } from './pages/InteractiveQuiz';
import { AdminDashboard } from './pages/AdminDashboard';
import { UserSettings } from './pages/UserSettings';
import { Login } from './pages/Login';
import { Register } from './pages/Register';

export const App: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <div className="min-h-screen bg-[#07111F] text-[#EDF5FF] flex">
            {/* Collapsible Sidebar */}
            <Sidebar
              collapsed={sidebarCollapsed}
              onToggle={() => setSidebarCollapsed(prev => !prev)}
              mobileOpen={mobileSidebarOpen}
              onCloseMobile={() => setMobileSidebarOpen(false)}
            />

            {/* Main Application Area */}
            <div
              className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${
                sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'
              }`}
            >
              <Navbar onOpenMobile={() => setMobileSidebarOpen(true)} />

              <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto">
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/scanner" element={<ThreatScanner />} />
                  <Route path="/results/:scanId" element={<AnalysisResults />} />
                  <Route path="/history" element={<ScanHistory />} />
                  <Route path="/report" element={<IncidentReporting />} />
                  <Route path="/incidents/track" element={<IncidentTracking />} />
                  <Route path="/incidents/:reportId" element={<IncidentDetail />} />
                  <Route path="/academy" element={<CyberAcademy />} />
                  <Route path="/academy/:lessonId" element={<LessonDetail />} />
                  <Route path="/quiz" element={<InteractiveQuiz />} />
                  <Route path="/admin" element={<AdminDashboard />} />
                  <Route path="/settings" element={<UserSettings />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </main>

              <Footer />
            </div>
          </div>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
