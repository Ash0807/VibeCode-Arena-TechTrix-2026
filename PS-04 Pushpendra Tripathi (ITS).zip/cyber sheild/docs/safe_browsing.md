# Safe Web Browsing Guide

## How to Spot Malicious Websites & Fraudulent Links

Attackers frequently create duplicate websites that copy the design and logos of legitimate banks, social media platforms, or e-commerce companies.

---

### 1. Inspect the Domain Carefully
- **Look for typosquatting**: Attackers register misspellings such as `arnazon.com` (`r`+`n` mimicking `m`) or `paypa1.com`.
- **Check the Top-Level Domain (TLD)**: Official companies rarely shift their primary service to `.xyz`, `.top`, `.buzz`, or `.work`.
- **Analyze Subdomains**: Legitimate: `support.apple.com`. Malicious: `apple.com.security-verify.net` (the actual owner is `security-verify.net`).

---

### 2. Never Rely Solely on the "Lock" Icon
- An HTTPS padlock indicates encrypted communication between your browser and the website.
- **It does not mean the website owner is legitimate.** More than 80% of modern phishing websites utilize free SSL certificates.

---

### 3. Safe Browsing Practices
- **Type addresses manually**: If receiving an unexpected alert, open a browser tab and type the known address.
- **Preview before clicking**: Hover your mouse over hyperlinks on desktop to view the actual destination address.
- **Use Multi-Factor Authentication (MFA)**: Hardware security keys and authenticator apps prevent credential reuse even if phishing tricks you.
