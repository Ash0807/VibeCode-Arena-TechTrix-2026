# Phishing, Smishing & Social Engineering

## Understanding Common Attack Vectors

### 1. Email Phishing
- **Spoofed Sender Identities**: The display name may read "PayPal Support", but inspecting the actual email header reveals an origin like `service@pay-pal-alert99.biz` or a hacked personal account.
- **Urgent Emotional Triggers**: Messages warn of account suspension within 12-24 hours to panic victims into bypassing rational checks.
- **Hidden Hyperlinks**: Text displaying `https://bank.com/login` that routes internally to an attacker's credential harvester.

---

### 2. SMS Phishing ("Smishing")
- **Package Delivery Scams**: Fake courier notifications stating an unpaid customs fee or incomplete delivery address.
- **Banking / KYC Panic**: Texts urging users to complete immediate "KYC updates" or risk card cancellation.

---

### 3. Golden Rules of Defense
1. **Never share OTPs**: No legitimate bank representative will ever ask for your One-Time Password or PIN.
2. **Verify Out-of-Band**: Contact the party using an official, independently researched phone number or official app.
3. **Report Suspected Incidents**: Submit samples to help protect others and trace campaign patterns.
