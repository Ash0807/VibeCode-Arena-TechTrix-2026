# CyberShield - Phishing Verification & Incident Awareness Prototype

A multi-format security scanner built with FastAPI to detect indicators of phishing and fraud across **URLs**, **Emails**, **SMS messages**, and **Uploaded Screenshots**.

---

## 🚀 Quick Start in VS Code

### 1. Run the Backend API
In the VS Code terminal:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload --reload-dir app --port 8000
```
The API documentation (Swagger UI) is available at: `http://localhost:8000/docs`

### 2. Run the Frontend Interface
Open a second terminal tab in VS Code:
```bash
cd frontend
# Serve the lightweight web UI
python3 -m http.server 3000
```
Open your browser to: **`http://localhost:3000`**

---

## 🔍 Features Implemented

1. **Multi-Format Phishing Detection**:
   - **URL Scanner**: Flags IP-based hosts, dangerous TLDs (`.xyz`, `.top`, etc.), link shorteners, and typosquatting/brand impersonation.
   - **Email Scanner**: Checks sender display name vs actual domain, detects credential harvesting triggers, financial scam words, and checks embedded hyperlinks.
   - **SMS Scanner**: Smishing keyword matching (KYC, package delivery, bank block), and OTP solicitation flags.
   - **Screenshot OCR**: Extracts text from uploaded images using `pytesseract` and routes to heuristic evaluators.
2. **Explainable Risk Assessment**:
   - Risk score (0 - 100) mapped to Low / Medium / High tiers.
   - Itemized warning breakdown detailing *why* the content is suspicious.
   - Actionable safety recommendations (e.g., verifying out-of-band, blocking sender, reporting).
3. **Admin & Incident Recording API**:
   - Store reported incidents anonymously without holding sensitive credentials or OTPs.
   - Protected aggregated metrics endpoint (`/admin/summary`).
4. **Educational Guides**:
   - Markdown documents in [`docs/`](./docs/) covering safe browsing, phishing vectors, and awareness guidelines.
