import re
from typing import Dict, Any
from .url import analyze_url_string

SMS_SCAM_KEYWORDS = [
    r"delivery failed", r"package pending", r"customs fee",
    r"bank alert", r"account blocked", r"card suspended",
    r"claim your tax refund", r"unclaimed lottery", r"unusual sign-in",
    r"update kyc", r"pan card expired", r"sim deactivation"
]

def extract_urls(text: str):
    return re.findall(r"(https?://[^\s<>\"\'\)]+)", text)

def analyze(payload) -> Dict[str, Any]:
    sender_number = (payload.sender_number or "").strip()
    body = (payload.body or "").strip()
    text_lower = body.lower()

    warnings = []
    recommendations = []
    risk_score = 0

    # 1. Suspicious sender number patterns (alphanumeric headers or spoofed international numbers)
    if re.search(r"[a-zA-Z]", sender_number) and len(sender_number) < 8:
        # Often bulk SMS sender header (e.g. "VK-HDFCBK") - can be legitimately used or spoofed
        warnings.append({
            "type": "sender_header_info",
            "detail": f"Sender uses SMS shortcode or header '{sender_number}'. Scammers frequently spoof institutional sender codes."
        })

    # 2. Smishing keywords detection
    matched_phrases = [kw for kw in SMS_SCAM_KEYWORDS if re.search(r"\b" + kw, text_lower)]
    if matched_phrases:
        risk_score += min(len(matched_phrases) * 25, 50)
        warnings.append({
            "type": "smishing_pattern",
            "detail": f"Message mimics high-frequency scam triggers: {', '.join(matched_phrases)}."
        })
        recommendations.append("Do not call phone numbers or tap links provided in the SMS message.")

    # 3. Request for OTP or PIN
    if re.search(r"\b(otp|one time password|pin|verification code|cvv)\b", text_lower):
        risk_score += 40
        warnings.append({
            "type": "otp_solicitation",
            "detail": "Message directly discusses or requests verification credentials or one-time codes."
        })
        recommendations.append("Legitimate institutions will never ask you to send your OTP or PIN over SMS.")

    # 4. URLs in SMS (high smishing vector)
    urls = extract_urls(body)
    if urls:
        risk_score += 20
        for u in urls[:2]:
            url_res = analyze_url_string(u)
            if url_res["risk_score"] > 40:
                risk_score = max(risk_score, int(url_res["risk_score"]))
            for w in url_res["warnings"]:
                warnings.append({
                    "type": f"sms_link_{w['type']}",
                    "detail": f"Link in SMS ({u}): {w['detail']}"
                })
        recommendations.append("Never open shortened or unknown URLs delivered via text message.")

    risk_score = min(max(risk_score, 0), 100)

    if risk_score >= 60:
        risk_level = "high"
        recommendations.append("Block this sender and forward the message to your telecom fraud spam number (e.g. 7726 / 1930).")
    elif risk_score >= 30:
        risk_level = "medium"
        recommendations.append("Independently confirm through the official organization app or website.")
    else:
        risk_level = "low"
        recommendations.append("Exercise standard vigilance when responding to unexpected text messages.")

    return {
        "risk_score": float(risk_score),
        "risk_level": risk_level,
        "warnings": warnings,
        "recommendations": list(set(recommendations)),
        "educational_links": [
            "https://consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams",
            "https://www.fcc.gov/avoid-phone-scams"
        ]
    }
