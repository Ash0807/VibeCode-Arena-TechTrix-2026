import re
from typing import Dict, Any, List
from .url import analyze_url_string

URGENCY_KEYWORDS = [
    r"urgent", r"immediately", r"action required", r"account suspended",
    r"unauthorized access", r"security alert", r"within 24 hours", r"final warning",
    r"compromised", r"locked out"
]

CREDENTIAL_HARVEST_KEYWORDS = [
    r"verify your account", r"update password", r"confirm password",
    r"enter your pin", r"ssn", r"social security", r"bank account",
    r"login credential", r"otp", r"one-time password", r"credit card"
]

FINANCIAL_SCAM_KEYWORDS = [
    r"lottery", r"won", r"prize", r"inheritance", r"wire transfer",
    r"bitcoin", r"cryptocurrency", r"refund", r"invoice attached"
]

def extract_urls(text: str) -> List[str]:
    url_pattern = r"(https?://[^\s<>\"\'\)]+)"
    return re.findall(url_pattern, text)

def analyze(payload) -> Dict[str, Any]:
    sender_name = payload.sender_name or ""
    sender_email = str(payload.sender_email).lower()
    subject = payload.subject or ""
    body = payload.body or ""
    combined_text = f"{subject} {body}".lower()

    warnings = []
    recommendations = []
    risk_score = 0

    # 1. Check sender display name vs sender email domain
    sender_domain = sender_email.split("@")[-1] if "@" in sender_email else ""
    common_freemail = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]
    
    brand_keywords = ["paypal", "apple", "google", "microsoft", "amazon", "netflix", "bank"]
    for brand in brand_keywords:
        if brand in sender_name.lower() and brand not in sender_domain:
            risk_score += 45
            warnings.append({
                "type": "sender_impersonation",
                "detail": f"Sender name claims to be '{sender_name}' but the email originates from external domain '@{sender_domain}'."
            })
            recommendations.append(f"Independently contact {sender_name} through their verified official customer portal.")

    if any(brand in sender_name.lower() for brand in brand_keywords) and sender_domain in common_freemail:
        risk_score += 35
        warnings.append({
            "type": "free_email_impersonation",
            "detail": f"An official organization is claiming communication via a public free email provider ({sender_domain})."
        })

    # 2. Urgency language detection
    urgency_hits = [kw for kw in URGENCY_KEYWORDS if re.search(r"\b" + kw, combined_text)]
    if urgency_hits:
        risk_score += min(len(urgency_hits) * 15, 30)
        warnings.append({
            "type": "artificial_urgency",
            "detail": f"Message contains high-pressure psychological triggers: {', '.join(urgency_hits[:3])}."
        })
        recommendations.append("Pause before reacting. Scammers intentionally fabricate artificial emergencies to rush victims.")

    # 3. Credential and confidential requests
    cred_hits = [kw for kw in CREDENTIAL_HARVEST_KEYWORDS if re.search(r"\b" + kw, combined_text)]
    if cred_hits:
        risk_score += min(len(cred_hits) * 20, 40)
        warnings.append({
            "type": "credential_request",
            "detail": f"Message solicits confidential or sensitive access details: {', '.join(cred_hits[:3])}."
        })
        recommendations.append("Never share passwords, OTP codes, or banking PINs via email or online forms.")

    # 4. Financial lure keywords
    fin_hits = [kw for kw in FINANCIAL_SCAM_KEYWORDS if re.search(r"\b" + kw, combined_text)]
    if fin_hits:
        risk_score += min(len(fin_hits) * 15, 25)
        warnings.append({
            "type": "financial_lure",
            "detail": f"Message contains suspicious financial or reward promises: {', '.join(fin_hits[:3])}."
        })

    # 5. Extract and analyze embedded links
    extracted_urls = extract_urls(body)
    if extracted_urls:
        worst_url_score = 0
        for u in extracted_urls[:3]:
            url_res = analyze_url_string(u)
            if url_res["risk_score"] > worst_url_score:
                worst_url_score = url_res["risk_score"]
            for w in url_res["warnings"]:
                warnings.append({
                    "type": f"embedded_link_{w['type']}",
                    "detail": f"Embedded link ({u}): {w['detail']}"
                })
        risk_score = max(risk_score, int(worst_url_score * 0.9 + risk_score * 0.4))

    risk_score = min(max(risk_score, 0), 100)

    if risk_score >= 60:
        risk_level = "high"
        recommendations.append("Do not click links, open attachments, or reply to this sender.")
        recommendations.append("Report this email as phishing in your mail client.")
    elif risk_score >= 30:
        risk_level = "medium"
        recommendations.append("Treat this email with caution. Check email headers or verify the sender out-of-band.")
    else:
        risk_level = "low"
        recommendations.append("Standard caution advised. Ensure sender email headers match expected DKIM/SPF domains.")

    return {
        "risk_score": float(risk_score),
        "risk_level": risk_level,
        "warnings": warnings,
        "recommendations": list(set(recommendations)),
        "educational_links": [
            "https://consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams",
            "https://staysafeonline.org/resources/phishing-prevention/"
        ]
    }
