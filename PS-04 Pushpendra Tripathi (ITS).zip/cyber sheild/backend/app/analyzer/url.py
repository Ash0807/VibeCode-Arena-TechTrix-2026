import re
from urllib.parse import urlparse
from typing import List, Dict, Any

SUSPICIOUS_TLDS = {".xyz", ".top", ".buzz", ".work", ".click", ".loan", ".fit", ".rest", ".gq", ".ml", ".cf", ".tk", ".ga"}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "buff.ly", "ow.ly", "cutt.ly"}
KNOWN_BRANDS = ["paypal", "google", "apple", "microsoft", "amazon", "netflix", "chase", "bankofamerica", "wellsfargo", "facebook", "instagram"]

def analyze_url_string(url_str: str) -> Dict[str, Any]:
    warnings = []
    risk_score = 0
    recommendations = []

    try:
        if not url_str.startswith(("http://", "https://")):
            url_str = "http://" + url_str
        parsed = urlparse(url_str)
        hostname = (parsed.hostname or "").lower()
    except Exception:
        return {
            "risk_score": 85,
            "risk_level": "high",
            "warnings": [{"type": "malformed_url", "detail": "The URL format is invalid or malformed."}],
            "recommendations": ["Do not click or open this link."],
            "educational_links": ["https://staysafeonline.org/resources/safe-browsing/"]
        }

    # 1. IP address in hostname
    ip_pattern = r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"
    if re.match(ip_pattern, hostname):
        risk_score += 40
        warnings.append({
            "type": "ip_address_host",
            "detail": f"Hostname '{hostname}' uses an IP address instead of a recognized domain name, a common tactic to bypass domain reputation checks."
        })

    # 2. URL Shortener detection
    if hostname in SHORTENERS:
        risk_score += 25
        warnings.append({
            "type": "url_shortener",
            "detail": f"URL uses shortening service '{hostname}', which conceals the real final destination."
        })
        recommendations.append("Use a link unshortener or safe preview tool before visiting.")

    # 3. Suspicious TLD
    for tld in SUSPICIOUS_TLDS:
        if hostname.endswith(tld):
            risk_score += 30
            warnings.append({
                "type": "suspicious_tld",
                "detail": f"Domain ends with high-risk/frequently abused TLD '{tld}'."
            })
            break

    # 4. Brand impersonation / Typosquatting in hostname
    for brand in KNOWN_BRANDS:
        if brand in hostname:
            legitimate_domains = [f"{brand}.com", f"www.{brand}.com"]
            if hostname not in legitimate_domains and not hostname.endswith(f".{brand}.com"):
                risk_score += 45
                warnings.append({
                    "type": "brand_impersonation",
                    "detail": f"Domain contains brand keyword '{brand}' but does not appear to be an official {brand.capitalize()} domain."
                })
                recommendations.append(f"Visit the official {brand.capitalize()} website directly by typing the known official address into your browser.")

    # 5. Excessive subdomains / deceptive naming
    subdomains = hostname.split(".")
    if len(subdomains) > 4:
        risk_score += 20
        warnings.append({
            "type": "excessive_subdomains",
            "detail": f"Multiple subdomain levels detected ({len(subdomains)} segments), often used to mimic legitimate paths."
        })

    # 6. HTTP instead of HTTPS
    if parsed.scheme == "http":
        risk_score += 10
        warnings.append({
            "type": "insecure_protocol",
            "detail": "The URL uses unencrypted HTTP rather than HTTPS."
        })

    # Normalize risk score between 0 and 100
    risk_score = min(max(risk_score, 0), 100)

    if risk_score >= 60:
        risk_level = "high"
        recommendations.append("Avoid clicking this link or entering any sensitive details.")
        recommendations.append("Report the URL to your security team or fraud reporting portal.")
    elif risk_score >= 30:
        risk_level = "medium"
        recommendations.append("Exercise caution. Verify the destination with the sender before interacting.")
    else:
        risk_level = "low"
        recommendations.append("No obvious automated red flags found, but remain vigilant.")

    return {
        "risk_score": float(risk_score),
        "risk_level": risk_level,
        "warnings": warnings,
        "recommendations": list(set(recommendations)),
        "educational_links": [
            "https://staysafeonline.org/resources/safe-browsing/",
            "https://consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams"
        ]
    }

def analyze(payload) -> Dict[str, Any]:
    url_str = str(payload.url)
    return analyze_url_string(url_str)
