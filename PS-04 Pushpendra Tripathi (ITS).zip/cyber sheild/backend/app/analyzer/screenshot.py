import io
from typing import Dict, Any
from PIL import Image

try:
    import pytesseract
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

from .email import extract_urls, URGENCY_KEYWORDS, CREDENTIAL_HARVEST_KEYWORDS
from .url import analyze_url_string
import re

def analyze(image_bytes: bytes) -> Dict[str, Any]:
    extracted_text = ""
    warnings = []
    recommendations = []
    risk_score = 0

    if OCR_AVAILABLE:
        try:
            image = Image.open(io.BytesIO(image_bytes))
            extracted_text = pytesseract.image_to_string(image)
        except Exception as e:
            warnings.append({
                "type": "ocr_notice",
                "detail": f"OCR extraction was unable to parse text directly: {str(e)}."
            })
    else:
        warnings.append({
            "type": "ocr_unavailable",
            "detail": "pytesseract OCR engine is not configured in the host environment. Fallback mode applied."
        })

    text_lower = extracted_text.lower()

    if extracted_text.strip():
        # Check urgency
        urgency_hits = [kw for kw in URGENCY_KEYWORDS if re.search(r"\b" + kw, text_lower)]
        if urgency_hits:
            risk_score += 30
            warnings.append({
                "type": "ocr_urgency_detected",
                "detail": f"Visual text contains high-pressure terms: {', '.join(urgency_hits[:3])}."
            })

        # Check credential keywords
        cred_hits = [kw for kw in CREDENTIAL_HARVEST_KEYWORDS if re.search(r"\b" + kw, text_lower)]
        if cred_hits:
            risk_score += 40
            warnings.append({
                "type": "ocr_credential_request",
                "detail": f"Screenshot shows requests for confidential data: {', '.join(cred_hits[:3])}."
            })
            recommendations.append("Do not disclose passwords, OTPs, or bank account credentials.")

        # Check URLs detected in text
        urls = extract_urls(extracted_text)
        for u in urls[:2]:
            url_res = analyze_url_string(u)
            if url_res["risk_score"] > 40: 
                risk_score = max(risk_score, int(url_res["risk_score"]))
            for w in url_res["warnings"]:
                warnings.append({
                    "type": f"ocr_url_{w['type']}",
                    "detail": f"Detected URL ({u}): {w['detail']}"
                })
    else:
        warnings.append({
            "type": "text_not_detected",
            "detail": "No readable text was extracted from the screenshot. Please ensure the image is clear or paste text directly."
        })

    risk_score = min(max(risk_score, 0), 100)

    if risk_score >= 60:
        risk_level = "high"
        recommendations.append("High likelihood of a fraudulent message or deceptive interface. Do not interact.")
    elif risk_score >= 30:
        risk_level = "medium"
        recommendations.append("Medium risk detected in image text. Confirm source independently.")
    else:
        risk_level = "low"
        recommendations.append("Low risk detected, but keep in mind automated visual checks cannot catch all evasions.")

    return {
        "risk_score": float(risk_score),
        "risk_level": risk_level,
        "warnings": warnings,
        "recommendations": list(set(recommendations)),
        "educational_links": [
            "https://staysafeonline.org/resources/safe-browsing/",
            "https://consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams"
        ]
    }
