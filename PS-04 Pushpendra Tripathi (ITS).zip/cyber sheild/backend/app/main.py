import uvicorn
from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from starlette.responses import JSONResponse
from . import models, schemas, analyzer, utils

app = FastAPI(title="Cybersecurity Verification and Awareness Tool")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
    ],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

security = HTTPBasic()

def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    # Simple hardcoded admin credentials for prototype
    correct_username = "admin"
    correct_password = "password"
    if credentials.username != correct_username or credentials.password != correct_password:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return credentials.username

@app.post("/analyze/email", response_model=schemas.AnalysisResult)
async def analyze_email(payload: schemas.EmailPayload):
    result = analyzer.email.analyze(payload)
    return result

@app.post("/analyze/sms", response_model=schemas.AnalysisResult)
async def analyze_sms(payload: schemas.SMSPayload):
    result = analyzer.sms.analyze(payload)
    return result

@app.post("/analyze/url", response_model=schemas.AnalysisResult)
async def analyze_url(payload: schemas.URLPayload):
    result = analyzer.url.analyze(payload)
    return result

@app.post("/analyze/screenshot", response_model=schemas.AnalysisResult)
async def analyze_screenshot(file: UploadFile = File(...)):
    # Save to temp location
    content = await file.read()
    result = analyzer.screenshot.analyze(content)
    return result

@app.post("/incident/report")
async def report_incident(incident: schemas.IncidentCreate, username: str = Depends(get_current_username)):
    db = utils.get_db()
    new_inc = models.Incident(**incident.dict())
    db.add(new_inc)
    db.commit()
    db.refresh(new_inc)
    return {"incident_id": new_inc.id, "status": new_inc.status}

@app.get("/admin/summary")
async def admin_summary(username: str = Depends(get_current_username)):
    db = utils.get_db()
    total = db.query(models.Incident).count()
    high = db.query(models.Incident).filter(models.Incident.risk_score >= 70).count()
    medium = db.query(models.Incident).filter(models.Incident.risk_score.between(40, 69)).count()
    low = db.query(models.Incident).filter(models.Incident.risk_score < 40).count()
    return {"total": total, "high": high, "medium": medium, "low": low}

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
