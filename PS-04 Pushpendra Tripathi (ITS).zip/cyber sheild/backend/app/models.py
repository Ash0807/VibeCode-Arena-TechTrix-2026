from sqlalchemy import Column, Integer, String, Float, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
import enum
import datetime

Base = declarative_base()

class RiskLevel(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class Incident(Base):
    __tablename__ = "incidents"

    id = Column(String, primary_key=True)  # UUID string
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    content_type = Column(String)  # email, sms, url, screenshot
    raw_content = Column(String)  # store raw payload (truncated for privacy)
    risk_score = Column(Float)  # 0-100
    risk_level = Column(Enum(RiskLevel))
    status = Column(String, default="Submitted")
    # additional fields can be added later
