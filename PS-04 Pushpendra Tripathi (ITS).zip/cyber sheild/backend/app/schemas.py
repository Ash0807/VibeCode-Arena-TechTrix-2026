from pydantic import BaseModel, HttpUrl, EmailStr, Field
from typing import List, Optional

class Warning(BaseModel):
    type: str
    detail: str

class AnalysisResult(BaseModel):
    risk_score: float = Field(..., ge=0, le=100)
    risk_level: str
    warnings: List[Warning]
    recommendations: List[str]
    educational_links: List[HttpUrl]

class EmailPayload(BaseModel):
    sender_name: str
    sender_email: EmailStr
    subject: str
    body: str

class SMSPayload(BaseModel):
    sender_number: str
    body: str

class URLPayload(BaseModel):
    url: HttpUrl

class IncidentCreate(BaseModel):
    content_type: str
    raw_content: str
    risk_score: float
    risk_level: str
    status: Optional[str] = "Submitted"
