# SchemeSaathi (योजना साथी) — Aapka Sarkari Mitra
### Unified Government Scheme & Housing Assistance Finder for Indian Citizens

> **A college and hackathon project demonstration prototype designed to empower rural, underserved, and economically weaker communities across India to discover welfare schemes and housing grants with 100% transparent, explainable rule-based matching.**

---

## 🌟 Executive Summary

Navigating India's welfare ecosystem traditionally requires browsing dozens of siloed central and state portals, visiting block development offices, or risking exploitation by unauthorized middlemen. 

**SchemeSaathi** solves this by offering a unified, mobile-first, and accessible civic discovery platform:
1. **Interactive 5-Step Questionnaire:** Citizens enter basic profile details (age group, location type, all 36 Indian states/UTs, family size, economic vulnerability, income bracket, occupation, and needs).
2. **Transparent Rule-Based Eligibility Engine:** Evaluates each scheme deterministically against known criteria (strictly: 🟢 *Potentially Eligible*, 🟡 *More Information Required*, or 🔴 *Eligibility Criteria Not Met*).
3. **Dedicated Housing Assistance Finder:** Tailored vertical for PMAY-Gramin and PMAY-Urban 2.0 based on current housing situation (kutcha, rented, houseless, pucca).
4. **Document Checklist Tool:** Interactive preparation manager with download capabilities for offline visits to Common Service Centres (CSCs).
5. **Instant Demo Profiles:** 3 pre-built demographic profiles (Rural Farmer, Urban Worker, Student) for instant hackathon demonstration.

---

## 🚀 Instant Quickstart (Zero Dependencies)

SchemeSaathi requires **no build tools, no npm, and no external servers**. It runs natively in any modern web browser:

### Option 1: Direct File Open
Double click `index.html` or open in your browser:
```
file:///C:/scheme-saathi/index.html
```

### Option 2: Local Static Server (PowerShell / Python / IIS)
```powershell
cd C:\scheme-saathi
# Using Python (if available):
# python -m http.server 8000
# Or directly view index.html in Edge/Chrome/Firefox
Start-Process "index.html"
```

---

## 📐 Key Architectural Modules

```text
C:\scheme-saathi/
├── index.html                  # Accessible semantic UI with mobile-responsive tabs & modals
├── styles.css                  # Civic Tech design system (Navy #0f2b5c, Emerald #059669, Saffron #ea580c)
├── js/
│   ├── schemes-data.js         # Master database of 21 verified welfare schemes across 7 sectors
│   ├── eligibility-engine.js   # Deterministic, explainable rule-based matching engine
│   ├── housing-calculator.js   # PMAY-G vs PMAY-U 2.0 housing assistance logic
│   ├── store.js                # State store with LocalStorage persistence & 3 demo profiles
│   ├── components.js           # SVG icon definitions, status badges, toasts & file downloads
│   └── app.js                  # Main controller, wizard routing, search & filter orchestrator
└── README.md                   # Documentation & hackathon project guide
```

---

## 💡 Transparent Rule-Based Engine

Unlike black-box AI algorithms, SchemeSaathi classifies every scheme using strict deterministic checks:

### 1. 🟢 Potentially Eligible
- **When used:** The user's available answers satisfy all known criteria configured for the scheme (location type, state, age group, income range, housing status, and occupation).
- **Example rationale:**
  > *"You selected Rural, Uttar Pradesh, an income range of ₹1–2.5 lakh, and occupation as Farmer and a housing need. These details match the sample criteria configured for this scheme."*

### 2. 🟡 More Information Required
- **When used:** Basic demographic criteria align, but essential statutory verifications are required before eligibility can be confirmed.
- **Example rationale:**
  > *"You match the basic demographic criteria, but additional information such as official land revenue ownership records (Khatauni / Patta) and Aadhaar e-KYC is required to determine a stronger match."*

### 3. 🔴 Eligibility Criteria Not Met
- **When used:** The entered profile clearly conflicts with a configured rule (e.g. income exceeds ceiling limit, or user already owns a pucca house).
- **Example rationale:**
  > *"Based on the information provided, your selected income range is above the income limit configured for this scheme."*

---

## 🏠 Dedicated Housing Assistance Experience

Housing receives dedicated prominence via the **🏠 Housing Assistance Finder**:
- **Question:** *"What best describes your current housing situation?"*
  - *I own a permanent house*
  - *I own a kutcha/semi-permanent house*
  - *I live in a rented house*
  - *I do not have a permanent house*
  - *I'm not sure*
- **PMAY-G (Gramin):**
  - ₹1,20,000 (Plains) or ₹1,30,000 (Hilly/difficult areas) direct cash grant
  - 90–95 days of unskilled labour wages under MGNREGA (~₹25,000)
  - ₹12,000 toilet grant via Swachh Bharat Mission (Grameen)
  - Total benefit: ₹1,57,000 to ₹1,67,000 direct assistance
- **PMAY-U 2.0 (Urban):**
  - Interest Subsidy Scheme (ISS): 4% interest subvention up to ₹1.80L – ₹2.67L on home loans up to ₹25L
  - Beneficiary-Led Construction (BLC): Direct ₹1.5L – ₹2.5L grant for EWS
  - Affordable Housing in Partnership (AHP) & In-Situ Slum Redevelopment (ISSR)
- **Pucca House Disqualification Rule:**
  - Clearly explains that families owning a pucca house cannot apply for new house construction, directing them instead to **PM Surya Ghar (Rooftop Solar)** for up to ₹78,000 capital subsidy.

---

## ⚡ 3 Instant Demo Profiles for Hackathon Judges

You can test the application in 1 second using the demo profile buttons located on the homepage and within the finder:

1. **🌾 Demo 1: Rural Farmer (UP)**
   - Uttar Pradesh, Rural, Age 26–40, Farmer, Income ₹1–2.5 lakh, Housing status: No permanent house.
   - **Expected Results:** Potentially eligible for *PMAY-Gramin*, *PM-KISAN*, *PMFBY Crop Insurance*, *Kisan Credit Card (KCC)*, and *Ayushman Bharat*.
2. **👷 Demo 2: Urban Worker**
   - Maharashtra, Urban, Age 26–40, Daily wage / Self-employed, Income: Below ₹1 lakh, Housing status: Rented.
   - **Expected Results:** Potentially eligible for *PM SVANidhi (Street Vendors)*, *PMAY-Urban 2.0 (ISS / Rental)*, *PM Vishwakarma*, and *Atal Pension Yojana*.
3. **🎓 Demo 3: Student**
   - Bihar, Urban/Rural, Age 18–25, Student, Low personal income, Education need.
   - **Expected Results:** Potentially eligible for *Post-Matric Scholarship Scheme*, *Pre-Matric Scholarship*, and *PM Jan Dhan Yojana*.

---

## ⚖️ Official Legal Disclaimer

> **Important:** SchemeSaathi provides preliminary recommendations based on the information entered by the user and the sample rules available in this prototype. These results do not constitute official eligibility determination and do not guarantee application approval, benefits, or government assistance. Users should verify current eligibility requirements and application procedures through official government sources (.gov.in / .nic.in).
