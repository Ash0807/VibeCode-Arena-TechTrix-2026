// SchemeSaathi - Main Application Controller
// Orchestrates multi-step form, rule-based matching, view routing, modals, and persistent state

const App = (() => {
  let activeTab = "home";
  let activeStep = 1;
  let resultsFilter = "all";
  let resultsSort = "best_match";
  let exploreCategory = "all";
  let exploreLocation = "all";
  let exploreState = "all";
  let exploreSearchQuery = "";
  let activeModalScheme = null;

  // Master Document Definitions
  const MASTER_DOCUMENTS = [
    { id: "aadhaar", name: "Aadhaar Card", description: "Mandatory biometric identity proof for all family members. Ensure mobile number is linked for e-KYC." },
    { id: "bank", name: "Bank Passbook with DBT Seeding", description: "Aadhaar-seeded savings bank account mapped on NPCI DBT mapper to receive direct financial assistance." },
    { id: "income_cert", name: "Income Certificate (Aay Praman Patra)", description: "Issued by competent revenue authority (Tehsildar / SDO / CSC) certifying annual household income." },
    { id: "ration", name: "Ration Card (NFSA / BPL / AAY)", description: "Proves family structure, economic vulnerability, and inclusion in priority food subsidy registers." },
    { id: "caste_cert", name: "Caste / Category Certificate (SC / ST / OBC / EWS)", description: "Required for reservation-specific scholarships, housing allotments, and concessional loans." },
    { id: "residence_cert", name: "Domicile / Residence Certificate", description: "Proof of state and municipal/panchayat residency (Voter ID, electricity bill, or residence certificate)." },
    { id: "land_record", name: "Land Records / Patta / Khatauni", description: "Mandatory for agricultural schemes (PM-KISAN, KCC, PMFBY) and rural house construction (PMAY-G)." },
    { id: "no_pucca_affidavit", name: "Affidavit of No Pucca House", description: "Notarized self-declaration affirming family owns no permanent pucca house anywhere in India (for PMAY)." },
    { id: "udid_card", name: "Unique Disability ID (UDID) / Medical Certificate", description: "Certifying 40%+ or 80%+ disability for Divyangjan pension and assistive allowances." }
  ];

  /**
   * Application Initialization
   */
  function init() {
    SchemeStore.init();

    // Populate State Dropdowns
    populateStateDropdowns();

    // Populate Wizard from active store profile
    populateWizardFromStore();

    // Populate Master Document Checklist
    renderMasterDocChecklist();

    // Render Initial Views
    renderHousingFinder();
    renderExploreSchemes();
    renderSavedSchemes();
    updateSavedCounterBadge();

    // Setup hash router
    const hash = window.location.hash.replace("#", "");
    if (hash && ["home", "finder", "housing", "explore", "docs", "saved", "how-it-works", "about"].includes(hash)) {
      navigateTo(hash);
    } else {
      navigateTo("home");
    }

    // Subscribe to state updates
    SchemeStore.subscribe(() => {
      updateSavedCounterBadge();
      renderSavedSchemes();
      renderMasterDocChecklist();
      if (document.getElementById("results-container").style.display !== "none") {
        renderResults();
      }
    });
  }

  /**
   * Populates state select elements with all 36 Indian States and UTs
   */
  function populateStateDropdowns() {
    const states = window.INDIAN_STATES_AND_UTS || [];

    // Finder State Select
    const formStateSelect = document.getElementById("form-state");
    if (formStateSelect) {
      formStateSelect.innerHTML = states.map((st) => `<option value="${st}">${st}</option>`).join("");
      formStateSelect.value = "Uttar Pradesh";
    }

    // Explore State Filter
    const exploreStateSelect = document.getElementById("explore-state-filter");
    if (exploreStateSelect) {
      exploreStateSelect.innerHTML = `<option value="all">All States & Union Territories</option>` +
        states.map((st) => `<option value="${st}">${st}</option>`).join("");
    }
  }

  /**
   * Navigation router between tab views
   */
  function navigateTo(tabId) {
    activeTab = tabId;
    window.location.hash = tabId;

    // Update Nav links active state
    document.querySelectorAll(".nav-item-link").forEach((link) => {
      link.classList.toggle("active", link.dataset.tab === tabId);
    });

    // Update View Sections visibility
    document.querySelectorAll(".view-section").forEach((sec) => {
      sec.classList.toggle("active", sec.id === `view-${tabId}`);
    });

    // Close mobile menu if open
    const mainNav = document.getElementById("main-nav");
    if (mainNav) mainNav.classList.remove("mobile-open");

    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });

    // Specialized view updates
    if (tabId === "saved") renderSavedSchemes();
    if (tabId === "docs") renderMasterDocChecklist();
    if (tabId === "housing") renderHousingFinder();
    if (tabId === "explore") renderExploreSchemes();
  }

  function toggleMobileMenu() {
    const mainNav = document.getElementById("main-nav");
    if (mainNav) {
      mainNav.classList.toggle("mobile-open");
    }
  }

  /**
   * Form Wizard: Go to specific step (1 to 5)
   */
  function goToStep(stepNum) {
    if (stepNum < 1 || stepNum > 5) return;

    // Validate current step before advancing forward
    if (stepNum > activeStep) {
      const isValid = validateStep(activeStep);
      if (!isValid) return;
    }

    activeStep = stepNum;

    // Update Progress Step Buttons
    for (let i = 1; i <= 5; i++) {
      const btn = document.getElementById(`step-btn-${i}`);
      const content = document.getElementById(`step-content-${i}`);

      if (btn) {
        btn.classList.toggle("active", i === activeStep);
        btn.classList.toggle("completed", i < activeStep);
      }
      if (content) {
        content.classList.toggle("active", i === activeStep);
      }
    }

    // Scroll wizard into view on mobile
    const wizardCard = document.getElementById("scheme-finder-card");
    if (wizardCard && window.innerWidth < 768) {
      wizardCard.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  /**
   * Step validation helper
   */
  function validateStep(stepNum) {
    if (stepNum === 1) {
      const ageChecked = document.querySelector('input[name="form-age"]:checked');
      const genderChecked = document.querySelector('input[name="form-gender"]:checked');
      if (!ageChecked || !genderChecked) {
        Components.showToast("Please select your age group and gender to proceed.", "warning");
        return false;
      }
    } else if (stepNum === 2) {
      const stateEl = document.getElementById("form-state");
      const locChecked = document.querySelector('input[name="form-location"]:checked');
      if (!stateEl || !stateEl.value || !locChecked) {
        Components.showToast("Please select your State and Location type.", "warning");
        return false;
      }
    } else if (stepNum === 3) {
      const vulnerableChecked = document.querySelector('input[name="form-vulnerable"]:checked');
      const housingChecked = document.querySelector('input[name="form-housing"]:checked');
      if (!vulnerableChecked || !housingChecked) {
        Components.showToast("Please answer all family and housing questions.", "warning");
        return false;
      }
    } else if (stepNum === 4) {
      const incomeChecked = document.querySelector('input[name="form-income"]:checked');
      const occChecked = document.querySelector('input[name="form-occ"]:checked');
      if (!incomeChecked || !occChecked) {
        Components.showToast("Please select your income range and occupation.", "warning");
        return false;
      }
    }
    return true;
  }

  /**
   * Collects all current user answers from form inputs
   */
  function collectUserProfileFromForm() {
    const ageEl = document.querySelector('input[name="form-age"]:checked');
    const genderEl = document.querySelector('input[name="form-gender"]:checked');
    const stateEl = document.getElementById("form-state");
    const locEl = document.querySelector('input[name="form-location"]:checked');
    const districtEl = document.getElementById("form-district");

    const membersEl = document.getElementById("form-members");
    const childrenEl = document.getElementById("form-children");
    const seniorsEl = document.getElementById("form-seniors");
    const disabledEl = document.getElementById("form-disabled");
    const vulnEl = document.querySelector('input[name="form-vulnerable"]:checked');
    const housingEl = document.querySelector('input[name="form-housing"]:checked');

    const incomeEl = document.querySelector('input[name="form-income"]:checked');
    const occEl = document.querySelector('input[name="form-occ"]:checked');

    // Selected Needs (multiple checkboxes)
    const selectedNeeds = [];
    document.querySelectorAll('input[name="form-needs"]:checked').forEach((cb) => {
      selectedNeeds.push(cb.value);
    });

    return {
      ageGroup: ageEl ? ageEl.value : "26–40",
      gender: genderEl ? genderEl.value : "Male",
      state: stateEl ? stateEl.value : "Uttar Pradesh",
      locationType: locEl ? locEl.value : "Rural",
      district: districtEl ? districtEl.value.trim() : "",
      familyMembers: membersEl ? parseInt(membersEl.value, 10) || 4 : 4,
      children: childrenEl ? parseInt(childrenEl.value, 10) || 0 : 0,
      seniors: seniorsEl ? parseInt(seniorsEl.value, 10) || 0 : 0,
      disabled: disabledEl ? parseInt(disabledEl.value, 10) || 0 : 0,
      isVulnerable: vulnEl ? vulnEl.value : "Yes",
      housingStatus: housingEl ? housingEl.value : "No permanent house",
      incomeRange: incomeEl ? incomeEl.value : "₹1–2.5 lakh",
      occupation: occEl ? occEl.value : "Farmer",
      needs: selectedNeeds.length > 0 ? selectedNeeds : ["Housing"]
    };
  }

  /**
   * Populates wizard form inputs from state store
   */
  function populateWizardFromStore() {
    const profile = SchemeStore.getProfile();

    setRadioValue("form-age", profile.ageGroup);
    setRadioValue("form-gender", profile.gender);
    setSelectValue("form-state", profile.state);
    setRadioValue("form-location", profile.locationType);
    setInputValue("form-district", profile.district || "");

    setInputValue("form-members", profile.familyMembers || 4);
    setInputValue("form-children", profile.children || 0);
    setInputValue("form-seniors", profile.seniors || 0);
    setInputValue("form-disabled", profile.disabled || 0);
    setRadioValue("form-vulnerable", profile.isVulnerable);
    setRadioValue("form-housing", profile.housingStatus);

    setRadioValue("form-income", profile.incomeRange);
    setRadioValue("form-occ", profile.occupation);

    // Needs checkboxes
    const needs = profile.needs || [];
    document.querySelectorAll('input[name="form-needs"]').forEach((cb) => {
      cb.checked = needs.includes(cb.value);
    });
  }

  function setRadioValue(name, val) {
    if (!val) return;
    const el = document.querySelector(`input[name="${name}"][value="${val}"]`);
    if (el) el.checked = true;
  }

  function setSelectValue(id, val) {
    if (!val) return;
    const el = document.getElementById(id);
    if (el) el.value = val;
  }

  function setInputValue(id, val) {
    const el = document.getElementById(id);
    if (el) el.value = val;
  }

  /**
   * Multi-step Form Submission Handler
   */
  function handleFinderSubmit() {
    // Validate Step 5 needs selection
    const checkedNeeds = document.querySelectorAll('input[name="form-needs"]:checked');
    if (checkedNeeds.length === 0) {
      Components.showToast("Please select at least one need category to find matching schemes.", "warning");
      return;
    }

    const userProfile = collectUserProfileFromForm();
    SchemeStore.updateProfile(userProfile);
    SchemeStore.setSubmitted(true);

    Components.showToast("Evaluating your profile across government criteria...", "info", 1500);

    renderResults();

    // Scroll to results
    const resultsContainer = document.getElementById("results-container");
    if (resultsContainer) {
      resultsContainer.style.display = "block";
      resultsContainer.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  /**
   * Resets multi-step form to clean defaults
   */
  function resetFinderForm() {
    SchemeStore.resetForm();
    populateWizardFromStore();
    goToStep(1);
    const resultsContainer = document.getElementById("results-container");
    if (resultsContainer) resultsContainer.style.display = "none";
    Components.showToast("Form has been reset to default values.", "info");
  }

  /**
   * Demo Profile Launcher (Section 20)
   * Instantly loads demo profile, populates form, and runs matching engine
   */
  function launchDemoProfile(profileKey) {
    const profileData = SchemeStore.loadDemoProfile(profileKey);
    if (!profileData) return;

    navigateTo("finder");
    populateWizardFromStore();
    goToStep(5);

    Components.showToast(`Loaded ${SchemeStore.DEMO_PROFILES[profileKey].name}! Evaluating schemes...`, "success");

    renderResults();

    const resultsContainer = document.getElementById("results-container");
    if (resultsContainer) {
      resultsContainer.style.display = "block";
      setTimeout(() => {
        resultsContainer.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    }
  }

  /**
   * Evaluates all schemes and renders the Results section
   */
  function renderResults() {
    const userProfile = SchemeStore.getProfile();
    const allSchemes = window.SCHEMES_DATABASE || [];

    // Run deterministic rule engine
    const evaluatedSchemes = EligibilityEngine.matchAll(userProfile, allSchemes);

    // Compute Summary Statistics
    let potentialCount = 0;
    let moreInfoCount = 0;
    let notMetCount = 0;
    const matchedCategories = new Set();

    evaluatedSchemes.forEach((item) => {
      if (item.evaluation.status === "potentially_eligible") {
        potentialCount++;
        matchedCategories.add(item.category);
      } else if (item.evaluation.status === "more_information_required") {
        moreInfoCount++;
      } else {
        notMetCount++;
      }
    });

    // Update Metric Badges
    const statPotEl = document.getElementById("stat-potential-count");
    const statMoreEl = document.getElementById("stat-more-info-count");
    const statNotMetEl = document.getElementById("stat-not-met-count");
    const statCatEl = document.getElementById("stat-categories-count");

    if (statPotEl) statPotEl.textContent = potentialCount;
    if (statMoreEl) statMoreEl.textContent = moreInfoCount;
    if (statNotMetEl) statNotMetEl.textContent = notMetCount;
    if (statCatEl) statCatEl.textContent = matchedCategories.size;

    // Apply Filter & Sorting
    let filtered = evaluatedSchemes.filter((item) => {
      if (resultsFilter === "all") return true;
      if (resultsFilter === "potentially_eligible" || resultsFilter === "more_information_required" || resultsFilter === "criteria_not_met") {
        return item.evaluation.status === resultsFilter;
      }
      return item.category === resultsFilter;
    });

    // Sorting
    if (resultsSort === "category") {
      filtered.sort((a, b) => a.category.localeCompare(b.category));
    } else if (resultsSort === "name") {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    }
    // "best_match" already sorted by status and score in EligibilityEngine.matchAll

    const countLabel = document.getElementById("results-showing-count");
    if (countLabel) {
      countLabel.textContent = `Showing ${filtered.length} of ${evaluatedSchemes.length} evaluated schemes`;
    }

    const grid = document.getElementById("matched-schemes-grid");
    if (!grid) return;

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="empty-state-card" style="grid-column: 1 / -1;">
          <div class="empty-state-icon">🔍</div>
          <h4 class="empty-state-title">No Matching Schemes Found</h4>
          <p class="empty-state-desc">No schemes in our database match your currently selected filter (${resultsFilter}). You can reset your filters or explore all available welfare programs.</p>
          <button class="btn btn-primary btn-sm" onclick="App.setResultsFilter('all')">Show All Results</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map((item) => renderSchemeCard(item, item.evaluation)).join("");
  }

  /**
   * Generates HTML markup for a single Scheme Card (Section 7)
   */
  function renderSchemeCard(scheme, evaluation) {
    const isSaved = SchemeStore.isSchemeSaved(scheme.id);
    const badgeHtml = Components.getEligibilityBadge(evaluation.status);
    const categoryIcon = Components.getCategoryIcon(scheme.category);

    const whyMatchedHtml = (evaluation.matchedCriteria && evaluation.matchedCriteria.length > 0)
      ? evaluation.matchedCriteria.map((c) => `<li><span class="bullet-icon">✓</span> <span>${c}</span></li>`).join("")
      : `<li><span class="bullet-icon">ℹ</span> <span>General welfare initiative</span></li>`;

    const benefitsHtml = (scheme.benefits && scheme.benefits.length > 0)
      ? scheme.benefits.slice(0, 2).map((b) => `<li><span>🎁</span> <span>${b}</span></li>`).join("")
      : `<li><span>🎁</span> <span>Financial and social support per official guidelines</span></li>`;

    return `
      <div class="scheme-card" data-id="${scheme.id}">
        <div class="scheme-card-top">
          <div class="scheme-header-info">
            <span class="category-tag">${categoryIcon} ${scheme.category}</span>
            <h4 class="scheme-title">${scheme.name}</h4>
            ${scheme.hindiName ? `<div class="scheme-hindi-title">${scheme.hindiName}</div>` : ""}
            <div>${badgeHtml}</div>
          </div>
          <button class="scheme-bookmark-btn ${isSaved ? "saved" : ""}" 
                  onclick="App.handleToggleSave('${scheme.id}', event)" 
                  title="${isSaved ? "Remove from saved" : "Save this scheme"}"
                  aria-label="${isSaved ? "Remove from saved" : "Save this scheme"}">
            ${isSaved ? Components.ICONS.bookmarkFilled : Components.ICONS.bookmark}
          </button>
        </div>

        <p class="scheme-short-desc">${scheme.shortDescription}</p>

        <!-- Why This Matched Box -->
        <div class="scheme-why-matched-box">
          <div class="why-matched-label">
            <span>💡</span>
            <span>Why This Matched</span>
          </div>
          <ul class="why-matched-list">
            ${whyMatchedHtml}
          </ul>
        </div>

        <!-- Potential Benefits Preview -->
        <div class="scheme-benefits-preview">
          <div class="benefits-label">Potential Benefits</div>
          <ul class="benefits-list">
            ${benefitsHtml}
          </ul>
        </div>

        <!-- Actions -->
        <div class="scheme-card-footer">
          <button class="btn btn-primary btn-sm flex-1" onclick="App.openSchemeModal('${scheme.id}')">
            <span>View Details</span>
            <svg class="ss-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </button>
          <button class="btn ${isSaved ? "btn-secondary" : "btn-outline"} btn-sm" onclick="App.handleToggleSave('${scheme.id}', event)">
            ${isSaved ? "Saved" : "Save Scheme"}
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Results Page Filter Selector
   */
  function setResultsFilter(filterKey) {
    resultsFilter = filterKey;

    document.querySelectorAll("#results-filter-chips .filter-chip-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.filter === filterKey);
    });

    renderResults();
  }

  function handleResultsSort(sortKey) {
    resultsSort = sortKey;
    renderResults();
  }

  /**
   * Save / Bookmark toggle action
   */
  function handleToggleSave(schemeId, event) {
    if (event) event.stopPropagation();

    const wasSaved = SchemeStore.toggleSaveScheme(schemeId);
    const scheme = (window.SCHEMES_DATABASE || []).find((s) => s.id === schemeId);
    const schemeName = scheme ? scheme.name : "Scheme";

    if (wasSaved) {
      Components.showToast(`Saved "${schemeName}" to My Saved Schemes.`, "success");
    } else {
      Components.showToast(`Removed "${schemeName}" from saved schemes.`, "info");
    }

    updateSavedCounterBadge();
    renderSavedSchemes();

    // Re-render card bookmarks
    document.querySelectorAll(`.scheme-card[data-id="${schemeId}"] .scheme-bookmark-btn`).forEach((btn) => {
      btn.classList.toggle("saved", wasSaved);
      btn.innerHTML = wasSaved ? Components.ICONS.bookmarkFilled : Components.ICONS.bookmark;
    });
  }

  function updateSavedCounterBadge() {
    const count = SchemeStore.getState().savedSchemes.length;
    const badge = document.getElementById("saved-counter-badge");
    if (badge) {
      badge.textContent = count;
      badge.style.display = count > 0 ? "inline-block" : "none";
    }
  }

  /**
   * SCHEME DETAILS MODAL (Section 8)
   */
  function openSchemeModal(schemeId) {
    const scheme = (window.SCHEMES_DATABASE || []).find((s) => s.id === schemeId);
    if (!scheme) return;

    activeModalScheme = scheme;
    const userProfile = SchemeStore.getProfile();
    const evaluation = EligibilityEngine.checkEligibility(userProfile, scheme);

    // Modal Header
    const catEl = document.getElementById("modalSchemeCategory");
    const titleEl = document.getElementById("modalSchemeTitle");
    const hindiEl = document.getElementById("modalSchemeHindi");

    if (catEl) catEl.textContent = `${Components.getCategoryIcon(scheme.category)} ${scheme.category}`;
    if (titleEl) titleEl.textContent = scheme.name;
    if (hindiEl) hindiEl.textContent = scheme.hindiName || "";

    // Modal Body Content
    const bodyEl = document.getElementById("modalSchemeBody");
    if (bodyEl) {
      const isSaved = SchemeStore.isSchemeSaved(scheme.id);
      const badgeHtml = Components.getEligibilityBadge(evaluation.status);

      // Criteria Checklist Items
      const crit = scheme.eligibilityCriteria;
      const comp = evaluation.comparisonDetails;

      const criteriaChecklistHtml = `
        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:1rem; margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.65rem;">Eligibility Criteria Checklist</h4>
          <ul style="list-style:none; display:flex; flex-direction:column; gap:0.4rem; font-size:0.875rem;">
            <li>${comp.state.status === "matched" ? "✓" : "✗"} <strong>State:</strong> ${crit.state}</li>
            <li>${comp.locationType.status === "matched" ? "✓" : "✗"} <strong>Location Type:</strong> ${crit.locationType}</li>
            <li>${comp.income.status === "matched" ? "✓" : (comp.income.status === "pending" ? "⚠" : "✗")} <strong>Income:</strong> ${crit.income}</li>
            <li>${comp.age.status === "matched" ? "✓" : "✗"} <strong>Age:</strong> ${crit.age}</li>
            <li>${comp.occupation.status === "matched" ? "✓" : (comp.occupation.status === "pending" ? "⚠" : "✗")} <strong>Occupation:</strong> ${crit.occupation}</li>
            <li>⚠ <strong>Additional Verification:</strong> ${crit.additional || "Subject to local field inspection"}</li>
          </ul>
        </div>
      `;

      // Why You Received This Result (Side-by-side comparison table)
      const comparisonTableHtml = `
        <div style="margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.5rem;">Why You Received This Result</h4>
          <p style="font-size:0.875rem; color:var(--text-secondary); margin-bottom:0.75rem; line-height:1.5;">${evaluation.explanation}</p>

          <table class="criteria-comparison-table">
            <thead>
              <tr>
                <th>Factor</th>
                <th>Your Information</th>
                <th>Scheme Criteria</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Location</strong></td>
                <td>${userProfile.locationType} (${userProfile.state})</td>
                <td>${scheme.locationType}</td>
                <td>${getStatusPill(comp.locationType.status)}</td>
              </tr>
              <tr>
                <td><strong>Income</strong></td>
                <td>${userProfile.incomeRange}</td>
                <td>${scheme.incomeCriteria ? scheme.incomeCriteria.join(", ") : "Universal"}</td>
                <td>${getStatusPill(comp.income.status)}</td>
              </tr>
              <tr>
                <td><strong>Occupation</strong></td>
                <td>${userProfile.occupation}</td>
                <td>${scheme.occupationCriteria ? scheme.occupationCriteria.join(", ") : "Any"}</td>
                <td>${getStatusPill(comp.occupation.status)}</td>
              </tr>
              <tr>
                <td><strong>Housing</strong></td>
                <td>${userProfile.housingStatus}</td>
                <td>${scheme.housingCriteria ? scheme.housingCriteria.join(", ") : "Any"}</td>
                <td>${getStatusPill(comp.housing.status)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      `;

      // Required Documents Checklist (with interactive mark as completed)
      const docsListHtml = (scheme.requiredDocuments || []).map((doc, idx) => {
        const isDone = SchemeStore.isDocCompleted(doc.id || `doc_${idx}`);
        return `
          <div class="checklist-item" style="padding:0.6rem 0;">
            <input type="checkbox" id="modal-doc-${doc.id || idx}" 
                   ${isDone ? "checked" : ""} 
                   onchange="App.handleToggleModalDoc('${doc.id || `doc_${idx}`}', this.checked)">
            <div class="checklist-doc-info">
              <div class="checklist-doc-name ${isDone ? "completed" : ""}" id="modal-doc-title-${doc.id || idx}">${doc.name}</div>
              <div class="checklist-doc-desc">${doc.description}</div>
            </div>
          </div>
        `;
      }).join("");

      bodyEl.innerHTML = `
        <div style="margin-bottom:1.25rem;">
          ${badgeHtml}
        </div>

        <div style="margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.35rem;">Purpose</h4>
          <p style="font-size:0.9rem; color:var(--text-secondary); line-height:1.6;">${scheme.purpose}</p>
        </div>

        <div style="margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.35rem;">Intended Beneficiaries</h4>
          <p style="font-size:0.9rem; color:var(--text-secondary); line-height:1.6;">${scheme.targetBeneficiaries}</p>
        </div>

        <div style="margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.5rem;">Available Benefits</h4>
          <ul style="padding-left:1.25rem; font-size:0.875rem; color:var(--text-secondary); line-height:1.6;">
            ${(scheme.benefits || []).map((b) => `<li>${b}</li>`).join("")}
          </ul>
        </div>

        ${criteriaChecklistHtml}

        ${comparisonTableHtml}

        <div style="margin-bottom:1.5rem;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
            <h4 style="font-weight:700; color:var(--primary-navy);">Required Documents Checklist</h4>
            <button class="btn btn-outline btn-xs" onclick="App.downloadSchemeChecklist('${scheme.id}')">
              Download Scheme Checklist
            </button>
          </div>
          <p class="text-xs text-muted mb-2">Check off documents you have prepared:</p>
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:0.75rem 1rem;">
            ${docsListHtml}
          </div>
        </div>
      `;
    }

    // Modal Footer with Official Resource Link
    const footerEl = document.getElementById("modalSchemeFooter");
    if (footerEl) {
      const isSaved = SchemeStore.isSchemeSaved(scheme.id);
      footerEl.innerHTML = `
        <button class="btn btn-outline btn-sm" onclick="App.handleToggleSave('${scheme.id}', event)">
          ${isSaved ? "Saved in Dossier ✓" : "Save Scheme"}
        </button>
        <a href="${scheme.officialApplicationUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">
          <span>Official Application / Information</span>
          <svg class="ss-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
        </a>
      `;
    }

    Components.openModal("schemeDetailModal");
  }

  function getStatusPill(status) {
    if (status === "matched") {
      return `<span style="color:#059669; font-weight:700;">✓ Matched</span>`;
    } else if (status === "pending") {
      return `<span style="color:#d97706; font-weight:700;">⚠ Needs verification</span>`;
    } else {
      return `<span style="color:#dc2626; font-weight:700;">✗ Criteria not met</span>`;
    }
  }

  function handleToggleModalDoc(docId, isChecked) {
    SchemeStore.toggleDocCompleted(docId);
    const titleEl = document.getElementById(`modal-doc-title-${docId}`);
    if (titleEl) {
      titleEl.classList.toggle("completed", isChecked);
    }
    renderMasterDocChecklist();
  }

  /**
   * Generates and downloads scheme-specific document checklist
   */
  function downloadSchemeChecklist(schemeId) {
    const scheme = (window.SCHEMES_DATABASE || []).find((s) => s.id === schemeId);
    if (!scheme) return;

    let content = `=================================================================\n`;
    content += `SCHEMESAATHI — REQUIRED DOCUMENT CHECKLIST\n`;
    content += `Scheme: ${scheme.name}\n`;
    content += `Category: ${scheme.category}\n`;
    content += `Official Portal: ${scheme.officialApplicationUrl}\n`;
    content += `Generated: ${new Date().toLocaleDateString("en-IN")}\n`;
    content += `=================================================================\n\n`;
    content += `MANDATORY DOCUMENTS TO PREPARE BEFORE APPLYING:\n\n`;

    (scheme.requiredDocuments || []).forEach((doc, idx) => {
      const isDone = SchemeStore.isDocCompleted(doc.id || `doc_${idx}`);
      content += `[${isDone ? "X" : " "}] ${idx + 1}. ${doc.name}\n`;
      content += `     Details: ${doc.description}\n\n`;
    });

    content += `\n-----------------------------------------------------------------\n`;
    content += `IMPORTANT ADVISORY:\n`;
    content += `SchemeSaathi provides preliminary guidance. Applications must be\n`;
    content += `submitted through the official government portal or authorized CSCs.\n`;
    content += `=================================================================\n`;

    Components.downloadTextFile(`${scheme.id}_document_checklist.txt`, content);
    Components.showToast(`Downloaded checklist for ${scheme.name}!`, "success");
  }

  /**
   * HOUSING ASSISTANCE FINDER LOGIC (Section 9)
   */
  let housingSelectedSituation = "I do not have a permanent house";
  let housingSelectedLocation = "Rural";

  function handleHousingSituationSelect(labelEl, situation) {
    housingSelectedSituation = situation;

    document.querySelectorAll(".housing-option-card").forEach((c) => c.classList.remove("selected"));
    labelEl.classList.add("selected");
    labelEl.querySelector('input[type="radio"]').checked = true;

    renderHousingFinder();
  }

  function handleHousingLocChange(locVal) {
    housingSelectedLocation = locVal;
    renderHousingFinder();
  }

  function renderHousingFinder() {
    const container = document.getElementById("housing-finder-result-container");
    if (!container) return;

    const evaluation = HousingCalculator.evaluateHousingAssistance({
      situation: housingSelectedSituation,
      locationType: housingSelectedLocation
    });

    let breakdownHtml = "";
    if (evaluation.financialBreakdown && evaluation.financialBreakdown.length > 0) {
      breakdownHtml = `
        <table class="financial-breakdown-table">
          <thead>
            <tr>
              <th>Financial Component</th>
              <th>Grant / Subsidy Value</th>
            </tr>
          </thead>
          <tbody>
            ${evaluation.financialBreakdown.map((row) => `
              <tr>
                <td><strong>${row.label}</strong></td>
                <td><span style="color:#059669; font-weight:700;">${row.amount}</span></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }

    container.innerHTML = `
      <div class="housing-result-panel">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem; margin-bottom:1rem;">
          <div>
            <span class="category-tag mb-1">🏠 Housing Analysis Result</span>
            <h3 style="font-family:var(--font-display); font-size:1.45rem; color:var(--primary-navy);">${evaluation.title}</h3>
          </div>
          <span class="status-badge ${evaluation.badgeClass}">
            ${evaluation.statusText}
          </span>
        </div>

        <p style="font-size:0.95rem; color:var(--text-secondary); line-height:1.6; margin-bottom:1rem;">
          ${evaluation.summary}
        </p>

        ${breakdownHtml}

        <div style="margin-bottom:1.25rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.4rem;">Key Benefits & Guidelines</h4>
          <ul style="padding-left:1.25rem; font-size:0.875rem; color:var(--text-secondary); line-height:1.6;">
            ${(evaluation.benefits || []).map((b) => `<li>${b}</li>`).join("")}
          </ul>
        </div>

        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:8px; padding:1rem; margin-bottom:1.25rem;">
          <h5 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.25rem;">Official Verification Process</h5>
          <p style="font-size:0.85rem; color:var(--text-secondary); line-height:1.5;">${evaluation.verificationProcess || "Subject to local field inspection."}</p>
        </div>

        <div style="margin-bottom:1.5rem;">
          <h4 style="font-weight:700; color:var(--primary-navy); margin-bottom:0.4rem;">Next Steps to Take</h4>
          <ol style="padding-left:1.25rem; font-size:0.875rem; color:var(--text-secondary); line-height:1.6;">
            ${(evaluation.nextSteps || []).map((s) => `<li>${s}</li>`).join("")}
          </ol>
        </div>

        <div style="display:flex; gap:1rem; flex-wrap:wrap;">
          ${evaluation.schemeId ? `
            <button class="btn btn-primary btn-sm" onclick="App.openSchemeModal('${evaluation.schemeId}')">
              View Detailed Scheme Rules
            </button>
          ` : ""}
          <a href="${evaluation.officialUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm">
            <span>Visit Official Portal</span>
            <svg class="ss-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
          </a>
        </div>
      </div>
    `;
  }

  /**
   * EXPLORE SCHEMES DIRECTORY (Section 12)
   */
  function renderExploreSchemes() {
    const allSchemes = window.SCHEMES_DATABASE || [];
    const userProfile = SchemeStore.getProfile();

    let filtered = allSchemes.filter((scheme) => {
      // 1. Search Query
      if (exploreSearchQuery) {
        const query = exploreSearchQuery.toLowerCase();
        const matchName = scheme.name.toLowerCase().includes(query);
        const matchHindi = (scheme.hindiName || "").toLowerCase().includes(query);
        const matchCat = scheme.category.toLowerCase().includes(query);
        const matchDesc = scheme.shortDescription.toLowerCase().includes(query);
        const matchPurpose = (scheme.purpose || "").toLowerCase().includes(query);
        const matchBen = (scheme.targetBeneficiaries || "").toLowerCase().includes(query);

        if (!matchName && !matchHindi && !matchCat && !matchDesc && !matchPurpose && !matchBen) {
          return false;
        }
      }

      // 2. Category Filter
      if (exploreCategory !== "all" && scheme.category !== exploreCategory) {
        return false;
      }

      // 3. Location Filter
      if (exploreLocation !== "all") {
        if (scheme.locationType !== "Both" && scheme.locationType !== exploreLocation) {
          return false;
        }
      }

      // 4. State Filter
      if (exploreState !== "all") {
        if (!scheme.states.includes("All") && !scheme.states.includes(exploreState)) {
          return false;
        }
      }

      return true;
    });

    const countEl = document.getElementById("explore-count-label");
    if (countEl) {
      countEl.textContent = `Showing ${filtered.length} of ${allSchemes.length} schemes`;
    }

    const grid = document.getElementById("explore-schemes-grid");
    if (!grid) return;

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="empty-state-card" style="grid-column: 1 / -1;">
          <div class="empty-state-icon">🔎</div>
          <h4 class="empty-state-title">No Schemes Found</h4>
          <p class="empty-state-desc">No government schemes matched your search query "${exploreSearchQuery}". Try adjusting your keywords or clearing the category and state filters.</p>
          <button class="btn btn-primary btn-sm" onclick="App.resetExploreFilters()">Reset All Filters</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map((scheme) => {
      const evaluation = EligibilityEngine.checkEligibility(userProfile, scheme);
      return renderSchemeCard(scheme, evaluation);
    }).join("");
  }

  function handleExploreSearch(val) {
    exploreSearchQuery = (val || "").trim();
    renderExploreSchemes();
  }

  function setExploreCategory(cat) {
    exploreCategory = cat;

    document.querySelectorAll("#explore-category-chips .filter-chip-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.cat === cat);
    });

    renderExploreSchemes();
  }

  function handleExploreLocationFilter(loc) {
    exploreLocation = loc;
    renderExploreSchemes();
  }

  function handleExploreStateFilter(st) {
    exploreState = st;
    renderExploreSchemes();
  }

  function resetExploreFilters() {
    exploreSearchQuery = "";
    exploreCategory = "all";
    exploreLocation = "all";
    exploreState = "all";

    const searchInput = document.getElementById("explore-search-input");
    if (searchInput) searchInput.value = "";

    const locSelect = document.getElementById("explore-location-filter");
    if (locSelect) locSelect.value = "all";

    const stateSelect = document.getElementById("explore-state-filter");
    if (stateSelect) stateSelect.value = "all";

    document.querySelectorAll("#explore-category-chips .filter-chip-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.cat === "all");
    });

    renderExploreSchemes();
    Components.showToast("Explore filters have been reset.", "info");
  }

  /**
   * SAVED SCHEMES VIEW (Section 11)
   */
  function renderSavedSchemes() {
    const grid = document.getElementById("saved-schemes-grid");
    if (!grid) return;

    const savedList = SchemeStore.getState().savedSchemes || [];
    const allSchemes = window.SCHEMES_DATABASE || [];
    const userProfile = SchemeStore.getProfile();

    if (savedList.length === 0) {
      grid.innerHTML = `
        <div class="empty-state-card" style="grid-column: 1 / -1;">
          <div class="empty-state-icon">🔖</div>
          <h4 class="empty-state-title">No Schemes Saved Yet</h4>
          <p class="empty-state-desc">You have not bookmarked any welfare schemes. While exploring schemes or viewing your matches, click the bookmark icon to save them for quick reference.</p>
          <button class="btn btn-primary btn-sm" onclick="App.navigateTo('explore')">Explore Schemes to Save</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = savedList.map((item) => {
      const schemeId = typeof item === "string" ? item : item.id;
      const dateSaved = typeof item === "object" ? item.dateSaved : "Recently";
      const scheme = allSchemes.find((s) => s.id === schemeId);

      if (!scheme) return "";

      const evaluation = EligibilityEngine.checkEligibility(userProfile, scheme);
      const badgeHtml = Components.getEligibilityBadge(evaluation.status);

      return `
        <div class="scheme-card" data-id="${scheme.id}">
          <div class="scheme-card-top">
            <div class="scheme-header-info">
              <span class="category-tag">${Components.getCategoryIcon(scheme.category)} ${scheme.category}</span>
              <h4 class="scheme-title">${scheme.name}</h4>
              <div class="text-xs text-muted mb-2">Saved on: ${dateSaved}</div>
              <div>${badgeHtml}</div>
            </div>
            <button class="scheme-bookmark-btn saved" onclick="App.handleToggleSave('${scheme.id}', event)" title="Remove from saved">
              ${Components.ICONS.bookmarkFilled}
            </button>
          </div>

          <p class="scheme-short-desc">${scheme.shortDescription}</p>

          <div class="scheme-card-footer">
            <button class="btn btn-primary btn-sm flex-1" onclick="App.openSchemeModal('${scheme.id}')">
              View Details
            </button>
            <button class="btn btn-outline btn-sm" style="color:var(--status-not-met-icon);" onclick="App.handleToggleSave('${scheme.id}', event)">
              Remove
            </button>
          </div>
        </div>
      `;
    }).join("");
  }

  function clearAllSavedSchemes() {
    if (confirm("Are you sure you want to clear all saved schemes from your dossier?")) {
      SchemeStore.clearAllSavedSchemes();
      updateSavedCounterBadge();
      renderSavedSchemes();
      Components.showToast("All saved schemes cleared.", "info");
    }
  }

  /**
   * MASTER DOCUMENT CHECKLIST (Section 10)
   */
  function renderMasterDocChecklist() {
    const container = document.getElementById("master-doc-checklist-items");
    if (!container) return;

    let completedCount = 0;
    const totalCount = MASTER_DOCUMENTS.length;

    const itemsHtml = MASTER_DOCUMENTS.map((doc) => {
      const isDone = SchemeStore.isDocCompleted(doc.id);
      if (isDone) completedCount++;

      return `
        <div class="checklist-item">
          <input type="checkbox" id="master-doc-${doc.id}" 
                 ${isDone ? "checked" : ""} 
                 onchange="App.handleToggleMasterDoc('${doc.id}', this.checked)">
          <div class="checklist-doc-info">
            <div class="checklist-doc-name ${isDone ? "completed" : ""}" id="master-doc-title-${doc.id}">
              ${doc.name}
            </div>
            <div class="checklist-doc-desc">${doc.description}</div>
          </div>
        </div>
      `;
    }).join("");

    container.innerHTML = itemsHtml;

    // Update Progress
    const pct = Math.round((completedCount / totalCount) * 100);
    const badgeEl = document.getElementById("doc-readiness-badge");
    const barEl = document.getElementById("doc-readiness-bar");
    const countEl = document.getElementById("doc-readiness-count");

    if (badgeEl) badgeEl.textContent = `${pct}% Prepared`;
    if (barEl) barEl.style.width = `${pct}%`;
    if (countEl) countEl.textContent = `${completedCount} of ${totalCount} essential documents marked completed`;
  }

  function handleToggleMasterDoc(docId, isChecked) {
    SchemeStore.toggleDocCompleted(docId);
    const titleEl = document.getElementById(`master-doc-title-${docId}`);
    if (titleEl) titleEl.classList.toggle("completed", isChecked);
    renderMasterDocChecklist();
  }

  function downloadMasterChecklist() {
    let content = `=================================================================\n`;
    content += `SCHEMESAATHI — CITIZEN MASTER DOCUMENT READINESS CHECKLIST\n`;
    content += `Generated: ${new Date().toLocaleDateString("en-IN")}\n`;
    content += `=================================================================\n\n`;

    MASTER_DOCUMENTS.forEach((doc, idx) => {
      const isDone = SchemeStore.isDocCompleted(doc.id);
      content += `[${isDone ? "X" : " "}] ${idx + 1}. ${doc.name}\n`;
      content += `     Details: ${doc.description}\n\n`;
    });

    content += `=================================================================\n`;
    content += `IMPORTANT CIVIC TIPS:\n`;
    content += `1. DigiLocker: Ministry-issued digital certificates are legally\n`;
    content += `   valid under IT Act 2000 (digilocker.gov.in).\n`;
    content += `2. NPCI DBT Mapper: Ensure your primary bank account is seeded with\n`;
    content += `   Aadhaar at your bank branch to receive government cash transfers.\n`;
    content += `=================================================================\n`;

    Components.downloadTextFile("SchemeSaathi_Master_Document_Checklist.txt", content);
    Components.showToast("Downloaded Master Document Checklist!", "success");
  }

  return {
    init,
    navigateTo,
    toggleMobileMenu,
    goToStep,
    handleFinderSubmit,
    resetFinderForm,
    launchDemoProfile,
    setResultsFilter,
    handleResultsSort,
    handleToggleSave,
    openSchemeModal,
    handleToggleModalDoc,
    downloadSchemeChecklist,
    handleHousingSituationSelect,
    handleHousingLocChange,
    handleExploreSearch,
    setExploreCategory,
    handleExploreLocationFilter,
    handleExploreStateFilter,
    resetExploreFilters,
    clearAllSavedSchemes,
    handleToggleMasterDoc,
    downloadMasterChecklist,
    DEMO_PROFILES: SchemeStore.DEMO_PROFILES
  };
})();

if (typeof window !== "undefined") {
  window.App = App;
}
