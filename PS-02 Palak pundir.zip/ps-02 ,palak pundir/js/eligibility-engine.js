// SchemeSaathi - Rule-Based Eligibility Engine
// Deterministic, explainable, transparent rule-based matching
// Evaluates user profile against scheme criteria and returns EXACTLY ONE of:
// - "potentially_eligible" (🟢 Potentially Eligible)
// - "more_information_required" (🟡 More Information Required)
// - "criteria_not_met" (🔴 Eligibility Criteria Not Met)

const EligibilityEngine = (() => {

  /**
   * Evaluates a single scheme against a user profile
   * @param {Object} userProfile
   * @param {Object} scheme
   * @returns {Object} eligibility assessment result
   */
  function checkEligibility(userProfile, scheme) {
    if (!userProfile || !scheme) {
      return {
        status: "criteria_not_met",
        score: 0,
        matchedCriteria: [],
        missingInformation: ["Incomplete user profile or scheme details"],
        unmetCriteria: ["Profile not provided"],
        explanation: "Please complete the questionnaire to evaluate eligibility."
      };
    }

    const matchedCriteria = [];
    const missingInformation = [];
    const unmetCriteria = [];
    let score = 20; // Base baseline score
    let isHardDisqualified = false;

    // Detailed comparison breakdown for the Scheme Details modal
    const comparisonDetails = {
      state: { label: "State Applicability", userVal: userProfile.state || "Not specified", schemeVal: scheme.states.includes("All") ? "All India" : scheme.states.join(", "), status: "matched" },
      locationType: { label: "Location Type", userVal: userProfile.locationType || "Not specified", schemeVal: scheme.locationType, status: "matched" },
      age: { label: "Age Group", userVal: userProfile.ageGroup || "Not specified", schemeVal: scheme.ageCriteria ? scheme.ageCriteria.join(", ") : "All", status: "matched" },
      income: { label: "Income Bracket", userVal: userProfile.incomeRange || "Not specified", schemeVal: scheme.incomeCriteria ? scheme.incomeCriteria.join(", ") : "All", status: "matched" },
      occupation: { label: "Occupation", userVal: userProfile.occupation || "Not specified", schemeVal: scheme.occupationCriteria ? scheme.occupationCriteria.join(", ") : "All", status: "matched" },
      housing: { label: "Housing Status", userVal: userProfile.housingStatus || "Not specified", schemeVal: scheme.housingCriteria ? scheme.housingCriteria.join(", ") : "Any", status: "matched" },
      verification: { label: "Additional Verification", userVal: "Self-declared profile", schemeVal: scheme.eligibilityCriteria.additional || "Standard documentation", status: "pending" }
    };

    // 1. STATE APPLICABILITY CHECK
    if (scheme.states.includes("All") || scheme.states.includes(userProfile.state)) {
      score += 10;
      matchedCriteria.push(`Applicable in your state/UT (${userProfile.state || "All India"})`);
      comparisonDetails.state.status = "matched";
    } else {
      isHardDisqualified = true;
      unmetCriteria.push(`Scheme is not operational in ${userProfile.state}`);
      comparisonDetails.state.status = "unmet";
    }

    // 2. LOCATION TYPE CHECK (Rural / Urban)
    if (scheme.locationType === "Both" || scheme.locationType === userProfile.locationType) {
      score += 15;
      matchedCriteria.push(`Matches your ${userProfile.locationType} area classification`);
      comparisonDetails.locationType.status = "matched";
    } else {
      isHardDisqualified = true;
      unmetCriteria.push(`Scheme is restricted strictly to ${scheme.locationType} areas (you selected ${userProfile.locationType})`);
      comparisonDetails.locationType.status = "unmet";
    }

    // 3. AGE CRITERIA CHECK
    const schemeAgeList = scheme.ageCriteria || [];
    if (schemeAgeList.length === 0 || schemeAgeList.includes(userProfile.ageGroup)) {
      score += 15;
      matchedCriteria.push(`Your age group (${userProfile.ageGroup}) qualifies`);
      comparisonDetails.age.status = "matched";
    } else {
      // Check for partial compatibility or hard disqualification
      if (scheme.id.includes("scholarship") && (userProfile.ageGroup === "41–60" || userProfile.ageGroup === "60+")) {
        isHardDisqualified = true;
        unmetCriteria.push(`Scheme is restricted to school/college student age groups (${schemeAgeList.join(", ")})`);
        comparisonDetails.age.status = "unmet";
      } else if (scheme.id.includes("old-age") && userProfile.ageGroup !== "60+") {
        isHardDisqualified = true;
        unmetCriteria.push(`Requires senior citizen age of 60+ years (you selected ${userProfile.ageGroup})`);
        comparisonDetails.age.status = "unmet";
      } else if (scheme.id === "atal-pension" && (userProfile.ageGroup === "41–60" || userProfile.ageGroup === "60+")) {
        isHardDisqualified = true;
        unmetCriteria.push(`Atal Pension entry age is strictly capped at 40 years (you selected ${userProfile.ageGroup})`);
        comparisonDetails.age.status = "unmet";
      } else {
        isHardDisqualified = true;
        unmetCriteria.push(`Target age group is ${schemeAgeList.join(", ")}, which differs from ${userProfile.ageGroup}`);
        comparisonDetails.age.status = "unmet";
      }
    }

    // 4. INCOME CRITERIA CHECK
    const schemeIncomeList = scheme.incomeCriteria || [];
    if (userProfile.incomeRange === "Prefer not to say") {
      missingInformation.push("Income certificate and exact annual income confirmation required");
      comparisonDetails.income.status = "pending";
      score += 5;
    } else if (schemeIncomeList.length === 0 || schemeIncomeList.includes(userProfile.incomeRange)) {
      score += 20;
      matchedCriteria.push(`Your annual income (${userProfile.incomeRange}) is within the eligible threshold`);
      comparisonDetails.income.status = "matched";
    } else {
      // Income exceeded
      const isHighIncome = userProfile.incomeRange === "Above ₹10 lakh" || userProfile.incomeRange === "₹5–10 lakh";
      const isSchemeLowIncome = schemeIncomeList.includes("Below ₹1 lakh") && !schemeIncomeList.includes("₹5–10 lakh");
      
      if (isHighIncome && isSchemeLowIncome) {
        isHardDisqualified = true;
        unmetCriteria.push(`Selected income range (${userProfile.incomeRange}) is above the configured ceiling limit (${schemeIncomeList.join(", ")})`);
        comparisonDetails.income.status = "unmet";
      } else {
        missingInformation.push(`Income eligibility threshold is ${schemeIncomeList.join(", ")}; requires official income verification`);
        comparisonDetails.income.status = "pending";
        score += 5;
      }
    }

    // 5. OCCUPATION CRITERIA CHECK
    const schemeOccList = scheme.occupationCriteria || [];
    const userOcc = userProfile.occupation || "Other";
    if (schemeOccList.includes("Any") || schemeOccList.includes(userOcc)) {
      score += 15;
      matchedCriteria.push(`Matches target occupation profile (${userOcc})`);
      comparisonDetails.occupation.status = "matched";
    } else {
      // Specific scheme exclusions
      if (scheme.category === "Agriculture" && !["Farmer", "Agricultural worker"].includes(userOcc)) {
        isHardDisqualified = true;
        unmetCriteria.push(`Scheme is exclusively for Farmers and Agricultural workers (your occupation: ${userOcc})`);
        comparisonDetails.occupation.status = "unmet";
      } else if (scheme.category === "Education" && userOcc !== "Student") {
        isHardDisqualified = true;
        unmetCriteria.push(`Scheme is targeted for currently enrolled students (your occupation: ${userOcc})`);
        comparisonDetails.occupation.status = "unmet";
      } else if (scheme.id === "pm-svanidhi" && !["Self-employed", "Daily wage worker", "Other"].includes(userOcc)) {
        isHardDisqualified = true;
        unmetCriteria.push(`Street vendor assistance is for daily traders and self-employed vendors`);
        comparisonDetails.occupation.status = "unmet";
      } else {
        missingInformation.push(`Primary focus is ${schemeOccList.join(", ")}; occupational proof required`);
        comparisonDetails.occupation.status = "pending";
      }
    }

    // 6. HOUSING STATUS CHECK
    const schemeHousingList = scheme.housingCriteria || [];
    const userHousing = userProfile.housingStatus || "Other";

    if (scheme.category === "Housing") {
      if (scheme.id === "pmay-gramin" || scheme.id === "pmay-urban") {
        if (userHousing === "Own house") {
          isHardDisqualified = true;
          unmetCriteria.push("PMAY guidelines mandate that the beneficiary family must not own a pucca house anywhere in India");
          comparisonDetails.housing.status = "unmet";
        } else {
          score += 15;
          matchedCriteria.push(`Current housing condition (${userHousing}) qualifies for permanent housing support`);
          comparisonDetails.housing.status = "matched";
        }
      } else if (scheme.id === "pm-surya-ghar") {
        if (userHousing === "Own house") {
          score += 15;
          matchedCriteria.push("Owns residential premises suitable for rooftop solar installation");
          comparisonDetails.housing.status = "matched";
        } else {
          isHardDisqualified = true;
          unmetCriteria.push("Rooftop solar capital subsidy requires residential roof ownership (you selected: " + userHousing + ")");
          comparisonDetails.housing.status = "unmet";
        }
      }
    } else {
      // Other schemes don't strictly disqualify on housing
      if (schemeHousingList.length === 0 || schemeHousingList.includes(userHousing)) {
        score += 5;
        comparisonDetails.housing.status = "matched";
      }
    }

    // 7. USER NEEDS PRIORITY MATCH
    const userNeeds = userProfile.needs || [];
    if (userNeeds.includes(scheme.category)) {
      score += 10;
      matchedCriteria.push(`Directly satisfies your stated need for ${scheme.category}`);
    }

    // 8. FAMILY PROFILE & VULNERABILITY BONUS
    if (userProfile.isVulnerable === "Yes") {
      score += 5;
      matchedCriteria.push("Economically vulnerable family status aligns with priority welfare guidelines");
    }

    if (scheme.id.includes("disability") || scheme.id === "nsap-disability-pension") {
      if (parseInt(userProfile.disabled, 10) > 0) {
        score += 20;
        matchedCriteria.push("Family includes person(s) with disability (qualifies for Divyang welfare)");
      } else {
        isHardDisqualified = true;
        unmetCriteria.push("Reserved exclusively for persons with certified disability");
      }
    }

    if (scheme.id === "nsap-ignoaps") {
      if (parseInt(userProfile.seniors, 10) > 0 || userProfile.ageGroup === "60+") {
        score += 10;
        matchedCriteria.push("Senior citizen in household eligible for pension assessment");
      }
    }

    // 9. SCHEME-SPECIFIC MISSING INFORMATION GAPS
    if (scheme.id === "pm-kisan" || scheme.id === "kcc-scheme" || scheme.id === "pmfby") {
      missingInformation.push("Official land revenue ownership records (Khatauni / Patta) and Aadhaar e-KYC");
    } else if (scheme.id === "pmay-gramin") {
      missingInformation.push("Verification of household in Awaas+ / SECC rural priority survey validated by Gram Sabha");
    } else if (scheme.id === "pmay-urban") {
      missingInformation.push("No-pucca-house affidavit and Urban Local Body (ULB) registration");
    } else if (scheme.id === "ayushman-bharat") {
      missingInformation.push("Active Ration Card (NFSA/BPL) or SECC database record for Golden Card issuance");
    } else if (scheme.id === "pm-svanidhi") {
      missingInformation.push("Certificate of Vending (CoV) or Letter of Recommendation from Town Vending Committee");
    } else if (scheme.id === "pm-vishwakarma") {
      missingInformation.push("Artisan trade verification certificate from Gram Panchayat or ULB screening committee");
    } else if (scheme.id.includes("scholarship")) {
      missingInformation.push("Active educational institution bonafide certificate and caste/income verification");
    }

    // DETERMINISTIC ELIGIBILITY STATUS CLASSIFICATION
    // Exactly one of:
    // 1. "potentially_eligible" (🟢 Potentially Eligible)
    // 2. "more_information_required" (🟡 More Information Required)
    // 3. "criteria_not_met" (🔴 Eligibility Criteria Not Met)

    let status = "more_information_required";
    let explanation = "";

    if (isHardDisqualified || unmetCriteria.length > 0) {
      status = "criteria_not_met";
      score = Math.min(score, 35);
      
      // Generate human-readable explanation
      const primaryUnmet = unmetCriteria[0];
      if (primaryUnmet.includes("income")) {
        explanation = `Based on the information provided, your selected income range (${userProfile.incomeRange}) is above the income limit configured for this scheme.`;
      } else if (primaryUnmet.includes("Location") || primaryUnmet.includes("restricted strictly")) {
        explanation = `Based on the information provided, this scheme is configured for ${scheme.locationType} areas, whereas you selected ${userProfile.locationType}.`;
      } else if (primaryUnmet.includes("pucca house")) {
        explanation = `You selected "${userProfile.housingStatus}". Official guidelines strictly require that the beneficiary family does not own a permanent pucca house.`;
      } else if (primaryUnmet.includes("occupation")) {
        explanation = `This scheme is specifically designed for ${scheme.occupationCriteria.join(", ")}, which does not match your selected occupation (${userProfile.occupation}).`;
      } else {
        explanation = `Based on the information provided, ${primaryUnmet.toLowerCase()}.`;
      }
    } else if (score >= 65 && missingInformation.length <= 1) {
      status = "potentially_eligible";
      score = Math.min(Math.round(score), 98);

      const stateStr = userProfile.state || "your state";
      const locStr = userProfile.locationType || "your location";
      const incStr = userProfile.incomeRange || "your income";
      const needStr = userNeeds.includes(scheme.category) ? ` and a ${scheme.category.toLowerCase()} need` : "";

      explanation = `You selected ${locStr}, ${stateStr}, an income range of ${incStr}, and occupation as ${userProfile.occupation}${needStr}. These details match the sample criteria configured for this scheme.`;
    } else {
      status = "more_information_required";
      score = Math.min(Math.max(Math.round(score), 45), 65);

      const firstMissing = missingInformation[0] || "supporting documentation";
      explanation = `You match the basic demographic criteria, but additional information such as ${firstMissing.toLowerCase()} is required to determine a stronger match.`;
    }

    return {
      status, // "potentially_eligible" | "more_information_required" | "criteria_not_met"
      score,
      matchedCriteria: matchedCriteria.slice(0, 5),
      missingInformation: missingInformation.slice(0, 3),
      unmetCriteria: unmetCriteria.slice(0, 3),
      explanation,
      comparisonDetails
    };
  }

  /**
   * Matches all schemes in database against user profile
   * @param {Object} userProfile
   * @param {Array} schemes
   * @returns {Array} list of schemes with evaluated eligibility
   */
  function matchAll(userProfile, schemes) {
    if (!schemes || !schemes.length) return [];
    
    const results = schemes.map((scheme) => {
      const evaluation = checkEligibility(userProfile, scheme);
      return {
        ...scheme,
        evaluation
      };
    });

    // Sort: Potentially Eligible first, then More Info, then Not Met; sub-sort by score desc
    const statusOrder = {
      "potentially_eligible": 1,
      "more_information_required": 2,
      "criteria_not_met": 3
    };

    results.sort((a, b) => {
      const orderA = statusOrder[a.evaluation.status] || 99;
      const orderB = statusOrder[b.evaluation.status] || 99;
      if (orderA !== orderB) return orderA - orderB;
      return b.evaluation.score - a.evaluation.score;
    });

    return results;
  }

  return {
    checkEligibility,
    matchAll
  };
})();

if (typeof window !== "undefined") {
  window.EligibilityEngine = EligibilityEngine;
}
