// SchemeSaathi - Dedicated Housing Assistance Finder & PMAY Calculator
// Implements prompt Section 9: PMAY-G vs PMAY-U distinct logic and current housing situation evaluation

const HousingCalculator = (() => {

  /**
   * Evaluates housing situation and returns tailored PMAY guidance
   * @param {Object} params
   * @param {string} params.situation
   * @param {string} params.locationType ('Rural' | 'Urban')
   * @param {string} params.incomeRange
   * @returns {Object} detailed recommendation
   */
  function evaluateHousingAssistance({ situation, locationType, incomeRange = "₹1–2.5 lakh" }) {
    const loc = (locationType || "Rural").toLowerCase();

    // 1. SITUATION: Owns a permanent house
    if (situation === "I own a permanent house") {
      return {
        eligibleForPMAY: false,
        statusText: "Ineligible for New House Construction",
        badgeClass: "badge-not-met",
        title: "Pucca House Ownership Rule",
        summary: "Both PMAY-Gramin and PMAY-Urban guidelines strictly require that neither the applicant nor any member of their family owns a permanent pucca house anywhere in India.",
        schemeName: "Alternative: PM Surya Ghar: Muft Bijli Yojana",
        schemeId: "pm-surya-ghar",
        benefits: [
          "Direct capital subsidy of up to ₹78,000 for installing residential rooftop solar panels.",
          "Up to 300 units of free electricity per month, drastically slashing power bills.",
          "State Government home renovation or solar loan schemes through nationalized banks."
        ],
        nextSteps: [
          "If your existing pucca house requires rooftop solar or energy efficiency improvements, apply on pmsuryaghar.gov.in.",
          "Check your local municipal or panchayat office for home expansion loans."
        ],
        officialUrl: "https://pmsuryaghar.gov.in"
      };
    }

    // 2. RURAL HOUSING (PMAY-G)
    if (loc === "rural") {
      let situationNote = "Priority verification under Gram Sabha Awaas+ list.";
      if (situation === "I do not have a permanent house") {
        situationNote = "Highest priority categorisation for houseless families in rural areas.";
      } else if (situation === "I own a kutcha/semi-permanent house") {
        situationNote = "Eligible for complete pucca house replacement grant.";
      }

      return {
        eligibleForPMAY: true,
        statusText: "Potentially Eligible for PMAY-Gramin",
        badgeClass: "badge-eligible",
        title: "Pradhan Mantri Awas Yojana – Gramin (PMAY-G)",
        schemeName: "Pradhan Mantri Awas Yojana – Gramin",
        schemeId: "pmay-gramin",
        summary: `As a rural resident (${situation}), you are eligible to be considered for direct financial grants to build a minimum 25 sq.m pucca house with hygienic cooking space.`,
        financialBreakdown: [
          { label: "Direct Construction Grant (Plains)", amount: "₹1,20,000" },
          { label: "Direct Construction Grant (Hilly/Difficult areas)", amount: "₹1,30,000" },
          { label: "MGNREGA Unskilled Labour (90-95 days)", amount: "~₹25,000" },
          { label: "Swachh Bharat Mission (Toilet Grant)", amount: "₹12,000" },
          { label: "Total Estimated Direct Assistance", amount: "₹1,57,000 – ₹1,67,000" }
        ],
        benefits: [
          "100% direct cash subsidy transferred into your Aadhaar-linked bank account in milestone installments (foundation, lintel, roof).",
          "No loan repayment or interest burden — this is a non-refundable welfare grant.",
          "Free LPG gas connection under PM Ujjwala Yojana and piped water under Jal Jeevan Mission upon house completion."
        ],
        verificationProcess: "Eligibility is validated via the Awaas+ permanent waitlist and physically verified through geo-tagged milestone photos uploaded by the Gram Panchayat Secretary.",
        nextSteps: [
          "Visit your local Gram Panchayat or Block Development Office (BDO).",
          "Ask the Panchayat Secretary to check your family's name in the Awaas+ priority list.",
          "Ensure your bank account is seeded with Aadhaar and mapped on the NPCI DBT mapper."
        ],
        officialUrl: "https://pmayg.nic.in"
      };
    }

    // 3. URBAN HOUSING (PMAY-U 2.0)
    let urbanVertical = "Interest Subsidy Scheme (ISS)";
    let urbanDetails = [];

    if (situation === "I own a kutcha/semi-permanent house") {
      urbanVertical = "Beneficiary-Led Construction (BLC)";
      urbanDetails = [
        "Direct central financial assistance of ₹1,50,000 plus state top-up (~₹1,00,000) for EWS families to build a new pucca house on their existing plot.",
        "Disbursed in 3 construction milestone stages via urban local body municipal engineers."
      ];
    } else if (situation === "I live in a rented house") {
      urbanVertical = "Interest Subsidy Scheme (ISS) & Affordable Rental Housing (ARHC)";
      urbanDetails = [
        "4% interest subvention on home loans up to ₹25 lakh for property value up to ₹35 lakh (total net subsidy up to ₹1.80L - ₹2.67L over 5-year installments).",
        "Access to Affordable Housing in Partnership (AHP) subsidized flats constructed by municipal development authorities (DDA, MHADA, CIDCO, etc.).",
        "Affordable Rental Housing Complexes (ARHC) for urban migrant workers."
      ];
    } else if (situation === "I do not have a permanent house") {
      urbanVertical = "In-Situ Slum Redevelopment (ISSR) & Affordable Housing in Partnership (AHP)";
      urbanDetails = [
        "Central assistance of ₹1,00,000 to ₹1,50,000 per house for rehabilitation in notified urban areas.",
        "Preference in computerized municipal lottery flats for Economically Weaker Section (EWS) applicants."
      ];
    } else {
      urbanVertical = "PMAY-Urban 2.0 Comprehensive Assistance";
      urbanDetails = [
        "Interest subsidy on bank home loans or municipal allotment based on verified income tier (EWS, LIG, or MIG).",
        "Mandatory or preferred female co-ownership for house registration."
      ];
    }

    return {
      eligibleForPMAY: true,
      statusText: "Potentially Eligible for PMAY-Urban 2.0",
      badgeClass: "badge-eligible",
      title: "Pradhan Mantri Awas Yojana – Urban 2.0 (PMAY-U)",
      schemeName: "Pradhan Mantri Awas Yojana – Urban 2.0",
      schemeId: "pmay-urban",
      summary: `For urban residents without an owned pucca house (${situation}), PMAY-U 2.0 provides interest subvention and affordable housing allotments across statutory towns.`,
      recommendedVertical: urbanVertical,
      financialBreakdown: [
        { label: "Interest Subsidy (ISS Net Present Value)", amount: "Up to ₹2,67,000" },
        { label: "Direct Construction Grant (BLC component)", amount: "₹1,50,000 – ₹2,50,000" },
        { label: "Eligible Home Loan Amount", amount: "Up to ₹25 Lakhs" },
        { label: "Property Value Ceiling", amount: "Up to ₹35 Lakhs" }
      ],
      benefits: urbanDetails,
      verificationProcess: "Approval requires municipal ward assessment, verification of no pucca house in the name of any family member across India, and bank credit sanction.",
      nextSteps: [
        "Visit your City Municipal Corporation / Municipality Housing Cell or pmay-urban.gov.in.",
        "Approach any participating commercial or housing finance bank for PMAY-U Interest Subsidy.",
        "Submit an affidavit affirming that your family does not own a pucca house in India."
      ],
      officialUrl: "https://pmay-urban.gov.in"
    };
  }

  return {
    evaluateHousingAssistance
  };
})();

if (typeof window !== "undefined") {
  window.HousingCalculator = HousingCalculator;
}
