// SchemeSaathi - State Store with LocalStorage Persistence
// Handles user profile, saved schemes, document checklist, and demo profiles

const SchemeStore = (() => {
  const STORAGE_KEY = "schemesaathi_storage_v2";

  // Pre-configured Demo Profiles (as required by prompt section 20)
  const DEMO_PROFILES = {
    rural_farmer: {
      id: "rural_farmer",
      name: "Demo 1: Rural Farmer (UP)",
      description: "Uttar Pradesh, Rural, Age 26–40, Farmer, Income ₹1–2.5L, Housing assistance needed",
      data: {
        ageGroup: "26–40",
        gender: "Male",
        state: "Uttar Pradesh",
        locationType: "Rural",
        district: "Varanasi",
        familyMembers: 5,
        children: 2,
        seniors: 1,
        disabled: 0,
        isVulnerable: "Yes",
        housingStatus: "No permanent house",
        incomeRange: "₹1–2.5 lakh",
        occupation: "Farmer",
        needs: ["Agriculture", "Housing", "Healthcare", "Social Welfare"]
      }
    },
    urban_worker: {
      id: "urban_worker",
      name: "Demo 2: Urban Worker",
      description: "Urban, Age 26–40, Daily wage / Self-employed, Lower income, Rented accommodation",
      data: {
        ageGroup: "26–40",
        gender: "Male",
        state: "Maharashtra",
        locationType: "Urban",
        district: "Mumbai Suburban",
        familyMembers: 4,
        children: 2,
        seniors: 0,
        disabled: 0,
        isVulnerable: "Yes",
        housingStatus: "Rented",
        incomeRange: "Below ₹1 lakh",
        occupation: "Daily wage worker",
        needs: ["Employment", "Housing", "Healthcare", "Financial Assistance"]
      }
    },
    student: {
      id: "student",
      name: "Demo 3: Student",
      description: "Age 18–25, Student, Low personal income, Education & Scholarship need",
      data: {
        ageGroup: "18–25",
        gender: "Female",
        state: "Bihar",
        locationType: "Urban",
        district: "Patna",
        familyMembers: 4,
        children: 0,
        seniors: 0,
        disabled: 0,
        isVulnerable: "Yes",
        housingStatus: "Rented",
        incomeRange: "Below ₹1 lakh",
        occupation: "Student",
        needs: ["Education", "Financial Assistance"]
      }
    }
  };

  // Default empty profile
  const defaultProfile = {
    ageGroup: "26–40",
    gender: "Male",
    state: "Uttar Pradesh",
    locationType: "Rural",
    district: "Varanasi",
    familyMembers: 4,
    children: 2,
    seniors: 0,
    disabled: 0,
    isVulnerable: "Yes",
    housingStatus: "No permanent house",
    incomeRange: "₹1–2.5 lakh",
    occupation: "Farmer",
    needs: ["Housing", "Agriculture", "Healthcare"]
  };

  const defaultState = {
    userProfile: { ...defaultProfile },
    hasSubmittedFinder: false,
    savedSchemes: [
      { id: "pmay-gramin", dateSaved: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) },
      { id: "ayushman-bharat", dateSaved: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) }
    ],
    completedDocs: {
      "aadhaar": true,
      "bank": true,
      "income_cert": false,
      "ration": true,
      "no_pucca_affidavit": false
    },
    housingFinderAnswers: {
      situation: "I do not have a permanent house",
      locationType: "Rural"
    }
  };

  let state = { ...defaultState };
  const listeners = [];

  function init() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        state = {
          ...defaultState,
          ...parsed,
          userProfile: { ...defaultState.userProfile, ...(parsed.userProfile || {}) },
          savedSchemes: Array.isArray(parsed.savedSchemes) ? parsed.savedSchemes : defaultState.savedSchemes,
          completedDocs: { ...defaultState.completedDocs, ...(parsed.completedDocs || {}) },
          housingFinderAnswers: { ...defaultState.housingFinderAnswers, ...(parsed.housingFinderAnswers || {}) }
        };
      }
    } catch (e) {
      console.warn("Storage load error, using default state:", e);
      state = { ...defaultState };
    }
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      notify();
    } catch (e) {
      console.error("Storage save error:", e);
    }
  }

  function notify() {
    listeners.forEach((fn) => {
      try {
        fn(state);
      } catch (err) {
        console.error("Store listener error:", err);
      }
    });
  }

  function subscribe(fn) {
    listeners.push(fn);
    return () => {
      const idx = listeners.indexOf(fn);
      if (idx > -1) listeners.splice(idx, 1);
    };
  }

  function getState() {
    return state;
  }

  function getProfile() {
    return state.userProfile;
  }

  function updateProfile(newProfileData) {
    state.userProfile = {
      ...state.userProfile,
      ...newProfileData
    };
    save();
  }

  function setSubmitted(val = true) {
    state.hasSubmittedFinder = val;
    save();
  }

  function loadDemoProfile(profileKey) {
    const demo = DEMO_PROFILES[profileKey];
    if (demo) {
      state.userProfile = { ...demo.data };
      state.hasSubmittedFinder = true;
      save();
      return demo.data;
    }
    return null;
  }

  // Saved schemes management
  function isSchemeSaved(schemeId) {
    return state.savedSchemes.some((s) => (typeof s === "string" ? s === schemeId : s.id === schemeId));
  }

  function toggleSaveScheme(schemeId) {
    const existingIndex = state.savedSchemes.findIndex((s) => (typeof s === "string" ? s === schemeId : s.id === schemeId));
    let wasSaved = false;

    if (existingIndex > -1) {
      state.savedSchemes.splice(existingIndex, 1);
      wasSaved = false;
    } else {
      const dateStr = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
      state.savedSchemes.push({ id: schemeId, dateSaved: dateStr });
      wasSaved = true;
    }

    save();
    return wasSaved;
  }

  function removeSavedScheme(schemeId) {
    state.savedSchemes = state.savedSchemes.filter((s) => (typeof s === "string" ? s !== schemeId : s.id !== schemeId));
    save();
  }

  function clearAllSavedSchemes() {
    state.savedSchemes = [];
    save();
  }

  // Document checklist management
  function isDocCompleted(docId) {
    return !!state.completedDocs[docId];
  }

  function toggleDocCompleted(docId) {
    state.completedDocs[docId] = !state.completedDocs[docId];
    save();
    return state.completedDocs[docId];
  }

  function resetForm() {
    state.userProfile = {
      ageGroup: "26–40",
      gender: "Male",
      state: "Uttar Pradesh",
      locationType: "Rural",
      district: "",
      familyMembers: 1,
      children: 0,
      seniors: 0,
      disabled: 0,
      isVulnerable: "Prefer not to say",
      housingStatus: "Rented",
      incomeRange: "₹1–2.5 lakh",
      occupation: "Farmer",
      needs: ["Housing"]
    };
    state.hasSubmittedFinder = false;
    save();
  }

  return {
    init,
    getState,
    getProfile,
    updateProfile,
    setSubmitted,
    loadDemoProfile,
    isSchemeSaved,
    toggleSaveScheme,
    removeSavedScheme,
    clearAllSavedSchemes,
    isDocCompleted,
    toggleDocCompleted,
    resetForm,
    subscribe,
    DEMO_PROFILES
  };
})();

if (typeof window !== "undefined") {
  window.SchemeStore = SchemeStore;
}
