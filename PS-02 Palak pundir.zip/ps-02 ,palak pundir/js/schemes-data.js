// SchemeSaathi - Master Database of Government Welfare & Housing Schemes
// Structured according to exact specification:
// id, name, category, shortDescription, purpose, targetBeneficiaries, benefits,
// eligibilityCriteria, requiredDocuments, states, locationType, ageCriteria,
// incomeCriteria, occupationCriteria, familyCriteria, housingCriteria, officialApplicationUrl

const SCHEMES_DATABASE = [
  // ==========================================
  // HOUSING ASSISTANCE
  // ==========================================
  {
    id: "pmay-gramin",
    name: "Pradhan Mantri Awas Yojana – Gramin (PMAY-G)",
    hindiName: "प्रधानमंत्री आवास योजना - ग्रामीण",
    category: "Housing",
    shortDescription: "Direct financial assistance and construction grant for rural houseless families and those living in kutcha or dilapidated houses.",
    purpose: "To provide a pucca house with basic amenities to all houseless households and households living in kutcha and dilapidated houses in rural areas of India.",
    targetBeneficiaries: "Rural families living in kutcha/dilapidated houses or without permanent housing, selected through SECC 2011 / Awaas+ list.",
    benefits: [
      "Direct financial grant of ₹1,20,000 in plains and ₹1,30,000 in hilly/difficult/North-Eastern states.",
      "Additional 90 to 95 days of unskilled labour wages under MGNREGA (~₹25,000).",
      "₹12,000 financial incentive for toilet construction through Swachh Bharat Mission (Grameen).",
      "Total estimated assistance value: ₹1,57,000 to ₹1,67,000 without loan repayment burden.",
      "Convergence with Jal Jeevan Mission for tap water and PM Ujjwala for LPG connection."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories (Rural areas)",
      locationType: "Rural",
      age: "Adult head of household (18+ years)",
      income: "Below ₹2.5 lakh annual household income",
      occupation: "Farmer, Agricultural worker, Daily wage worker, Unemployed, or Any",
      family: "Houseless family or living in 0, 1, or 2 room kutcha house",
      housing: "No permanent pucca house owned by any family member anywhere in India",
      additional: "Name must appear in the Awaas+ / SECC permanent waiting list validated by Gram Sabha."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Identity proof of all adult family members" },
      { id: "bank", name: "Bank Passbook / Account Details", description: "Aadhaar-seeded DBT enabled bank account" },
      { id: "mgnrega", name: "MGNREGA Job Card Number", description: "To credit 90-95 days unskilled construction wages" },
      { id: "ration", name: "Ration Card (BPL/PHH/AAY)", description: "Proof of family composition and economic status" },
      { id: "land_patta", name: "Land Ownership / Gram Panchayat Patta", description: "Proof of rural homestead land or allocation" },
      { id: "no_pucca_affidavit", name: "Affidavit of No Pucca House", description: "Self-declaration of no pucca house ownership in India" }
    ],
    states: ["All"],
    locationType: "Rural",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Daily wage worker", "Self-employed", "Unemployed", "Homemaker", "Senior citizen", "Other"],
    familyCriteria: "Economically vulnerable rural households; preference to SC/ST/Divyangjan/Women-headed households",
    housingCriteria: ["No permanent house", "Rented", "Other"],
    officialApplicationUrl: "https://pmayg.nic.in"
  },
  {
    id: "pmay-urban",
    name: "Pradhan Mantri Awas Yojana – Urban 2.0 (PMAY-U)",
    hindiName: "प्रधानमंत्री आवास योजना - शहरी 2.0",
    category: "Housing",
    shortDescription: "Interest subsidy and direct construction grants to enable urban families to own or construct pucca houses in statutory towns.",
    purpose: "To address urban housing shortages among Economically Weaker Sections (EWS), Low Income Groups (LIG), and Middle Income Groups (MIG) through interest subvention, beneficiary-led construction, and affordable rental housing.",
    targetBeneficiaries: "Urban families belonging to EWS (income up to ₹3L), LIG (₹3-6L), or MIG (up to ₹9L) who do not own a pucca house in India.",
    benefits: [
      "Interest Subsidy Scheme (ISS): 4% interest subvention on home loans up to ₹25 lakh for houses valued up to ₹35 lakh (net benefit up to ₹1.80L - ₹2.67L).",
      "Beneficiary-Led Construction (BLC): Direct financial grant of ₹1,50,000 to ₹2,50,000 for EWS families owning land/kutcha house to construct a new pucca house.",
      "Affordable Housing in Partnership (AHP): Subsidized flats constructed by state housing boards with private developers.",
      "Affordable Rental Housing Complexes (ARHC) for urban migrants and industrial workers.",
      "Mandatory or preferred female co-ownership for house title deeds."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories (Statutory urban towns)",
      locationType: "Urban",
      age: "Adult citizen (18 to 70 years)",
      income: "Household income up to ₹9 lakh (EWS up to ₹3L, LIG ₹3-6L, MIG ₹6-9L)",
      occupation: "Salaried employee, Self-employed, Daily wage worker, Homemaker, or Any",
      family: "Family must comprise husband, wife, and unmarried children",
      housing: "Beneficiary family must not own a pucca house anywhere in India",
      additional: "Property carpet area: EWS up to 30 sq.m, LIG up to 60 sq.m, MIG up to 120 sq.m."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card of all family members", description: "Mandatory biometric identity verification" },
      { id: "income_cert", name: "Income Certificate / Salary Slip / Form 16", description: "Proof of annual household income bracket" },
      { id: "urban_residence", name: "Proof of Residence in Urban Local Body", description: "Voter ID, electricity bill, or municipal tax receipt" },
      { id: "bank_account", name: "Bank Account Passbook / Statements", description: "Aadhaar-linked active savings account" },
      { id: "no_pucca_decl", name: "Notarized Affidavit of No Pucca House", description: "Declaration that family owns no pucca house in India" },
      { id: "land_docs", name: "Title Deed / Plot Papers (for BLC component)", description: "Proof of lawful land possession for construction" }
    ],
    states: ["All"],
    locationType: "Urban",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh"],
    occupationCriteria: ["Salaried employee", "Self-employed", "Daily wage worker", "Homemaker", "Unemployed", "Student", "Senior citizen", "Other"],
    familyCriteria: "Urban household with no pucca house anywhere in India",
    housingCriteria: ["Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmay-urban.gov.in"
  },

  // ==========================================
  // AGRICULTURE
  // ==========================================
  {
    id: "pm-kisan",
    name: "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
    hindiName: "पीएम किसान सम्मान निधि",
    category: "Agriculture",
    shortDescription: "Direct income support of ₹6,000 per year transferred into bank accounts of landholding farmer families across India.",
    purpose: "To supplement the financial needs of small and marginal farmer families for procuring various inputs related to agriculture and domestic requirements.",
    targetBeneficiaries: "All landholding farmer families with cultivable land parcels in their names, subject to institutional exclusions.",
    benefits: [
      "₹6,000 annual direct income support disbursed in 3 equal installments of ₹2,000 every four months.",
      "Direct Benefit Transfer (DBT) straight into the farmer's Aadhaar-linked bank account.",
      "Provides liquidity for quality seeds, fertilizers, and agricultural equipment prior to sowing cycles."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Rural",
      age: "18 years and above",
      income: "Farmer families without high institutional income",
      occupation: "Farmer, Agricultural worker",
      family: "Landholding farmer household (Husband, wife, and minor children)",
      housing: "Any housing status",
      additional: "Excludes institutional landholders, income tax payers, serving/retired government officials, and constitutional post holders."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Mandatory biometric identification with e-KYC" },
      { id: "land_record", name: "Land Ownership Record (Khatauni / RoR / Patta)", description: "Proof of cultivable landholding registered in revenue records" },
      { id: "bank_dbt", name: "Aadhaar-seeded Bank Passbook", description: "Account enabled for Direct Benefit Transfer (DBT)" },
      { id: "mobile_aadhaar", name: "Aadhaar-linked Mobile Number", description: "Required for OTP and annual e-KYC authentication" }
    ],
    states: ["All"],
    locationType: "Rural",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Farmer", "Agricultural worker"],
    familyCriteria: "Landholding farmer family in revenue records",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmkisan.gov.in"
  },
  {
    id: "pmfby",
    name: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
    hindiName: "प्रधानमंत्री फसल बीमा योजना",
    category: "Agriculture",
    shortDescription: "Comprehensive crop insurance cover against non-preventable natural risks from pre-sowing to post-harvest.",
    purpose: "To provide insurance coverage and financial support to farmers in the event of crop loss or damage resulting from natural calamities, pests, and diseases.",
    targetBeneficiaries: "All farmers growing notified crops in notified areas, including sharecroppers and tenant farmers.",
    benefits: [
      "Uniform maximum premium of only 2% for Kharif crops, 1.5% for Rabi food and oilseed crops, and 5% for commercial/horticultural crops.",
      "Balance premium subsidy of up to 90% shared equally by Central and State Governments.",
      "Covers localized calamities (hailstorm, landslide, inundation) and post-harvest losses up to 14 days.",
      "Claim settlement credited directly to farmer's bank account via National Crop Insurance Portal."
    ],
    eligibilityCriteria: {
      state: "All participating Indian States and Union Territories",
      locationType: "Rural",
      age: "18 years and above",
      income: "Open to all farmer income brackets",
      occupation: "Farmer, Agricultural worker",
      family: "Farming household growing notified agricultural crops",
      housing: "Any housing status",
      additional: "Insurance must be enrolled before the designated cut-off date for Kharif or Rabi season."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Identity verification of the farmer" },
      { id: "land_possession", name: "Land Possession Certificate / Khasra-Khatauni", description: "Proof of land cultivation or tenancy agreement" },
      { id: "sowing_cert", name: "Sowing Certificate / Patwari Report", description: "Verification that the notified crop has been sown" },
      { id: "bank_passbook", name: "Bank Passbook with IFSC", description: "For premium deduction and claim settlement" }
    ],
    states: ["All"],
    locationType: "Rural",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh"],
    occupationCriteria: ["Farmer", "Agricultural worker"],
    familyCriteria: "Farmer cultivating notified crops",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmfby.gov.in"
  },
  {
    id: "kcc-scheme",
    name: "Kisan Credit Card (KCC) Scheme",
    hindiName: "किसान क्रेडिट कार्ड योजना",
    category: "Agriculture",
    shortDescription: "Concessional institutional short-term credit for crop cultivation, post-harvest expenses, and animal husbandry.",
    purpose: "To ensure that farmers have timely access to affordable institutional credit without being trapped in high-interest private moneylending cycles.",
    targetBeneficiaries: "Individual/joint cultivators, tenant farmers, oral lessees, sharecroppers, and Self-Help Groups (SHGs).",
    benefits: [
      "Credit limit up to ₹3,00,000 at a concessional interest rate of 4% per annum (with 3% prompt repayment incentive).",
      "Collateral-free agricultural loans up to ₹1,60,000.",
      "Flexible revolving cash credit with unlimited withdrawals and repayments based on harvest cycles.",
      "Includes coverage for dairy, fisheries, and allied agricultural activities."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Rural",
      age: "18 to 75 years (co-borrower mandatory above 60)",
      income: "Small, marginal, and medium farmers",
      occupation: "Farmer, Agricultural worker",
      family: "Agricultural household",
      housing: "Any housing status",
      additional: "Satisfactory credit history and cultivable land documentation."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card & PAN / Form 60", description: "KYC identity and financial documentation" },
      { id: "land_records", name: "Revenue Land Records (7/12, Khatauni, Chitta)", description: "Certified land title documents" },
      { id: "cropping_pattern", name: "Cropping Pattern Declaration", description: "Details of crops planned for upcoming seasons" },
      { id: "photo", name: "Passport Sized Photographs", description: "Recent applicant photos" }
    ],
    states: ["All"],
    locationType: "Rural",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Farmer", "Agricultural worker"],
    familyCriteria: "Farming family engaged in crop or animal husbandry",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://myscheme.gov.in/schemes/kcc"
  },

  // ==========================================
  // HEALTHCARE
  // ==========================================
  {
    id: "ayushman-bharat",
    name: "Ayushman Bharat – Pradhan Mantri Jan Arogya Yojana (PM-JAY)",
    hindiName: "आयुष्मान भारत - प्रधानमंत्री जन आरोग्य योजना",
    category: "Healthcare",
    shortDescription: "Cashless secondary and tertiary hospitalisation cover of up to ₹5 lakh per family per year across 28,000+ empaneled hospitals.",
    purpose: "To reduce catastrophic out-of-pocket healthcare expenses for vulnerable families and provide universal hospitalisation access.",
    targetBeneficiaries: "Deprived rural households and identified occupational categories of urban workers listed in SECC database; all senior citizens aged 70+.",
    benefits: [
      "Cashless and paperless inpatient health insurance cover of up to ₹5,00,000 per family per year.",
      "Covers 1,949 medical procedures including heart surgeries, knee replacements, cancer treatments, and ICU care.",
      "Covers 3 days of pre-hospitalization and 15 days of post-hospitalization diagnostic and medication costs.",
      "No cap on family size or age of family members.",
      "Universal coverage for ALL citizens aged 70 and above irrespective of household income (Ayushman Vay Vandana Card)."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories (except non-participating UTs/states)",
      locationType: "Both",
      age: "All age groups (Under 18, 18-25, 26-40, 41-60, 60+)",
      income: "Below ₹2.5 lakh or identified economically vulnerable household; all 70+ citizens",
      occupation: "Farmer, Agricultural worker, Daily wage worker, Unemployed, Homemaker, Senior citizen, Other, Any",
      family: "Economically vulnerable households or any family with a member aged 70+",
      housing: "Any housing status",
      additional: "Verification via Ration Card (NFSA) or SECC household database at any CSC or empaneled hospital."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Biometric e-KYC verification for Ayushman Golden Card" },
      { id: "ration_card", name: "Ration Card (NFSA / Antyodaya / BPL)", description: "Proof of family membership and entitlement" },
      { id: "mobile_number", name: "Active Mobile Number", description: "For instant OTP generation" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18", "18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "Prefer not to say"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Daily wage worker", "Self-employed", "Unemployed", "Homemaker", "Senior citizen", "Other", "Student"],
    familyCriteria: "Economically vulnerable families or seniors aged 70+",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmjay.gov.in"
  },
  {
    id: "pmsby",
    name: "Pradhan Mantri Suraksha Bima Yojana (PMSBY)",
    hindiName: "प्रधानमंत्री सुरक्षा बीमा योजना",
    category: "Healthcare",
    shortDescription: "Ultra-affordable accidental death and disability insurance cover of ₹2 lakh at an annual premium of just ₹20.",
    purpose: "To provide social security against unforeseen accidental death and permanent disability to citizen bank account holders.",
    targetBeneficiaries: "Citizens aged 18 to 70 years holding an active savings bank account with auto-debit consent.",
    benefits: [
      "₹2,00,000 financial compensation on accidental death or total permanent disability (loss of both eyes/limbs).",
      "₹1,00,000 compensation on partial permanent disability (loss of one eye or one limb).",
      "Nominal annual premium of only ₹20 auto-debited once a year in May/June.",
      "Hassle-free direct claim settlement into beneficiary/nominee bank account."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18 to 70 years",
      income: "Open to all income brackets",
      occupation: "Farmer, Agricultural worker, Student, Salaried employee, Self-employed, Daily wage worker, Unemployed, Homemaker, Senior citizen, Other",
      family: "Individual account holder",
      housing: "Any housing status",
      additional: "Must maintain a savings bank account with auto-debit facility."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Primary KYC identification" },
      { id: "bank_account", name: "Active Savings Bank Account Passbook", description: "Account enabled for ₹20 auto-debit" },
      { id: "nominee_details", name: "Nominee Aadhaar & Relationship Proof", description: "Designated recipient in case of accidental demise" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh", "Above ₹10 lakh", "Prefer not to say"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Student", "Salaried employee", "Self-employed", "Daily wage worker", "Unemployed", "Homemaker", "Senior citizen", "Other"],
    familyCriteria: "Any citizen with savings bank account",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://jansuraksha.gov.in"
  },

  // ==========================================
  // EMPLOYMENT & LIVELIHOOD
  // ==========================================
  {
    id: "mgnrega",
    name: "Mahatma Gandhi National Rural Employment Guarantee Act (MGNREGA)",
    hindiName: "महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम",
    category: "Employment",
    shortDescription: "Guaranteed 100 days of wage employment per financial year to adult members of rural households willing to do manual work.",
    purpose: "To enhance livelihood security in rural areas by providing at least 100 days of guaranteed wage employment while creating durable rural infrastructure.",
    targetBeneficiaries: "Any adult member of a rural household willing to do unskilled manual work.",
    benefits: [
      "Legal guarantee of 100 days of unskilled wage employment per household per year.",
      "Statutory daily minimum wage (₹230 to ₹375 per day depending on state) paid via direct bank transfer.",
      "Unemployment allowance payable if work is not allocated within 15 days of application.",
      "Worksites equipped with drinking water, crèche facility, shade, and first aid.",
      "At least one-third of participating workforce reserved for women beneficiaries."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories (Rural areas)",
      locationType: "Rural",
      age: "18 years and above",
      income: "Below ₹2.5 lakh annual household income",
      occupation: "Agricultural worker, Daily wage worker, Farmer, Unemployed, Homemaker, Other",
      family: "Rural household seeking livelihood wage support",
      housing: "Any housing status",
      additional: "Must reside within the Gram Panchayat where Job Card is registered."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Identity proof and DBT link" },
      { id: "job_card", name: "MGNREGA Job Card", description: "Issued by Gram Panchayat with family photograph" },
      { id: "bank_post", name: "Post Office / Bank Account Passbook", description: "Aadhaar-seeded account for direct weekly wage transfer" },
      { id: "residence_rural", name: "Proof of Local Rural Residence", description: "Gram Panchayat registration record" }
    ],
    states: ["All"],
    locationType: "Rural",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Agricultural worker", "Daily wage worker", "Farmer", "Unemployed", "Homemaker", "Other"],
    familyCriteria: "Rural family willing to perform unskilled manual labour",
    housingCriteria: ["No permanent house", "Rented", "Own house", "Other"],
    officialApplicationUrl: "https://nrega.nic.in"
  },
  {
    id: "pm-svanidhi",
    name: "PM SVANidhi (PM Street Vendor's AtmaNirbhar Nidhi)",
    hindiName: "पीएम स्वनिधि (स्ट्रीट वेंडर्स आत्मनिर्भर निधि)",
    category: "Employment",
    shortDescription: "Collateral-free working capital micro-loans (₹10,000, ₹20,000, and ₹50,000) with 7% interest subsidy for street vendors.",
    purpose: "To empower urban, peri-urban, and rural street vendors to restart and scale their livelihoods through formal banking credit.",
    targetBeneficiaries: "Street vendors, hawkers, thela-walas, and informal daily traders vending in urban and peri-urban locations.",
    benefits: [
      "Initial collateral-free working capital loan of up to ₹10,000 for 1-year tenure.",
      "Enhanced second tranche loan up to ₹20,000 and third tranche loan up to ₹50,000 on timely repayment.",
      "Interest subsidy of 7% per annum credited quarterly into the vendor's bank account.",
      "Monthly digital cashback up to ₹100 for receiving digital payments via UPI / QR code.",
      "No pre-payment penalty for early loan closure."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Urban",
      age: "18 years and above",
      income: "Below ₹2.5 lakh or informal trade income",
      occupation: "Self-employed, Daily wage worker, Other",
      family: "Street vendor household",
      housing: "Any housing status",
      additional: "Must possess Certificate of Vending (CoV), Urban Local Body (ULB) recommendation letter, or identity card."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Biometric identification of the vendor" },
      { id: "cov_lor", name: "Certificate of Vending (CoV) / Letter of Recommendation (LoR)", description: "Issued by Urban Local Body / Town Vending Committee" },
      { id: "bank_account", name: "Savings Bank Account Passbook", description: "For loan disbursement and interest subsidy" },
      { id: "upi_qr", name: "UPI QR Code / VPA Details", description: "To receive monthly digital cashback rewards" }
    ],
    states: ["All"],
    locationType: "Urban",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Self-employed", "Daily wage worker", "Other"],
    familyCriteria: "Informal street vending family",
    housingCriteria: ["Rented", "No permanent house", "Own house", "Other"],
    officialApplicationUrl: "https://pmsvanidhi.mohua.gov.in"
  },
  {
    id: "pm-vishwakarma",
    name: "PM Vishwakarma Yojana",
    hindiName: "पीएम विश्वकर्मा योजना",
    category: "Employment",
    shortDescription: "End-to-end holistic support including ₹15,000 toolkit incentive, advanced training stipend, and 5% collateral-free loans for traditional artisans.",
    purpose: "To recognize and support traditional artisans and craftspersons across 18 designated trades to upgrade their skills, access credit, and enter modern value chains.",
    targetBeneficiaries: "Traditional artisans working with hands and tools (carpenters, blacksmiths, goldsmiths, potters, cobblers, masons, tailors, basket weavers, etc.).",
    benefits: [
      "Official PM Vishwakarma Certificate and Digital Identity Card.",
      "Basic skill training (5-7 days) and advanced training (15 days) with ₹500/day daily stipend.",
      "₹15,000 e-voucher toolkit modern incentive upon completing basic training.",
      "Collateral-free enterprise loan: 1st tranche up to ₹1,00,000 (18-month tenure) and 2nd tranche up to ₹2,00,000 (30-month tenure) at concessional 5% interest rate.",
      "Marketing and branding support for direct market linkage."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18 years and above",
      income: "Traditional artisan / craft household",
      occupation: "Self-employed, Daily wage worker, Other",
      family: "Only one member per family eligible; must not have active PMEGP/Mudra loans",
      housing: "Any housing status",
      additional: "Engaged in one of the 18 eligible traditional family-based artisan trades."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Biometric e-KYC authentication" },
      { id: "trade_proof", name: "Trade Evidence / Declaration", description: "Proof of active artisan profession verified by Gram Panchayat / ULB" },
      { id: "bank_account", name: "Aadhaar-linked Bank Account", description: "For stipend, toolkit grant, and loan disbursement" },
      { id: "ration_card", name: "Ration Card", description: "Verification that only one family member avails the scheme" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40", "41–60"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Self-employed", "Daily wage worker", "Other"],
    familyCriteria: "Traditional artisan / craftsman family",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmvishwakarma.gov.in"
  },

  // ==========================================
  // EDUCATION
  // ==========================================
  {
    id: "post-matric-scholarship",
    name: "Post-Matric Scholarship Scheme (SC / ST / OBC / EWS)",
    hindiName: "पोस्ट-मैट्रिक छात्रवृत्ति योजना",
    category: "Education",
    shortDescription: "Complete tuition fee reimbursement and monthly maintenance allowances for students pursuing Class 11, undergraduate, postgraduate, and professional courses.",
    purpose: "To provide financial assistance to meritorious students from disadvantaged communities studying at post-secondary levels to drastically reduce dropouts.",
    targetBeneficiaries: "Students belonging to SC, ST, OBC, or EWS categories pursuing recognized post-matric courses in government or accredited private institutions.",
    benefits: [
      "100% compulsory non-refundable course tuition fee reimbursement directly to institution.",
      "Monthly maintenance allowance ranging from ₹550 to ₹1,350 per month for hostellers and day scholars.",
      "Additional disability allowance and study tour assistance for eligible scholars.",
      "Direct DBT credit into the student's personal bank account."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18–25 years (or enrolled post-matric students)",
      income: "Household annual income below ₹2.5 lakh (up to ₹1.5L for some OBC state guidelines)",
      occupation: "Student",
      family: "Economically weaker or reserved community household",
      housing: "Any housing status",
      additional: "Passed previous academic qualifying exam; enrolled in an accredited college/university."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Student Aadhaar Card", description: "Aadhaar-seeded for DBT scholarship" },
      { id: "caste_cert", name: "Caste / Category Certificate (SC/ST/OBC)", description: "Issued by competent revenue authority (Tehsildar / SDO)" },
      { id: "income_cert", name: "Income Certificate (Aay Praman Patra)", description: "Certifying household annual income below ceiling" },
      { id: "prev_marksheet", name: "Previous Academic Marksheets & Passing Certificate", description: "Proof of academic eligibility" },
      { id: "fee_receipt", name: "College Bonafide Certificate & Current Fee Receipt", description: "Proof of active college enrollment" },
      { id: "bank_passbook", name: "Student Bank Account Passbook", description: "Must be in student's own name" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18", "18–25", "26–40"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Student"],
    familyCriteria: "Economically weaker household with children in higher education",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://scholarships.gov.in"
  },
  {
    id: "pre-matric-scholarship",
    name: "Pre-Matric Scholarship Scheme",
    hindiName: "प्री-मैट्रिक छात्रवृत्ति योजना",
    category: "Education",
    shortDescription: "Annual scholarship and book grants for students studying in Classes 9 and 10 to encourage secondary schooling.",
    purpose: "To support economically vulnerable parents in sending their children to secondary school, minimizing dropout rates between primary and matriculation.",
    targetBeneficiaries: "Students studying in Class 9th and 10th in government or recognized private schools from vulnerable socio-economic backgrounds.",
    benefits: [
      "Annual scholarship grant of ₹3,500 to ₹7,000 covering tuition, books, and educational stationery.",
      "Special disability allowance for differently-abled school scholars.",
      "Direct DBT credit into the student or parent joint bank account."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "Under 18 years",
      income: "Annual parental income below ₹2.5 lakh",
      occupation: "Student",
      family: "Economically disadvantaged family with school-going children",
      housing: "Any housing status",
      additional: "Regular attendance of at least 75% in recognized secondary school."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Student / Parent Aadhaar Card", description: "Identity authentication" },
      { id: "income_cert", name: "Parent Income Certificate", description: "Valid proof of family income below ₹2.5 lakh" },
      { id: "caste_cert", name: "Community / Category Certificate (if applicable)", description: "SC/ST/OBC/Minority status verification" },
      { id: "school_id", name: "School Bonafide Certificate & Class Marksheet", description: "Signed by School Headmaster / Principal" },
      { id: "bank_acc", name: "Bank Passbook (Student or Joint with Parent)", description: "DBT-enabled account" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Student"],
    familyCriteria: "Family with children studying in secondary school (Classes 9-10)",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://scholarships.gov.in"
  },
  {
    id: "nmmss-scholarship",
    name: "National Means-cum-Merit Scholarship Scheme (NMMSS)",
    hindiName: "राष्ट्रीय साधन-सह-योग्यता छात्रवृत्ति योजना",
    category: "Education",
    shortDescription: "Merit-cum-means financial scholarship of ₹12,000 per year for students studying from Class 9 to Class 12.",
    purpose: "To award scholarships to meritorious students of economically weaker sections to arrest their drop-out at class 8 and encourage them to continue study at secondary stage.",
    targetBeneficiaries: "Students of Class 9 to 12 who clear the state-level NMMSS mental ability and scholastic aptitude test.",
    benefits: [
      "₹12,000 per annum (₹1,000 per month) from Class 9 up to Class 12 completion.",
      "Total scholarship benefit of ₹48,000 over 4 years of secondary schooling.",
      "Direct Benefit Transfer into beneficiary bank account through National Scholarship Portal (NSP)."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "Under 18",
      income: "Parental income from all sources not exceeding ₹3.5 lakh per annum",
      occupation: "Student",
      family: "Economically weaker family with meritorious school student",
      housing: "Any housing status",
      additional: "Minimum 55% marks in Class 7 exam and must clear the state-conducted NMMSS selection test."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card of Student", description: "Mandatory for NSP registration" },
      { id: "nmmss_admit", name: "NMMSS Selection Exam Scorecard / Roll Number", description: "Proof of qualifying the competitive test" },
      { id: "income_proof", name: "Parent Income Certificate", description: "Income within ₹3.5 lakh" },
      { id: "school_records", name: "Class 7/8 Marksheet & Headmaster Verification", description: "Academic performance proof" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Student"],
    familyCriteria: "Family with secondary school student passing merit exam",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://scholarships.gov.in"
  },

  // ==========================================
  // SOCIAL WELFARE & PENSIONS
  // ==========================================
  {
    id: "nsap-ignoaps",
    name: "National Social Assistance Programme – Old Age Pension (IGNOAPS)",
    hindiName: "राष्ट्रीय सामाजिक सहायता कार्यक्रम - वृद्धावस्था पेंशन",
    category: "Social Welfare",
    shortDescription: "Monthly non-contributory social security pension for destitute senior citizens living below the poverty line.",
    purpose: "To provide basic social security and dignity to elderly citizens without adequate family support or personal income.",
    targetBeneficiaries: "Senior citizens aged 60 years and above belonging to BPL households.",
    benefits: [
      "Monthly pension of ₹1,000 to ₹3,000 (Central component + substantial State top-up).",
      "Enhanced pension rates for super senior citizens aged 80 years and above.",
      "Direct bank credit or DBT delivery through rural post office branches."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "60+",
      income: "Below ₹1 lakh (BPL / Antyodaya household)",
      occupation: "Senior citizen, Unemployed, Other",
      family: "BPL household with senior citizen members",
      housing: "Any housing status",
      additional: "Must belong to an identified BPL household verified by local revenue authorities."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card / Age Proof Document", description: "Certifying age is 60 years or above" },
      { id: "bpl_card", name: "BPL Ration Card / BPL Certificate", description: "Proof of living below the official poverty line" },
      { id: "bank_passbook", name: "Bank / Post Office Savings Passbook", description: "DBT-enabled account for monthly pension" },
      { id: "domicile", name: "State Domicile / Residence Certificate", description: "Proof of permanent state residency" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["60+"],
    incomeCriteria: ["Below ₹1 lakh"],
    occupationCriteria: ["Senior citizen", "Unemployed", "Homemaker", "Other"],
    familyCriteria: "BPL household with senior citizens",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://nsap.nic.in"
  },
  {
    id: "nsap-widow-pension",
    name: "Indira Gandhi National Widow Pension Scheme (IGNWPS)",
    hindiName: "इंदिरा गांधी राष्ट्रीय विधवा पेंशन योजना",
    category: "Social Welfare",
    shortDescription: "Monthly financial pension support for widowed women from economically vulnerable households.",
    purpose: "To ensure sustained social protection, nutritional dignity, and financial independence for destitute widows.",
    targetBeneficiaries: "Widowed women aged 40 to 79 years living in households Below Poverty Line (BPL).",
    benefits: [
      "Monthly direct cash pension of ₹1,000 to ₹2,500 depending on state government top-up contribution.",
      "Continuous monthly pension until remarriage or attaining age 80 (then transitioned to super-senior pension).",
      "Direct electronic fund transfer into the widow's individual bank account."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "41–60, 60+",
      income: "Below ₹1 lakh or identified BPL family",
      occupation: "Homemaker, Daily wage worker, Unemployed, Other",
      family: "Widowed female head of household",
      housing: "Any housing status",
      additional: "Must not have remarried and must satisfy state-specific BPL criteria."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card of Applicant", description: "Identity and age verification" },
      { id: "death_cert", name: "Husband's Official Death Certificate", description: "Proof of widowhood issued by municipal/panchayat registrar" },
      { id: "bpl_card", name: "BPL Ration Card / Income Certificate", description: "Economic vulnerability proof" },
      { id: "bank_passbook", name: "Personal Bank Account Passbook", description: "Aadhaar-linked account" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Homemaker", "Daily wage worker", "Unemployed", "Other"],
    familyCriteria: "Widowed female beneficiary",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://nsap.nic.in"
  },
  {
    id: "nsap-disability-pension",
    name: "Indira Gandhi National Disability Pension Scheme (IGNDPS)",
    hindiName: "इंदिरा गांधी राष्ट्रीय दिव्यांग पेंशन योजना",
    category: "Social Welfare",
    shortDescription: "Monthly financial pension assistance for persons with severe and multiple disabilities living in poverty.",
    purpose: "To assist impoverished persons with severe disabilities with necessary financial support for daily living and medical care.",
    targetBeneficiaries: "Persons aged 18 to 79 years with severe or multiple disabilities (80% and above disability or dwarfism) living in BPL households.",
    benefits: [
      "Monthly pension of ₹1,000 to ₹3,000 (Central share + State supplement).",
      "Free assistive devices (tricycles, wheelchairs, hearing aids) through ADIP scheme convergence.",
      "Access to special bus passes and rail concessions."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18–25, 26–40, 41–60, 60+",
      income: "Below ₹1 lakh (BPL household)",
      occupation: "Unemployed, Daily wage worker, Homemaker, Senior citizen, Other",
      family: "Household with person with severe disability",
      housing: "Any housing status",
      additional: "Disability level must be certified at 80% or higher by a Medical Board / UDID Card."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Identity authentication" },
      { id: "udid_card", name: "Unique Disability ID (UDID) / Medical Certificate", description: "Certifying at least 80% disability issued by Civil Surgeon" },
      { id: "bpl_ration", name: "BPL Ration Card / Income Certificate", description: "Poverty line verification" },
      { id: "bank_passbook", name: "Bank Passbook with Aadhaar Seeding", description: "Direct credit of monthly pension" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh"],
    occupationCriteria: ["Unemployed", "Daily wage worker", "Student", "Homemaker", "Senior citizen", "Other"],
    familyCriteria: "Family with person with disabilities",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://nsap.nic.in"
  },

  // ==========================================
  // FINANCIAL ASSISTANCE
  // ==========================================
  {
    id: "pmjdy",
    name: "Pradhan Mantri Jan Dhan Yojana (PMJDY)",
    hindiName: "प्रधानमंत्री जन धन योजना",
    category: "Financial Assistance",
    shortDescription: "Zero-balance basic savings bank account with free RuPay debit card, ₹2 lakh accidental cover, and ₹10,000 overdraft facility.",
    purpose: "To ensure universal access to formal banking facilities with at least one basic banking account for every unbanked adult citizen.",
    targetBeneficiaries: "Any unbanked Indian citizen aged 10 years and above.",
    benefits: [
      "Zero minimum balance requirement (no maintenance charges).",
      "Free RuPay Debit Card with built-in ₹2,00,000 accidental insurance cover.",
      "Overdraft (OD) facility up to ₹10,000 to eligible adult account holders (especially women).",
      "Direct gateway to receive all government welfare subsidies (DBT) seamlessly without leakages."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "Under 18, 18–25, 26–40, 41–60, 60+",
      income: "Open to all income brackets, especially low income",
      occupation: "Farmer, Agricultural worker, Student, Salaried employee, Self-employed, Daily wage worker, Unemployed, Homemaker, Senior citizen, Other",
      family: "Any citizen lacking a formal bank account",
      housing: "Any housing status",
      additional: "Can be opened at any bank branch or Bank Mitra / Business Correspondent (BC) kiosk."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Single document for identity and address verification" },
      { id: "photo", name: "Two Passport Sized Photographs", description: "For account opening form" },
      { id: "mobile", name: "Mobile Number", description: "For SMS alerts and mobile banking" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18", "18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh", "Above ₹10 lakh", "Prefer not to say"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Student", "Salaried employee", "Self-employed", "Daily wage worker", "Unemployed", "Homemaker", "Senior citizen", "Other"],
    familyCriteria: "Any citizen or household",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://pmjdy.gov.in"
  },
  {
    id: "sukanya-samriddhi",
    name: "Sukanya Samriddhi Yojana (SSY)",
    hindiName: "सुकन्या समृद्धि योजना",
    category: "Financial Assistance",
    shortDescription: "High-interest government-backed small savings scheme for girl children with 8.2% annual interest and Section 80C tax exemption.",
    purpose: "To promote the financial security, higher education, and marriage fund for girl children under the Beti Bachao Beti Padhao mission.",
    targetBeneficiaries: "Parents or legal guardians of a girl child aged from birth up to 10 years.",
    benefits: [
      "Government-notified highest sovereign interest rate of 8.2% per annum, compounded annually.",
      "Triple tax exemption (EEE) under Section 80C: deposit, interest earned, and final maturity amount are completely tax-free.",
      "Low minimum annual deposit of only ₹250 (up to maximum ₹1,50,000 per financial year).",
      "Partial withdrawal up to 50% permitted for higher education once the girl turns 18 or passes Class 10."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "Parents with girl child (Age Under 18 / birth to 10 years)",
      income: "Open to all income brackets",
      occupation: "Farmer, Agricultural worker, Student, Salaried employee, Self-employed, Daily wage worker, Unemployed, Homemaker, Senior citizen, Other",
      family: "Family having at least one girl child under 10 years of age (max 2 accounts per family)",
      housing: "Any housing status",
      additional: "Account can be opened at any Post Office or authorized commercial bank."
    },
    requiredDocuments: [
      { id: "birth_cert", name: "Girl Child Birth Certificate", description: "Mandatory proof of child's age issued by municipal/hospital registrar" },
      { id: "parent_aadhaar", name: "Parent / Guardian Aadhaar Card & PAN", description: "KYC documentation of depositor" },
      { id: "address_proof", name: "Address Proof of Guardian", description: "Utility bill, voter card, or passport" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["Under 18", "18–25", "26–40", "41–60"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh", "Above ₹10 lakh", "Prefer not to say"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Salaried employee", "Self-employed", "Daily wage worker", "Homemaker", "Other"],
    familyCriteria: "Family with female children",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://www.indiapost.gov.in/Financial/Pages/Content/Sukanya-Samriddhi-Account.aspx"
  },
  {
    id: "atal-pension",
    name: "Atal Pension Yojana (APY)",
    hindiName: "अटल पेंशन योजना",
    category: "Financial Assistance",
    shortDescription: "Guaranteed monthly life pension of ₹1,000 to ₹5,000 after age 60 for unorganized sector workers.",
    purpose: "To provide an institutional defined pension safety net to unorganized workers who do not have formal retirement benefits.",
    targetBeneficiaries: "All Indian bank account holders aged 18 to 40 years working in the unorganized or informal sector.",
    benefits: [
      "Guaranteed monthly lifetime pension of ₹1,000, ₹2,000, ₹3,000, ₹4,000, or ₹5,000 starting from age 60.",
      "Same pension guaranteed to spouse upon demise of subscriber.",
      "Return of full accumulated pension wealth to nominee upon demise of both subscriber and spouse.",
      "Affordable monthly contribution auto-debited from bank account based on entry age (e.g., ₹210/month at age 18 for ₹5,000/month pension)."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18–25, 26–40",
      income: "Non-income-tax payers with income below ₹5 lakh",
      occupation: "Farmer, Agricultural worker, Self-employed, Daily wage worker, Unemployed, Homemaker, Other",
      family: "Unorganized worker family",
      housing: "Any housing status",
      additional: "Applicant must not be an income tax payer under Income Tax Act 1961."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card", description: "Primary KYC identity and address" },
      { id: "bank_account", name: "Savings Bank Account Passbook", description: "Account enabled for monthly auto-debit of subscription" },
      { id: "nominee_aadhaar", name: "Nominee Information & Spouse Aadhaar", description: "Required for pension continuity" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh"],
    occupationCriteria: ["Farmer", "Agricultural worker", "Self-employed", "Daily wage worker", "Homemaker", "Other"],
    familyCriteria: "Informal/unorganized sector worker",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://www.npscra.nsdl.co.in/scheme-details.php"
  },
  {
    id: "pm-mudra",
    name: "Pradhan Mantri Mudra Yojana (PMMY)",
    hindiName: "प्रधानमंत्री मुद्रा योजना",
    category: "Financial Assistance",
    shortDescription: "Collateral-free micro-business loans up to ₹20 lakh under Shishu (up to ₹50k), Kishore (up to ₹5L), and Tarun (up to ₹10L/₹20L) categories.",
    purpose: "To provide institutional funding to the unfunded small micro-enterprises and entrepreneurs for manufacturing, trading, and service activities.",
    targetBeneficiaries: "Small business owners, shopkeepers, fruit/vegetable vendors, small artisans, and aspiring entrepreneurs.",
    benefits: [
      "No collateral or third-party guarantee required for any Mudra loan.",
      "Three distinct loan categories matching business lifecycle: Shishu (up to ₹50,000), Kishore (₹50,000 to ₹5,00,000), and Tarun (₹5,00,000 to ₹20,00,000).",
      "Affordable interest rates linked to bank base rates with no processing fees for Shishu loans.",
      "Issued with a Mudra Debit Card for easy working capital drawdowns from ATMs."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18–25, 26–40, 41–60",
      income: "Open to self-employed, daily wage, and micro-business owners",
      occupation: "Self-employed, Daily wage worker, Other",
      family: "Micro-entrepreneur household",
      housing: "Any housing status",
      additional: "Satisfactory credit record with no default on prior commercial bank loans."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card & PAN Card", description: "Identity and KYC verification" },
      { id: "business_proof", name: "Business Registration / Udyam Certificate / Shop Act License", description: "Proof of running or proposed business" },
      { id: "bank_statements", name: "Last 6 Months Bank Statement", description: "Proof of cash flow" },
      { id: "project_report", name: "Project Report / Quotation for Machinery (for Kishore/Tarun)", description: "Estimate of machinery or inventory purchase" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40", "41–60"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh"],
    occupationCriteria: ["Self-employed", "Daily wage worker", "Other"],
    familyCriteria: "Micro-business entrepreneur family",
    housingCriteria: ["Own house", "Rented", "No permanent house", "Other"],
    officialApplicationUrl: "https://www.mudra.org.in"
  },
  {
    id: "pm-surya-ghar",
    name: "PM Surya Ghar: Muft Bijli Yojana",
    hindiName: "पीएम सूर्य घर: मुफ्त बिजली योजना",
    category: "Housing",
    shortDescription: "Direct capital subsidy of up to ₹78,000 to install rooftop solar panels and get up to 300 units of free electricity every month.",
    purpose: "To provide free electricity to 1 crore residential households across India by installing rooftop solar systems and enabling households to earn income by selling surplus power.",
    targetBeneficiaries: "Residential households with roof rights suitable for solar panel installation and an active residential electricity connection.",
    benefits: [
      "Direct capital subsidy: ₹30,000 for 1 kW system, ₹60,000 for 2 kW system, and up to ₹78,000 for 3 kW and larger systems.",
      "Up to 300 units of free clean solar electricity per month (saving ₹15,000 to ₹18,000 annually on power bills).",
      "Net metering allows households to sell excess power back to the local DISCOM grid.",
      "Access to collateral-free low-interest solar loans (around 7% interest rate) from nationalized banks."
    ],
    eligibilityCriteria: {
      state: "All Indian States and Union Territories",
      locationType: "Both",
      age: "18–25, 26–40, 41–60, 60+",
      income: "Open to all residential households",
      occupation: "Farmer, Salaried employee, Self-employed, Daily wage worker, Homemaker, Senior citizen, Other",
      family: "Residential household with electricity meter",
      housing: "Own house",
      additional: "Must own a pucca or suitable roof surface and have an active domestic power connection in applicant's name."
    },
    requiredDocuments: [
      { id: "aadhaar", name: "Aadhaar Card of House Owner", description: "Identity of property owner" },
      { id: "electricity_bill", name: "Recent Residential Electricity Bill (last 6 months)", description: "Verifying consumer number and domestic tariff connection" },
      { id: "roof_photo", name: "Photograph of Residential Roof", description: "Proof of unshaded rooftop space" },
      { id: "bank_passbook", name: "Bank Passbook with Aadhaar Seeding", description: "For direct release of ₹78,000 capital subsidy" }
    ],
    states: ["All"],
    locationType: "Both",
    ageCriteria: ["18–25", "26–40", "41–60", "60+"],
    incomeCriteria: ["Below ₹1 lakh", "₹1–2.5 lakh", "₹2.5–5 lakh", "₹5–10 lakh", "Above ₹10 lakh"],
    occupationCriteria: ["Farmer", "Salaried employee", "Self-employed", "Daily wage worker", "Homemaker", "Senior citizen", "Other"],
    familyCriteria: "Residential electricity consumer",
    housingCriteria: ["Own house"],
    officialApplicationUrl: "https://pmsuryaghar.gov.in"
  }
];

// All 36 Indian States and Union Territories (28 States + 8 UTs)
const INDIAN_STATES_AND_UTS = [
  "Andaman and Nicobar Islands",
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chandigarh",
  "Chhattisgarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi (NCT)",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu and Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Ladakh",
  "Lakshadweep",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Puducherry",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal"
];

// Category metadata
const CATEGORIES_META = {
  "Housing": { icon: "🏠", color: "#ea580c", badgeClass: "badge-housing" },
  "Agriculture": { icon: "🌾", color: "#059669", badgeClass: "badge-agriculture" },
  "Healthcare": { icon: "🏥", color: "#dc2626", badgeClass: "badge-healthcare" },
  "Employment": { icon: "💼", color: "#2563eb", badgeClass: "badge-employment" },
  "Education": { icon: "🎓", color: "#7c3aed", badgeClass: "badge-education" },
  "Social Welfare": { icon: "👨‍👩‍👧", color: "#d97706", badgeClass: "badge-social" },
  "Financial Assistance": { icon: "💰", color: "#0891b2", badgeClass: "badge-financial" }
};

if (typeof window !== "undefined") {
  window.SCHEMES_DATABASE = SCHEMES_DATABASE;
  window.INDIAN_STATES_AND_UTS = INDIAN_STATES_AND_UTS;
  window.CATEGORIES_META = CATEGORIES_META;
}
