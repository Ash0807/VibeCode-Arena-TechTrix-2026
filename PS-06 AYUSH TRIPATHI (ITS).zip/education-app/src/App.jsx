import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import JoinQueue from './pages/JoinQueue';
import LiveDashboard from './pages/LiveDashboard';
import AdminPanel from './pages/AdminPanel';
import Settings from './pages/Settings';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderPage = () => {
    switch (activeTab) {
      case 'home': return <Home setActiveTab={setActiveTab} />;
      case 'join': return <JoinQueue setActiveTab={setActiveTab} />;
      case 'live': return <LiveDashboard />;
      case 'admin': return <AdminPanel />;
      case 'settings': return <Settings />;
      default: return <Home setActiveTab={setActiveTab} />;
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-slate-100 dark:bg-[#121c16] text-slate-900 dark:text-slate-100 flex flex-col font-sans">
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        {/* Main Content Area with left padding to avoid sidebar overlap */}
        <main className="flex-1 lg:pl-64 pt-16 transition-all">
          {renderPage()}
        </main>

        <footer className="lg:pl-64 py-6 text-center text-xs text-slate-400 border-t border-slate-200 dark:border-slate-800">
          QueueSmart AI &copy; 2026 • Developed by Ayush Tripathi in Skydash Theme.
        </footer>
      </div>
    </ThemeProvider>
  );
}