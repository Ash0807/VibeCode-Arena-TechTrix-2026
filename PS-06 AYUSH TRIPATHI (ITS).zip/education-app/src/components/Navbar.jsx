import React, { useState } from 'react';
import { LayoutDashboard, Users, Clock, ShieldAlert, Settings, Menu, Search, Bell, LogIn, X, Check } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [email, setEmail] = useState('ayush@queuesmart.ai');
  const [password, setPassword] = useState('••••••••');

  const navItems = [
    { id: 'home', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'join', label: 'Join Queue', icon: Users },
    { id: 'live', label: 'Live Monitor', icon: Clock },
    { id: 'admin', label: 'Admin Counters', icon: ShieldAlert },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setIsLoginOpen(false);
  };

  return (
    <>
      {/* Top Header Navbar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white dark:bg-[#1a2b20] border-b border-slate-200 dark:border-slate-800 z-50 flex items-center justify-between px-4 lg:px-6">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-xl font-black tracking-tight text-[#4B49AC] dark:text-[#98BDFF]">QueueSmart AI</span>
          </div>
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          {/* Search bar */}
          <div className="hidden md:flex items-center bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded-full w-72 border border-slate-200 dark:border-slate-700">
            <Search className="w-4 h-4 text-slate-400 mr-2" />
            <input 
              type="text" 
              placeholder="Search now" 
              className="bg-transparent border-none outline-none text-xs text-slate-700 dark:text-slate-200 w-full placeholder-slate-400"
            />
          </div>
        </div>

        {/* Right Header Icons & Profile (Clickable for Login) */}
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#F3797E] rounded-full"></span>
          </button>
          
          {/* Profile Section - Click to open login modal */}
          <div 
            onClick={() => setIsLoginOpen(true)}
            className="flex items-center space-x-2 pl-2 border-l border-slate-200 dark:border-slate-700 cursor-pointer hover:opacity-80 transition-opacity p-1 rounded-xl"
            title="Click to manage login / profile"
          >
            <div className="w-9 h-9 rounded-full bg-[#7978E9] flex items-center justify-center text-white font-bold text-sm shadow">
              AT
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">Ayush Tripathi</p>
              <p className="text-[10px] text-emerald-500 font-medium">{isLoggedIn ? '● Logged In' : '○ Click to Login'}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Left Sidebar */}
      <aside className={`fixed top-16 bottom-0 left-0 w-64 bg-white dark:bg-[#1a2b20] border-r border-slate-200 dark:border-slate-800 z-40 transition-transform duration-300 overflow-y-auto ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="p-4 space-y-1.5">
          <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">Navigation</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-[#4B49AC] text-white shadow-md shadow-[#4B49AC]/30'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Working Login Modal */}
      {isLoginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a2b20] border border-slate-200 dark:border-slate-800 w-full max-w-md rounded-3xl shadow-2xl p-6 relative animate-fadeIn">
            <button 
              onClick={() => setIsLoginOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-[#4B49AC] text-white flex items-center justify-center mx-auto mb-3 shadow-md">
                <LogIn className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">QueueSmart AI Portal</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Authenticate as System Administrator</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">Email Address</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required 
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 outline-none focus:border-[#4B49AC]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required 
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 outline-none focus:border-[#4B49AC]"
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="accent-[#4B49AC]" />
                  <span>Remember me</span>
                </label>
                <span className="text-[#4B49AC] dark:text-[#98BDFF] font-semibold cursor-pointer">Forgot password?</span>
              </div>

              <button 
                type="submit"
                className="w-full py-3 rounded-xl bg-[#4B49AC] hover:bg-[#3f3d91] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center space-x-2"
              >
                <Check className="w-4 h-4" />
                <span>Secure Login</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}