import React, { useState } from 'react';
import { Clock } from 'lucide-react';

export default function LiveDashboard() {
  const [currentServing] = useState('GEN-104');
  const [waitingTokens] = useState([
    { token: 'GEN-105', name: 'Rrahul Sharma', wait: '12 mins' },
    { token: 'BIL-202', name: 'Priya Verma', wait: '18 mins' },
  ]);

  return (
    <div className="max-w-6xl mx-auto px-4 lg:px-8 py-10">
      <div className="p-8 mb-8 rounded-3xl bg-gradient-to-br from-[#1a2b20] to-[#253D2C] border border-[#2E6F40]/50 shadow-2xl text-center text-white">
        <p className="text-xs uppercase font-bold tracking-widest text-[#CFFFDC]/80 mb-2">Currently Serving Token</p>
        <h2 className="text-6xl font-extrabold mb-3 text-[#CFFFDC]">{currentServing}</h2>
        <p className="text-sm text-slate-300">Please proceed to Counter 2 immediately.</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="p-6 rounded-3xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm">
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-4 flex items-center space-x-2">
            <Clock className="w-5 h-5 text-[#68BA7F]" />
            <span>Waiting Queue</span>
          </h2>
          <div className="space-y-3">
            {waitingTokens.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-[#1a2b20] border border-slate-200 dark:border-[#2E6F40]/30">
                <span className="font-bold text-slate-800 dark:text-slate-100">{item.token} - {item.name}</span>
                <span className="text-xs text-slate-400">Est. wait: {item.wait}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}