import React from 'react';
import { useTheme } from '../context/ThemeContext';

export default function Settings() {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-6">Platform Settings</h1>
      <div className="space-y-6">
        <div className="p-6 rounded-2xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Appearance Mode</h3>
            <p className="text-xs text-slate-500 dark:text-slate-300">Switch between dark theme and light mode</p>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`px-5 py-2.5 rounded-xl font-bold text-sm ${darkMode ? 'bg-[#2E6F40] text-[#CFFFDC]' : 'bg-slate-200 text-slate-800'}`}
          >
            {darkMode ? 'Dark Mode On' : 'Light Mode On'}
          </button>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Administrator Account</h3>
            <p className="text-xs text-slate-500 dark:text-slate-300">Logged in as <strong>Ayush Tripathi</strong></p>
          </div>
          <span className="text-xs px-3 py-1 rounded-full bg-[#CFFFDC]/20 text-[#2E6F40] dark:text-[#CFFFDC] font-bold">Verified</span>
        </div>
      </div>
    </div>
  );
}