import React from 'react';
import { Users, Clock, ShieldAlert, ArrowRight, TrendingUp } from 'lucide-react';

export default function Home({ setActiveTab }) {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-white dark:bg-[#1a2b20] p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-slate-100">
            Welcome Ayush Tripathi
          </h1>
          <p className="text-xs lg:text-sm text-slate-500 dark:text-slate-400 mt-1">
            All systems are running smoothly! You have <span className="text-[#F3797E] font-semibold">3 unread alerts!</span>
          </p>
        </div>
        <div className="px-4 py-2 bg-[#98BDFF]/20 text-[#4B49AC] dark:text-[#98BDFF] rounded-xl text-xs font-bold border border-[#98BDFF]/40">
          Today (10 Jan 2026)
        </div>
      </div>

      {/* Top Grid: Weather/Illustration Banner & 4 Stats Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Big Card (Illustration / Weather style matching reference) */}
        <div className="lg:col-span-2 rounded-2xl bg-gradient-to-r from-[#7DA0FA] to-[#98BDFF] p-6 text-slate-900 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div className="flex justify-between items-start z-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider bg-white/40 px-3 py-1 rounded-full">QueueSmart AI</span>
              <h2 className="text-3xl font-black mt-2">31°C Chicago</h2>
              <p className="text-xs opacity-90 mt-1">Active live queue monitoring & congestion prevention.</p>
            </div>
            <div className="p-4 bg-white/30 backdrop-blur-md rounded-2xl">
              <Users className="w-8 h-8 text-white" />
            </div>
          </div>
          <div className="mt-8 pt-4 border-t border-white/30 flex justify-between items-center text-xs font-semibold">
            <span>Status: Optimal Flow</span>
            <button onClick={() => setActiveTab('live')} className="underline hover:text-white flex items-center space-x-1">
              <span>View live status</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right 4 Small Cards matching your color specs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          
          {/* Card 1 - Color: #4B49AC */}
          <div className="p-4 rounded-2xl bg-[#4B49AC] text-white shadow-md">
            <p className="text-[11px] uppercase font-semibold opacity-80">Today's Bookings</p>
            <h3 className="text-2xl font-black mt-1">4006</h3>
            <p className="text-[10px] mt-2 opacity-90">10.00% (30 days)</p>
          </div>

          {/* Card 2 - Color: #7978E9 */}
          <div className="p-4 rounded-2xl bg-[#7978E9] text-white shadow-md">
            <p className="text-[11px] uppercase font-semibold opacity-80">Number of Meetings</p>
            <h3 className="text-2xl font-black mt-1">34040</h3>
            <p className="text-[10px] mt-2 opacity-90">2.00% (30 days)</p>
          </div>

        </div>
      </div>

      {/* Second Row: Detailed Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
        
        {/* Card 3 - Color: #98BDFF */}
        <div className="p-6 rounded-2xl bg-[#98BDFF] text-slate-900 shadow-md flex justify-between items-center">
          <div>
            <p className="text-xs uppercase font-bold opacity-80">Total Bookings</p>
            <h3 className="text-3xl font-black mt-1">61344</h3>
            <p className="text-xs mt-2 font-semibold">22.00% (30 days)</p>
          </div>
          <div className="p-3 bg-white/40 rounded-xl">
            <TrendingUp className="w-6 h-6 text-[#4B49AC]" />
          </div>
        </div>

        {/* Card 4 - Color: #F3797E (Coral / Red) */}
        <div className="p-6 rounded-2xl bg-[#F3797E] text-white shadow-md flex justify-between items-center">
          <div>
            <p className="text-xs uppercase font-bold opacity-90">Number of Clients</p>
            <h3 className="text-3xl font-black mt-1">47033</h3>
            <p className="text-xs mt-2 opacity-90">0.22% (30 days)</p>
          </div>
          <div className="p-3 bg-white/20 rounded-xl">
            <Users className="w-6 h-6 text-white" />
          </div>
        </div>

      </div>

    </div>
  );
}