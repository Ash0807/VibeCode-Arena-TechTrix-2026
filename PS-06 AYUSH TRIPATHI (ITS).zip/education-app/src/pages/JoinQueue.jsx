import React, { useState } from 'react';
import { Ticket } from 'lucide-react';

export default function JoinQueue({ setActiveTab }) {
  const [formData, setFormData] = useState({
    name: 'Ayush Tripathi',
    phone: '9876543210',
    service: 'General Consultation / Inquiry',
  });

  const [generatedToken, setGeneratedToken] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const randomNum = Math.floor(100 + Math.random() * 900);
    const prefix = formData.service.substring(0, 3).toUpperCase();
    const token = `${prefix}-${randomNum}`;
    
    setGeneratedToken({
      token,
      name: formData.name,
      service: formData.service,
      peopleAhead: Math.floor(3 + Math.random() * 8),
      estimatedWait: Math.floor(10 + Math.random() * 25)
    });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-slate-100">Join Service Queue</h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">Receive a unique token and AI-estimated waiting time.</p>
      </div>

      {!generatedToken ? (
        <form onSubmit={handleSubmit} className="p-8 rounded-3xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm space-y-6">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-600 dark:text-[#CFFFDC] mb-2">Full Name</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-[#1a2b20] border border-slate-200 dark:border-[#2E6F40]/50 text-slate-900 dark:text-slate-100 text-sm outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-600 dark:text-[#CFFFDC] mb-2">Service Category</label>
            <select
              value={formData.service}
              onChange={(e) => setFormData({ ...formData, service: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-[#1a2b20] border border-slate-200 dark:border-[#2E6F40]/50 text-slate-900 dark:text-slate-100 text-sm outline-none"
            >
              <option>General Consultation / Inquiry</option>
              <option>Billing & Payments</option>
              <option>Document Verification</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#2E6F40] to-[#68BA7F] text-white font-bold text-sm shadow-md"
          >
            Generate Digital Token
          </button>
        </form>
      ) : (
        <div className="p-8 rounded-3xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm text-center">
          <Ticket className="w-12 h-12 mx-auto text-[#68BA7F] mb-4" />
          <h2 className="text-4xl font-extrabold text-slate-900 dark:text-slate-100 my-3">{generatedToken.token}</h2>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-6">{generatedToken.service}</p>
          <button
            onClick={() => setActiveTab('live')}
            className="py-3 px-6 rounded-xl bg-[#2E6F40] text-[#CFFFDC] font-bold text-sm shadow"
          >
            View Live Queue Dashboard
          </button>
        </div>
      )}
    </div>
  );
}