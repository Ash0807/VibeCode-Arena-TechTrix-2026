import React, { useState } from 'react';
import { Cpu } from 'lucide-react';

export default function AdminPanel() {
  const [counters] = useState([
    { id: 1, name: 'Counter 1 (General)', status: 'Active', currentToken: 'GEN-103' },
    { id: 2, name: 'Counter 2 (Billing)', status: 'Active', currentToken: 'GEN-104' },
  ]);

  return (
    <div className="max-w-6xl mx-auto px-4 lg:px-8 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-slate-100 mb-2">Administrative Control Center</h1>
      <p className="text-sm text-slate-600 dark:text-slate-300 mb-6">Manage counters and review AI queue optimization.</p>

      <div className="p-6 mb-8 rounded-3xl bg-amber-500/10 border border-amber-500/40 text-amber-800 dark:text-amber-200 flex items-start space-x-4">
        <Cpu className="w-6 h-6 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-base mb-1">AI Queue Optimization Suggestion</h3>
          <p className="text-xs">High footfall detected. Recommendation: Open Counter 3 to reduce congestion.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {counters.map((counter) => (
          <div key={counter.id} className="p-6 rounded-3xl bg-white dark:bg-[#253D2C]/60 border border-slate-200 dark:border-[#2E6F40]/40 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-2">{counter.name}</h3>
            <p className="text-2xl font-bold text-[#2E6F40] dark:text-[#68BA7F] mb-4">{counter.currentToken}</p>
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-600 text-xs font-bold">{counter.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}