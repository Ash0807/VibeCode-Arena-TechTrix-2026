/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        skydash: {
          main: '#4B49AC',
          lightBlue: '#98BDFF',
          accentBlue: '#7DA0FA',
          purple: '#7978E9',
          coral: '#F3797E',
        }
      }
    },
  },
  plugins: [],
}