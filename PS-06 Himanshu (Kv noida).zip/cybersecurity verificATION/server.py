"""Second Look backend. Python standard library only (no pip install needed).

Run:  python server.py        then open http://127.0.0.1:8000
Env:  ADMIN_TOKEN (default demo123), PORT (default 8000), HOST (default 127.0.0.1), DB_PATH
"""
import hmac
import json
import os
import re
import sqlite3
import time
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import detector

ROOT = Path(__file__).parent
DB_PATH = os.environ.get("DB_PATH", str(ROOT / "reports.db"))
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "demo123")
MAX_BODY = 20000
TYPES = {"Phishing email", "Scam SMS", "Fake website", "Suspicious call", "Account compromised"}
RATE = {}  # ip -> [timestamps]; simple in-memory limiter


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS reports(
            n INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, domain TEXT, summary TEXT,
            tags TEXT, status INTEGER DEFAULT 0, date TEXT, evidence TEXT)""")
        if c.execute("SELECT COUNT(*) FROM reports").fetchone()[0] == 0:
            d = lambda n: (date.today() - timedelta(days=n)).isoformat()
            seed = [
                ("Scam SMS", "sbi-kyc-verify.top", "KYC update threat with link", ["urgency", "credentials", "lookalike"], 3, d(14), "sms1.png"),
                ("Phishing email", "micr0soft-support.xyz", "Password expiry notice", ["urgency", "credentials", "lookalike"], 2, d(11), None),
                ("Suspicious call", "-", "Caller claiming to be customs, demanding fee", ["threat", "payment"], 1, d(9), None),
                ("Scam SMS", "bit.ly", "Cashback reward, asks for UPI PIN", ["prize", "credentials", "link"], 1, d(6), "claim.jpg"),
                ("Fake website", "netflix.com.billing-help.click", "Card update page", ["lookalike", "credentials"], 0, d(4), None),
                ("Phishing email", "-", "Support agent asks to install remote app", ["remote", "secrecy"], 0, d(3), None),
                ("Scam SMS", "sbi-secure-login.top", "Account blocked within hours", ["urgency", "lookalike"], 0, d(2), None),
                ("Suspicious call", "-", "Job offer with registration fee", ["prize", "payment"], 0, d(1), None)]
            c.executemany("INSERT INTO reports(type,domain,summary,tags,status,date,evidence) VALUES(?,?,?,?,?,?,?)",
                          [(a, b, s, json.dumps(t), st, dt, ev) for a, b, s, t, st, dt, ev in seed])


def mask_pii(t):
    t = re.sub(r"[\w.+-]+@[\w-]+(\.[\w-]+)+", "[email]", t)
    return re.sub(r"\+?\d[\d\s-]{7,}\d", "[number]", t)


def row_out(r):
    return {"id": "SR-%d" % (1000 + r["n"]), "type": r["type"], "domain": r["domain"], "sum": r["summary"],
            "tags": json.loads(r["tags"]), "status": r["status"], "date": r["date"], "ev": r["evidence"]}


class Handler(BaseHTTPRequestHandler):
    server_version = "SecondLook/1.0"

    def log_message(self, fmt, *a):  # keep logs free of message content
        print("%s %s" % (self.command, self.path.split("?")[0]))

    def send(self, code, obj=None, ctype="application/json", raw=None):
        body = raw if raw is not None else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if ctype == "application/json":
            self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("Request too large")
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON")
        if not isinstance(data, dict):
            raise ValueError("Expected a JSON object")
        return data

    def authed(self):
        tok = self.headers.get("X-Admin-Token", "")
        if hmac.compare_digest(tok.encode(), ADMIN_TOKEN.encode()):
            return True
        self.send(401, {"error": "Admin passcode required"})
        return False

    def limited(self):
        ip, now = self.client_address[0], time.time()
        hits = [t for t in RATE.get(ip, []) if now - t < 60]
        hits.append(now)
        RATE[ip] = hits
        if len(hits) > 60:
            self.send(429, {"error": "Too many requests. Wait a minute and try again."})
            return True
        return False

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            return self.send(200, ctype="text/html", raw=(ROOT / "static" / "index.html").read_bytes())
        if path == "/api/health":
            return self.send(200, {"ok": True})
        m = re.fullmatch(r"/api/reports/SR-(\d+)", path)
        if m:  # public tracking: only type, date and status
            with db() as c:
                r = c.execute("SELECT * FROM reports WHERE n=?", (int(m.group(1)) - 1000,)).fetchone()
            if not r:
                return self.send(404, {"error": "Not found"})
            o = row_out(r)
            return self.send(200, {"id": o["id"], "type": o["type"], "date": o["date"], "status": o["status"]})
        if path == "/api/admin/reports":
            if not self.authed():
                return
            with db() as c:
                rows = c.execute("SELECT * FROM reports ORDER BY n").fetchall()
            return self.send(200, [row_out(r) for r in rows])
        if path == "/api/test":
            return self.send(200, detector.evaluate())
        self.send(404, {"error": "Not found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        if self.limited():
            return
        try:
            data = self.body()
        except ValueError as e:
            return self.send(400, {"error": str(e)})
        if path == "/api/analyze":
            flags = [f for f in data.get("flags", []) if isinstance(f, str)]
            return self.send(200, detector.analyze(url=str(data.get("url") or ""), text=str(data.get("text") or ""),
                                                   sender=str(data.get("sender") or ""), flags=flags))
        if path == "/api/reports":
            rtype = data.get("type") if data.get("type") in TYPES else "Phishing email"
            url, desc = str(data.get("url") or "")[:300], str(data.get("desc") or "")[:2000]
            if not url.strip() and not desc.strip():
                return self.send(400, {"error": "Add a link, sender or description"})
            res = detector.analyze(text=(desc + " " + url).strip())
            domain = detector.analyze_url(url)["host"] if url.strip() else "-"
            ev = os.path.basename(str(data.get("evidence") or ""))[:80] or None
            with db() as c:
                cur = c.execute("INSERT INTO reports(type,domain,summary,tags,status,date,evidence) VALUES(?,?,?,?,0,?,?)",
                                (rtype, domain, mask_pii(desc)[:120] or "(no description)",
                                 json.dumps(sorted({s["k"] for s in res["sig"]})), date.today().isoformat(), ev))
            return self.send(201, {"id": "SR-%d" % (1000 + cur.lastrowid)})
        self.send(404, {"error": "Not found"})

    def do_PATCH(self):
        m = re.fullmatch(r"/api/admin/reports/SR-(\d+)", self.path.split("?")[0])
        if not m:
            return self.send(404, {"error": "Not found"})
        if not self.authed():
            return
        try:
            status = int(self.body().get("status"))
        except (ValueError, TypeError):
            return self.send(400, {"error": "status must be 0 to 3"})
        if status not in range(4):
            return self.send(400, {"error": "status must be 0 to 3"})
        with db() as c:
            c.execute("UPDATE reports SET status=? WHERE n=?", (status, int(m.group(1)) - 1000))
        self.send(200, {"ok": True})


if __name__ == "__main__":
    init_db()
    host, port = os.environ.get("HOST", "127.0.0.1"), int(os.environ.get("PORT", "8000"))
    print("Second Look running at http://%s:%d  (admin passcode: set ADMIN_TOKEN, default demo123)" % (host, port))
    ThreadingHTTPServer((host, port), Handler).serve_forever()
