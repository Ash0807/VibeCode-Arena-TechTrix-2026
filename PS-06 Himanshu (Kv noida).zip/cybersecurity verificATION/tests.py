import unittest
import detector


class DetectorTests(unittest.TestCase):
    def test_accuracy_and_false_positives(self):
        r = detector.evaluate()
        self.assertGreaterEqual(r["accuracy"], 0.85)
        self.assertEqual(r["false_positives"], 0, r["rows"])

    def test_lookalike_domain(self):
        r = detector.analyze(url="https://micr0soft-support.xyz/signin")
        self.assertEqual(r["lvl"], "high")

    def test_legit_domain_not_flagged(self):
        self.assertEqual(detector.analyze(url="https://www.amazon.in/gp/your-orders")["score"], 0)

    def test_otp_masked_and_warning_not_flagged(self):
        r = detector.analyze(text="Your OTP is 482913. Do not share this OTP with anyone.")
        self.assertTrue(r["masked"])
        self.assertEqual(r["lvl"], "low")

    def test_client_cannot_inject_flag_text(self):
        r = detector.analyze(text="hello", flags=["<script>"])
        self.assertEqual(r["sig"], [])


if __name__ == "__main__":
    unittest.main()
