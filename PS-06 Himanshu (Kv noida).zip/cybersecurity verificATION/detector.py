"""Rule-based phishing detector. Links are analysed as text and never opened."""
import html
import re
from urllib.parse import urlparse

BRANDS = ["paypal", "amazon", "google", "microsoft", "apple", "netflix", "sbi", "hdfc", "icici", "paytm",
          "phonepe", "flipkart", "facebook", "instagram", "whatsapp", "irctc", "airtel", "jio", "dhl", "fedex"]
LEGIT = {"hdfcbank.com", "icicibank.com", "onlinesbi.sbi", "sbi.co.in", "sbicard.com", "paytm.com", "phonepe.com",
         "google.com", "gmail.com", "microsoft.com", "live.com", "apple.com", "amazon.com", "amazon.in",
         "paypal.com", "netflix.com", "flipkart.com", "facebook.com", "instagram.com", "whatsapp.com",
         "irctc.co.in", "airtel.in", "jio.com", "dhl.com", "fedex.com"}
SHORT = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "cutt.ly", "is.gd", "rb.gy", "shorturl.at", "ow.ly"}
BADTLD = {"xyz", "top", "click", "icu", "rest", "cfd", "sbs", "buzz", "work", "monster", "link"}

# (key, weight, pattern, title, detail)
RULES = [
    ("urgency", 15, r"urgent|immediately|within \d+ ?(hours?|minutes?|hrs)|last warning|final notice|act now|will be (blocked|suspended|closed)|expires? today|deactivat|suspend|turant|account band|band ho (jayega|jaega)",
     "Pressure to act fast", "Scammers rush you so you skip checking."),
    ("credentials", 25, r"(enter|share|send|provide|confirm|update|verify|reply with|submit)[^.\n]{0,40}(password|\bpin\b|\botp\b|cvv|card number|aadhaar|\bpan\b|net ?banking)",
     "Asks for confidential details", "Real banks and services never ask for passwords, PINs or OTPs by message."),
    ("credentials", 20, r"verify your (account|identity)|kyc (update|expire|pending|verification)|complete (your )?kyc",
     "Account or KYC ‘verification’ demand", "A common script to harvest identity and login details."),
    ("payment", 20, r"gift ?card|crypto|bitcoin|usdt|wire transfer|processing fee|registration fee|upi (collect|request)|pay .{0,30}(to claim|to release|fee)",
     "Unusual payment demand", "Fees, gift cards and crypto are hard to reverse and favoured by fraudsters."),
    ("prize", 15, r"\bwon\b|winner|lottery|reward|cashback|free (gift|iphone)|congratulations|refund|selected for",
     "Too-good-to-be-true offer or refund bait", "Prizes and refunds are used to lure you into a link or call."),
    ("threat", 25, r"arrest|legal action|police|court|warrant|customs|digital arrest|cbi\b|narcotics|illegal items",
     "Threat of legal trouble", "Impersonating authorities creates fear. Real agencies do not demand money by message."),
    ("remote", 25, r"anydesk|teamviewer|quicksupport|install (the |this )?(app|apk)|\.apk",
     "Asks you to install a remote-access app", "This gives the scammer control of your phone or computer."),
    ("secrecy", 10, r"don.?t tell|do not (tell|inform)|keep (this )?confidential|tell no one",
     "Asks you to keep it secret", "Isolation stops friends or family from spotting the scam."),
    ("credentials", 25, r"(otp|pin|password|cvv)[^.\n]{0,20}(bhejo|batao|share karo|send karo)",
     "Asks for confidential details (Hinglish)", "Real banks and services never ask for passwords, PINs or OTPs by message."),
    ("callback", 10, r"(call|whatsapp|contact|message)[^.\n]{0,25}\+?(91[\s-]?)?\d{10}",
     "Pushes you to call or message a number", "Scammers move you off official channels to a phone number they control."),
    ("generic", 8, r"dear (customer|user|member|account holder|sir/madam|valued)",
     "Generic greeting", "Your real bank or shop usually uses your name."),
]
RULES = [(k, w, re.compile(p, re.I), t, d) for k, w, p, t, d in RULES]
SAFE_PHRASE = re.compile(r"(do not|don.?t|never|dont) (share|disclose|give|reveal)[^.\n]*\.?", re.I)
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+")
LINK = re.compile(r"(?:https?://|www\.)[^\s<>\"')]+|\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|in|net|org|xyz|top|click|icu|info|link|cc|co|me|ly|sbs|cfd)(?:/[^\s<>\"')]*)?", re.I)

# Screenshot checklist: the client sends only these keys, never free text.
FLAGS = {
    "logo": (12, "Blurry or off-brand logo", "Scam pages often reuse low-quality copies of a logo."),
    "lookalike": (20, "Address bar or sender does not match the brand", "The name on screen says one thing, the address says another."),
    "qr": (18, "Asks you to scan a QR code or call a number", "QR codes and phone numbers hide where you are really going."),
    "urgency": (15, "Countdown or threat on screen", "Pressure is used to stop you thinking."),
}


def norm(s):
    return s.replace("0", "o").replace("1", "l").replace("3", "e").replace("5", "s").replace("rn", "m").replace("vv", "w")


def reg(host):
    p = host.split(".")
    if len(p) <= 2:
        return host
    if len(p[-1]) == 2 and p[-2] in ("co", "com", "org", "net", "gov", "ac", "nic"):
        return ".".join(p[-3:])
    return ".".join(p[-2:])


def _sig(w, t, d, k="link"):
    return {"w": w, "k": k, "t": t, "d": d}


def analyze_url(raw):
    has = bool(re.match(r"^[a-z]+://", raw, re.I))
    try:
        u = urlparse(raw if has else "http://" + raw)
        host = (u.hostname or "").lower()
    except ValueError:
        host = ""
    if not host:
        return {"sig": [_sig(10, "Link could not be read", "Malformed addresses are sometimes used to dodge filters.")], "host": raw[:60], "regd": raw[:60]}
    rd = reg(host)
    lab = rd.split(".")[0]
    ok = rd in LEGIT
    e = html.escape
    sig = []
    if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", host):
        sig.append(_sig(30, "Address is a raw IP number", "Real organisations use names, not numbers, for customer pages."))
    if "xn--" in host:
        sig.append(_sig(25, "Contains look-alike characters (punycode)", "Foreign letters can mimic English ones, such as a Cyrillic ‘a’.", "lookalike"))
    if u.username:
        sig.append(_sig(25, "Hidden destination using ‘@’", "Everything before the @ is ignored by the browser. The real site is %s." % e(host)))
    if rd in SHORT:
        sig.append(_sig(15, "Shortened link", "A short link hides the real destination until you click."))
    tld = host.split(".")[-1]
    if tld in BADTLD and not ok:
        sig.append(_sig(15, "Domain ending often abused by scammers (.%s)" % e(tld), "Cheap domain endings are common in throwaway scam sites."))
    if len(host.split(".")) >= 5:
        sig.append(_sig(10, "Unusually many subdomains", "Long chains are used to push the real domain out of sight."))
    if host.count("-") >= 3:
        sig.append(_sig(10, "Many hyphens in the domain", "Strings like secure-login-verify-bank are a common pattern."))
    if has and u.scheme == "http":
        sig.append(_sig(10, "Not encrypted (http)", "Legitimate login pages use https."))
    if not ok:
        n = norm(lab)
        for b in BRANDS:
            if lab == b:
                break
            if n == b or (b in n and b not in lab):
                sig.append(_sig(35, "Look-alike of ‘%s’" % b, "The domain %s imitates %s with swapped characters." % (e(rd), b), "lookalike"))
                break
            if b in lab:
                sig.append(_sig(30, "Brand name inside an unrelated domain", "The real domain is %s, not %s.com." % (e(rd), b), "lookalike"))
                break
            if b in host[:len(host) - len(rd)]:
                sig.append(_sig(30, "Brand name used as a subdomain", "The address looks like %s but the real domain is %s." % (b, e(rd)), "lookalike"))
                break
        if re.search(r"login|signin|verify|secure|update|confirm|wallet|kyc|bonus|claim", host + u.path):
            sig.append(_sig(8, "Account-style words in the address", "Words like login or verify are used to look official."))
    if len(raw) > 75:
        sig.append(_sig(8, "Very long address", "Long addresses can bury the real domain."))
    return {"sig": sig, "host": host, "regd": rd}


def mask_secrets(text):
    out, n = re.subn(r"(otp|code|pin|password|passcode)(.{0,60}?)\b(\d{4,8})\b", lambda m: m.group(1) + m.group(2) + "••••", text, flags=re.I)
    return out, n > 0


def find_links(text):
    stripped = EMAIL.sub(" ", text)
    seen = []
    for m in LINK.finditer(stripped):
        v = m.group(0).rstrip(".,;:!?")
        if v not in seen:
            seen.append(v)
    return seen


def analyze(url=None, text=None, sender="", flags=()):
    e = html.escape
    sig, masked, links = [], False, []
    if url:
        sig += analyze_url(url[:500])["sig"]
        links = [url[:500]]
    if text:
        text, masked = mask_secrets(text[:5000])
        check = SAFE_PHRASE.sub("", text)
        for k, w, rx, t, d in RULES:
            if rx.search(check):
                sig.append({"w": w, "k": k, "t": t, "d": d})
        links = find_links(text)
        ls, total = [], 0
        for l in links:
            r = analyze_url(l)
            for s in r["sig"]:
                ls.append({**s, "t": "Link %s: %s" % (e(r["host"]), s["t"])})
        for s in ls:
            if total >= 45:
                break
            total += s["w"]
            sig.append(s)
        mention = [b for b in BRANDS if re.search(r"\b%s\b" % b, text, re.I)]
        if mention and links and not any(reg(analyze_url(l)["host"]) in LEGIT for l in links):
            sig.append({"w": 20, "k": "impersonation", "t": "Names ‘%s’ but links elsewhere" % mention[0],
                        "d": "The message claims a trusted brand while the link goes to an unrelated site."})
        s = (sender or "").strip().lower()[:200]
        if "@" in s:
            sd = reg(s.split("@")[-1])
            if mention and sd not in LEGIT:
                sig.append({"w": 25, "k": "impersonation", "t": "Sender domain does not match the brand",
                            "d": "Sent from %s while naming %s." % (e(sd), mention[0])})
            for x in analyze_url(sd)["sig"]:
                if x["k"] == "lookalike":
                    sig.append({**x, "t": "Sender: " + x["t"]})
    for k in flags or ():
        if k in FLAGS:
            w, t, d = FLAGS[k]
            sig.append({"w": w, "k": k, "t": t, "d": d})
    keys = {s["k"] for s in sig}
    if "urgency" in keys and "credentials" in keys:
        sig.append({"w": 10, "k": "combo", "t": "Urgency combined with a request for secrets",
                    "d": "This pairing is the classic phishing pattern."})
    score = min(100, sum(s["w"] for s in sig))
    lvl = "high" if score >= 55 else "med" if score >= 25 else "low"
    sig.sort(key=lambda s: -s["w"])
    return {"score": score, "lvl": lvl, "sig": sig, "masked": masked, "links": links}


# Labelled samples for the accuracy test (24): (is_phishing, text)
TESTS = [
    (1, "URGENT: Your SBI account will be blocked within 24 hours. Complete KYC update now: http://sbi-kyc-verify.top/login"),
    (1, "Dear customer, you have won a cashback reward of Rs 9,500. Claim now: bit.ly/3xClaim and share your UPI PIN to receive."),
    (1, "This is Customs. A parcel in your name contains illegal items. Legal action and arrest will follow unless you pay a processing fee via gift cards today."),
    (1, "Your Microsoft 365 password expires today. Verify your account here: https://micr0soft-support.xyz/signin"),
    (1, "Hello, I am from Amazon support. Install AnyDesk so I can process your refund. Do not tell anyone."),
    (1, "Netflix: payment failed. Update your card number and CVV at http://netflix.com.billing-help.click/update"),
    (1, "Congratulations! You are selected for a work-from-home job. Pay a registration fee of Rs 500 to start. Reply with your Aadhaar and PAN number."),
    (0, "Your OTP for the HDFC transaction of Rs 1,200 is 482913. Do not share this OTP with anyone."),
    (0, "Hi Riya, your Amazon order has shipped and arrives Thursday. Track it in the Amazon app: https://www.amazon.in/gp/your-orders"),
    (0, "Team lunch is at 1 pm on Friday. Let me know if you have any dietary needs."),
    (0, "Your electricity bill of Rs 842 is due on the 30th. Pay in your usual provider app or portal. Ignore if already paid."),
    (0, "Reminder: your appointment with Dr. Mehta is tomorrow at 10:30. Reply YES to confirm."),
    (0, "Google security alert: new sign-in on a Pixel phone. If this was you, no action needed. Review activity at https://myaccount.google.com/notifications"),
    (1, "Aapka SBI account band ho jayega. Turant KYC update karein: http://sbi-update.click"),
    (1, "Hi, I'm from HR. Urgent: payroll portal login expired. Sign in at https://company-payroll.verify-login.top and confirm your password."),
    (1, "PayPal alert: unusual activity. Confirm your identity at paypa1-secure.com within 12 hours or your account will be suspended."),
    (1, "Your parcel is held. Pay Rs 49 redelivery fee at http://199.45.12.8/track to avoid return. Do not tell anyone."),
    (1, "Dear user, your electricity connection will be disconnected tonight. Call +91 9876543210 immediately to verify your consumer number and pay the pending amount."),
    (0, "Your Flipkart order #4432 is out for delivery today. Delivery partner: Ravi. Open the Flipkart app for live tracking."),
    (0, "Hi, this is Dr. Mehta's clinic. Please call us on 0141-2345678 if you need to reschedule."),
    (0, "Netflix: your payment method was updated. If this wasn't you, change your password at netflix.com/password."),
    (0, "Don't forget to verify your attendance by Monday. The form is at https://forms.gle/abc123"),
    (0, "Congratulations on the new job, Anil! Lunch is on me this Friday."),
    (0, "Your bank statement for September is ready. Log in to your bank’s official app to view it. We never ask for your password by call or SMS."),
]
THRESHOLD = 25


def evaluate():
    tp = fp = tn = fn = 0
    rows = []
    for label, text in TESTS:
        score = analyze(text=text)["score"]
        pred = 1 if score >= THRESHOLD else 0
        if label and pred: tp += 1
        elif not label and pred: fp += 1
        elif not label: tn += 1
        else: fn += 1
        rows.append({"label": label, "text": text[:70], "score": score,
                     "result": "Correct" if pred == label else ("False positive" if pred else "Missed")})
    div = lambda a, b: round(a / b, 3) if b else None
    return {"accuracy": div(tp + tn, len(TESTS)), "precision": div(tp, tp + fp), "recall": div(tp, tp + fn),
            "false_positives": fp, "missed": fn, "rows": rows}
