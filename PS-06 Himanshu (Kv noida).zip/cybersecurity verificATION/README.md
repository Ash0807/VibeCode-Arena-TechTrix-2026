# Second Look: phishing check and awareness tool

A prototype that helps people check suspicious emails, SMS messages, links and screenshots for signs of phishing, understand why, and know what to do next. Built for the Vibe Code Arena cybersecurity problem statement.

## Project layout

```
second-look/
  server.py        Python backend (standard library only) + SQLite
  detector.py      Detection engine, accuracy test samples
  tests.py         Unit tests for the detector
  static/index.html  Front end (HTML, CSS, JavaScript)
  reports.db       Created on first run
```

## Run it with the Python backend

Requires Python 3.9 or newer. No packages to install.

```
python server.py
```

Open http://127.0.0.1:8000. The admin passcode defaults to `demo123`.

Settings (environment variables): `ADMIN_TOKEN` (change this), `PORT` (8000), `HOST` (127.0.0.1), `DB_PATH`.

Run the tests: `python -m unittest tests.py`

### Front end only

`static/index.html` also works on its own: double-click it. When it cannot reach the backend it falls back to the same detection logic in JavaScript and saves reports in the browser's `localStorage`.

## API

| Method and path | Auth | Purpose |
|---|---|---|
| `POST /api/analyze` | none | Body: `{text, sender, url, flags}`. Returns score, level, warning signs, masked flag |
| `POST /api/reports` | none | Body: `{type, url, desc, evidence}` (evidence is a file name only). Returns `{id}` |
| `GET /api/reports/SR-1001` | none | Public tracking: type, date, status only |
| `GET /api/admin/reports` | `X-Admin-Token` | All reports (masked, no personal data) |
| `PATCH /api/admin/reports/SR-1001` | `X-Admin-Token` | Body: `{status: 0..3}` |
| `GET /api/test` | none | Runs the 24-sample accuracy test |
| `GET /api/health` | none | Liveness check |

## Features

- Check an email or SMS, a link, or screenshot text plus a visual checklist
- Low / Medium / High risk with a 0 to 100 score, every warning sign explained, and tailored next steps
- Learning lessons: safe browsing, passwords, phishing techniques, common scams, recovery
- Incident reports with reference numbers and status tracking
- Admin dashboard: totals, recurring scam patterns, reports by type and status, status updates
- Verify tab: email header check (SPF, DKIM, DMARC, Reply-To and display-name mismatches), attachment file-name check, SMS sender or number check, and a "check with the source" checklist. These run in the browser on text only
- Copy summary button on each result, interactive 5-question quiz in Learn, masked CSV export in Admin
- Detects English and Hinglish scam wording (for example "turant", "account band") and callback-number pushes
- Accuracy test showing accuracy, precision, recall, false positives and missed scams

## Privacy and safety design

- Links are analysed as text. They are never fetched or opened by the browser or the server.
- Passwords, OTPs and card numbers are never requested. Code-like numbers near words such as OTP are masked before analysis.
- Reports collect no name, phone or email. Emails and phone numbers in free text are masked before saving. Evidence is stored as a file name only; no uploads are accepted.
- The admin view and API return domains and masked summaries only. Admin routes need the token (compared in constant time).
- The server limits request size (20 KB), rate-limits per IP, never logs message content, and escapes any user-derived text it returns. Screenshot flags are fixed keys, so clients cannot inject text.
- The server binds to localhost by default.

## Scoring

Each warning sign has a weight; weights are summed (link signals capped at 45) and clamped to 100. Under 25 is Low, 25 to 54 is Medium, 55 and above is High. The accuracy test treats 25 or more as flagged.

## Limitations

- Rule-based prototype, not a trained model. The 24-sample test shows where rules fail; it is not proof of real-world accuracy.
- No live reputation lookup. A production version could add a safe-browsing API, called from the server, still without opening the link.
- Screenshots are not read automatically (no OCR). Users type the visible text and tick a checklist.
- Reports stay in your own database and are not sent to any authority. For real incidents use the channels in the Report tab (India: call 1930, cybercrime.gov.in, CERT-In).
- The admin passcode is a single shared token. Real deployments need proper authentication, HTTPS and a production web server.

## Disclaimer

Automated assessments are guidance only. They cannot guarantee that a message or link is safe or fraudulent. When unsure, contact the organisation through its official app or number.
