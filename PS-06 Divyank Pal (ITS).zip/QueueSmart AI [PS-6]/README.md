# QueueSmart AI — Intelligent Queue Management Platform [PS-6]

**Problem Statement:** AI-Powered Smart Queue Management Platform  
**Target Solution:** Real-time queue tracking, dynamic wait-time estimation, priority-tier routing, and admin queue orchestration for hospitals, banks, and service centers.

---

## 📌 Project Overview
QueueSmart AI is a responsive, web-based digital queue management platform built to minimize waiting times and eliminate overcrowding at high-footfall institutions. Users can register digitally to receive dynamic tokens, monitor queue progress in real-time, and view accurate waiting-time estimates. The administrative console allows service operators to call tokens, scale active counters dynamically, and receive real-time counter allocation suggestions based on live queue load.

---

## 🚀 Key Features

1. **Digital Queue Registration & Token Generation:**
   - Multi-service selection (`General Enquiry`, `Account Services`, `Medical Consultation`, `Document Verification`, `Loan & Finance`, `Technical Support`).
   - Generates transparent, categorised tokens:
     - `E-xxx` — Emergency / Critical
     - `P-xxx` — Senior Citizens & Differently Abled
     - `N-xxx` — Standard / Normal FIFO queue

2. **Dynamic Waiting-Time Estimation:**
   - Formulated calculation:
     $$\text{Estimated Wait (min)} = \left\lceil \frac{\text{Queue Position} \times \text{Avg Service Duration}}{\text{Active Service Counters}} \right\rceil$$
   - Clearly displayed as an *estimate* rather than a guarantee.

3. **Live Public Queue Dashboard:**
   - Real-time "Now Serving" counter with live token tracking.
   - Separate, live-refreshing data tables for **Waiting** and **Completed** customers.
   - Status indicators and token count summaries.

4. **Transparent Priority Routing:**
   - Automated queue re-ordering placing emergency cases first, senior citizens second, and general cases in sequential arrival order.

5. **Smart Counter Optimization Engine:**
   - Analyzes queue congestion and automatically triggers alerts recommending administrators open additional service counters when queue thresholds are exceeded.

6. **Simulated In-App Notifications:**
   - Contextual alerts when a customer's turn is approaching (e.g., Position #3, #2, or Next in Line).

7. **Administrative Queue Management:**
   - Password-protected staff console (`admin123`).
   - "Call Next Token" button: completes current token and promotes the next in queue.
   - Real-time counter management: dynamically increment/decrement active counters (1 to 5).
   - One-click demo state reset.

---

## 🛠️ Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend Structure** | HTML5 | Clean, semantic document outline |
| **Styling & UI** | CSS3 + Bootstrap 5.3 (CDN) | Responsive layout, modern cards, and high-readability typography |
| **Icons** | Bootstrap Icons (CDN) | Consistent, lightweight vector iconography |
| **Application Logic** | Vanilla JavaScript (ES6) | Queue sorting, priority engine, wait time algorithms |
| **Data Persistence** | `localStorage` API | Persists queue, counters, and customer records across browser refreshes |
| **Session Control** | `sessionStorage` API | Secure client-side administrative authentication state |

*Zero backend installation required — runs completely client-side in any modern web browser.*

---

## 💻 Quick Setup & Execution Instructions

No dependencies, package managers, or server installations required!

1. **Clone or Download the repository:**
   ```bash
   git clone <YOUR-GITHUB-REPO-LINK>
   cd "QueueSmart AI"
   ```

2. **Run the Application:**
   - Simply double-click **`index.html`** or open it in any web browser (Google Chrome, Microsoft Edge, Safari, Firefox).
   - Or open via terminal / command prompt:
     ```powershell
     Start-Process "index.html"
     ```

3. **Admin Access Credentials:**
   - Go to **Admin Login** in the navigation bar.
   - Demo Password: `admin123`

---

## 📋 3-Minute Demo Script (For Presenters / Judges)

- **Minute 1: Customer Flow (`index.html` -> `join.html`)**
  - Open `index.html` and click **"Join a Queue"**.
  - Enter name, 10-digit phone number, choose a service category, and select **Emergency** or **Senior Citizen** priority.
  - Submit to receive a generated token (e.g., `E-002` or `P-002`) with an estimated waiting time.

- **Minute 2: Live Public Display (`dashboard.html`)**
  - Show the live dashboard: point out the **Now Serving** token, active counter count, and auto-sorted waiting table.
  - Notice how high-priority tokens automatically jump ahead of normal tokens transparently.

- **Minute 3: Staff Admin Console (`admin.html`)**
  - Login via `login.html` with password `admin123`.
  - Click **"Call Next Token"** — observe the current token move into the **Completed** list and the next customer get promoted.
  - Click **"Open Another Counter"** and show how estimated wait times across the entire queue instantly decrease!
  - Point out the **Smart Counter Suggestion banner** that warns staff if queues become overcrowded.

---

## 🔒 Privacy & Safety Note
This prototype does not store private user passwords or personal identifiable information on external servers. All sample records and queue sessions are kept locally in client-side storage. No external API keys are required or exposed.
