// ============================================================
//  QueueSmart AI — Core Application Logic
//  All queue state is stored in localStorage so every page
//  shares the same data without a backend.
// ============================================================

const SERVICES = [
  "General Enquiry",
  "Account Services",
  "Medical Consultation",
  "Document Verification",
  "Loan & Finance",
  "Technical Support"
];

const AVG_SERVICE_TIME = 5;   // minutes per token
const ADMIN_PASSWORD    = "admin123";
const QUEUE_THRESHOLD   = 5;  // warn when waiting > this

// ── localStorage helpers ─────────────────────────────────────

function getQueue() {
  return JSON.parse(localStorage.getItem("qs_queue") || "[]");
}
function setQueue(q) {
  localStorage.setItem("qs_queue", JSON.stringify(q));
}
function getCompleted() {
  return JSON.parse(localStorage.getItem("qs_completed") || "[]");
}
function setCompleted(c) {
  localStorage.setItem("qs_completed", JSON.stringify(c));
}
function getCounters() {
  return parseInt(localStorage.getItem("qs_counters") || "2", 10);
}
function setCounters(n) {
  localStorage.setItem("qs_counters", String(n));
}
function getTokenCounters() {
  return JSON.parse(localStorage.getItem("qs_token_counters") || '{"N":0,"P":0,"E":0}');
}
function setTokenCounters(t) {
  localStorage.setItem("qs_token_counters", JSON.stringify(t));
}
function getCurrentServing() {
  return localStorage.getItem("qs_current_serving") || "";
}
function setCurrentServing(token) {
  localStorage.setItem("qs_current_serving", token || "");
}

// ── Token generation ─────────────────────────────────────────

function generateToken(priority) {
  const counters = getTokenCounters();
  const key = priority === "emergency" ? "E" : priority === "senior" ? "P" : "N";
  counters[key]++;
  setTokenCounters(counters);
  return key + "-" + String(counters[key]).padStart(3, "0");
}

// ── Priority sort ─────────────────────────────────────────────

function priorityOrder(p) {
  return p === "emergency" ? 0 : p === "senior" ? 1 : 2;
}

function sortQueue(queue) {
  return queue.slice().sort(function (a, b) {
    var po = priorityOrder(a.priority) - priorityOrder(b.priority);
    return po !== 0 ? po : a.joinedAt - b.joinedAt;
  });
}

// ── Join queue ────────────────────────────────────────────────

function joinQueue(name, phone, service, priority) {
  var token = generateToken(priority);
  var queue = getQueue();
  var newItem = {
    token: token,
    name: name,
    phone: phone,
    service: service,
    priority: priority,
    status: "waiting",
    joinedAt: Date.now()
  };
  queue.push(newItem);

  // Keep serving item first, sort the rest by priority
  var serving = queue.filter(function (i) { return i.status === "serving"; });
  var waiting = sortQueue(queue.filter(function (i) { return i.status === "waiting"; }));
  setQueue(serving.concat(waiting));
  return newItem;
}

// ── Position & estimated wait ─────────────────────────────────

function getPosition(token) {
  var waiting = getQueue().filter(function (i) { return i.status === "waiting"; });
  var idx = waiting.findIndex(function (i) { return i.token === token; });
  return idx === -1 ? -1 : idx + 1;
}

function getEstimatedWait(position) {
  return Math.ceil((position * AVG_SERVICE_TIME) / getCounters());
}

// ── Call next token ───────────────────────────────────────────

function callNext() {
  var queue = getQueue();
  var currentToken = getCurrentServing();

  // Complete the currently serving token
  if (currentToken) {
    var idx = queue.findIndex(function (i) { return i.token === currentToken; });
    if (idx !== -1) {
      var completed = getCompleted();
      queue[idx].status = "completed";
      completed.unshift(queue[idx]);
      queue.splice(idx, 1);
      setCompleted(completed);
    }
  }

  // Find next waiting item
  var nextIdx = queue.findIndex(function (i) { return i.status === "waiting"; });
  if (nextIdx !== -1) {
    queue[nextIdx].status = "serving";
    setCurrentServing(queue[nextIdx].token);
    setQueue(queue);
    return queue[nextIdx];
  } else {
    setCurrentServing("");
    setQueue(queue);
    return null;
  }
}

// ── Counter suggestion ────────────────────────────────────────

function getSuggestion() {
  var waitingCount = getQueue().filter(function (i) { return i.status === "waiting"; }).length;
  var counters = getCounters();
  if (waitingCount === 0) return "Queue is clear. All counters are under-utilised.";
  if (waitingCount > QUEUE_THRESHOLD && counters < 5) {
    return "Queue length is " + waitingCount + ". Consider opening an additional service counter.";
  }
  return null;
}

// ── Priority badge HTML ───────────────────────────────────────

function priorityBadge(priority) {
  if (priority === "emergency") return '<span class="badge bg-danger">Emergency</span>';
  if (priority === "senior")    return '<span class="badge bg-warning text-dark">Senior / Disabled</span>';
  return '<span class="badge bg-secondary">Normal</span>';
}

// ── Populate service dropdown ─────────────────────────────────

function populateServices(selectId) {
  var sel = document.getElementById(selectId);
  if (!sel) return;
  SERVICES.forEach(function (s) {
    var opt = document.createElement("option");
    opt.value = s;
    opt.textContent = s;
    sel.appendChild(opt);
  });
}

// ── Toast notification ────────────────────────────────────────

function showToast(message, type) {
  type = type || "info";
  var container = document.getElementById("toastContainer");
  if (!container) return;
  var colorClass = type === "success" ? "bg-success"
                 : type === "warning" ? "bg-warning text-dark"
                 : "bg-primary";
  var id = "toast_" + Date.now();
  var html = '<div id="' + id + '" class="toast align-items-center text-white ' + colorClass + ' border-0" role="alert" aria-live="assertive" aria-atomic="true">'
           + '<div class="d-flex">'
           + '<div class="toast-body">' + message + '</div>'
           + '<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>'
           + '</div></div>';
  container.insertAdjacentHTML("beforeend", html);
  var toastEl = document.getElementById(id);
  var toast = new bootstrap.Toast(toastEl, { delay: 4500 });
  toast.show();
  toastEl.addEventListener("hidden.bs.toast", function () { toastEl.remove(); });
}

// ── Sample data (first load only) ────────────────────────────

function initSampleData() {
  if (localStorage.getItem("qs_initialized") === "true") return;

  var now = Date.now();
  var sampleQueue = [
    { token: "N-001", name: "Amit Patel",    phone: "9876543210", service: "General Enquiry",        priority: "normal",    status: "serving", joinedAt: now - 320000 },
    { token: "E-001", name: "Priya Singh",   phone: "9871234567", service: "Medical Consultation",   priority: "emergency", status: "waiting", joinedAt: now - 230000 },
    { token: "P-001", name: "Geeta Devi",    phone: "9845123456", service: "Account Services",       priority: "senior",    status: "waiting", joinedAt: now - 200000 },
    { token: "N-002", name: "Rahul Sharma",  phone: "9812345678", service: "Document Verification",  priority: "normal",    status: "waiting", joinedAt: now - 150000 },
    { token: "N-003", name: "Suresh Kumar",  phone: "9867891234", service: "Loan & Finance",         priority: "normal",    status: "waiting", joinedAt: now -  80000 }
  ];

  var sampleCompleted = [
    { token: "N-000", name: "Rajesh Gupta", phone: "9812300001", service: "General Enquiry",   priority: "normal", status: "completed", joinedAt: now - 700000 },
    { token: "P-000", name: "Kamla Devi",   phone: "9876500001", service: "Account Services",  priority: "senior", status: "completed", joinedAt: now - 950000 }
  ];

  // Serving item first, then sorted waiting items
  var serving = sampleQueue.filter(function (i) { return i.status === "serving"; });
  var waiting = sortQueue(sampleQueue.filter(function (i) { return i.status === "waiting"; }));

  setQueue(serving.concat(waiting));
  setCompleted(sampleCompleted);
  setCurrentServing("N-001");
  setCounters(2);
  setTokenCounters({ N: 3, P: 1, E: 1 });
  localStorage.setItem("qs_initialized", "true");
}

// Run on every page load
initSampleData();
