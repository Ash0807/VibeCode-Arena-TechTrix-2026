# QueueSmart AI — TechTrix’26 Vibe Code Arena

**Problem Statement:** PS-06 — AI-Powered Smart Queue Management Platform  
**Event:** Vibe Code Arena, TechTrix’26, ITS Engineering College

QueueSmart AI is a functional prototype for digital appointment and walk-in registration, token generation, estimated waiting times, and live queue monitoring. It provides a patient-facing portal and a staff dashboard for managing queue activity and doctor availability.

> **Prototype notice:** This repository documents a demonstration prototype using sample data. It is not a certified hospital system and must not be used with real patient data. Waiting times are estimates, not guarantees. Follow the event’s fresh-build and submission rules; document work honestly and do not claim features that are not implemented.

## Key features

- Appointment booking and walk-in queue registration
- Automatic token generation and queue status tracking
- Live queue display with pending-token counts
- Estimated waiting time based on the number of people ahead and configured average consultation duration
- Department and doctor selection, schedules, room labels, and appointment-slot capacity checks
- Staff authentication with bcrypt password hashing and server-side sessions
- Staff queue actions: call, start consultation, complete, and skip/recall
- Configurable normal/priority queue ordering in the queue data model
- Doctor availability controls and reassignment attempts when availability changes
- English/Hindi patient interface and responsive layout
- Sample departments/doctors in the SQL schema
- Health-check endpoint at `/api/health`

**Notifications:** The prototype does not integrate a real SMS/WhatsApp/push provider. Do not describe simulated or on-screen status updates as real external notifications.

## Technology stack

- **Frontend:** HTML, CSS, vanilla JavaScript
- **Backend:** Node.js, Express
- **Database:** MySQL 8+ or compatible MariaDB
- **Authentication:** bcryptjs and express-session
- **Security libraries:** Helmet, express-rate-limit, parameterized SQL queries

## Requirements

- Node.js 20 or newer
- MySQL 8+ or compatible MariaDB
- npm

## Run locally

1. Clone the repository and enter the project directory:

   ```bash
   git clone https://github.com/YOUR-USERNAME/queuesmart-ai.git
   cd queuesmart-ai
   ```

2. Create a database and import the schema. The schema creates the `smart_hospital` database and seeds sample departments/doctors:

   ```bash
   mysql -u root -p < sql/schema.sql
   ```

3. Copy the example environment file and configure it:

   ```bash
   cp .env.example .env
   ```

   Set the database host/name/user/password, a long random `SESSION_SECRET`, and a strong unique `ADMIN_PASSWORD`. Keep `.env` private and never commit it.

4. Install dependencies and start the app:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000`. Sign in with the `ADMIN_EMAIL` and `ADMIN_PASSWORD` configured in `.env`.

6. Check `http://localhost:3000/api/health`; a healthy response should include `"ok": true`.

## Main demo pages

- **Patient registration:** `/`
- **Live queue display:** `/live`
- **Staff dashboard:** sign in through the Staff Portal section on `/`
- **Health check:** `/api/health`

## Suggested 3-minute live demo

1. **0:00–0:25 — Problem:** Explain that walk-in queues can be confusing and patients need visibility into token progress.
2. **0:25–1:00 — Register:** Demonstrate a sample appointment or walk-in registration using fictional data.
3. **1:00–1:35 — Live status:** Open `/live` and show the token and pending-queue display updating from the database.
4. **1:35–2:25 — Staff workflow:** Sign in, show queue entries, and demonstrate a queue action such as calling or completing a token.
5. **2:25–3:00 — Value and limitations:** Explain estimated wait-time logic, priority ordering, bilingual UI, and that external notifications and production-grade identity verification are not integrated.

Use only fictional demo details. Rehearse the full flow before presenting and keep a fallback screenshot/video in case the network fails; the live demo remains mandatory under the supplied event brief.

## Hostinger deployment notes

1. Create a MySQL database and user in hPanel.
2. Import `sql/schema.sql` using phpMyAdmin.
3. Create a Node.js application using Node.js 20+ where supported by the hosting plan.
4. Configure the variables from `.env.example` in the hosting environment; use the database credentials provided by hPanel. `DB_PORT` is commonly `3306`, unless the host specifies another port.
5. Set `server.js` as the startup file, install dependencies, start/restart the app, connect the domain, and enable HTTPS.
6. Verify `/api/health`, patient registration, staff login, and `/live` using fictional data.

Hosting controls can vary by plan; use the options available in your hosting dashboard.

## Known limitations and safety

- Public patient registration and status lookup are disabled in production until mobile OTP verification is implemented and enforced server-side.
- Status lookup is not a substitute for authenticated patient access in a production deployment.
- Waiting-time estimates use configured average consultation duration and queue position; they are not AI-trained predictions.
- No real SMS, WhatsApp, or push notification provider is configured.
- A production deployment would need a persistent session store, CSRF protections, reviewed cookie/proxy settings, robust identity verification, monitoring, backups, retention policies, concurrency testing, and security/privacy review.
- Use sample data only. Never commit real patient records, database exports with real accounts, `.env` files, passwords, API keys, or session secrets.

## Submission checklist (from the supplied TechTrix’26 brief)

- [x] Project name and problem statement ID documented
- [x] Project description and key features documented
- [x] Source code and setup instructions included
- [ ] Add your own screenshots or a demo link after verifying them
- [ ] Confirm the organisers’ required repository/submission process
- [ ] Confirm the project complies with the 90-minute fresh-build rule; the event brief warns that pre-built/old projects may receive deductions or be disqualified

## GitHub push

Create an empty repository named `queuesmart-ai`, then run from this project folder:

```bash
git init
git add .
git status
git commit -m "Submit QueueSmart AI prototype for TechTrix'26 PS-06"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/queuesmart-ai.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Review `git status` before committing.

## License

No license is specified. Add a `LICENSE` file if you want to permit reuse or redistribution.
