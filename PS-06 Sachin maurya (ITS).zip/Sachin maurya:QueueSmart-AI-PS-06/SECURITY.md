# Security Policy

CareFlow is an MVP and is not ready to process real patient information.

## Reporting a vulnerability

Do not post credentials, patient information, or exploit details publicly. Contact the repository owner privately through the contact method listed on their GitHub profile.

## Before deployment

- Keep `.env` and production database exports out of Git.
- Rotate any credentials that may have been shared or committed.
- Configure a strong session secret and unique administrator password.
- Complete the production and privacy checklist in `README.md` before handling real patient data.
