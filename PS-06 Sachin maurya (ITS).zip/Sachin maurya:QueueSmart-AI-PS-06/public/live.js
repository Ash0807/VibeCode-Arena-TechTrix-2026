const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusText=s=>s==='in_consultation'?'In consultation':'Called';
function showCurrent(items){
 const root=$('#currentList');
 if(!items.length){root.innerHTML='<div class="empty">No token is being called right now.</div>';return}
 root.innerHTML=items.map(x=>`<div class="current-card"><div><div class="token">${esc(x.token)}</div><span class="status">${statusText(x.status)}</span></div><div class="dept">${esc(x.department)}<small>Room: ${esc(x.room||'—')}</small></div></div>`).join('');
}
function showWaiting(items){
 $('#waitingCount').textContent=`${items.length} shown`;
 const root=$('#waitingRows');
 if(!items.length){root.innerHTML='<tr><td colspan="3" class="empty">No pending tokens right now.</td></tr>';return}
 root.innerHTML=items.map(x=>`<tr><td>${esc(x.token)}</td><td>${esc(x.department)}</td><td>${esc(x.room||'—')}</td></tr>`).join('');
}
async function refresh(){
 try{
  const response=await fetch('/api/live-queue',{cache:'no-store'});
  if(!response.ok)throw new Error('Server returned '+response.status);
  const data=await response.json();
  $('#hospitalName').textContent=data.hospitalName||'CareFlow Hospital';
  $('#pendingCount').textContent=data.stats.pending;
  $('#calledCount').textContent=data.stats.called;
  $('#consultingCount').textContent=data.stats.consulting;
  $('#completedCount').textContent=data.stats.completed;
  $('#updatedAt').textContent=new Date(data.updatedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  $('#connection').textContent='Live · Connected';
  showCurrent(data.current);showWaiting(data.waiting);
 }catch(err){$('#connection').textContent='Reconnecting…';}
}
refresh();setInterval(refresh,5000);
