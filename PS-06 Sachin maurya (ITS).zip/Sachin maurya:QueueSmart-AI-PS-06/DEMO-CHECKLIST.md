# QueueSmart AI — Live Demo Checklist

- [ ] Start MySQL and import `sql/schema.sql`.
- [ ] Configure `.env` locally; never upload it.
- [ ] Run `npm install` and `npm start`.
- [ ] Confirm `/api/health` returns `ok: true`.
- [ ] Open the patient portal and create a demo entry with fictional details.
- [ ] Open `/live` and verify the pending token count and token list.
- [ ] Sign in to the staff portal and demonstrate a queue action.
- [ ] Explain that wait times are estimates and external notifications are not integrated.
- [ ] Keep screenshots as backup, but demonstrate the working app live.
- [ ] Ensure all work complies with the event’s 90-minute fresh-build rule.
