CREATE DATABASE IF NOT EXISTS smart_hospital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_hospital;

CREATE TABLE IF NOT EXISTS departments (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(120) NOT NULL UNIQUE,
 name_hi VARCHAR(120) NOT NULL DEFAULT '',
 opening_time TIME NOT NULL DEFAULT '09:00:00',
 closing_time TIME NOT NULL DEFAULT '17:00:00',
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctors (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 department_id BIGINT UNSIGNED NOT NULL,
 full_name VARCHAR(160) NOT NULL,
 qualification VARCHAR(160) NOT NULL DEFAULT '',
 avg_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 15,
 capacity_per_slot SMALLINT UNSIGNED NOT NULL DEFAULT 4,
 is_available BOOLEAN NOT NULL DEFAULT TRUE,
 schedule_start TIME NOT NULL DEFAULT '09:00:00',
 schedule_end TIME NOT NULL DEFAULT '17:00:00',
 room_label VARCHAR(80) NOT NULL DEFAULT 'Room 1',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_doctor_department FOREIGN KEY (department_id) REFERENCES departments(id)
);
CREATE TABLE IF NOT EXISTS patients (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 full_name VARCHAR(160) NOT NULL,
 mobile VARCHAR(20) NOT NULL UNIQUE,
 date_of_birth DATE NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS appointments (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 patient_id BIGINT UNSIGNED NOT NULL,
 department_id BIGINT UNSIGNED NOT NULL,
 doctor_id BIGINT UNSIGNED NOT NULL,
 appointment_date DATE NOT NULL,
 appointment_time TIME NOT NULL,
 status ENUM('booked','checked_in','in_consultation','completed','cancelled','no_show','reschedule_required') NOT NULL DEFAULT 'booked',
 token VARCHAR(24) NOT NULL UNIQUE,
 notes VARCHAR(300) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
 CONSTRAINT fk_appointment_department FOREIGN KEY (department_id) REFERENCES departments(id),
 CONSTRAINT fk_appointment_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id),
 INDEX idx_appointment_schedule (doctor_id, appointment_date, appointment_time, status)
);
CREATE TABLE IF NOT EXISTS queue_entries (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 patient_id BIGINT UNSIGNED NOT NULL,
 department_id BIGINT UNSIGNED NOT NULL,
 doctor_id BIGINT UNSIGNED NOT NULL,
 queue_date DATE NOT NULL,
 token VARCHAR(24) NOT NULL UNIQUE,
 queue_type ENUM('walk_in','appointment') NOT NULL DEFAULT 'walk_in',
 status ENUM('waiting','called','in_consultation','completed','cancelled','skipped') NOT NULL DEFAULT 'waiting',
 priority ENUM('normal','priority') NOT NULL DEFAULT 'normal',
 joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 called_at DATETIME NULL,
 started_at DATETIME NULL,
 completed_at DATETIME NULL,
 CONSTRAINT fk_queue_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
 CONSTRAINT fk_queue_department FOREIGN KEY (department_id) REFERENCES departments(id),
 CONSTRAINT fk_queue_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id),
 INDEX idx_queue_live (queue_date, department_id, status, joined_at)
);
CREATE TABLE IF NOT EXISTS staff_users (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 full_name VARCHAR(160) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','reception','doctor') NOT NULL,
 doctor_id BIGINT UNSIGNED NULL,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_staff_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 staff_id BIGINT UNSIGNED NULL,
 action VARCHAR(120) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id VARCHAR(80) NULL,
 details JSON NULL,
 ip_address VARCHAR(64) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_created (created_at)
);
CREATE TABLE IF NOT EXISTS feedback (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 appointment_id BIGINT UNSIGNED NOT NULL UNIQUE,
 rating TINYINT UNSIGNED NOT NULL,
 comment VARCHAR(500) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_feedback_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(id),
 CONSTRAINT chk_feedback_rating CHECK (rating BETWEEN 1 AND 5)
);

INSERT IGNORE INTO departments (name,name_hi) VALUES
 ('General Medicine','सामान्य चिकित्सा'),('Cardiology','हृदय रोग'),('Orthopedics','हड्डी रोग'),('Dermatology','त्वचा रोग'),('Pediatrics','बाल रोग');
INSERT INTO doctors (department_id,full_name,qualification,avg_minutes,capacity_per_slot,is_available,schedule_start,schedule_end,room_label)
SELECT d.id,'Dr. Aditi Sharma','MBBS, MD',12,4,TRUE,'09:00:00','17:00:00','Room 01' FROM departments d WHERE d.name='General Medicine'
AND NOT EXISTS (SELECT 1 FROM doctors x WHERE x.full_name='Dr. Aditi Sharma');
INSERT INTO doctors (department_id,full_name,qualification,avg_minutes,capacity_per_slot,is_available,schedule_start,schedule_end,room_label)
SELECT d.id,'Dr. Rahul Verma','MBBS, MD',18,3,TRUE,'10:00:00','16:00:00','Room 02' FROM departments d WHERE d.name='Cardiology'
AND NOT EXISTS (SELECT 1 FROM doctors x WHERE x.full_name='Dr. Rahul Verma');
INSERT INTO doctors (department_id,full_name,qualification,avg_minutes,capacity_per_slot,is_available,schedule_start,schedule_end,room_label)
SELECT d.id,'Dr. Neha Singh','MBBS, MS',15,4,TRUE,'09:00:00','17:00:00','Room 03' FROM departments d WHERE d.name='Orthopedics'
AND NOT EXISTS (SELECT 1 FROM doctors x WHERE x.full_name='Dr. Neha Singh');
