require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const pool = mysql.createPool({host:process.env.DB_HOST || '127.0.0.1',port:Number(process.env.DB_PORT || 3306),user:process.env.DB_USER || 'root',password:process.env.DB_PASSWORD || '',database:process.env.DB_NAME || 'smart_hospital',waitForConnections:true,connectionLimit:10,queueLimit:0,dateStrings:true});

app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'","https:"] ,scriptSrc:["'self'"],imgSrc:["'self'","data:","https:"],connectSrc:["'self'"],fontSrc:["'self'","https:","data:"],objectSrc:["'none'"],upgradeInsecureRequests: process.env.NODE_ENV==='production' ? [] : null}}}));
app.use(compression());
app.use(express.json({limit:'20kb'}));
app.use(express.urlencoded({extended:false,limit:'20kb'}));
app.use(session({name:'careflow.sid',secret:process.env.SESSION_SECRET || 'dev-only-change-this-session-secret-please',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge: Number(process.env.SESSION_MAX_AGE_MS || 30*60*1000)}}));
app.use('/api',rateLimit({windowMs:60*1000,limit:120,standardHeaders:'draft-7',legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'public')));

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const today = () => new Date().toISOString().slice(0,10);
const token = prefix => `${prefix}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
const roles = (...allowed) => (req,res,next) => { if(!req.session.staff) return res.status(401).json({error:'Please sign in.'}); if(!allowed.includes(req.session.staff.role)) return res.status(403).json({error:'You do not have permission for this action.'}); next(); };
async function audit(req, action, entityType, entityId=null, details={}) {
  try { await pool.execute('INSERT INTO audit_logs (staff_id,action,entity_type,entity_id,details,ip_address) VALUES (?,?,?,?,?,?)',[req.session.staff?.id || null,action,entityType,entityId ? String(entityId):null,JSON.stringify(details),String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').slice(0,64)]); } catch(e) { console.error('Audit write failed:',e.message); }
}
async function seedAdmin() {
  if(!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) return;
  const [rows] = await pool.execute('SELECT id FROM staff_users WHERE email=? LIMIT 1',[process.env.ADMIN_EMAIL.toLowerCase()]);
  if(rows.length) return;
  const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD,12);
  await pool.execute('INSERT INTO staff_users (full_name,email,password_hash,role) VALUES (?,?,?,\'admin\')',[process.env.ADMIN_NAME || 'Hospital Administrator',process.env.ADMIN_EMAIL.toLowerCase(),hash]);
  console.log(`Initial administrator created: ${process.env.ADMIN_EMAIL}`);
}

app.get('/api/health', asyncRoute(async(req,res)=>{ await pool.query('SELECT 1'); res.json({ok:true,service:'smart-hospital',time:new Date().toISOString()}); }));
app.get('/api/config',(req,res)=>res.json({hospitalName:process.env.APP_NAME || 'CareFlow Hospital',languages:['en','hi']}));
app.get('/api/departments',asyncRoute(async(req,res)=>{ const [rows]=await pool.query('SELECT id,name,name_hi FROM departments WHERE is_active=1 ORDER BY name'); res.json(rows); }));
app.get('/api/doctors',asyncRoute(async(req,res)=>{ const [rows]=await pool.query('SELECT d.id,d.full_name,d.qualification,d.avg_minutes,d.capacity_per_slot,d.is_available,d.schedule_start,d.schedule_end,d.room_label,d.department_id,dep.name AS department_name FROM doctors d JOIN departments dep ON dep.id=d.department_id WHERE dep.is_active=1 ORDER BY dep.name,d.full_name'); res.json(rows); }));
app.get('/api/auth/me',(req,res)=>res.json({staff:req.session.staff || null}));
app.post('/api/auth/login',rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
 if(!email || !password) return res.status(400).json({error:'Email and password are required.'});
 const [rows]=await pool.execute('SELECT id,full_name,email,password_hash,role,doctor_id,is_active FROM staff_users WHERE email=? LIMIT 1',[email]);
 if(!rows.length || !rows[0].is_active || !(await bcrypt.compare(password,rows[0].password_hash))) return res.status(401).json({error:'Invalid sign-in details.'});
 req.session.regenerate(err=>{ if(err) return res.status(500).json({error:'Unable to start session.'}); const u=rows[0]; req.session.staff={id:u.id,name:u.full_name,email:u.email,role:u.role,doctorId:u.doctor_id}; audit(req,'staff.login','staff_user',u.id); res.json({staff:req.session.staff}); });
}));
app.post('/api/auth/logout',(req,res)=>req.session.destroy(()=>{res.clearCookie('careflow.sid');res.json({ok:true});}));

// Basic mobile verification is intentionally not simulated here: configure a real OTP provider before public production use.
app.post('/api/patients/lookup',rateLimit({windowMs:10*60*1000,limit:8,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 const mobile=String(req.body.mobile||'').replace(/[^0-9+]/g,'').slice(0,20);
 if(mobile.length<10) return res.status(400).json({error:'Enter a valid mobile number.'});
 const [rows]=await pool.execute('SELECT id,full_name,mobile FROM patients WHERE mobile=? LIMIT 1',[mobile]);
 res.json({exists:rows.length>0,patient:rows[0]||null,verificationRequired:true,message:'Connect an OTP provider before enabling real patient account access.'});
}));
app.post('/api/appointments',rateLimit({windowMs:10*60*1000,limit:20,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 if(process.env.NODE_ENV==='production') return res.status(503).json({error:'Patient OTP verification must be integrated and enforced before public booking is enabled.'});
 const fullName=String(req.body.fullName||'').trim().slice(0,160), mobile=String(req.body.mobile||'').replace(/[^0-9+]/g,'').slice(0,20), departmentId=Number(req.body.departmentId), doctorId=Number(req.body.doctorId), date=String(req.body.date||''), time=String(req.body.time||''), notes=String(req.body.notes||'').trim().slice(0,300);
 if(fullName.length<2 || mobile.length<10 || !departmentId || !doctorId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) return res.status(400).json({error:'Complete all required fields with valid values.'});
 if(date<today()) return res.status(400).json({error:'Choose today or a future date.'});
 const [docs]=await pool.execute('SELECT id,department_id,is_available,capacity_per_slot,schedule_start,schedule_end FROM doctors WHERE id=? AND department_id=?',[doctorId,departmentId]);
 if(!docs.length) return res.status(400).json({error:'Selected doctor does not belong to this department.'});
 const doc=docs[0]; if(!doc.is_available) return res.status(409).json({error:'This doctor is currently unavailable. Please choose another doctor.'});
 if(time+':00'<doc.schedule_start || time+':00'>=doc.schedule_end) return res.status(400).json({error:'Selected time is outside this doctor’s schedule.'});
 const [count]=await pool.execute("SELECT COUNT(*) AS total FROM appointments WHERE doctor_id=? AND appointment_date=? AND appointment_time=? AND status IN ('booked','checked_in','in_consultation')",[doctorId,date,time]);
 if(count[0].total>=doc.capacity_per_slot) return res.status(409).json({error:'This slot is full. Please choose another time.'});
 const conn=await pool.getConnection();
 try { await conn.beginTransaction();
   const [existing]=await conn.execute('SELECT id,full_name FROM patients WHERE mobile=? FOR UPDATE',[mobile]); let patientId;
   if(existing.length){ patientId=existing[0].id; if(existing[0].full_name.toLowerCase()!==fullName.toLowerCase()) { await conn.rollback(); return res.status(409).json({error:'A patient record already exists for this mobile number. Reception must verify identity before changing or merging it.'}); } }
   else { const [p]=await conn.execute('INSERT INTO patients (full_name,mobile) VALUES (?,?)',[fullName,mobile]); patientId=p.insertId; }
   const bookingToken=token('APT'); const [result]=await conn.execute('INSERT INTO appointments (patient_id,department_id,doctor_id,appointment_date,appointment_time,status,token,notes) VALUES (?,?,?,?,?,\'booked\',?,?)',[patientId,departmentId,doctorId,date,time+':00',bookingToken,notes]);
   await conn.commit(); res.status(201).json({ok:true,appointmentId:result.insertId,token:bookingToken,status:'booked',message:'Appointment request saved. In production, verify the mobile number with OTP before exposing patient history.'});
 } catch(e){ await conn.rollback(); if(e.code==='ER_DUP_ENTRY') return res.status(409).json({error:'Duplicate booking detected. Please refresh and check your status.'}); throw e; } finally {conn.release();}
}));
app.post('/api/queue/join',rateLimit({windowMs:10*60*1000,limit:20,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 if(process.env.NODE_ENV==='production') return res.status(503).json({error:'Patient OTP verification must be integrated and enforced before public queue registration is enabled.'});
 const fullName=String(req.body.fullName||'').trim().slice(0,160), mobile=String(req.body.mobile||'').replace(/[^0-9+]/g,'').slice(0,20), departmentId=Number(req.body.departmentId), doctorId=Number(req.body.doctorId);
 if(fullName.length<2||mobile.length<10||!departmentId||!doctorId) return res.status(400).json({error:'Enter your name, mobile number, department, and doctor.'});
 const [docs]=await pool.execute('SELECT id,department_id,is_available FROM doctors WHERE id=? AND department_id=?',[doctorId,departmentId]); if(!docs.length) return res.status(400).json({error:'Choose a doctor in the selected department.'});
 if(!docs[0].is_available) return res.status(409).json({error:'This doctor is unavailable. Choose another doctor or ask reception.'});
 const conn=await pool.getConnection(); try {await conn.beginTransaction(); const [p]=await conn.execute('SELECT id,full_name FROM patients WHERE mobile=? FOR UPDATE',[mobile]); let patientId;
 if(p.length){patientId=p[0].id;if(p[0].full_name.toLowerCase()!==fullName.toLowerCase()){await conn.rollback();return res.status(409).json({error:'A patient record exists for this mobile number. Please contact reception for identity review.'});}}
 else {const [ins]=await conn.execute('INSERT INTO patients(full_name,mobile) VALUES(?,?)',[fullName,mobile]);patientId=ins.insertId;}
 const queueToken=token('Q'); const [q]=await conn.execute('INSERT INTO queue_entries(patient_id,department_id,doctor_id,queue_date,token,queue_type,status) VALUES(?,?,?,CURDATE(),?,\'walk_in\',\'waiting\')',[patientId,departmentId,doctorId,queueToken]); await conn.commit(); res.status(201).json({ok:true,queueId:q.insertId,token:queueToken,status:'waiting',message:'Walk-in queue entry created. Mobile OTP verification must be connected before public production use.'});
 }catch(e){await conn.rollback();throw e;}finally{conn.release();}
}));
app.get('/api/patient/status',rateLimit({windowMs:10*60*1000,limit:20,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 if(process.env.NODE_ENV==='production') return res.status(503).json({error:'OTP-authenticated patient access must be implemented before public status lookup is enabled.'});
 const mobile=String(req.query.mobile||'').replace(/[^0-9+]/g,'').slice(0,20); if(mobile.length<10) return res.status(400).json({error:'Enter a valid mobile number.'});
 const [appointments]=await pool.execute("SELECT a.id,a.token,a.appointment_date,a.appointment_time,a.status,d.full_name AS doctor,dep.name AS department FROM appointments a JOIN doctors d ON d.id=a.doctor_id JOIN departments dep ON dep.id=a.department_id JOIN patients p ON p.id=a.patient_id WHERE p.mobile=? AND a.appointment_date>=CURDATE() ORDER BY a.appointment_date,a.appointment_time LIMIT 10",[mobile]);
 const [queue]=await pool.execute("SELECT q.id,q.token,q.status,q.queue_type,d.full_name AS doctor,dep.name AS department,(SELECT COUNT(*) FROM queue_entries ahead WHERE ahead.department_id=q.department_id AND ahead.queue_date=q.queue_date AND ahead.status IN ('waiting','called','in_consultation') AND (ahead.priority='priority' AND q.priority='normal' OR ahead.joined_at<q.joined_at)) AS ahead,d.avg_minutes FROM queue_entries q JOIN doctors d ON d.id=q.doctor_id JOIN departments dep ON dep.id=q.department_id JOIN patients p ON p.id=q.patient_id WHERE p.mobile=? AND q.queue_date=CURDATE() AND q.status IN ('waiting','called','in_consultation') ORDER BY q.joined_at",[mobile]);
 res.json({appointments,queue:queue.map(q=>({...q,estimatedWaitMinutes:Number(q.ahead)*Number(q.avg_minutes)})),verificationRequired:true});
}));

// Public TV/display endpoint: token numbers and counts only; never returns patient names or phone numbers.
// Include both walk-in queue entries and today's booked appointments, because appointment booking
// creates an appointments row (not a queue_entries row).
app.get('/api/live-queue',rateLimit({windowMs:60*1000,limit:60,standardHeaders:'draft-7',legacyHeaders:false}),asyncRoute(async(req,res)=>{
 const [[queueStats]] = await pool.query(`
   SELECT
     COALESCE(SUM(status='waiting'),0) AS pending,
     COALESCE(SUM(status='called'),0) AS called,
     COALESCE(SUM(status='in_consultation'),0) AS consulting,
     COALESCE(SUM(status='completed'),0) AS completed
   FROM queue_entries
   WHERE queue_date=CURDATE()
 `);
 const [[appointmentStats]] = await pool.query(`
   SELECT
     COALESCE(SUM(status='booked'),0) AS pending,
     COALESCE(SUM(status='checked_in'),0) AS called,
     COALESCE(SUM(status='in_consultation'),0) AS consulting,
     COALESCE(SUM(status='completed'),0) AS completed
   FROM appointments
   WHERE appointment_date=CURDATE()
 `);
 const [current] = await pool.query(`
   SELECT token, status, department, room FROM (
     SELECT q.token, q.status, dep.name AS department, d.room_label AS room,
            COALESCE(q.called_at,q.joined_at) AS activity_time
     FROM queue_entries q
     JOIN departments dep ON dep.id=q.department_id
     JOIN doctors d ON d.id=q.doctor_id
     WHERE q.queue_date=CURDATE() AND q.status IN ('called','in_consultation')
     UNION ALL
     SELECT a.token, a.status, dep.name AS department, d.room_label AS room,
            CONCAT(a.appointment_date,' ',a.appointment_time) AS activity_time
     FROM appointments a
     JOIN departments dep ON dep.id=a.department_id
     JOIN doctors d ON d.id=a.doctor_id
     WHERE a.appointment_date=CURDATE() AND a.status IN ('checked_in','in_consultation')
   ) live_current
   ORDER BY activity_time DESC
   LIMIT 8
 `);
 const [waiting] = await pool.query(`
   SELECT token, department, room, joined_at FROM (
     SELECT q.token, dep.name AS department, d.room_label AS room, q.joined_at,
            (q.priority='priority') AS is_priority
     FROM queue_entries q
     JOIN departments dep ON dep.id=q.department_id
     JOIN doctors d ON d.id=q.doctor_id
     WHERE q.queue_date=CURDATE() AND q.status='waiting'
     UNION ALL
     SELECT a.token, dep.name AS department, d.room_label AS room,
            CONCAT(a.appointment_date,' ',a.appointment_time) AS joined_at, 0 AS is_priority
     FROM appointments a
     JOIN departments dep ON dep.id=a.department_id
     JOIN doctors d ON d.id=a.doctor_id
     WHERE a.appointment_date=CURDATE() AND a.status='booked'
   ) live_waiting
   ORDER BY is_priority DESC, joined_at ASC
   LIMIT 30
 `);
 res.set('Cache-Control','no-store, no-cache, must-revalidate, private');
 res.json({
   hospitalName:process.env.APP_NAME || 'CareFlow Hospital',
   updatedAt:new Date().toISOString(),
   stats:{
     pending:Number(queueStats.pending || 0) + Number(appointmentStats.pending || 0),
     called:Number(queueStats.called || 0) + Number(appointmentStats.called || 0),
     consulting:Number(queueStats.consulting || 0) + Number(appointmentStats.consulting || 0),
     completed:Number(queueStats.completed || 0) + Number(appointmentStats.completed || 0)
   },
   current:current.map(x=>({token:x.token,status:x.status,department:x.department,room:x.room})),
   waiting:waiting.map(x=>({token:x.token,department:x.department,room:x.room,joinedAt:x.joined_at}))
 });
}));
app.get('/live',(req,res)=>res.sendFile(path.join(__dirname,'public','live.html')));

app.get('/api/admin/summary',roles('admin','reception','doctor'),asyncRoute(async(req,res)=>{
 const doctorMode=req.session.staff.role==='doctor'; const doctorId=req.session.staff.doctorId;
 if(doctorMode && !doctorId) return res.status(403).json({error:'This staff account is not linked to a doctor profile.'});
 const [appointmentStats]=await pool.execute(`SELECT COUNT(*) AS total FROM appointments WHERE appointment_date=CURDATE() AND status<>'cancelled' ${doctorMode?'AND doctor_id=?':''}`,doctorMode?[doctorId]:[]);
 const [waitingStats]=await pool.execute(`SELECT COUNT(*) AS total FROM queue_entries WHERE queue_date=CURDATE() AND status='waiting' ${doctorMode?'AND doctor_id=?':''}`,doctorMode?[doctorId]:[]);
 const [servingStats]=await pool.execute(`SELECT COUNT(*) AS total FROM queue_entries WHERE queue_date=CURDATE() AND status IN ('called','in_consultation') ${doctorMode?'AND doctor_id=?':''}`,doctorMode?[doctorId]:[]);
 const [doctorStats]=await pool.execute(`SELECT COUNT(*) AS total FROM doctors WHERE is_available=1 ${doctorMode?'AND id=?':''}`,doctorMode?[doctorId]:[]);
 const [patientStats]=await pool.execute(`SELECT COUNT(DISTINCT patient_id) AS total FROM queue_entries WHERE queue_date=CURDATE() ${doctorMode?'AND doctor_id=?':''}`,doctorMode?[doctorId]:[]);
 const [queue]=await pool.execute(`SELECT q.id,q.token,q.status,q.queue_type,q.priority,q.joined_at,p.full_name,d.full_name doctor,dep.name department,d.avg_minutes FROM queue_entries q JOIN patients p ON p.id=q.patient_id JOIN doctors d ON d.id=q.doctor_id JOIN departments dep ON dep.id=q.department_id WHERE q.queue_date=CURDATE() AND q.status IN ('waiting','called','in_consultation','skipped') ${doctorMode?'AND q.doctor_id=?':''} ORDER BY (q.priority='priority') DESC,q.joined_at ASC LIMIT 100`,doctorMode?[doctorId]:[]);
 const [appointmentsList]=await pool.execute(`SELECT a.id,a.token,a.appointment_date,a.appointment_time,a.status,p.full_name,d.full_name doctor,dep.name department FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id JOIN departments dep ON dep.id=a.department_id WHERE a.appointment_date>=CURDATE() AND a.status IN ('booked','checked_in','in_consultation','reschedule_required') ${doctorMode?'AND a.doctor_id=?':''} ORDER BY a.appointment_date,a.appointment_time LIMIT 50`,doctorMode?[doctorId]:[]);
 res.json({stats:{appointments:appointmentStats[0].total,waiting:waitingStats[0].total,serving:servingStats[0].total,doctors:doctorStats[0].total,patients:patientStats[0].total},queue,appointments:appointmentsList});
}));
// Staff workflow for appointment tokens: booked -> checked_in (called) -> in_consultation -> completed.
app.post('/api/admin/appointments/:id/call',roles('admin','reception','doctor'),asyncRoute(async(req,res)=>{
 const id=Number(req.params.id), doctorMode=req.session.staff.role==='doctor', doctorId=req.session.staff.doctorId;
 if(doctorMode && !doctorId) return res.status(403).json({error:'This staff account is not linked to a doctor profile.'});
 const [result]=await pool.execute(
   `UPDATE appointments SET status='checked_in' WHERE id=? AND status='booked' ${doctorMode?'AND doctor_id=?':''}`,
   doctorMode?[id,doctorId]:[id]
 );
 if(!result.affectedRows)return res.status(409).json({error:'Appointment is not available to call or was already updated.'});
 await audit(req,'appointment.call','appointment',id);res.json({ok:true});
}));
app.post('/api/admin/appointments/:id/start',roles('admin','doctor'),asyncRoute(async(req,res)=>{
 const id=Number(req.params.id), doctorMode=req.session.staff.role==='doctor', doctorId=req.session.staff.doctorId;
 if(doctorMode && !doctorId) return res.status(403).json({error:'This staff account is not linked to a doctor profile.'});
 const [result]=await pool.execute(
   `UPDATE appointments SET status='in_consultation' WHERE id=? AND status='checked_in' ${doctorMode?'AND doctor_id=?':''}`,
   doctorMode?[id,doctorId]:[id]
 );
 if(!result.affectedRows)return res.status(409).json({error:'Call/check in the appointment before starting consultation.'});
 await audit(req,'appointment.consultation.start','appointment',id);res.json({ok:true});
}));
app.post('/api/admin/appointments/:id/complete',roles('admin','doctor'),asyncRoute(async(req,res)=>{
 const id=Number(req.params.id), doctorMode=req.session.staff.role==='doctor', doctorId=req.session.staff.doctorId;
 if(doctorMode && !doctorId) return res.status(403).json({error:'This staff account is not linked to a doctor profile.'});
 const [result]=await pool.execute(
   `UPDATE appointments SET status='completed' WHERE id=? AND status IN ('checked_in','in_consultation') ${doctorMode?'AND doctor_id=?':''}`,
   doctorMode?[id,doctorId]:[id]
 );
 if(!result.affectedRows)return res.status(409).json({error:'Only called or consulting appointments can be completed.'});
 await audit(req,'appointment.complete','appointment',id);res.json({ok:true});
}));
app.post('/api/admin/queue/:id/call',roles('admin','reception','doctor'),asyncRoute(async(req,res)=>{const id=Number(req.params.id);const [result]=await pool.execute("UPDATE queue_entries SET status='called',called_at=NOW() WHERE id=? AND status IN ('waiting','skipped')",[id]);if(!result.affectedRows)return res.status(409).json({error:'Queue entry is no longer waiting.'});await audit(req,'queue.call','queue_entry',id);res.json({ok:true});}));
app.post('/api/admin/queue/:id/start',roles('admin','doctor'),asyncRoute(async(req,res)=>{const id=Number(req.params.id);const [result]=await pool.execute("UPDATE queue_entries SET status='in_consultation',started_at=NOW() WHERE id=? AND status='called'",[id]);if(!result.affectedRows)return res.status(409).json({error:'Call the token before starting consultation.'});await audit(req,'consultation.start','queue_entry',id);res.json({ok:true});}));
app.post('/api/admin/queue/:id/complete',roles('admin','doctor'),asyncRoute(async(req,res)=>{const id=Number(req.params.id);const [result]=await pool.execute("UPDATE queue_entries SET status='completed',completed_at=NOW() WHERE id=? AND status IN ('called','in_consultation')",[id]);if(!result.affectedRows)return res.status(409).json({error:'Only called or consulting entries can be completed.'});await audit(req,'queue.complete','queue_entry',id);res.json({ok:true});}));
app.post('/api/admin/queue/:id/skip',roles('admin','reception','doctor'),asyncRoute(async(req,res)=>{const id=Number(req.params.id);const [result]=await pool.execute("UPDATE queue_entries SET status='skipped' WHERE id=? AND status IN ('waiting','called')",[id]);if(!result.affectedRows)return res.status(409).json({error:'Queue entry cannot be skipped in its current state.'});await audit(req,'queue.skip','queue_entry',id);res.json({ok:true});}));
app.post('/api/admin/doctors/:id/availability',roles('admin','reception'),asyncRoute(async(req,res)=>{
 const id=Number(req.params.id), available=Boolean(req.body.available); const conn=await pool.getConnection(); try {await conn.beginTransaction(); const [docs]=await conn.execute('SELECT id,department_id,full_name FROM doctors WHERE id=? FOR UPDATE',[id]); if(!docs.length){await conn.rollback();return res.status(404).json({error:'Doctor not found.'});}
 await conn.execute('UPDATE doctors SET is_available=? WHERE id=?',[available,id]); let moved=0;
 if(!available){const [affected]=await conn.execute("SELECT id,patient_id,department_id,appointment_date,appointment_time FROM appointments WHERE doctor_id=? AND appointment_date>=CURDATE() AND status='booked' ORDER BY appointment_date,appointment_time",[id]);
 for(const appt of affected){const [replacement]=await conn.execute("SELECT d.id FROM doctors d WHERE d.department_id=? AND d.id<>? AND d.is_available=1 AND d.schedule_start<=? AND d.schedule_end>? AND (SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=d.id AND a.appointment_date=? AND a.appointment_time=? AND a.status IN ('booked','checked_in','in_consultation'))<d.capacity_per_slot ORDER BY (SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=d.id AND a.appointment_date=? AND a.status IN ('booked','checked_in','in_consultation')),d.id LIMIT 1",[appt.department_id,id,appt.appointment_time,appt.appointment_time,appt.appointment_date,appt.appointment_time,appt.appointment_date]);
 if(replacement.length){await conn.execute('UPDATE appointments SET doctor_id=? WHERE id=?',[replacement[0].id,appt.id]); moved++;}else await conn.execute("UPDATE appointments SET status='reschedule_required' WHERE id=?",[appt.id]);
 }
 const [waiting]=await conn.execute("SELECT id,department_id FROM queue_entries WHERE doctor_id=? AND queue_date=CURDATE() AND status='waiting'",[id]); for(const q of waiting){const [rep]=await conn.execute("SELECT d.id FROM doctors d WHERE d.department_id=? AND d.id<>? AND d.is_available=1 ORDER BY (SELECT COUNT(*) FROM queue_entries qe WHERE qe.doctor_id=d.id AND qe.queue_date=CURDATE() AND qe.status IN ('waiting','called','in_consultation')),d.id LIMIT 1",[q.department_id,id]);if(rep.length){await conn.execute('UPDATE queue_entries SET doctor_id=? WHERE id=?',[rep[0].id,q.id]);moved++;}}
 }
 await conn.commit(); await audit(req,'doctor.availability.update','doctor',id,{available,moved});res.json({ok:true,available,reassigned:moved});
 }catch(e){await conn.rollback();throw e;}finally{conn.release();}
}));
app.get('/api/admin/audit',roles('admin'),asyncRoute(async(req,res)=>{const [rows]=await pool.query('SELECT a.id,a.action,a.entity_type,a.entity_id,a.details,a.created_at,u.full_name staff FROM audit_logs a LEFT JOIN staff_users u ON u.id=a.staff_id ORDER BY a.created_at DESC LIMIT 100');res.json(rows);}));
app.get('/api/admin/qr',(req,res)=>{ if(!req.session.staff || !['admin','reception'].includes(req.session.staff.role)) return res.status(403).json({error:'Admin or reception access required.'}); res.json({url:`${req.protocol}://${req.get('host')}/`,note:'Print this URL as the hospital-wide QR target. Use an approved QR generator or offline QR library for production.'}); });
app.use((req,res,next)=>{if(req.path.startsWith('/api/')) return res.status(404).json({error:'API route not found.'});res.sendFile(path.join(__dirname,'public','index.html'));});
app.use((err,req,res,next)=>{console.error(err);if(res.headersSent)return next(err);res.status(500).json({error:process.env.NODE_ENV==='production'?'Unexpected server error. Please retry.':err.message});});

(async()=>{try{await pool.query('SELECT 1'); await seedAdmin(); app.listen(PORT,()=>console.log(`Smart Hospital running at http://localhost:${PORT}`));}catch(e){console.error('Startup failed. Check database configuration and import sql/schema.sql first.');console.error(e.message);process.exit(1);}})();
